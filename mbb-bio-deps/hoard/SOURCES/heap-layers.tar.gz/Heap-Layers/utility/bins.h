#ifndef HL_BINS_H
#define HL_BINS_H

namespace HL {
  
  template <class Header, int Size>
    class bins;
  
}


#endif
