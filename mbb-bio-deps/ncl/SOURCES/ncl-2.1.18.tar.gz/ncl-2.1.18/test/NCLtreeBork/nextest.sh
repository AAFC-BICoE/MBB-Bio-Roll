#!/bin/bash

VAL=/Users/zwickl/Desktop/GarliDEV/ncl/ncl-2.1/builds/gccNoDynamic/installed/bin/NEXUSvalidator  
echo "########################################"
echo OK1
$VAL ok1.tre
echo "########################################"
echo OK2
$VAL ok2.tre
echo "########################################"
echo BORK
$VAL choke.tre
echo "########################################"
