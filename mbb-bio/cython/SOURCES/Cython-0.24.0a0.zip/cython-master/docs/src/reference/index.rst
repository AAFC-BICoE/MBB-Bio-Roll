Reference Guide
===============

.. note::
    .. todo::
        Most of the **boldface** is to be changed to refs or other markup later.

Contents:

.. toctree::
   :maxdepth: 2

   compilation
   language_basics
   extension_types
   interfacing_with_other_code
   special_mention
   limitations
   directives

Indices and tables
------------------

.. toctree::
    :maxdepth: 2

    special_methods_table

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
