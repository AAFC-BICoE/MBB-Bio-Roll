#ifndef __FRAMESHIFTS_H
#define __FRAMESHIFTS_H

void frameshiftScan(Array regions, int frameshiftThreshold);

#endif /* __FRAMEASHIFTS_H */
