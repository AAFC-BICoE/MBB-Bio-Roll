package org.gmod.schema.utils.propinterface;

import org.gmod.schema.cv.CvTerm;

/**
 * 
 * @author cp2
 */
public interface PropertyI {

	public abstract CvTerm getCvTerm();

}
