/**
 * BCL to FASTQ file converter
 * Copyright (c) 2007-2015 Illumina, Inc.
 *
 * This software is covered by the accompanying EULA
 * and certain third party copyright/licenses, and any user of this
 * source file is bound by the terms therein.
 *
 * \file FastqCreator.cpp
 *
 * \brief Implementation of FASTQ creator.
 *
 * \author Marek Balint
 * \author Mauricio Varea
 */


#include <string>
#include <algorithm>
#include <iterator>
#include <utility>

#include <boost/format.hpp>
#include <boost/bind.hpp>
#include <boost/foreach.hpp>
#include <boost/assign/list_of.hpp>

#include "common/FastIo.hh"
#include "layout/BarcodeTranslationTable.hh"
#include "io/GzipCompressor.hh"

#include "conversion/BclBaseConversion.hh"
#include "conversion/FastqCreator.hh"

namespace bcl2fastq
{
namespace conversion
{

namespace detail
{


/// \brief Number of FASQs per task.
/// \todo Refactoring: Put this into CMake configuration.
static const SampleIndex::FastqOffsetsContainer::size_type fastqsPerTask = 16384;


} // namespace detail

FastqCreateTask::FastqCreateTask(
    const BclBuffer &bclBuffer,
    BclBuffer::BclsContainer::const_iterator cyclesBegin,
    BclBuffer::BclsContainer::const_iterator cyclesEnd,
    const layout::FlowcellInfo &flowcellInfo,
    const layout::LaneInfo &laneInfo,
    layout::ReadInfosContainer::const_iterator currentReadInfo,
    SampleIndex::FastqOffsetsContainer::const_iterator offsetsBegin,
    SampleIndex::FastqOffsetsContainer::const_iterator offsetsEnd,
    std::size_t maskShortAdapterReads,
    float adapterStringency,
    const boost::ptr_vector<AdapterLocator>& maskAdapters,
    const boost::ptr_vector<AdapterLocator>& trimAdapters,
    bool generateReverseComplementFastqs,
    bool includeNonPfClusters,
    const layout::Layout &layout,
    bool useBgzf,
    int compressionLevel,
    bool findAdaptersWithSlidingWindow,
    std::vector< FastqCreateTask::ConversionStats > &tileStats,
    std::vector<stats::BarcodeHits> &unknownBarcodes,
    FastqBuffer::FastqsContainer::value_type::value_type::value_type &outputBuffer
)
: Task()
, bclBuffer_(bclBuffer)
, cyclesBegin_(cyclesBegin)
, cyclesEnd_(cyclesEnd)
, flowcellInfo_(flowcellInfo)
, laneInfo_(laneInfo)
, readInfo_(*currentReadInfo)
, sampleMetadata_(bclBuffer_.samples_.at(*offsetsBegin).first)
, offsetsBegin_(offsetsBegin)
, offsetsEnd_(offsetsEnd)
, outputBuffer_(outputBuffer)
, buffer_()
, useBgzf_(useBgzf)
, compressionLevel_(compressionLevel)
, findAdaptersWithSlidingWindow_(findAdaptersWithSlidingWindow)
, minimumTrimmedReadLength_(laneInfo_.getMinimumTrimmedReadLength())
, maskShortAdapterReads_(maskShortAdapterReads)
, adapterStringency_(adapterStringency)
, maskAdapters_(maskAdapters)
, trimAdapters_(trimAdapters)
, generateReverseComplementFastqs_(generateReverseComplementFastqs)
, includeNonPfClusters_(includeNonPfClusters)
, tileStats_(tileStats)
, unknownBarcodes_(unknownBarcodes)
, umiCycles_()
{
    BclBuffer::BclsContainer::const_iterator cycle = bclBuffer_.bcls_.begin();
    BOOST_FOREACH (const layout::ReadInfo &readInfo, std::make_pair(laneInfo_.readInfosBegin(), laneInfo_.readInfosEnd()))
    {
        BclBuffer::BclsContainer::const_iterator nextCycle = cycle + (readInfo.cycleInfosEnd() - readInfo.cycleInfosBegin());
        if (readInfo.isUmiRead())
        {
            umiCycles_.push_back(std::make_pair(cycle, nextCycle));
        }
        cycle = nextCycle;
    }
}

bool FastqCreateTask::execute(common::ThreadVector::size_type threadNum)
{
    io::GzipCompressor compressor(outputBuffer_,
                                  useBgzf_,
                                  boost::iostreams::gzip_params(compressionLevel_, // config param with default=4
                                                                boost::iostreams::zlib::deflated, // default
                                                                15, // default
                                                                9));
//    compressor.write(&*buffer_.begin(), 0);

    std::for_each(
        offsetsBegin_,
        offsetsEnd_,
        boost::bind(
            &FastqCreateTask::fastqCreate,
            this,
            threadNum,
            _1,
            boost::ref(compressor)
        )
    );

    return true;
}


namespace detail {


static const char fastqHeaderStart = '@';
static const char fastqHeaderSeparator = '\n';
static const char fastqHeaderValuesSeparator = ':';
static const char fastqHeaderPositionsSeparator = ' ';
static const char fastqHeaderUmiSeparator = '+';
static const std::string fastqBasesSeparator("\n+\n");
static const char fastqQualitiesSeparator('\n');
static const char fastqMaskedBase('N');
static const char fastqMaskedQuality('#');


template< typename StatsType >
static typename std::vector<StatsType>::iterator findStats( std::vector<StatsType> &stats, StatsType init )
{
    typedef typename std::vector<StatsType>::iterator ReturnType;
    const std::pair< ReturnType, ReturnType > statsRecord = std::equal_range( stats.begin(), stats.end(), init );
    BCL2FASTQ_ASSERT_MSG(statsRecord.first != statsRecord.second,
                        "Conversion statistics record for sample #" << init.index.first.sampleIndex_
                        << ", barcode #" << init.index.first.barcodeIndex_
                        << ", tile #" << init.index.second << " not found");
    return statsRecord.first;
}

template< typename StatsType >
static void transferStats( std::vector< typename StatsType::value_type > &stats,
                           std::vector< typename StatsType::value_type > &summary )
{
    typename StatsType::size_type conversionIndex = 0;
    BOOST_FOREACH( typename StatsType::value_type &tileStats, std::make_pair(stats.begin(), stats.end()) )
    {
        typename StatsType::value_type &summaryTileStats = summary.at(conversionIndex);
        BCL2FASTQ_ASSERT_MSG(!(tileStats < summaryTileStats), "Inconsistent conversion statistics structures");
        BCL2FASTQ_ASSERT_MSG(!(summaryTileStats < tileStats), "Inconsistent conversion statistics structures");
        summaryTileStats += tileStats;
        tileStats.reset();
        ++conversionIndex;
    }
}


} // namespace detail


bool FastqCreateTask::computeStatistics( common::ThreadVector::size_type threadNum,
                                         FastqConstIterator basesBegin,
                                         FastqConstIterator basesEnd,
                                         bool filterFlag,
                                         size_t trimmedCount )
{
    layout::LaneInfo::TileInfosContainer::size_type tileIndex =  std::distance( laneInfo_.tileInfosBegin(),
                                                                                bclBuffer_.tileInfo_ );
    ConversionStats::first_type::iterator allReads = detail::findStats(
        tileStats_.at(threadNum).first,
        stats::TileBarcodeStats( stats::TileStats<stats::AllReadsStats>::Index( sampleMetadata_, tileIndex ))
    );
    ConversionStats::second_type::iterator perRead = detail::findStats(
        tileStats_.at(threadNum).second,
        stats::ReadBarcodeStats( stats::TileStats<stats::ReadStats>::Index( sampleMetadata_, tileIndex )
                               , readInfo_.getNumber() )
    );
    stats::ReadStats readStats;
    readStats.yield = std::distance(basesBegin, basesEnd);
    readStats.yieldQ30 = std::count_if(basesBegin, basesEnd,boost::bind(&compareBcl2FastqQuality,_1,30));
    readStats.qualityScoreSum = std::accumulate(
                                     basesBegin,
                                     basesEnd,
                                     common::ClustersCount(0),
                                     boost::bind(
                                         std::plus<common::ClustersCount>(),
                                         _1,
                                         boost::bind(&convertBcl2FastqRawQuality, _2)
                                     )
                                );
    if( 1 == readInfo_.getNumber() )  { (*allReads)[stats::TileBarcodeStats::RAW].clusterCount += 1; }
    (*allReads)[stats::TileBarcodeStats::RAW].RecordAdapterStats(trimmedCount, readInfo_.getNumber());
    (*perRead)[stats::TileBarcodeStats::RAW] += readStats;
    if( filterFlag )
    {
        if( 1 == readInfo_.getNumber() )  { (*allReads)[stats::TileBarcodeStats::PF].clusterCount += 1; }
        (*allReads)[stats::TileBarcodeStats::PF].RecordAdapterStats(trimmedCount, readInfo_.getNumber());
        (*perRead)[stats::TileBarcodeStats::PF] += readStats;
    }
    return (0 != sampleMetadata_.sampleIndex_);
}


void FastqCreateTask::fastqCreate(
    common::ThreadVector::size_type threadNum,
    SampleIndex::FastqOffsetsContainer::value_type offset,
    io::GzipCompressor& compressor
)
{
    const FastqConstIterator begin(cyclesBegin_, offset);
    const FastqConstIterator end(cyclesEnd_, offset);

    const bool filterFlag = bclBuffer_.filters_.at(offset).data_;

    size_t trimmedCount = 0;
    if (includeNonPfClusters_ || filterFlag)
    {
        buffer_.clear();

        createHeader(offset,
                     filterFlag);

        createBasesAndQualities(offset,
                                compressor,
                                trimmedCount);
    }

    if (readInfo_.isDataRead())
    {
        if (!computeStatistics(threadNum, begin, end, filterFlag, trimmedCount))
        {
            if( 1 == readInfo_.getNumber() && (includeNonPfClusters_ || filterFlag) )  { unknownBarcodes_.at(threadNum).record( bclBuffer_.samples_.at(offset).second ); }
        }
    }
}

void FastqCreateTask::writeHeaderElement(const std::string& element)
{
    size_t bufferSize = buffer_.size();
    buffer_.resize(bufferSize + element.size() + 1);
    std::copy(element.begin(), element.end(), buffer_.begin() + bufferSize);
    buffer_.back() = detail::fastqHeaderValuesSeparator;
}

void FastqCreateTask::createHeader(SampleIndex::FastqOffsetsContainer::value_type offset,
                                   bool                                           filterFlag)
{
    const common::ControlFlag controlFlag = bclBuffer_.controls_.at(offset).data_;

    // HEADER
    buffer_.push_back(detail::fastqHeaderStart);
    // instrument
    writeHeaderElement(flowcellInfo_.getInstrument());
    // run number
    writeHeaderElement(flowcellInfo_.getRunNumber());
    // flow cell ID
    writeHeaderElement(flowcellInfo_.getFlowcellId());
    // lane number
    BOOST_ASSERT(laneInfo_.getNumber() <= 8);
    buffer_.push_back(char(laneInfo_.getNumber() + '0'));
    buffer_.push_back(detail::fastqHeaderValuesSeparator);
    // tile number
    common::putUnsignedInteger(bclBuffer_.tileInfo_->getNumber(), buffer_);
    buffer_.push_back(detail::fastqHeaderValuesSeparator);
    // x position
    common::putUnsignedInteger( bclBuffer_.positions_.size() > offset
                              ? bclBuffer_.positions_[offset].x_
                              : 0, buffer_ );
    buffer_.push_back(detail::fastqHeaderValuesSeparator);
    // y position
    common::putUnsignedInteger( bclBuffer_.positions_.size() > offset
                              ? bclBuffer_.positions_[offset].y_
                              : 0, buffer_ );
    // UMI
    if (!umiCycles_.empty())
    {
        buffer_.push_back(detail::fastqHeaderValuesSeparator);
        size_t i = 0;
        for (const auto& cycle : umiCycles_)
        {
            if (i > 0)
            {
                buffer_.push_back(detail::fastqHeaderUmiSeparator);
            }
            std::transform(
                FastqConstIterator(cycle.first, offset),
                FastqConstIterator(cycle.second, offset),
                std::back_inserter(buffer_),
                &convertBcl2FastqBase
            );
            ++i;
        }
    }
    buffer_.push_back(detail::fastqHeaderPositionsSeparator);

    // read number
    BOOST_ASSERT(readInfo_.getNumber() <= 9);
    buffer_.push_back(char(readInfo_.getNumber() + '0'));
    buffer_.push_back(detail::fastqHeaderValuesSeparator);
    // is-filtered
    buffer_.push_back(filterFlag ? 'N' : 'Y');
    buffer_.push_back(detail::fastqHeaderValuesSeparator);
    // control number
    common::putUnsignedInteger(controlFlag, buffer_);
    buffer_.push_back(detail::fastqHeaderValuesSeparator);
    // barcode
    if (bclBuffer_.samples_.at(offset).second.componentsBegin() == bclBuffer_.samples_.at(offset).second.componentsEnd())
    {
        common::putUnsignedInteger((laneInfo_.sampleInfosBegin()+sampleMetadata_.sampleIndex_)->getNumber(), buffer_);
    }
    else
    {
        bclBuffer_.samples_.at(offset).second.output(buffer_);
    }

    buffer_.push_back(detail::fastqHeaderSeparator);
}

void FastqCreateTask::createBasesAndQualities(SampleIndex::FastqOffsetsContainer::value_type offset,
                                              io::GzipCompressor& compressor,
                                              size_t& trimmedCount)
{
    const FastqConstIterator begin(cyclesBegin_, offset);
    const FastqConstIterator end(cyclesEnd_, offset);

    // BASES
    FastqConstIterator maskBegin = end;
    BOOST_FOREACH(const AdapterLocator& adapterLocator, std::make_pair(maskAdapters_.begin(), maskAdapters_.end()))
    {
        const FastqConstIterator adapterPos = adapterLocator.identifyAdapter(begin, end);
        maskBegin = std::min(maskBegin, adapterPos);
    }

    FastqConstIterator trimBegin = end;
    BOOST_FOREACH(const AdapterLocator& adapterLocator, std::make_pair(trimAdapters_.begin(), trimAdapters_.end()))
    {
        const FastqConstIterator adapterPos = adapterLocator.identifyAdapter(begin, end);
        trimBegin = std::min(trimBegin, adapterPos);
    }

    trimmedCount = end - std::min(trimBegin, maskBegin);
    if (readInfo_.isDataRead())
    {
        if ((trimBegin - begin) < FastqConstIterator::difference_type(minimumTrimmedReadLength_))
        {
            maskBegin = std::min(trimBegin, maskBegin);
            trimBegin = begin + minimumTrimmedReadLength_;
        }

        if ((maskBegin - begin) < FastqConstIterator::difference_type(maskShortAdapterReads_))
        {
            maskBegin = begin;
        }
    }

    const FastqConstIterator::difference_type maskedCount = trimBegin - maskBegin;
    FastqConstIterator basesEnd = std::min(maskBegin, trimBegin);
    size_t bufferSize = buffer_.size();

    size_t numBases = std::distance(begin, basesEnd);
    size_t numBasesPlusMask = numBases;
    if (maskedCount > 0)
    {
        numBasesPlusMask += maskedCount;
    }

    // Resize for bases + BasesSeparator + quality + QualitySeparator
    buffer_.resize(bufferSize + 2*numBasesPlusMask + 1 + detail::fastqBasesSeparator.size());
    std::vector<char>::iterator iter(buffer_.begin());
    std::advance(iter, bufferSize);
    if (generateReverseComplementFastqs_)
    {
        if (maskedCount > 0)
        {
            std::fill_n(iter, maskedCount, detail::fastqMaskedBase);
            std::advance(iter, maskedCount);
        }

        std::transform(
            FastqConstReverseIterator(basesEnd),
            FastqConstReverseIterator(begin),
            iter,
            &convertBcl2FastqBaseComplement
        );

        std::advance(iter, numBases);
    }
    else
    {
        std::transform(
            begin,
            basesEnd,
            iter,
            &convertBcl2FastqBase
        );

        std::advance(iter, numBases);
        if (maskedCount > 0)
        {
            std::fill_n(iter, maskedCount, detail::fastqMaskedBase);
            std::advance(iter, maskedCount);
        }
    }

    std::copy(detail::fastqBasesSeparator.begin(), detail::fastqBasesSeparator.end(), iter);
    std::advance(iter, detail::fastqBasesSeparator.size());

    // QUALITIES
    if (generateReverseComplementFastqs_)
    {
        if (maskedCount > 0)
        {
            std::fill_n(iter, maskedCount, detail::fastqMaskedQuality);
            std::advance(iter, maskedCount);
        }

        std::transform(FastqConstReverseIterator(basesEnd), FastqConstReverseIterator(begin), iter, &convertBcl2FastqQuality);
        std::advance(iter, numBases);
    }
    else
    {
        std::transform(begin, basesEnd, iter, &convertBcl2FastqQuality);

        std::advance(iter, numBases);
        if (maskedCount > 0)
        {
            std::fill_n(iter, maskedCount, detail::fastqMaskedQuality);
            std::advance(iter, maskedCount);
        }
    }
    *iter = detail::fastqQualitiesSeparator;

    std::streamsize bytesWritten = compressor.write(&*buffer_.begin(), buffer_.size());
    BCL2FASTQ_ASSERT_MSG( static_cast<FastqBuffer::FastqsContainer::value_type::value_type::value_type::size_type>(bytesWritten) == buffer_.size(),
                          "Only " << bytesWritten << " of " << buffer_.size() << " bytes have been written" );
}

FastqCreator::FastqCreator(
    common::ThreadVector::size_type threadsCount,
    StageMediator<InputBuffer> &inputMediator,
    StageMediator<OutputBuffer> &outputMediator,
    const layout::Layout &layout,
    const layout::LaneInfo &laneInfo,
    std::size_t maskShortAdapterReads,
    float adapterStringency,
    bool generateReverseComplementFastqs,
    bool includeNonPfClusters,
    bool createFastqsForIndexReads,
    bool useBgzf,
    int compressionLevel,
    bool findAdaptersWithSlidingWindow,
    FastqCreateTask::ConversionStats &summaryTileStats,
    stats::BarcodeHits &unknownBarcodeHits
)
: IntermediateStage<BclBuffer, FastqBuffer>(threadsCount, "Fastq creating", inputMediator, outputMediator)
, layout_(layout)
, laneInfo_(laneInfo)
, threadsCount_(threadsCount)
, sampleIndex_(laneInfo.sampleInfosEnd()-laneInfo.sampleInfosBegin(), BclBuffer::clustersPerChunk_)
, maskShortAdapterReads_(maskShortAdapterReads)
, adapterStringency_(adapterStringency)
, generateReverseComplementFastqs_(generateReverseComplementFastqs)
, includeNonPfClusters_(includeNonPfClusters)
, createFastqsForIndexReads_(createFastqsForIndexReads)
, useBgzf_(useBgzf)
, compressionLevel_(compressionLevel)
, findAdaptersWithSlidingWindow_(findAdaptersWithSlidingWindow)
, summaryTileStats_(summaryTileStats)
, tileStats_()
, unknownBarcodesHits_(unknownBarcodeHits)
, unknownBarcodes_()
{
    size_t nonIndexReadLength = 0;
    size_t numNonIndexReads = 0;
    BOOST_FOREACH (const layout::ReadInfo &readInfo, std::make_pair(laneInfo_.readInfosBegin(), laneInfo_.readInfosEnd()))
    {
        if (readInfo.isDataRead())
        {
            nonIndexReadLength = std::max(nonIndexReadLength, readInfo.getCyclesCount());
            numNonIndexReads = std::max(numNonIndexReads, readInfo.getNumber());
        }
    }

    layout::LaneInfo::SampleInfosContainer::size_type sampleIndex = 0;
    BOOST_FOREACH (const layout::SampleInfo &sampleInfo, std::make_pair(laneInfo_.sampleInfosBegin(), laneInfo_.sampleInfosEnd()))
    {
        layout::SampleInfo::BarcodesContainer::size_type barcodesCount = sampleInfo.getBarcodes().size();
        if( 0 == barcodesCount )
        {
            createTileStats( layout::BarcodeTranslationTable::SampleMetadata(sampleIndex),
                             nonIndexReadLength,
                             numNonIndexReads );
        } else {
            for( layout::SampleInfo::BarcodesContainer::size_type barcodeIndex = 0;
                 barcodeIndex < barcodesCount;
                 ++barcodeIndex )
            {
                createTileStats( layout::BarcodeTranslationTable::SampleMetadata(sampleIndex,barcodeIndex),
                                 nonIndexReadLength,
                                 numNonIndexReads );
            }
        }
        ++sampleIndex;
    }

    for (common::ThreadVector::size_type threadNum = 0; threadNum < threadsCount_; ++threadNum)
    {
        tileStats_.push_back(summaryTileStats_);
        unknownBarcodes_.push_back(unknownBarcodesHits_);
    }

}


void FastqCreator::createTileStats(const layout::BarcodeTranslationTable::SampleMetadata &sampleMetadata,
                                   size_t nonIndexReadLength,
                                   size_t numNonIndexReads)
{
    layout::LaneInfo::TileInfosContainer::size_type tilesCount = laneInfo_.tileInfosEnd() - laneInfo_.tileInfosBegin();
    for( layout::LaneInfo::TileInfosContainer::size_type tileIndex = 0;
         tileIndex < tilesCount;
         ++tileIndex )
    {
        summaryTileStats_.first.push_back(
                          FastqCreateTask::ConversionStats::first_type::value_type(
                                           stats::TileStats<stats::AllReadsStats>::Index(sampleMetadata, tileIndex)
                          )
        );
        summaryTileStats_.first.back()[stats::TileBarcodeStats::RAW].init(nonIndexReadLength, numNonIndexReads);
        summaryTileStats_.first.back()[stats::TileBarcodeStats::PF].init(nonIndexReadLength, numNonIndexReads);

        BOOST_FOREACH(const layout::ReadInfo& readInfo, std::make_pair(laneInfo_.readInfosBegin(), laneInfo_.readInfosEnd()))
        {
            if (readInfo.isDataRead())
            {
                summaryTileStats_.second.push_back(
                                  FastqCreateTask::ConversionStats::second_type::value_type(
                                                   stats::TileStats<stats::ReadStats>::Index(sampleMetadata, tileIndex),
                                                   readInfo.getNumber()
                                  )
                );
            }
        }
    }
}

bool FastqCreator::preExecute()
{
    TaskQueue &taskQueue = this->getTaskQueue();
    BclBuffer &inputBuffer = this->getInputBuffer();
    FastqBuffer &outputBuffer = this->getOutputBuffer();

    BCL2FASTQ_ASSERT_MSG(inputBuffer.bcls_.size() > 0, "No BCL cycles to process");
    const BclBuffer::BclsContainer::size_type dataSize = inputBuffer.bcls_.front().size();
    BCL2FASTQ_LOG(common::LogLevel::DEBUG) << "Clusters/BCL: " << dataSize << std::endl;

    sampleIndex_.reset(dataSize);
    // find out how many reads in each sample
    for (BclBuffer::BclsContainer::size_type offset = 0; offset < dataSize; ++offset)
    {
        sampleIndex_.incrementFastqCount(inputBuffer.samples_.at(offset).first.sampleIndex_);
    }
    sampleIndex_.reserve();
    // initialize offsets
    for (BclBuffer::BclsContainer::size_type offset = 0; offset < dataSize; ++offset)
    {
        sampleIndex_.addOffset(inputBuffer.samples_.at(offset).first.sampleIndex_, offset);
    }

    sampleIndex_.finalize();

    {
        const layout::LaneInfo::SampleInfosContainer::const_iterator sampleInfosBegin = laneInfo_.sampleInfosBegin();
        const layout::LaneInfo::SampleInfosContainer::const_iterator sampleInfosEnd = laneInfo_.sampleInfosEnd();
        layout::LaneInfo::SampleInfosContainer::size_type sampleInfosCounts = sampleInfosEnd - sampleInfosBegin;
        outputBuffer.fastqs_.resize(sampleInfosCounts);
        const layout::ReadInfosContainer::const_iterator readInfosBegin = laneInfo_.readInfosBegin();
        const layout::ReadInfosContainer::const_iterator readInfosEnd = laneInfo_.readInfosEnd();
        layout::ReadInfosContainer::size_type readsCount = std::count_if(readInfosBegin,
                                                                         readInfosEnd,
                                                                         boost::bind(&layout::ReadInfo::isDataRead, _1));

        if (createFastqsForIndexReads_)
        {
            readsCount += std::count_if(readInfosBegin,
                                        readInfosEnd,
                                        boost::bind(&layout::ReadInfo::isIndexRead, _1));
        }

        for( layout::LaneInfo::SampleInfosContainer::size_type sampleInfoIndex = 0;
             sampleInfoIndex < sampleInfosCounts;
             ++sampleInfoIndex )
        {
            outputBuffer.fastqs_.at(sampleInfoIndex).resize(readsCount);
            BclBuffer::BclsContainer::const_iterator cycle = inputBuffer.bcls_.begin();
            layout::ReadInfosContainer::size_type readInfoIndex = 0;
            for( layout::ReadInfosContainer::const_iterator readInfo = readInfosBegin;
                 readInfo != readInfosEnd;
                 ++readInfo )
            {
                maskAdapters_.push_back(new boost::ptr_vector<AdapterLocator>());
                trimAdapters_.push_back(new boost::ptr_vector<AdapterLocator>());

                createAdapters(maskAdapters_.back(),
                               readInfo->maskAdaptersBegin(),
                               readInfo->maskAdaptersEnd());

                createAdapters(trimAdapters_.back(),
                               readInfo->trimAdaptersBegin(),
                               readInfo->trimAdaptersEnd());

                BclBuffer::BclsContainer::const_iterator nextCycle = cycle + (readInfo->cycleInfosEnd() - readInfo->cycleInfosBegin());

                if ((createFastqsForIndexReads_ && readInfo->isIndexRead()) || readInfo->isDataRead())
                {
                    SampleIndex::FastqOffsetsContainer::size_type offsetsIndex = 0;
                    const SampleIndex::FastqOffsetsContainer::const_iterator offsetsEnd = sampleIndex_.offsetsEnd(sampleInfoIndex);
                    SampleIndex::FastqOffsetsContainer::const_iterator offset = sampleIndex_.offsetsBegin(sampleInfoIndex);
                    outputBuffer.fastqs_.at(sampleInfoIndex).at(readInfoIndex).resize((offsetsEnd-offset + detail::fastqsPerTask - 1) / detail::fastqsPerTask);
                    while(offset != offsetsEnd)
                    {
                        BCL2FASTQ_ASSERT_MSG(offsetsEnd - offset > 0, "Invalid offset iterator");
                        const SampleIndex::FastqOffsetsContainer::const_iterator nextOffset =
                            offset
                            +
                            (static_cast<std::size_t>(offsetsEnd - offset) < detail::fastqsPerTask ? offsetsEnd - offset : detail::fastqsPerTask)
                        ; 
                        taskQueue.addTask(new FastqCreateTask(
                            inputBuffer,
                            cycle,
                            nextCycle,
                            layout_.getFlowcellInfo(),
                            laneInfo_,
                            readInfo,
                            offset,
                            nextOffset,
                            maskShortAdapterReads_,
                            adapterStringency_,
                            maskAdapters_.back(),
                            trimAdapters_.back(),
                            generateReverseComplementFastqs_,
                            includeNonPfClusters_,
                            layout_,
                            useBgzf_,
                            compressionLevel_,
                            findAdaptersWithSlidingWindow_,
                            tileStats_,
                            unknownBarcodes_,
                            outputBuffer.fastqs_.at(sampleInfoIndex).at(readInfoIndex).at(offsetsIndex)
                        ));
                        ++offsetsIndex;
                        offset = nextOffset;
                    }
                    ++readInfoIndex;
                }
                cycle = nextCycle;
            }
        }
    }

    return true;
}


bool FastqCreator::postExecute()
{
    for (common::ThreadVector::size_type threadNum = 0; threadNum < threadsCount_; ++threadNum)
    {
        detail::transferStats< FastqCreateTask::ConversionStats::first_type >( tileStats_.at(threadNum).first,
                                                                               summaryTileStats_.first );
        detail::transferStats< FastqCreateTask::ConversionStats::second_type >( tileStats_.at(threadNum).second,
                                                                                summaryTileStats_.second );
        unknownBarcodesHits_.merge( unknownBarcodes_.at(threadNum) );
        unknownBarcodes_.at(threadNum).reset();
    }

    return true;
}

void FastqCreator::createAdapters(boost::ptr_vector<AdapterLocator>& adapters,
                                  layout::ReadInfo::AdaptersContainer::const_iterator begin,
                                  layout::ReadInfo::AdaptersContainer::const_iterator end) const
{
    size_t minimumTrimmedReadLength = laneInfo_.getMinimumTrimmedReadLength();
    BOOST_FOREACH (const layout::ReadInfo::AdaptersContainer::value_type& adapter, std::make_pair(begin, end))
    {
        findAdaptersWithSlidingWindow_ ?
            adapters.push_back(new AdapterLocatorSlidingWindow(adapter, adapterStringency_)) :
            adapters.push_back(new AdapterLocatorWithIndels(adapter, adapterStringency_, minimumTrimmedReadLength));
    }
}

} // namespace conversion
} // namespace bcl2fastq


