/**
 * BCL to FASTQ file converter
 * Copyright (c) 2007-2015 Illumina, Inc.
 *
 * This software is covered by the accompanying EULA
 * and certain third party copyright/licenses, and any user of this
 * source file is bound by the terms therein.
 *
 * \file LaneInfo.cpp
 *
 * \brief Implementation of lane metadata.
 *
 * \author Marek Balint
 */


#include <sstream>
#include <iterator>
#include <numeric>
#include <utility>

#include <boost/assign.hpp>
#include <boost/format.hpp>
#include <boost/foreach.hpp>

#include "common/Debug.hh"
#include "layout/LaneInfo.hh"


namespace bcl2fastq {


namespace layout {


LaneInfo::LaneInfo(common::LaneNumber number)
: number_(number)
, sampleInfos_()
, tileInfos_()
, readInfos_()
, minimumTrimmedReadLength_(0)
{
}

void LaneInfo::maskBarcode(common::ReadNumber indexNumber)
{
    for (auto& sampleInfo : sampleInfos_)
    {
        sampleInfo.maskBarcode(indexNumber);
    }
}

common::ClustersCount LaneInfo::getClustersCount() const
{
    return std::accumulate(
        this->tileInfosBegin(),
        this->tileInfosEnd(),
        common::ClustersCount(0),
        boost::bind(
            std::plus<common::ClustersCount>(),
            _1,
            boost::bind(&TileInfo::getClustersCount, _2)
        )
    );
}

bool LaneInfo::haveClustersCount() const
{
    BOOST_FOREACH (const TileInfo &tileInfo, std::make_pair(this->tileInfosBegin(), this->tileInfosEnd()))
    {
        if (!tileInfo.haveClustersCount())
        {
            return false;
        }
    }
    return true;
}

common::CycleNumber LaneInfo::getCyclesCount() const
{
    return std::accumulate(
        this->readInfosBegin(),
        this->readInfosEnd(),
        common::CycleNumber(0),
        boost::bind(
            std::plus<common::CycleNumber>(),
            _1,
            boost::bind(&ReadInfo::getCyclesCount, _2)
        )
    );
}



} // namespace layout


} // namespace bcl2fastq


