/**
 * BCL to FASTQ file converter
 * Copyright (c) 2007-2015 Illumina, Inc.
 *
 * This software is covered by the accompanying EULA
 * and certain third party copyright/licenses, and any user of this
 * source file is bound by the terms therein.
 *
 * \file testBarcodeCollisionDetector.cpp
 *
 * \brief BarcodeCollisionDetector cppunit test declarations.
 *
 * \author Aaron Day
 */


#include "layout/BarcodeCollisionDetector.hh"

#include "RegistryName.hh"
#include "testBarcodeCollisionDetector.hh"


CPPUNIT_TEST_SUITE_NAMED_REGISTRATION(TestBarcodeCollisionDetector, registryName("BarcodeCollisionDetector"));


void TestBarcodeCollisionDetector::setUp()
{
    componentMaxMismatches_.push_back(0);
    componentMaxMismatches_.push_back(1);
    componentMaxMismatches_.push_back(2);
}

void TestBarcodeCollisionDetector::tearDown()
{
}

void TestBarcodeCollisionDetector::testSuccess()
{
    bcl2fastq::common::SampleMetadata::BarcodesContainer barcodeContainer1(1);
    barcodeContainer1.back().push_back("ACGTACGT");
    barcodeContainer1.back().push_back("TTTTCCCC");
    barcodeContainer1.back().push_back("CGCGCGCGCGCG");
    barcodeContainer1.back().push_back("AAAAAAAAAA");

    bcl2fastq::common::SampleMetadata::BarcodesContainer barcodeContainer2(1);
    barcodeContainer2.back().push_back("ACGGACCT"); // 2 mismatches
    barcodeContainer2.back().push_back("ATAACCCC"); // 3 mismatches 
    barcodeContainer2.back().push_back("CACGAGTGCCCA"); // 5 mismatches
    barcodeContainer2.back().push_back("GGGGGGGGGG"); // all mismatches

    bcl2fastq::layout::BarcodeCollisionDetector collisionDetector(componentMaxMismatches_.begin(),
                                                                  componentMaxMismatches_.end());

    collisionDetector.validateBarcode(barcodeContainer1);

    collisionDetector.validateBarcode(barcodeContainer2);

    // Add 2 close barcodes, which is ok, since they're for the same sample
    bcl2fastq::common::SampleMetadata::BarcodesContainer barcodeContainer3(1);
    barcodeContainer3.back().push_back("ACGTACGT"); // 0 mismatch
    barcodeContainer3.back().push_back("TTTTCCCC"); // 0 mismatches
    barcodeContainer3.back().push_back("CGCGCGCGCGCG"); // 0 mismatches
    barcodeContainer3.back().push_back("AAAAGGGGGG"); // 6 mismatches

    barcodeContainer3.push_back(bcl2fastq::common::SampleMetadata::BarcodesContainer::value_type());
    barcodeContainer3.back().push_back("ACGTACGT"); // 0 mismatches
    barcodeContainer3.back().push_back("TTTTCCCC"); // 0 mismatches
    barcodeContainer3.back().push_back("CGCGCGCGCGCG"); // 0 mismatches
    barcodeContainer3.back().push_back("AAAAAGGGGG"); // 5 mismatches

    collisionDetector.validateBarcode(barcodeContainer3);
}

void TestBarcodeCollisionDetector::testMismatchLength()
{
    bcl2fastq::common::SampleMetadata::BarcodesContainer barcodeContainer1(1);
    barcodeContainer1.back().push_back("ACGTACGT");
    barcodeContainer1.back().push_back("TTTTCCCCG");

    bcl2fastq::common::SampleMetadata::BarcodesContainer barcodeContainer2(1);
    barcodeContainer2.back().push_back("CGCGTATA");
    barcodeContainer2.back().push_back("AACCGGTT");

    bcl2fastq::layout::BarcodeCollisionDetector collisionDetector(componentMaxMismatches_.begin(),
                                                                  componentMaxMismatches_.end());

    collisionDetector.validateBarcode(barcodeContainer1);

    CPPUNIT_ASSERT_THROW(collisionDetector.validateBarcode(barcodeContainer2),
                         bcl2fastq::layout::BarcodeCollisionError);

    // 2 barcodes of different length in the same sample
    bcl2fastq::common::SampleMetadata::BarcodesContainer barcodeContainer3(1);
    barcodeContainer3.back().push_back("AAAAAAAA");
    barcodeContainer3.back().push_back("TTTTTTTT");
    barcodeContainer3.push_back(bcl2fastq::common::SampleMetadata::BarcodesContainer::value_type());
    barcodeContainer3.back().push_back("AAAAAAAAAA");
    barcodeContainer3.back().push_back("TTTTTTTTTT");

    CPPUNIT_ASSERT_THROW(collisionDetector.validateBarcode(barcodeContainer3),
                         bcl2fastq::layout::BarcodeCollisionError);
}

void TestBarcodeCollisionDetector::testNumComponents()
{
    bcl2fastq::common::SampleMetadata::BarcodesContainer barcodeContainer1(1);
    barcodeContainer1.back().push_back("ACGTACGT");
    barcodeContainer1.back().push_back("TTTTCCCC");
    barcodeContainer1.back().push_back("CTCTGATG");

    bcl2fastq::common::SampleMetadata::BarcodesContainer barcodeContainer2(1);
    barcodeContainer2.back().push_back("CGCGTATA");
    barcodeContainer2.back().push_back("AACCGGTT");

    bcl2fastq::layout::BarcodeCollisionDetector collisionDetector(componentMaxMismatches_.begin(),
                                                                  componentMaxMismatches_.end());

    collisionDetector.validateBarcode(barcodeContainer1);

    CPPUNIT_ASSERT_THROW(collisionDetector.validateBarcode(barcodeContainer2),
                         bcl2fastq::layout::BarcodeCollisionError);
}

void TestBarcodeCollisionDetector::testCollision()
{
    bcl2fastq::common::SampleMetadata::BarcodesContainer barcodeContainer1(1);
    barcodeContainer1.back().push_back("ACGTACGT");
    barcodeContainer1.back().push_back("TTTTCCCC");

    bcl2fastq::common::SampleMetadata::BarcodesContainer barcodeContainer2(1);
    barcodeContainer2.back().push_back("ACGTACGT"); // 2 mismatches
    barcodeContainer2.back().push_back("TTTTTTCC"); // 2 mismatches

    bcl2fastq::layout::BarcodeCollisionDetector collisionDetector(componentMaxMismatches_.begin(),
                                                                  componentMaxMismatches_.end());

    collisionDetector.validateBarcode(barcodeContainer1);

    CPPUNIT_ASSERT_THROW(collisionDetector.validateBarcode(barcodeContainer2),
                         bcl2fastq::layout::BarcodeCollisionError);

    barcodeContainer1.back().push_back("GGGGGGGGGGGG");
    barcodeContainer2.back().push_back("AAAAGGGGGGGG"); // 4 mismatches
    CPPUNIT_ASSERT_THROW(collisionDetector.validateBarcode(barcodeContainer2),
                         bcl2fastq::layout::BarcodeCollisionError);
}

