/**
 * BCL to FASTQ file converter
 * Copyright (c) 2007-2015 Illumina, Inc.
 *
 * This software is covered by the accompanying EULA
 * and certain third party copyright/licenses, and any user of this
 * source file is bound by the terms therein.
 *
 * \file BclLoader.cpp
 *
 * \brief Implementation of BCL loader.
 *
 * \author Marek Balint
 * \author Mauricio Varea
 */


#include <errno.h>
#include <algorithm>
#include <utility>

#include <boost/format.hpp>
#include <boost/foreach.hpp>
#include <boost/filesystem.hpp>

#include "common/Debug.hh"
#include "common/Exceptions.hh"
#include "common/Types.hh"
#include "conversion/BclLoader.hh"


namespace bcl2fastq {


namespace conversion {


BclLoadTask::BclLoadTask(
    data::BclFile &bclFile,
    data::CycleBCIFile &cycleBciFile,
    const boost::filesystem::path &inputDir,
    bool aggregateTilesFlag,
    const layout::LaneInfo &laneInfo,
    const layout::CycleInfo &cycleInfo,
    const layout::TileInfo &tileInfo,
    common::ClustersCount clustersCount,
    bool ignoreMissingBcls,
    BclBuffer::BclsContainer::value_type &outputBuffer
)
: Task()
, bclFile_(bclFile)
, cycleBciFile_(cycleBciFile)
, inputDir_(inputDir)
, aggregateTilesFlag_(aggregateTilesFlag)
, laneInfo_(laneInfo)
, cycleInfo_(cycleInfo)
, tileInfo_(tileInfo)
, clustersCount_(clustersCount)
, ignoreMissingBcls_(ignoreMissingBcls)
, outputBuffer_(outputBuffer)
{
}

bool BclLoadTask::execute(common::ThreadVector::size_type threadNum)
{
    if (aggregateTilesFlag_)
    {
        if (!bclFile_.isOpen())
        {
            bclFile_.openFile(inputDir_,
                              laneInfo_.getNumber(),
                              cycleInfo_.getNumber(),
                              ignoreMissingBcls_);
        }

        if (tileInfo_.getSkippedTilesCount())
        {
            if (!cycleBciFile_.isOpen())
            {
                cycleBciFile_.openFile(inputDir_, laneInfo_.getNumber(), cycleInfo_.getNumber());
            }
            data::CycleBCIFile::Record record = cycleBciFile_.getRecord(tileInfo_.getIndex());
            bclFile_.seek(record.compressedOffset, record.uncompressedOffset);
        }
    }
    else
    {
        bclFile_.openFile(inputDir_,
                          laneInfo_.getNumber(),
                          tileInfo_.getNumber(),
                          cycleInfo_.getNumber(),
                          ignoreMissingBcls_);

        clustersCount_ = bclFile_.getClustersCount();
    }

    outputBuffer_.resize(clustersCount_);
    std::streamsize result = bclFile_.read(&*outputBuffer_.begin(), clustersCount_);
    int errnum = errno;
    if (result != static_cast<std::streamsize>(clustersCount_))
    {
        if (ignoreMissingBcls_)
        {
            BCL2FASTQ_LOG(common::LogLevel::WARNING) << "BCL file '" << bclFile_.getPath() << "' truncated: bytes_read=" << result << " bytes_expected=" << clustersCount_ << ":" << std::strerror(errnum) << " (" << errnum << ")" << std::endl;
            outputBuffer_.resize(result > 0 ? result : 0);
            outputBuffer_.resize(clustersCount_, 0);
        }
        else
        {
            BOOST_THROW_EXCEPTION(common::InputDataError(errnum, (boost::format("BCL file '%s' truncated: bytes_read=%d bytes_expected=%d") % bclFile_.getPath().string() % result % clustersCount_).str()));
        }
    }

    return true;
}


PositionsLoadTask::PositionsLoadTask(
    boost::shared_ptr<data::PositionsFile> &positionsFile,
    const boost::filesystem::path &intensitiesDir,
    bool aggregateTilesFlag,
    bool isPatternedFlowcell,
    const layout::LaneInfo &laneInfo,
    const layout::TileInfo &tileInfo,
    BclBuffer::PositionsContainer::size_type clustersCount,
    bool ignoreMissingPositions,
    BclBuffer::PositionsContainer &outputBuffer
)
: Task()
, positionsFile_(positionsFile)
, intensitiesDir_(intensitiesDir)
, aggregateTilesFlag_(aggregateTilesFlag)
, isPatternedFlowcell_(isPatternedFlowcell)
, laneInfo_(laneInfo)
, tileInfo_(tileInfo)
, clustersCount_(clustersCount)
, ignoreMissingPositions_(ignoreMissingPositions)
, outputBuffer_(outputBuffer)
{
}

bool PositionsLoadTask::execute(common::ThreadVector::size_type threadNum)
{
    if (!positionsFile_ || !aggregateTilesFlag_)
    {
        positionsFile_ = data::PositionsFileFactory::createPositionsFile(intensitiesDir_,
                                                                         aggregateTilesFlag_,
                                                                         isPatternedFlowcell_,
                                                                         laneInfo_.getNumber(),
                                                                         tileInfo_.getNumber(),
                                                                         ignoreMissingPositions_);

        if (!positionsFile_)
        {
            if (ignoreMissingPositions_)
            {
                outputBuffer_.clear();
                return true;
            }
            else
            {
                BOOST_THROW_EXCEPTION(common::InputDataError(
                    errno,
                    (boost::format("Could not find positions file for lane %s and tile %s.")
                        % laneInfo_.getNumber() % tileInfo_.getNumber()).str() ));
            }
        }
    }

    if (aggregateTilesFlag_ && !isPatternedFlowcell_)
    {
        std::size_t skippedClustersCount = tileInfo_.getSkippedClustersCount();
        if (skippedClustersCount)
        {
            std::vector<data::PositionsFile::Record> buffer;
            buffer.resize(skippedClustersCount);
            positionsFile_->read(&*buffer.begin(), skippedClustersCount);
        }
    }
    else
    {
        clustersCount_ = positionsFile_->getClustersCount();
    }

    outputBuffer_.resize(clustersCount_);
    std::size_t recordsRead = positionsFile_->read(&*outputBuffer_.begin(), clustersCount_);

    int errnum = errno;
    if (recordsRead != clustersCount_)
    {
        if (ignoreMissingPositions_)
        {
            BCL2FASTQ_LOG(common::LogLevel::WARNING) << "Positions file '" << positionsFile_->getPath() << "' truncated: records_read=" << recordsRead << " records_expected=" << clustersCount_ << ":" << std::strerror(errnum) << " (" << errnum << ")" << std::endl;
            outputBuffer_.resize(recordsRead);
            static const data::PositionsFile::Record defaultRecord = { /* .x_ = */ 0, /* .y_ = */ 0 };
            outputBuffer_.resize(clustersCount_, defaultRecord);
        }
        else
        {
            BOOST_THROW_EXCEPTION(common::InputDataError(errnum, (boost::format("Positions file '%s' truncated: records_real=%d records_expected=%d") % positionsFile_->getPath().string() % recordsRead % clustersCount_).str()));
        }
    }
    return true;
}


FilterLoadTask::FilterLoadTask(
    boost::shared_ptr<data::FilterFile> &filterFile,
    const boost::filesystem::path &inputDir,
    bool aggregateTilesFlag,
    const layout::LaneInfo &laneInfo,
    const layout::TileInfo &tileInfo,
    BclBuffer::FiltersContainer::size_type clustersCount,
    bool ignoreMissingFilters,
    BclBuffer::FiltersContainer &outputBuffer,
    BclBuffer::ControlsContainer &controlsOutputBuffer
)
: Task()
, filterFile_(filterFile)
, inputDir_(inputDir)
, aggregateTilesFlag_(aggregateTilesFlag)
, laneInfo_(laneInfo)
, tileInfo_(tileInfo)
, clustersCount_(clustersCount)
, ignoreMissingFilters_(ignoreMissingFilters)
, outputBuffer_(outputBuffer)
, controlsOutputBuffer_(controlsOutputBuffer)
{
}

bool FilterLoadTask::execute(common::ThreadVector::size_type threadNum)
{
    if (filterFile_)
    {
        BOOST_ASSERT(aggregateTilesFlag_);
        readAggregateTilesFilterFile();
    }
    else
    {
        boost::filesystem::path filePath;
        if (data::FilterFile::doesFileExist(inputDir_,
                                            aggregateTilesFlag_,
                                            laneInfo_.getNumber(),
                                            tileInfo_.getNumber(),
                                            filePath))
        {
            if (aggregateTilesFlag_)
            {
                readAggregateTilesFilterFile(filePath);
            }
            else
            {
                readTileFilterFile(filePath);
            }
        }
    }

    return true;
}

void FilterLoadTask::readAggregateTilesFilterFile(const boost::filesystem::path& filePath)
{
    if (!filterFile_)
    {
        filterFile_ = boost::shared_ptr<data::FilterFile>(new data::FilterFile(filePath,
                                                                               ignoreMissingFilters_));
    }

    std::size_t skippedClustersCount = tileInfo_.getSkippedClustersCount();
    if (skippedClustersCount)
    {
        std::vector<data::FilterFile::Record> buffer;
        buffer.resize(skippedClustersCount);
        filterFile_->read(&*buffer.begin(), skippedClustersCount);
    }

    readFilterFile(*filterFile_);
}

void FilterLoadTask::readTileFilterFile(const boost::filesystem::path& filePath)
{
    data::FilterFile filterFile(filePath,
                                ignoreMissingFilters_);

    clustersCount_ = filterFile.getClustersCount();

    readFilterFile(filterFile);
}

void FilterLoadTask::readFilterFile(data::FilterFile& filterFile)
{
    outputBuffer_.resize(clustersCount_);
    std::size_t recordsRead = filterFile.read(&*outputBuffer_.begin(), clustersCount_);
    validateFilterRecords(recordsRead,
                          filterFile.getPath());
}

void FilterLoadTask::validateFilterRecords(std::size_t                    recordsRead,
                                           const boost::filesystem::path& filePath)
{
    int errnum = errno;
    if (recordsRead != clustersCount_)
    {
        if (ignoreMissingFilters_)
        {
            BCL2FASTQ_LOG(common::LogLevel::WARNING) << "Filter file '" << filePath << "' truncated: records_read=" << recordsRead << " records_expected=" << clustersCount_ << ":" << std::strerror(errnum) << " (" << errnum << ")" << std::endl;
            outputBuffer_.resize(recordsRead);
            static const data::FilterFile::Record defaultRecord(0x01);
            outputBuffer_.resize(clustersCount_, defaultRecord);
        }
        else
        {
            BOOST_THROW_EXCEPTION(common::InputDataError(errnum, (boost::format("Filter file '%s' truncated: records_real=%d records_expected=%d") % filePath.string() % recordsRead % clustersCount_).str()));
        }
    }
}

ControlLoadTask::ControlLoadTask(
    boost::shared_ptr<data::ControlFile> &controlFile,
    const boost::filesystem::path &inputDir,
    const layout::LaneInfo &laneInfo,
    const layout::TileInfo &tileInfo,
    BclBuffer::ControlsContainer::size_type clustersCount,
    bool ignoreMissingControls,
    BclBuffer::ControlsContainer &outputBuffer
)
: Task()
, controlFile_(controlFile)
, inputDir_(inputDir)
, laneInfo_(laneInfo)
, tileInfo_(tileInfo)
, clustersCount_(clustersCount)
, ignoreMissingControls_(ignoreMissingControls)
, outputBuffer_(outputBuffer)
{
}

bool ControlLoadTask::execute(common::ThreadVector::size_type threadNum)
{
    controlFile_ = data::ControlFileFactory::createControlFile(inputDir_,
                                                               laneInfo_.getNumber(),
                                                               tileInfo_.getNumber(),
                                                               ignoreMissingControls_);

    if (!controlFile_)
    {
        // There might not be a control file
        return true;
    }

    clustersCount_ = controlFile_->getClustersCount();

    outputBuffer_.resize(clustersCount_);
    std::size_t recordsRead = controlFile_->read(&*outputBuffer_.begin(), clustersCount_);

    int errnum = errno;
    if (recordsRead != clustersCount_)
    {
        if (ignoreMissingControls_)
        {
            BCL2FASTQ_LOG(common::LogLevel::WARNING) << "Control file '" << controlFile_->getPath() << "' truncated: records_read=" << recordsRead << " records_expected=" << clustersCount_ << ":" << std::strerror(errnum) << " (" << errnum << ")" << std::endl;
            outputBuffer_.resize(recordsRead);
            outputBuffer_.resize(clustersCount_);
        }
        else
        {
            BOOST_THROW_EXCEPTION(common::InputDataError(errnum, (boost::format("Control file '%s' truncated: records_real=%d records_expected=%d") % controlFile_->getPath().string() % recordsRead % clustersCount_).str()));
        }
    }
    return true;
}


BclLoader::BclLoader(
    common::ThreadVector::size_type threadsCount,
    StageMediator<OutputBuffer> &outputMediator,
    const layout::Layout &layout,
    const layout::LaneInfo &laneInfo,
    bool ignoreMissingBcls,
    bool ignoreMissingFilters,
    bool ignoreMissingPositions,
    bool ignoreMissingControls,
    const boost::filesystem::path &inputDir,
    const boost::filesystem::path &intensitiesDir
)
: SourceStage<BclBuffer>(threadsCount, "Bcl loading", outputMediator)
, layout_(layout)
, laneInfo_(laneInfo)
, ignoreMissingBcls_(ignoreMissingBcls)
, ignoreMissingFilters_(ignoreMissingFilters)
, ignoreMissingPositions_(ignoreMissingPositions)
, ignoreMissingControls_(ignoreMissingControls)
, currentTileInfo_(laneInfo_.tileInfosBegin())
, inputDir_(inputDir)
, intensitiesDir_(intensitiesDir)
, bclFiles_()
, cycleBciFiles_()
, positionsFile_()
, filterFile_()
, controlFile_()
, patternedFlowcellPositions_()
, uniqueFailedReadIndex_(0)
{
    common::CycleNumber cyclesCount = laneInfo.getCyclesCount();
    BCL2FASTQ_ASSERT_MSG(cyclesCount != 0, "There are no cycles to be processed");
    for (common::CycleNumber i = 0; i < cyclesCount; ++i)
    {
        bclFiles_.push_back(new data::BclFile);
        cycleBciFiles_.push_back(new data::CycleBCIFile);
    }
}

bool BclLoader::preExecute()
{
    if (currentTileInfo_ == laneInfo_.tileInfosEnd())
    {
        return false;
    }

    TaskQueue &taskQueue = this->getTaskQueue();
    BclBuffer &outputBuffer = this->getOutputBuffer();
    const bool aggregateTilesFlag = layout_.getFlowcellInfo().getAggregateTilesFlag();
    const bool isPatternedFlowcell = layout_.getFlowcellInfo().isPatternedFlowcell();
    const bool haveClustersCount = currentTileInfo_->haveClustersCount();
    const common::ClustersCount clustersCount = haveClustersCount ? currentTileInfo_->getClustersCount() : 0;

    outputBuffer.bcls_.resize(laneInfo_.getCyclesCount());
    BclFilesContainer::size_type bclIdx = 0;
    BOOST_FOREACH (const layout::ReadInfo &readInfo, std::make_pair(laneInfo_.readInfosBegin(), laneInfo_.readInfosEnd()))
    {
        BOOST_FOREACH (const layout::CycleInfo &cycleInfo, std::make_pair(readInfo.cycleInfosBegin(), readInfo.cycleInfosEnd()))
        {
            taskQueue.addTask(new BclLoadTask(
                bclFiles_.at(bclIdx),
                cycleBciFiles_.at(bclIdx),
                inputDir_,
                aggregateTilesFlag,
                laneInfo_,
                cycleInfo,
                *currentTileInfo_,
                clustersCount,
                ignoreMissingBcls_,
                outputBuffer.bcls_.at(bclIdx)
            ));

            ++bclIdx;
        }
    }

    taskQueue.addTask(new FilterLoadTask(
        filterFile_,
        inputDir_,
        aggregateTilesFlag,
        laneInfo_,
        *currentTileInfo_,
        clustersCount,
        ignoreMissingFilters_,
        outputBuffer.filters_,
        outputBuffer.controls_
    ));

    if (!isPatternedFlowcell || !positionsFile_)
    {
        taskQueue.addTask(new PositionsLoadTask(
            positionsFile_,
            intensitiesDir_,
            aggregateTilesFlag,
            isPatternedFlowcell,
            laneInfo_,
            *currentTileInfo_,
            clustersCount,
            ignoreMissingPositions_,
            isPatternedFlowcell ? patternedFlowcellPositions_ : outputBuffer.positions_
        ));
    }

    taskQueue.addTask(new ControlLoadTask(
        controlFile_,
        inputDir_,
        laneInfo_,
        *currentTileInfo_,
        clustersCount,
        ignoreMissingControls_,
        outputBuffer.controls_
    ));

    return true;
}

void BclLoader::bclMismatchCount(std::string fileType,
                                 common::CycleNumber cycleNumber,
                                 BclBuffer::BclsContainer::value_type::size_type realSize,
                                 BclBuffer::BclsContainer::value_type::size_type expectedSize)
{
    if ((ignoreMissingBcls_ && "BCL" == fileType)
    ||  (ignoreMissingPositions_ && "positions" == fileType)
    ||  (ignoreMissingFilters_ && "filter" == fileType)
    ||  (ignoreMissingControls_ && "control" == fileType))
    {
        BCL2FASTQ_LOG(common::LogLevel::WARNING) << "Mismatching cluster count in " << fileType << " file: Cycle #" << cycleNumber << ": bytes_real=" << realSize << " bytes_expected=" << expectedSize << std::endl;
    } else {
        BOOST_THROW_EXCEPTION(common::InputDataError((boost::format("Mismatching cluster count in %s file: Cycle #%d: bytes_real=%d bytes_expected=%d") % fileType % cycleNumber % realSize % expectedSize).str()));
    }
}

void BclLoader::createUniqueFakePositions(BclBuffer::BclsContainer::value_type::size_type bufferSize)
{
    BclBuffer &outputBuffer = this->getOutputBuffer();

    outputBuffer.positions_.resize(bufferSize);

    for (BclBuffer::BclsContainer::value_type::size_type i = 0; i < bufferSize; ++i)
    {
        outputBuffer.positions_[i].y_ = uniqueFailedReadIndex_++;
    }
}

bool BclLoader::postExecute()
{
    BclBuffer &outputBuffer = this->getOutputBuffer();

    if (layout_.getFlowcellInfo().isPatternedFlowcell())
    {
        outputBuffer.positions_ = patternedFlowcellPositions_;
    }

    const BclBuffer::BclsContainer::const_iterator largestBuffer = std::max_element(
        outputBuffer.bcls_.begin(),
        outputBuffer.bcls_.end(),
        boost::bind(&BclBuffer::BclsContainer::value_type::size, _1) < boost::bind(&BclBuffer::BclsContainer::value_type::size, _2)
    );
    const BclBuffer::BclsContainer::value_type::size_type bufferSize = largestBuffer->size();

    common::CycleNumber cycleNumber = 1;
    BOOST_FOREACH (BclBuffer::BclsContainer::value_type &bclBuffer, std::make_pair(outputBuffer.bcls_.begin(), outputBuffer.bcls_.end()))
    {
        const BclBuffer::BclsContainer::value_type::size_type currentSize = bclBuffer.size();
        if (bufferSize != currentSize)
        {
            bclMismatchCount("BCL",cycleNumber,currentSize,bufferSize);
            bclBuffer.resize(bufferSize, 0);
        }
        ++cycleNumber;
    }
    if (outputBuffer.positions_.size() != bufferSize)
    {
        bclMismatchCount("positions",1,outputBuffer.positions_.size(),bufferSize);
        createUniqueFakePositions(bufferSize);
    }
    if (outputBuffer.filters_.size() != bufferSize)
    {
        bclMismatchCount("filter",1,outputBuffer.filters_.size(),bufferSize);
        outputBuffer.filters_.resize(bufferSize, data::FilterFile::Record(1));
    }
    if (outputBuffer.controls_.size() != bufferSize)
    {
        if (controlFile_)
        {
            bclMismatchCount("control",1,outputBuffer.controls_.size(),bufferSize);
        }
        outputBuffer.controls_.resize(bufferSize);
    }

    this->getOutputBuffer().tileInfo_ = currentTileInfo_;
    ++currentTileInfo_;
    return true;
}


} // namespace conversion


} // namespace bcl2fastq


