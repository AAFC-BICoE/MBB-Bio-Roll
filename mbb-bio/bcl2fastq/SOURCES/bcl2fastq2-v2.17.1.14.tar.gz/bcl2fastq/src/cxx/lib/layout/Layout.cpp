/**
 * BCL to FASTQ file converter
 * Copyright (c) 2007-2015 Illumina, Inc.
 *
 * This software is covered by the accompanying EULA
 * and certain third party copyright/licenses, and any user of this
 * source file is bound by the terms therein.
 *
 * \file Layout.cpp
 *
 * \brief Implementation of data layout.
 *
 * \author Marek Balint
 * \author Mauricio Varea
 */


#include <utility>
#include <numeric>
#include <sstream>

#include <boost/bind.hpp>
#include <boost/foreach.hpp>
#include <boost/format.hpp>
#include <boost/filesystem.hpp>
#include <boost/regex.hpp>
#include <boost/algorithm/string.hpp>
#include <boost/filesystem/operations.hpp>

#include "common/Logger.hh"
#include "common/Types.hh"
#include "layout/Layout.hh"
#include "layout/UseBasesMask.hh"
#include "layout/RunInfoXml.hh"
#include "config/SampleSheetCsv.hh"
#include "layout/ConfigXml.hh"
#include "layout/BCIndex.hh"
#include "common/DirectoryValidator.hh"
#include "layout/BarcodeCollisionDetector.hh"
#include "layout/FileExistenceVerifier.hh"

namespace bcl2fastq {


namespace layout {


const FlowcellInfo & Layout::getFlowcellInfo() const
{
    return flowcellInfo_;
}

FlowcellInfo & Layout::getFlowcellInfo()
{
    return flowcellInfo_;
}

LaneInfosContainer::const_iterator Layout::laneInfosBegin() const
{
    return laneInfos_.begin();
}

LaneInfosContainer::const_iterator Layout::laneInfosEnd() const
{
    return laneInfos_.end();
}

void Layout::addLane(const LaneInfo &laneInfo)
{
    laneInfos_.push_back(laneInfo);
}

bool includeTile(const std::string&               flowcell,
                 common::LaneNumber               laneNumber,
                 common::TileNumber               tileNumber,
                 const std::vector<boost::regex>& tileRegexps,
                 const config::SampleSheetCsv&    sampleSheet)
{
    if (tileRegexps.empty())
    {
        return !sampleSheet.isTileExcluded(flowcell, laneNumber, tileNumber);
    }
    else
    {
        std::string tileString((boost::format("s_%d_%04d") % laneNumber % tileNumber).str());
        BOOST_FOREACH(const boost::regex &re, tileRegexps)
        {
            if (boost::regex_search(tileString, re))
            {
                return true;
            }
        }
    }
    return false;
}

bool checkBciExistence( boost::filesystem::path laneDir )
{
    boost::regex pattern(".*\\.bci$", boost::regex_constants::mod_x);
    if( !boost::filesystem::is_directory( laneDir ))  return false;
    BCL2FASTQ_LOG(common::LogLevel::DEBUG) << "Checking if there are any BCI files in: " << laneDir << std::endl;
    for( boost::filesystem::directory_iterator it(laneDir), end;  it != end;  ++it )
    {
        boost::smatch match;
        if( boost::filesystem::is_regular_file( it->status() )
         && boost::regex_match( it->path().leaf().string(), match, pattern ))
        {
            BCL2FASTQ_LOG(common::LogLevel::DEBUG) << "\t... found " << it->path() << std::endl;
            return true;
        }
    }
    BCL2FASTQ_LOG(common::LogLevel::DEBUG) << "\t... no BCI files found!" << std::endl;
    return false;
}

enum AdapterType
{
    TRIM,
    MASK
};

unsigned int addAdaptersToRead( config::SampleSheetCsv::AdaptersContainer::const_iterator adaptersBegin,
                                config::SampleSheetCsv::AdaptersContainer::const_iterator adaptersEnd,
                                ReadInfo &readInfo,
                                AdapterType adapterType)
{
    BCL2FASTQ_ASSERT_MSG(adapterType == TRIM || adapterType == MASK, "Unrecognized adapter type");

    unsigned int adapterCount = 0;
    bool haveNonZeroReadAdapter = false;
    BOOST_FOREACH (const config::SampleSheetCsv::AdaptersContainer::value_type &adapter, std::make_pair(adaptersBegin, adaptersEnd))
    {
        if (adapter.first != 0)
        {
        	haveNonZeroReadAdapter = true;
        }
    }
    BOOST_FOREACH (const config::SampleSheetCsv::AdaptersContainer::value_type &adapter, std::make_pair(adaptersBegin, adaptersEnd))
    {
        bool acceptAdapter = false;
        if(!haveNonZeroReadAdapter)
        {
            acceptAdapter = true;
        }
        else if (adapter.first == readInfo.getNumber())
        {
            acceptAdapter = true;
        }
        else if((adapter.first == 0) && (readInfo.getNumber() == 1))
        {
            acceptAdapter = true;
        }

        if (acceptAdapter)
        {
            std::string adapterTypeStr;
            if (adapterType == MASK)
            {
                readInfo.addMaskAdapter(adapter.second);
                adapterTypeStr = "mask";
            }
            else if (adapterType == TRIM)
            {
                readInfo.addTrimAdapter(adapter.second);
                adapterTypeStr = "trim";
            }

            ++adapterCount;
            BCL2FASTQ_LOG(common::LogLevel::INFO) << "  Adapter: " << adapter.second << (boost::format(" (%s adapter)") % adapterTypeStr).str() << std::endl;
        }
    }
    return adapterCount;
}

void addBarcodesToSample(const common::SampleMetadata::BarcodesContainer& barcodes,
                         SampleInfo &sampleInfo,
                         BarcodeCollisionDetector& barcodeCollisionDetector,
                         std::vector<size_t>& barcodeLengths)
{
    barcodeCollisionDetector.validateBarcode(barcodes);
    for (const auto& barcodeComponents : barcodes)
    {
        common::SampleMetadata::BarcodesContainer::value_type nonEmptyBarcodeComponents;
        for (const auto& component : barcodeComponents)
        {
            if (!component.empty())
            {
                nonEmptyBarcodeComponents.push_back(component);
            }
        }
        Barcode barcode (nonEmptyBarcodeComponents.begin(), nonEmptyBarcodeComponents.end());
        sampleInfo.addBarcode(barcode);
        BCL2FASTQ_LOG(common::LogLevel::INFO) << "    Barcode: '" << barcode << "'" << std::endl;

        if (barcodeLengths.empty())
        {
            for (const auto& component : barcodeComponents)
            {
                barcodeLengths.push_back(component.size());
            }
        }
    }
}

void detectFlowcellInfo(const boost::filesystem::path& intensitiesDir,
                        const RunInfoXml&              runInfoXml,
                        boost::optional<bool>          tilesAggregationFlag,
                        bool                           hasBci,
                        Layout&                        layout,
                        bool&                          flowcellAggregateTilesFlag)
{
    FlowcellInfo &flowcellInfo = layout.getFlowcellInfo();
    flowcellInfo.setInstrument(runInfoXml.getInstrument());
    flowcellInfo.setRunNumber(runInfoXml.getRunNumber());
    flowcellInfo.setFlowcellId(runInfoXml.getFlowcellId());
    if( boost::filesystem::exists( intensitiesDir / "s.locs" ) )
    {
        flowcellInfo.setPatternedFlowcell();
        BCL2FASTQ_LOG(common::LogLevel::INFO) << "Patterned flowcell detected" << std::endl;
        BCL2FASTQ_LOG(common::LogLevel::DEBUG) << "This may be a 'HiSeq X Ten' run" << std::endl;
    } else {
        flowcellInfo.resetPatternedFlowcell();
        BCL2FASTQ_LOG(common::LogLevel::DEBUG) << "NO patterned flowcell detected" << std::endl;
    }

    if( tilesAggregationFlag )
    {   // force a tile-aggregation mode
        flowcellInfo.setAggregateTilesFlag( tilesAggregationFlag.get() );
        BCL2FASTQ_LOG(common::LogLevel::DEBUG) << "User-specified tile-aggregation mode" << std::endl;
    } else if( hasBci ) {
        flowcellInfo.setAggregateTilesFlag(true);
        BCL2FASTQ_LOG(common::LogLevel::DEBUG) << "This may be a 'NextSeq 500' run" << std::endl;
    } else {
        flowcellInfo.setAggregateTilesFlag(false);
    }

    if( flowcellInfo.getAggregateTilesFlag() )
    {
        BCL2FASTQ_LOG(common::LogLevel::INFO) << "Setting tile-aggregation mode to: YES" << std::endl;
    } else {
        BCL2FASTQ_LOG(common::LogLevel::INFO) << "Setting tile-aggregation mode to: NO" << std::endl;
    }

    flowcellAggregateTilesFlag = flowcellInfo.getAggregateTilesFlag();
}

void parseUseBasesMasks(const std::vector<std::string>&            useBasesMaskStrs,
                        std::map<common::LaneNumber, std::string>& useBasesMasksForLane,
                        std::string&                               defaultUseBasesMask)
{
    BOOST_FOREACH(const std::string& useBasesMask, useBasesMaskStrs)
    {
        std::vector<std::string> useBasesMaskAndLane;
        boost::split(useBasesMaskAndLane, useBasesMask, boost::is_any_of(":"));

        if (useBasesMaskAndLane.size() == 1)
        {
            BCL2FASTQ_ASSERT_MSG(defaultUseBasesMask.empty(), "Multiple use-bases-mask paramters entered without specifying lane number.");

            defaultUseBasesMask = useBasesMask;
        }
        else if (useBasesMaskAndLane.size() == 2)
        {
            boost::algorithm::trim<std::string>(useBasesMaskAndLane[0]);
            boost::algorithm::trim<std::string>(useBasesMaskAndLane[1]);

            useBasesMasksForLane.insert(std::make_pair(boost::lexical_cast<unsigned int>(useBasesMaskAndLane[0]),
                                        useBasesMaskAndLane[1]));
        }
        else
        {
            BCL2FASTQ_ASSERT_MSG(false, "Invalid use-bases-mask: " + useBasesMask);
        }
    }
}

void setReadMetadata(common::CycleNumber startCycle,
                     common::CycleNumber endCycle,
                     layout::ReadMetadata& readMetadata)
{
    if (endCycle >= 1)
    {
        readMetadata.lastCycle_ = readMetadata.firstCycle_ + (endCycle-1);
    }
    if (startCycle >= 1)
    {
        readMetadata.firstCycle_ += (startCycle-1);
    }
}

bool setIndexReadMetadata(const std::vector<size_t>& barcodeLengths,
                          layout::ReadMetadata&      readMetadata,
                          size_t                     indexNumber)
{
    if (barcodeLengths.size() > indexNumber)
    {
        if (barcodeLengths[indexNumber] > 1 + readMetadata.lastCycle_ - readMetadata.firstCycle_)
        {
            BOOST_THROW_EXCEPTION(common::InputDataError((boost::format(
                "Barcodes in sample sheet are longer than the index length found in RunInfo.xml.")).str()));
        }

        setReadMetadata(0,
                        barcodeLengths[indexNumber],
                        readMetadata);

        return barcodeLengths[indexNumber] != 0;
    }

    return false;
}

void setUmiReadMetadata(common::CycleNumber            umiLength,
                        common::ReadNumber             readNumber,
                        layout::ReadMetadata&          readMetadata,
                        layout::ReadMetadataContainer& readMetadataContainer)
{
    if (umiLength > 0)
    {
        common::CycleNumber readLength = readMetadata.lastCycle_ - readMetadata.firstCycle_ + 1;
        if (umiLength > readLength)
        {
            BOOST_THROW_EXCEPTION(common::InputDataError((boost::format("UMI length: %d longer than read length: %d ") % umiLength % readLength ).str()));
        }

        readMetadataContainer.push_back(layout::ReadMetadata(layout::ReadMetadata::Range(readMetadata.firstCycle_,
                                                                                         readMetadata.firstCycle_ + umiLength - 1),
                                                             readNumber,
                                                             common::ReadType::UMI));
        readMetadata.firstCycle_ += umiLength;
    }
}

void validateIndexLengths(const layout::ReadMetadataContainer& readMetadataContainer,
                          const std::vector<size_t>&           barcodeLengths,
                          layout::LaneInfo&                    laneInfo)
{
    std::vector<std::pair<size_t,size_t>> indexNumberLengthPairs;
    for (const auto& readMetadata : readMetadataContainer)
    {
        if (readMetadata.readType_ == common::ReadType::INDEX)
        {
            indexNumberLengthPairs.push_back(std::make_pair(readMetadata.lastCycle_ - readMetadata.firstCycle_ + 1, readMetadata.readNumber_));
        }
    }

    for (const std::pair<size_t,size_t> indexNumberLengthPair : indexNumberLengthPairs)
    {
        if (indexNumberLengthPair.second > 2)
        {
            BOOST_THROW_EXCEPTION(common::InputDataError("Greater than 2 index reads encountered in use-bases-mask. This is not allowed."));
        }

        if ((indexNumberLengthPairs.size() == 2 && barcodeLengths.at(indexNumberLengthPair.second - 1) != indexNumberLengthPair.first) ||
            (barcodeLengths[0] != indexNumberLengthPair.first && barcodeLengths[1] != indexNumberLengthPair.first))
        {
            BOOST_THROW_EXCEPTION(common::InputDataError("Barcode lengths in the sample sheet do not match those in --use-bases-mask"));
        }
    }

    if (indexNumberLengthPairs.empty())
    {
        // There are no index sequences
        if (barcodeLengths[0] != 0 && barcodeLengths[1] != 0)
        {
            laneInfo.maskBarcode(2);
            laneInfo.maskBarcode(1);
        }
        else if (barcodeLengths[0] != 0 || barcodeLengths[1] != 0)
        {
            laneInfo.maskBarcode(1);
        }
    }
    else if ((indexNumberLengthPairs.size() == 1 && barcodeLengths.size() == 2) &&
             (barcodeLengths[0] != 0 && barcodeLengths[1] != 0))
    {
        laneInfo.maskBarcode(indexNumberLengthPairs[0].second);
    }
}

void getReadMetaData(const RunInfoXml&              runInfoXml,
                     const std::vector<size_t>&     barcodeLengths,
                     const std::string&             useBasesMaskStr,
                     common::CycleNumber            read1StartCycle,
                     common::CycleNumber            read2StartCycle,
                     common::CycleNumber            read1EndCycle,
                     common::CycleNumber            read2EndCycle,
                     common::CycleNumber            read1UmiLength,
                     common::CycleNumber            read2UmiLength,
                     layout::LaneInfo&              laneInfo,
                     layout::ReadMetadataContainer& readMetadataContainer)
{
    layout::ReadMetadataContainer readMetadataContainerTmp =
        layout::ReadMetadataContainer(runInfoXml.readMetadataBegin(),
                                      runInfoXml.readMetadataEnd());

    size_t indexNumber = 0;
    common::ReadNumber readNumber = 1;
    for (auto& readMetadata : readMetadataContainerTmp)
    {
        if (readMetadata.readType_ == common::ReadType::INDEX)
        {
            if (!setIndexReadMetadata(barcodeLengths,
                                      readMetadata,
                                      indexNumber++))
            {
                continue;
            }
        }
        else
        {
            if (readNumber == 1)
            {
                setUmiReadMetadata(read1UmiLength,
                                   readNumber,
                                   readMetadata,
                                   readMetadataContainer);

                setReadMetadata(read1StartCycle,
                                read1EndCycle,
                                readMetadata);
            }
            else if (readNumber == 2)
            {
                setUmiReadMetadata(read2UmiLength,
                                   readNumber,
                                   readMetadata,
                                   readMetadataContainer);

                setReadMetadata(read2StartCycle,
                                read2EndCycle,
                                readMetadata);
            }

            ++readNumber;
        }
        readMetadataContainer.push_back(readMetadata);
    }

    if (!useBasesMaskStr.empty())
    {
        if (read1UmiLength != 0 || read2UmiLength != 0)
        {
            BOOST_THROW_EXCEPTION(common::InputDataError("Use of --use-bases-mask is not supported with a UMI sequence entered in the sample sheet."));
        }

        // useBasesMask overrides the data from RunInfoXml
        layout::UseBasesMask useBasesMask(useBasesMaskStr,
                                          runInfoXml.readMetadataBegin(),
                                          runInfoXml.readMetadataEnd());

        if (!useBasesMask.isEmpty())
        {
            readMetadataContainer = layout::ReadMetadataContainer(useBasesMask.readMetadataBegin(),
                                                                  useBasesMask.readMetadataEnd());

            if (!barcodeLengths.empty())
            {
                validateIndexLengths(readMetadataContainer,
                                     barcodeLengths,
                                     laneInfo);
            }
        }
    }
}

void detectReadLayout(const RunInfoXml&               runInfoXml,
                      const config::SampleSheetCsv&   sampleSheetCsv,
                      const std::vector<std::string>& useBasesMaskStrs,
                      size_t                          minimumTrimmedReadLength,
                      common::CycleNumber             read1StartCycle,
                      common::CycleNumber             read2StartCycle,
                      common::CycleNumber             read1EndCycle,
                      common::CycleNumber             read2EndCycle,
                      common::CycleNumber             read1UmiLength,
                      common::CycleNumber             read2UmiLength,
                      LaneInfosContainer&             lanes,
                      const std::vector<std::vector<size_t>>& barcodeLengthsForLane)
{
    std::map<common::LaneNumber, std::string> useBasesMasksForLane;
    std::string defaultUseBasesMask;
    parseUseBasesMasks(useBasesMaskStrs,
                       useBasesMasksForLane,
                       defaultUseBasesMask);

    BOOST_FOREACH(LaneInfo& laneInfo, lanes)
    {
        std::string useBasesMaskStr(defaultUseBasesMask);
        std::map<common::LaneNumber, std::string>::const_iterator pos = useBasesMasksForLane.find(laneInfo.getNumber());
        if (pos != useBasesMasksForLane.end())
        {
            useBasesMaskStr = pos->second;
        }

        BCL2FASTQ_LOG(common::LogLevel::INFO) << "Mask: " << useBasesMaskStr << std::endl;

        unsigned int totalAdapters = 0;
        size_t minimumNonIndexReadLength = minimumTrimmedReadLength;

        BCL2FASTQ_LOG(common::LogLevel::INFO) << "Lane: " << laneInfo.getNumber() << std::endl;

        layout::ReadMetadataContainer readMetadataContainer;
        getReadMetaData(runInfoXml,
                        barcodeLengthsForLane[laneInfo.getNumber()-1],
                        useBasesMaskStr,
                        read1StartCycle,
                        read2StartCycle,
                        read1EndCycle,
                        read2EndCycle,
                        read1UmiLength,
                        read2UmiLength,
                        laneInfo,
                        readMetadataContainer);

        BOOST_FOREACH (const layout::ReadMetadata &readMetadata, readMetadataContainer)
        {
            // read
            ReadInfo readInfo(readMetadata.readNumber_, readMetadata.readType_);

            BCL2FASTQ_LOG(common::LogLevel::INFO) << "Read: " << readInfo.getNumber() << " " << readInfo.getReadType() << std::endl;

            // cycles
            std::ostringstream cycles;
            for (common::CycleNumber cycleNumber = readMetadata.firstCycle_; cycleNumber <= readMetadata.lastCycle_; ++cycleNumber)
            {
                CycleInfo cycleInfo(cycleNumber);
                readInfo.addCycle(cycleInfo);

                if (!cycles.str().empty())
                {
                    cycles << ",";
                }
                cycles << cycleInfo.getNumber();
            }
            BCL2FASTQ_LOG(common::LogLevel::INFO) << "  Cycles: " << cycles.str() << std::endl;

            // adapters
            if (readInfo.isDataRead())
            {
                size_t readLength = readMetadata.lastCycle_ - readMetadata.firstCycle_ + 1;
                if (readLength < minimumTrimmedReadLength)
                {
                    minimumNonIndexReadLength = readLength;
                }

                totalAdapters += addAdaptersToRead(sampleSheetCsv.maskAdaptersBegin(), sampleSheetCsv.maskAdaptersEnd(), readInfo, MASK);
                totalAdapters += addAdaptersToRead(sampleSheetCsv.trimAdaptersBegin(), sampleSheetCsv.trimAdaptersEnd(), readInfo, TRIM);
            }

            laneInfo.addRead(readInfo);
        }
        BCL2FASTQ_LOG(common::LogLevel::DEBUG) << "Total number of adapters: " << totalAdapters << std::endl;

        if (minimumTrimmedReadLength > minimumNonIndexReadLength)
        {
            BCL2FASTQ_LOG(common::LogLevel::WARNING) << "Option: '--minimum-trimmed-read-length' with value: "
                                                     << minimumTrimmedReadLength
                                                     << " is being overwritten by the shortest non-index read length: "
                                                     << minimumNonIndexReadLength << std::endl;

            minimumTrimmedReadLength = minimumNonIndexReadLength;
        }

        laneInfo.setMinimumTrimmedReadLength(minimumTrimmedReadLength);
    }
}

typedef std::map<std::string, std::pair<common::LaneNumber, SampleInfo>> SampleMap;

const std::string& getSampleName(const std::string& sampleName, const std::string& sampleId)
{
    return sampleName.empty() ?
        (sampleId.empty() ? SampleInfo::defaultName : sampleId) :
         sampleName;
}

void checkForDuplicateSample(const std::string& sampleId,
                             const SampleInfo& sample1,
                             const SampleInfo& sample2,
                             common::LaneNumber laneNumber1,
                             common::LaneNumber laneNumber2)
{
    if (laneNumber1 == laneNumber2)
    {
        BOOST_THROW_EXCEPTION(common::InputDataError((boost::format(
            "Identical sample ID used multiple times: '" + sampleId + "'.")).str()));
    }
    if (sample1.getProject() != sample2.getProject())
    {
        BOOST_THROW_EXCEPTION(common::InputDataError((boost::format(
           "Only 1 project is allowed for a given sampleId. SampleId: '" + sampleId + "'.")).str()));
    }
    if (sample1.getName() != sample2.getName())
    {
        BOOST_THROW_EXCEPTION(common::InputDataError((boost::format(
            "Only 1 sample name is allowed for a given sampleId. SampleId: '" + sampleId + "'.")).str()));
    }
    if (sample1.getBarcodes() != sample2.getBarcodes())
    {
        BOOST_THROW_EXCEPTION(common::InputDataError((boost::format(
            "Only 1 barcode is allowed for a given sampleId. SampleId: '" + sampleId + "'.")).str()));
    }
}

void handleDuplicateSampleId(SampleMap& sampleMap,
                             SampleInfo& sample,
                             common::LaneNumber laneNumber,
                             common::SampleNumber& sampleNumber)
{
    std::pair<SampleMap::iterator, bool> pos = sampleMap.insert(std::make_pair(sample.getId(), std::make_pair(laneNumber, sample)));
    if (!pos.second)
    {
        // Duplicate sample id.
        sample.setNumber(pos.first->second.second.getNumber());

        checkForDuplicateSample(sample.getId(), sample, pos.first->second.second, laneNumber, pos.first->second.first);

        pos.first->second.first = laneNumber;
    }
    else
    {
        ++sampleNumber;
    }
}

void handleDefaultSample(bool hasBarcodes,
                         bool hasNoSamples,
                         size_t numSamplesInLane,
                         LaneInfo& laneInfo,
                         bool& sampleWithoutBarcodesInLane)
{
    if (hasBarcodes)
    {
        if (hasNoSamples)
        {
            SampleInfo defaultSample;
            laneInfo.addSample(defaultSample);
            BCL2FASTQ_LOG(common::LogLevel::INFO) << "  Sample: " << defaultSample << std::endl;
        }
    }
    else
    {
        sampleWithoutBarcodesInLane = true;
    }

    if (sampleWithoutBarcodesInLane && numSamplesInLane != 1)
    {
        BOOST_THROW_EXCEPTION(common::InputDataError((boost::format("Missing a barcode in lane %d") % laneInfo.getNumber()).str()));
    }
}

void addSamplesForLane(const common::SampleMetadataContainer& sampleMetadataContainer,
                       SampleMap& sampleMap,
                       BarcodeCollisionDetector& barcodeCollisionDetector,
                       common::SampleNumber& sampleNumber,
                       LaneInfo& laneInfo,
                       std::vector<size_t>& barcodeLengths)
{
    common::LaneNumber laneNumber = laneInfo.getNumber();

    size_t numSamplesInLane = 0;
    bool sampleWithoutBarcodesInLane = false;
    for (const auto& sampleMetadata : sampleMetadataContainer)
    {
        if (!sampleMetadata.lanes_.empty() &&
            std::find(sampleMetadata.lanes_.begin(), sampleMetadata.lanes_.end(), laneNumber) == sampleMetadata.lanes_.end())
        {
            // SampleSheet.csv specified a lane for this sample, and this lane is not it.
            continue;
        }

        ++numSamplesInLane;

        bool hasBarcodes       = !sampleMetadata.barcodes_.empty();
        std::string sampleId   = sampleMetadata.id_.empty() ? SampleInfo::defaultId : sampleMetadata.id_;
        std::string sampleName = getSampleName(sampleMetadata.name_, sampleMetadata.id_);

        handleDefaultSample(hasBarcodes,
                            laneInfo.sampleInfosBegin() == laneInfo.sampleInfosEnd(),
                            numSamplesInLane,
                            laneInfo,
                            sampleWithoutBarcodesInLane);

        SampleInfo sample(sampleNumber,
                          sampleId,
                          sampleName,
                          sampleMetadata.project_.empty() ? SampleInfo::defaultProject : sampleMetadata.project_);

        handleDuplicateSampleId(sampleMap,
                                sample,
                                laneNumber,
                                sampleNumber);

        BCL2FASTQ_LOG(common::LogLevel::INFO) << "  Sample: " << sample << std::endl;

        if( hasBarcodes )
        {
            addBarcodesToSample( sampleMetadata.barcodes_,
                                 sample,
                                 barcodeCollisionDetector,
                                 barcodeLengths );
        }

        laneInfo.addSample(sample);
    }
}

void detectLaneLayout(const layout::RunInfoXml&                       runInfoXml,
                      const config::SampleSheetCsv&                   sampleSheetCsv,
                      const boost::filesystem::path&                  inputDir,
                      bool                                            autoSetToZeroMismatches,
                      const std::vector<std::size_t>::const_iterator& componentMaxMismatchesBegin,
                      const std::vector<std::size_t>::const_iterator& componentMaxMismatchesEnd,
                      bool                                            hasConfigXml,
                      bool&                                           hasBci,
                      LaneInfosContainer&                             lanes,
                      std::vector<std::vector<size_t>>&               barcodeLengthsForLane)
{
    common::SampleNumber sampleNumber = 1;
    SampleMap sampleMap;

    const common::LaneNumber lanesCount = runInfoXml.getLanesCount();
    for (common::LaneNumber laneNumber = 1; laneNumber <= lanesCount; ++laneNumber)
    {
        BarcodeCollisionDetector barcodeCollisionDetector(componentMaxMismatchesBegin,
                                                          componentMaxMismatchesEnd,
                                                          autoSetToZeroMismatches);

        // lane
        LaneInfo laneInfo(laneNumber);
        BCL2FASTQ_LOG(common::LogLevel::INFO) << "Lane: " << laneInfo.getNumber() << std::endl;

        barcodeLengthsForLane.resize(barcodeLengthsForLane.size() + 1);
        if (sampleSheetCsv.getSampleMetadata().empty())
        {
            // Add a default sample
            laneInfo.addSample(SampleInfo());
        }
        else
        {
            addSamplesForLane(sampleSheetCsv.getSampleMetadata(),
                              sampleMap,
                              barcodeCollisionDetector,
                              sampleNumber,
                              laneInfo,
                              barcodeLengthsForLane.back());

        }

        if (laneInfo.sampleInfosBegin() != laneInfo.sampleInfosEnd())
        {
            hasBci = hasBci || checkBciExistence( inputDir / laneInfo.getDirName() );
            lanes.push_back(laneInfo);
        }
    }

    BCL2FASTQ_LOG(common::LogLevel::DEBUG) << "Has BCI: " << hasBci << std::endl;
    BCL2FASTQ_LOG(common::LogLevel::DEBUG) << "Has 'config.xml': " << hasConfigXml << std::endl;
}

void readTilesFromRunInfoXmlForLane(const layout::RunInfoXml&        runInfoXml,
                                    const config::SampleSheetCsv&    sampleSheet,
                                    const std::vector<boost::regex>& tileRegexps,
                                    common::LaneNumber               laneNumber,
                                    LaneInfo&                        laneInfo)
{
    size_t skippedTiles = 0;
    size_t tileIndex = 0;
    BOOST_FOREACH (const common::TileNumber &tileNumber,
                   std::make_pair( runInfoXml.tileNumbersBegin( laneNumber ),
                                   runInfoXml.tileNumbersEnd( laneNumber )) )
    {
        if ( includeTile(runInfoXml.getFlowcellId(), laneNumber, tileNumber, tileRegexps, sampleSheet) )
        {
            TileInfo tileInfo(tileNumber, tileIndex, skippedTiles);
            laneInfo.addTile(tileInfo);
            skippedTiles = 0;
        }
        else
        {
            ++skippedTiles;
        }
        ++tileIndex;
    }
}

void readTilesFromRunInfoXml(const layout::RunInfoXml&        runInfoXml,
                             const config::SampleSheetCsv&    sampleSheet,
                             const std::vector<boost::regex>& tileRegexps,
                             std::vector<LaneInfo>&           lanes)
{
    BOOST_FOREACH (LaneInfo &laneInfo, std::make_pair(lanes.begin(), lanes.end()))
    {
        common::LaneNumber laneNumber = laneInfo.getNumber();
        BCL2FASTQ_ASSERT_MSG( 1 <= laneNumber && laneNumber <= runInfoXml.getLanesCount(), "Lane '" << laneNumber << "' is out of range");
        BCL2FASTQ_LOG(common::LogLevel::INFO) << "Lane: " << laneNumber << std::endl;

        readTilesFromRunInfoXmlForLane(runInfoXml,
                                       sampleSheet,
                                       tileRegexps,
                                       laneNumber,
                                       laneInfo);
    }
}

void readTilesFromBciFile(const boost::filesystem::path&   inputDir,
                          const config::SampleSheetCsv&    sampleSheet,
                          const std::vector<boost::regex>& tileRegexps,
                          const std::string&               flowcellId,
                          std::vector<LaneInfo>&           lanes)
{
    BOOST_FOREACH (LaneInfo &laneInfo, std::make_pair(lanes.begin(), lanes.end()))
    {
        size_t skippedTiles = 0;
        size_t skippedClusters = 0;
        size_t tileIndex = 0;
        common::LaneNumber laneNumber = laneInfo.getNumber();
        if (checkBciFile(inputDir, laneNumber))
        {
            const BCIndex bcIndex = createBCIndex(inputDir, laneInfo.getNumber());
            BOOST_FOREACH (const BCIndex::TileMetadata &tileMetadata, std::make_pair(bcIndex.tileMetadataBegin(), bcIndex.tileMetadataEnd()))
            {
                if ( includeTile(flowcellId, laneNumber, tileMetadata.tileNumber_, tileRegexps, sampleSheet) )
                {
                    TileInfo tileInfo(tileMetadata.tileNumber_, tileIndex, tileMetadata.clustersCount_, skippedTiles, skippedClusters);
                    laneInfo.addTile(tileInfo);
                    skippedTiles = 0;
                    skippedClusters = 0;
                }
                else
                {
                    ++skippedTiles;
                    skippedClusters += tileMetadata.clustersCount_;
                }
                ++tileIndex;
            }
        }
    }
}

void readTilesFromConfigXmlOrRunInfoXml(const boost::filesystem::path&   inputDir,
                                        const layout::RunInfoXml&        runInfoXml,
                                        const config::SampleSheetCsv&    sampleSheet,
                                        const std::vector<boost::regex>& tileRegexps,
                                        std::vector<LaneInfo>&           lanes)
{
    BCL2FASTQ_LOG(common::LogLevel::DEBUG) << "This may be a 'HiSeq 2000' / 'MiSeq' run" << std::endl;
    const ConfigXml configXml = createConfigXml(inputDir);
    BOOST_FOREACH (LaneInfo &laneInfo, std::make_pair(lanes.begin(), lanes.end()))
    {
        size_t skippedTiles = 0;
        size_t tileIndex = 0;
        common::LaneNumber laneNumber = laneInfo.getNumber();
        BCL2FASTQ_LOG(common::LogLevel::INFO) << "Lane: " << laneNumber << std::endl;

        if (configXml.containsLaneNumber(laneNumber))
        {
            BOOST_FOREACH (const ConfigXml::TileMetadata &tileMetadata,
                           std::make_pair(configXml.tileMetadataBegin(laneInfo.getNumber()),
                                          configXml.tileMetadataEnd(laneInfo.getNumber())) )
            {
                if ( includeTile(runInfoXml.getFlowcellId(), laneNumber, tileMetadata.tileNumber_, tileRegexps, sampleSheet) )
                {
                    TileInfo tileInfo(tileMetadata.tileNumber_, tileIndex, skippedTiles);
                    laneInfo.addTile(tileInfo);
                    skippedTiles = 0;
                }
                else
                {
                    ++skippedTiles;
                }
                ++tileIndex;
            }
        }
        else
        {
            readTilesFromRunInfoXmlForLane(runInfoXml,
                                           sampleSheet,
                                           tileRegexps,
                                           laneNumber,
                                           laneInfo);
        }
    }
}

void detectTileLayout(const std::vector<std::string>& tilesFilterList,
                      const layout::RunInfoXml&       runInfoXml,
                      const config::SampleSheetCsv&   sampleSheet,
                      const boost::filesystem::path&  inputDir,
                      std::vector<LaneInfo>&          lanes,
                      bool                            flowcellAggregateTilesFlag,
                      bool                            hasConfigXml)
{
    std::vector<boost::regex> tileRegexps;
    BOOST_FOREACH(const std::string &tileRegex, tilesFilterList)
    {
        tileRegexps.push_back(boost::regex(tileRegex));
    }
    if ( !flowcellAggregateTilesFlag )
    {
        if( hasConfigXml )
        {
            readTilesFromConfigXmlOrRunInfoXml(inputDir,
                                               runInfoXml,
                                               sampleSheet,
                                               tileRegexps,
                                               lanes);
        } else {  // !hasConfigXml
            readTilesFromRunInfoXml(runInfoXml,
                                    sampleSheet,
                                    tileRegexps,
                                    lanes);
        }
    } else {  // flowcellInfo.getAggregateTilesFlag()
        readTilesFromBciFile(inputDir,
                             sampleSheet,
                             tileRegexps,
                             runInfoXml.getFlowcellId(),
                             lanes);
    }
}

Layout detectLayout(
    const boost::filesystem::path& runfolderDir,
    const boost::filesystem::path& intensitiesDir,
    const boost::filesystem::path& inputDir,
    const boost::filesystem::path& outputDir,
    const boost::filesystem::path& reportsDir,
    const boost::filesystem::path& statsDir,
    const config::SampleSheetCsv& sampleSheet,
    boost::optional<bool> tilesAggregationFlag,
    const std::vector<std::string> & tilesFilterList,
    const std::vector<std::string>& useBasesMasks,
    size_t minimumTrimmedReadLength,
    bool autoSetToZeroMismatches,
    const std::vector<std::size_t>::const_iterator& componentMaxMismatchesBegin,
    const std::vector<std::size_t>::const_iterator& componentMaxMismatchesEnd,
    bool ignoreMissingBcls,
    bool ignoreMissingFilters,
    bool ignoreMissingPositions,
    common::CycleNumber read1StartCycle,
    common::CycleNumber read2StartCycle,
    common::CycleNumber read1EndCycle,
    common::CycleNumber read2EndCycle,
    common::CycleNumber read1UmiLength,
    common::CycleNumber read2UmiLength
)
{
    common::DirectoryValidator::getSingleton().addUniquePath(reportsDir, "Reports");
    common::DirectoryValidator::getSingleton().addUniquePath(statsDir, "Stats");

    const layout::RunInfoXml runInfoXml = layout::createRunInfoXml(runfolderDir);

    Layout layout;

    bool hasConfigXml = checkConfigXml(inputDir);

    bool hasBci = false;
    std::vector<LaneInfo> lanes;
    std::vector<std::vector<size_t>> barcodeLengthsForLane;
    detectLaneLayout(runInfoXml,
                     sampleSheet,
                     inputDir,
                     autoSetToZeroMismatches,
                     componentMaxMismatchesBegin,
                     componentMaxMismatchesEnd,
                     hasConfigXml,
                     hasBci,
                     lanes,
                     barcodeLengthsForLane);

    detectReadLayout(runInfoXml,
                     sampleSheet,
                     useBasesMasks,
                     minimumTrimmedReadLength,
                     read1StartCycle,
                     read2StartCycle,
                     read1EndCycle,
                     read2EndCycle,
                     read1UmiLength,
                     read2UmiLength,
                     lanes,
                     barcodeLengthsForLane);

    bool flowcellAggregateTilesFlag = false;
    detectFlowcellInfo(intensitiesDir,
                       runInfoXml,
                       tilesAggregationFlag,
                       hasBci,
                       layout,
                       flowcellAggregateTilesFlag);

    detectTileLayout(tilesFilterList,
                     runInfoXml,
                     sampleSheet,
                     inputDir,
                     lanes,
                     flowcellAggregateTilesFlag,
                     hasConfigXml);

    BOOST_FOREACH (LaneInfo &laneInfo, std::make_pair(lanes.begin(), lanes.end()))
    {
         if (laneInfo.tileInfosBegin() == laneInfo.tileInfosEnd())
         {
             continue;
         }

         FileExistenceVerifier::verifyAllFilesExist(inputDir,
                                                    intensitiesDir,
                                                    laneInfo,
                                                    flowcellAggregateTilesFlag,
                                                    layout.getFlowcellInfo().isPatternedFlowcell(),
                                                    ignoreMissingBcls,
                                                    ignoreMissingFilters,
                                                    ignoreMissingPositions);

        layout.addLane(laneInfo);
    }

    return layout;
}


} // namespace layout


} // namespace bcl2fastq


