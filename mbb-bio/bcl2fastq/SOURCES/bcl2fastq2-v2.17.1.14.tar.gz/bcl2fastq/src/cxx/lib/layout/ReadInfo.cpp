/**
 * BCL to FASTQ file converter
 * Copyright (c) 2007-2015 Illumina, Inc.
 *
 * This software is covered by the accompanying EULA
 * and certain third party copyright/licenses, and any user of this
 * source file is bound by the terms therein.
 *
 * \file ReadInfo.cpp
 *
 * \brief Implementation of read metadata.
 *
 * \author Marek Balint
 */


#include "layout/ReadInfo.hh"


namespace bcl2fastq {


namespace layout {


ReadInfo::ReadInfo(common::ReadNumber number, common::ReadType readType)
: number_(number)
, readType_(readType)
, cycleInfos_()
, maskAdapters_()
, trimAdapters_()
{
}

} // namespace layout


} // namespace bcl2fastq


