/**
 * BCL to FASTQ file converter
 * Copyright (c) 2007-2015 Illumina, Inc.
 *
 * This software is covered by the accompanying EULA
 * and certain third party copyright/licenses, and any user of this
 * source file is bound by the terms therein.
 *
 * \file FastqIterator.hpp
 *
 * \brief Implementation of FASTQ iterator.
 *
 * \author Marek Balint
 */


#ifndef BCL2FASTQ_CONVERSION_FASTQITERATOR_HPP
#define BCL2FASTQ_CONVERSION_FASTQITERATOR_HPP


#include "conversion/FastqIterator.hh"


namespace bcl2fastq {


namespace conversion {


template<bool IsConstant>
FastqIteratorTemplate<IsConstant>::FastqIteratorTemplate()
: iterator_()
, offset_(0)
{
}

template<bool IsConstant>
FastqIteratorTemplate<IsConstant>::FastqIteratorTemplate(
    typename boost::mpl::if_c<
        IsConstant,
        BclBuffer::BclsContainer::const_iterator,
        BclBuffer::BclsContainer::iterator
    >::type iterator,
    BclBuffer::BclsContainer::value_type::size_type offset
)
: iterator_(iterator)
, offset_(offset)
{
}

template<bool IsConstant>
FastqIteratorTemplate<IsConstant>::operator FastqIteratorTemplate<true>() const
{
    return FastqIteratorTemplate<true>(
        iterator_,
        offset_
    );
}

template<bool IsConstant>
typename FastqIteratorTemplate<IsConstant>::reference FastqIteratorTemplate<IsConstant>::dereference() const
{
    return iterator_->begin()[offset_];
}

template<bool IsConstant>
template<bool IsRhsConstant>
bool FastqIteratorTemplate<IsConstant>::equal(const FastqIteratorTemplate<IsRhsConstant> &rhs) const
{
    return (iterator_ == rhs.iterator_) && (offset_ == rhs.offset_);
}

template<bool IsConstant>
void FastqIteratorTemplate<IsConstant>::increment()
{
    ++iterator_;
}

template<bool IsConstant>
void FastqIteratorTemplate<IsConstant>::decrement()
{
    --iterator_;
}

template<bool IsConstant>
void FastqIteratorTemplate<IsConstant>::advance(typename FastqIteratorTemplate<IsConstant>::difference_type diff)
{
    iterator_ += diff;
}

template<bool IsConstant>
template<bool IsRhsConstant>
typename FastqIteratorTemplate<IsConstant>::difference_type FastqIteratorTemplate<IsConstant>::distance_to(const FastqIteratorTemplate<IsRhsConstant> &rhs) const
{
    return rhs.iterator_ - iterator_;
}


} // namespace conversion


} // namespace bcl2fastq


#endif // BCL2FASTQ_CONVERSION_FASTQITERATOR_HPP


