//
//  fakeoptimatrix.hpp
//  Mothur
//
//  Created by Sarah Westcott on 4/20/17.
//  Copyright © 2017 Schloss Lab. All rights reserved.
//

#ifndef fakeoptimatrix_hpp
#define fakeoptimatrix_hpp

#include "optimatrix.h"

class FakeOptiMatrix : public OptiMatrix {
    
public:
    FakeOptiMatrix(); 
    ~FakeOptiMatrix(){ }
};


#endif /* fakeoptimatrix_hpp */
