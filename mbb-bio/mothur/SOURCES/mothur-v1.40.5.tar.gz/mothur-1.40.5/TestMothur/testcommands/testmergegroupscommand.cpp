//
//  testmergegroupscommand.cpp
//  Mothur
//
//  Created by Sarah Westcott on 7/29/15.
//  Copyright (c) 2015 Schloss Lab. All rights reserved.
//

#include "testmergegroupscommand.h"


/*
TEST_CASE("Testing MergeGroupsCommand Class") {
    TestMergeGroupsCommand tMergeGroupsCommand;
    
    //how do we unit test this??
    //each private function reads files processes them and writes new ones.
}

*/
