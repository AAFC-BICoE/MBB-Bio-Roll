//
//  testgetgroupscommand.cpp
//  Mothur
//
//  Created by Sarah Westcott on 7/30/15.
//  Copyright (c) 2015 Schloss Lab. All rights reserved.
//

#include "testgetgroupscommand.h"

/*

TEST_CASE("Testing GetGroupsCommand Class") {
    TestGetGroupsCommand tGetGroupsCommand;
    
    //how do we unit test this??
    //each private function reads files processes them and writes new ones.
}
*/
