//
//  testremovegroupscommand.cpp
//  Mothur
//
//  Created by Sarah Westcott on 7/30/15.
//  Copyright (c) 2015 Schloss Lab. All rights reserved.
//

#include "testremovegroupscommand.h"
#include "catch.hpp"


TEST_CASE("Testing RemoveGroupsCommand Class") {
    TestRemoveGroupsCommand tRemoveGroupsCommand;
    
    //how do we unit test this??
    //each private function reads files processes them and writes new ones.
}
