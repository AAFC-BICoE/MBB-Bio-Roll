//
//  testtrimoligos.cpp
//  Mothur
//
//  Created by Sarah Westcott on 7/14/16.
//  Copyright © 2016 Schloss Lab. All rights reserved.
//

#include "catch.hpp"
#include "testtrimoligos.hpp"

/**************************************************************************************************/
TestTrimOligos::TestTrimOligos() {  //setup
    m = MothurOut::getInstance();
    
    //set up barcodes, primers, pairedBarcodes and pairedPrimers
    
    //Set up vector of seqs with barcodes and primers
    
    //Set up vector of seqs with pairedbarcodes and pairedprimers
    
}
/**************************************************************************************************/
TestTrimOligos::~TestTrimOligos() {
    
}
/**************************************************************************************************/

TEST_CASE("Testing TrimOligos Class") {
    TestTrimOligos testTrim;
    
    
    //Create trimoligos classes with various constructors
    
    
    //run all public strip functions
    
    
    //run private functions
    
    
}
/**************************************************************************************************/
