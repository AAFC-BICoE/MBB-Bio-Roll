//
//  regularizeddecisiontree.h
//  Mothur
//
//  Created by Kathryn Iverson on 11/16/12.
//  Copyright (c) 2012 Schloss Lab. All rights reserved.
//

#ifndef __Mothur__regularizeddecisiontree__
#define __Mothur__regularizeddecisiontree__

#include <iostream>
#include "rftreenode.hpp"
#include "abstractdecisiontree.hpp"

#endif /* defined(__Mothur__regularizeddecisiontree__) */
