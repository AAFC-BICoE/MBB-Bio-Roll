#ifndef WARNINGS_H_
#define WARNINGS_H_

#define SUPPRESS_UNUSED_WARNING(a) (void)a

#endif
