#ifndef LOG_H
#define LOG_H 1

#include <ostream>

std::ostream& logger(int level);

#endif
