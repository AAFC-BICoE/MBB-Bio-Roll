#include "ContigID.h"

Dictionary g_contigNames;

unsigned g_nextContigName;
