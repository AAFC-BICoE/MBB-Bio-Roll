#ifndef SIGNALHANDLER_H
#define SIGNALHANDLER_H 1

void signalInit();

#endif
