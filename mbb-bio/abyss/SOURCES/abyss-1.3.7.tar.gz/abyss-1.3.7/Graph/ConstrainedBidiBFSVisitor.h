#ifndef CONSTRAINED_BIDI_BFS_VISITOR_H
#define CONSTRAINED_BIDI_BFS_VISITOR_H

#include "Common/UnorderedMap.h"
#include "Common/UnorderedSet.h"
#include "Common/IOUtil.h"
#include "Graph/Path.h"
#include "Graph/HashGraph.h"
#include "Graph/BidirectionalBFSVisitor.h"
#include "Graph/AllPathsSearch.h"
#include <boost/graph/graph_traits.hpp>
#include <iostream>
#include <sstream>
#include <vector>
#include <algorithm>

template <typename G>
class ConstrainedBidiBFSVisitor : public BidirectionalBFSVisitor<G>
{

protected:

	typedef typename boost::graph_traits<G>::vertex_descriptor V;
	typedef typename boost::graph_traits<G>::edge_descriptor E;
	typedef unsigned short depth_t;
	typedef std::vector< Path<V> > PathList;
	typedef unordered_map<V, depth_t, hash<V> > DepthMap;

	struct EdgeHash {
		const G& m_g;
		EdgeHash(const G& g) : m_g(g) { }
		std::size_t operator()(const E& e) const {
			V u = source(e, m_g);
			V v = target(e, m_g);
			return hash<V>()(u) ^ hash<V>()(v);
		}
	};

	typedef unordered_set<E, EdgeHash> EdgeSet;

	const G& m_graph;
	const V& m_start;
	const V& m_goal;
	unsigned m_maxPaths;

	/** records history of forward/reverse traversals */
	HashGraph<V> m_traversalGraph[2];

	/** records depth of vertices during forward/reverse traversal */
	DepthMap m_depthMap[2];

	/** depth limits for forward/reverse traversal */
	depth_t m_maxDepth[2];

	/** max depth for forward/reverse traversal */
	depth_t m_maxDepthVisited[2];

	depth_t m_minPathLength;
	depth_t m_maxPathLength;
	bool m_tooManyPaths;

	/** edges that connect the forward and reverse traversals */
	EdgeSet m_commonEdges;

	PathList m_pathsFound;

public:

	ConstrainedBidiBFSVisitor(
		const G& graph,
		const V& start,
		const V& goal,
		unsigned maxPaths,
		depth_t minPathLength,
		depth_t maxPathLength) :
			m_graph(graph),
			m_start(start),
			m_goal(goal),
			m_maxPaths(maxPaths),
			m_minPathLength(minPathLength),
			m_maxPathLength(maxPathLength),
			m_tooManyPaths(false),
			m_commonEdges(m_maxPaths, EdgeHash(m_graph))
	{

		depth_t maxDepth = maxPathLength - 1;
		m_maxDepth[FORWARD] = maxDepth / 2 + maxDepth % 2;
		m_maxDepth[REVERSE] = maxDepth / 2;

		m_maxDepthVisited[FORWARD] = 0;
		m_maxDepthVisited[REVERSE] = 0;

		// special case
		if (start == goal) {
			Path<V> path;
			path.push_back(start);
			m_pathsFound.push_back(path);
		}
	}

#if 0
	// for debugging
	void examine_vertex(const V& v, const G& g, Direction dir)
	{
		SUPPRESS_UNUSED_WARNING(g);
		std::cout << "visiting vertex: " << v << " from dir: " << dir << "\n";
	}

	void examine_edge(const E& e, const G& g, Direction dir)
	{
		SUPPRESS_UNUSED_WARNING(g);
		std::cout << "visiting edge: " << e << " from dir: " << dir << "\n";
	}
#endif

	BFSVisitorResult tree_edge(const E& e, const G& g, Direction dir)
	{
		if (!updateTargetDepth(e, g, dir))
			return SKIP_ELEMENT;

		recordEdgeTraversal(e, g, dir);
		return SUCCESS;
	}

	BFSVisitorResult non_tree_edge(const E& e, const G& g, Direction dir)
	{
		recordEdgeTraversal(e, g, dir);
		return SUCCESS;
	}

	BFSVisitorResult common_edge(const E& e, const G& g, Direction dir)
	{
		V u = source(e, g);
		V v = target(e, g);

		const V& parent = (dir == FORWARD) ? u : v;

		if (m_depthMap[dir][parent] >= m_maxDepth[dir])
			return SKIP_ELEMENT;

		return recordCommonEdge(e);
	}

	PathSearchResult uniquePathToGoal(Path<V>& path)
	{
		std::vector< Path<V> > paths;
		PathSearchResult result = pathsToGoal(paths);
		if (paths.size() > 1) {
			return TOO_MANY_PATHS;
		} else if (result == FOUND_PATH && paths.size() == 1) {
			path = paths[0];
			return FOUND_PATH;
		}
		return result;
	}

	PathSearchResult pathsToGoal(PathList& pathsFound)
	{
		if (m_tooManyPaths)
			return TOO_MANY_PATHS;

		buildPaths();

		if (m_tooManyPaths) {
			return TOO_MANY_PATHS;
		}
		else if (m_pathsFound.empty()) {
			return NO_PATH;
		} else {
			pathsFound = m_pathsFound;
			return FOUND_PATH;
		}
	}

	depth_t getMaxDepthVisited(Direction dir)
	{
		return m_maxDepthVisited[dir];
	}

protected:

	BFSVisitorResult recordCommonEdge(const E& e)
	{
		m_commonEdges.insert(e);
		if (m_maxPaths != NO_LIMIT &&
			m_commonEdges.size() > m_maxPaths) {
			m_tooManyPaths = true;
			return ABORT_SEARCH;
		}
		return SUCCESS;
	}

	/**
	 * Record history of edge traversal, so that we can retrace
	 * paths from a common edge to start/goal.
	 */
	void recordEdgeTraversal(const E& e, const G& g, Direction dir)
	{
		V u = source(e, g);
		V v = target(e, g);

		if (dir == FORWARD)
			add_edge(v, u, m_traversalGraph[FORWARD]);
		else
			add_edge(u, v, m_traversalGraph[REVERSE]);
	}

	/**
	 * Record the depth of a newly visited vertex.
	 * @return true if the vertex is visitable is less than the max
	 * depth limit false otherwise.
	 */
	bool updateTargetDepth(const E& e, const G& g, Direction dir)
	{
		const V& parent = (dir == FORWARD) ? source(e, g) : target(e, g);
		const V& child = (dir == FORWARD) ? target(e, g) : source(e, g);

		depth_t parentDepth = m_depthMap[dir][parent];
		if (parentDepth == m_maxDepth[dir])
			return false;

		depth_t childDepth = parentDepth + 1;
		m_depthMap[dir][child] = childDepth;

		if (childDepth > m_maxDepthVisited[dir])
			m_maxDepthVisited[dir] = childDepth;

		return true;
	}

	void buildPaths()
	{
		typename EdgeSet::const_iterator i = m_commonEdges.begin();
		for (; i != m_commonEdges.end(); i++) {
			if (buildPaths(*i) == TOO_MANY_PATHS)
				break;
		}
	}

	PathSearchResult buildPaths(const E& common_edge)
	{
		V u = source(common_edge, m_graph);
		V v = target(common_edge, m_graph);

		// find paths from common edge to start vertex (forward traversal)

		unsigned maxPathsToStart = m_maxPaths - m_pathsFound.size();

		PathList pathsToStart;
		PathSearchResult result = allPathsSearch(
			m_traversalGraph[FORWARD], u, m_start, maxPathsToStart,
			0, m_maxDepth[FORWARD], pathsToStart);

		if (result == FOUND_PATH) {

			// find paths from common edge to goal vertex (reverse traversal)

			unsigned maxPathsToGoal =
				(m_maxPaths - m_pathsFound.size()) / pathsToStart.size();

			PathList pathsToGoal;
			result = allPathsSearch(m_traversalGraph[REVERSE], v, m_goal,
				maxPathsToGoal, 0, m_maxDepth[REVERSE], pathsToGoal);

			if (result == FOUND_PATH)
				buildPaths(pathsToStart, pathsToGoal);

		} // result == FOUND_PATH (common edge => start)

		if (result == TOO_MANY_PATHS)
			m_tooManyPaths = true;

		return result;
	}

	void buildPaths(const PathList& pathsToStart, const PathList& pathsToGoal)
	{
		typename PathList::const_iterator pathToStart = pathsToStart.begin();
		for (; pathToStart != pathsToStart.end(); pathToStart++) {
			typename PathList::const_iterator pathToGoal = pathsToGoal.begin();
			for(; pathToGoal != pathsToGoal.end(); pathToGoal++) {
				if (pathToStart->size() + pathToGoal->size() < m_minPathLength ||
					pathToStart->size() + pathToGoal->size() > m_maxPathLength)
					continue;
				m_pathsFound.push_back(*pathToStart);
				Path<V>& mergedPath = m_pathsFound.back();
				reverse(mergedPath.begin(), mergedPath.end());
				m_pathsFound.back().insert(mergedPath.end(),
					pathToGoal->begin(), pathToGoal->end());
			}
		}
	}

};

#endif /* CONSTRAINED_BFS_VISITOR_H */
