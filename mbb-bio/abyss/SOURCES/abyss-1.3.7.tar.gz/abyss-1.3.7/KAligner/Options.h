#ifndef ALIGN_OPTIONS_H
#define ALIGN_OPTIONS_H 1

namespace opt {
	enum { IGNORE, MULTIMAP, ERROR };
	extern int multimap;
}

#endif
