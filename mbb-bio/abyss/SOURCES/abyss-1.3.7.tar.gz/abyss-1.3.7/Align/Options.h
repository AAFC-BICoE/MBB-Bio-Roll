#ifndef ALIGN_OPTIONS
#define ALIGN_OPTIONS 1

namespace opt {
	extern int match;
	extern int mismatch;
	extern int gap_open;
	extern int gap_extend;
}

#endif
