#ifndef DATALAYER_OPTIONS
#define DATALAYER_OPTIONS 1

namespace opt {
	extern int chastityFilter;
	extern int trimMasked;
	extern int qualityOffset;
	extern int qualityThreshold;
	extern int internalQThreshold;
}

#endif
