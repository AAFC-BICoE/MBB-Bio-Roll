#ifndef FCONTROL_H
#define FCONTROL_H 1

int setCloexec(int fd);

#endif
