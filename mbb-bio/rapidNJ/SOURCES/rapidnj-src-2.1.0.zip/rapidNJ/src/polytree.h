#ifndef POLYTREE_H
#define POLYTREE_H
#include "stdinclude.h"

class polytree{

 public:
  polytree(int size, vector<string> sequenceNames);
  ~polytree(void);
  
  void addLeaf(std::string name);
  void addInternalNode(double left_dist, double right_dist, int left_index, int right_index);
  void serialize_tree(int left_index, int right_index, double distance);
  void serialize_node(int left_index, int right_index, int index);
  
 private:
  double *distances; //2n-1
  int *left_indexes;// n-1
  int *right_indexes;//n-1
  std::string *leaf_names;//n
  int size;
  int current_index;
  char buffer[64];
  int leaf_index;
};

#endif
