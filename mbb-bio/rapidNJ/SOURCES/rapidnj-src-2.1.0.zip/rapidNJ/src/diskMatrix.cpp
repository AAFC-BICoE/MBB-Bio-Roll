#include "stdinclude.h"
#include "diskMatrix.h"
#include <assert.h>
#include <sched.h>

using namespace std;

/* A distance matrix stored in external memory. The matrix is stored in files of size 1 GB.
 */

diskMatrix::diskMatrix(std::string data_dir, int size) {  
  diskMatrix::size = size;
  diskMatrix::data_dir = data_dir;
  rowToFileId = new int[size];
  rowToFileIndex = new int[size];
  if(MAX_FILE_SIZE < size * ((int)sizeof(distType))){
    cout << "The matrix is too large \n";
    exit(1);
  }
  rowsPerFile = MAX_FILE_SIZE / (size * ((int)sizeof(distType)));
  numberOfFiles = size / rowsPerFile;
  if(size % rowsPerFile != 0.0){
    numberOfFiles++;
  }
  fstreams = new fstream[numberOfFiles];
  char buf[256];
  int rowSize = size * sizeof(distType);
  int fileId = 0;  
  int fileRowCount = 0;
  int totalRowCount = 0;
  for(int i = 0; i < numberOfFiles; i++){
    sprintf(buf, "%s/.row_data_%d",data_dir.c_str(),fileId);
    fstreams[fileId].open(buf,fstream::out | fstream::in | fstream::binary | fstream::trunc);
    if(!fstreams[fileId].is_open()){
      string filename(buf);
      cout << "Could not open file " << filename << "\n";
      cout << "Check if the cache directory is accessible\n";
      exit(1);
    }    
    for(int j = 0; j < rowsPerFile; j++){
      rowToFileIndex[totalRowCount] = fileRowCount * rowSize;      
      rowToFileId[totalRowCount] = fileId;
      if(totalRowCount == size-1){
	return;
      }
      fileRowCount++;      
      totalRowCount++;      
    }
    fileRowCount = 0;
    fileId++;
  }
}

void diskMatrix::writeEntry(distType value, int row, int col){
  int fileId = rowToFileId[row];  
  fstreams[fileId].seekp(rowToFileIndex[row] + col * sizeof(distType));
  fstreams[fileId].write((char*)&value, sizeof(distType));
  fstreams[fileId].flush();  
}

void diskMatrix::writeArray(distType *values, int row, int size){
  int fileId = rowToFileId[row];
  fstreams[fileId].seekp(rowToFileIndex[row]);
  fstreams[fileId].write((char*)values, sizeof(distType) * size);  
  fstreams[fileId].flush();  
}

distType diskMatrix::readEntry(int row, int col){
  char char_buf[sizeof(distType)];
  distType distType_buf[1];
  int fileId = rowToFileId[row];
  fstreams[fileId].seekg(rowToFileIndex[row] + col * sizeof(distType));
  fstreams[fileId].read(char_buf, sizeof(distType));
  memcpy(distType_buf,char_buf,sizeof(distType));
  return distType_buf[0];
}

void diskMatrix::readArray(distType *values, int row, int size){  
  int fileId = rowToFileId[row];
  fstreams[fileId].seekg(rowToFileIndex[row]);
  fstreams[fileId].read((char*)values, sizeof(distType) * size);
}

void diskMatrix::writeArrayNewSize(distType *values, int newRow, int newSize){  
  int fileId = rowToFileId[newRow];  
  int newIndex = (newRow % rowsPerFile) * newSize * sizeof(distType);
  fstreams[fileId].seekp(newIndex);  
  rowToFileIndex[newRow] = newIndex;
  fstreams[fileId].write((char*)values, sizeof(distType) * newSize);  
  fstreams[fileId].flush();
}

void diskMatrix::setNewSize(int newSize){
  size = newSize;
}

void diskMatrix::updateRowIndex(int newRow, int newSize){  
  rowToFileIndex[newRow] = (newRow % rowsPerFile) * newSize * sizeof(distType);;
}

void diskMatrix::flush(){
  for(int i = 0; i < numberOfFiles; i++){
    fstreams[i].flush();
  }
}

diskMatrix::~diskMatrix(){  
  char buf[256];
  for(int i = 0; i < numberOfFiles; i++){
    fstreams[i].close();
    sprintf(buf, "%s/.row_data_%d",data_dir.c_str(),i);
    remove(buf);
  } 
}
