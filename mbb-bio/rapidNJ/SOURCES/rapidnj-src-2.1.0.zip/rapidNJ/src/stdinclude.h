#ifndef STDINCLUDE_H
#define STDINCLUDE_H

#include <stdio.h>
#include <iostream>
#include <stdlib.h>
#include <string.h>
#include <emmintrin.h>
#include <vector>

using namespace std;

enum {Abin=0, Cbin=3, Gbin=1, Tbin=2};
enum InputType {DNA, PROTEIN, UNKNOWN};

typedef unsigned int v4ui __attribute__ ((vector_size(16)));

union v4ui_vector {
  v4ui v;
  unsigned int d[4];
  char c[16];
  unsigned long long ul[2];
};

typedef float distType;

//RAPID_DISK CONSTANT: percentage of free space compared to the current memory usage before resizing and rebuilding the sorted matrix and cache
const int DATA_STRUCTURE_SIZE_TRESSHOLD = 90;
// MEMORY EFFICIENT RAPIDNJ CONSTANT: the minimum percentage of the sorted matrix which must fit in memory.
const distType MIN_SORTED_MATRIX_SIZE = 0.05;

#endif
