#include "stdinclude.h"
#include <sys/time.h>
#include "rdDataInitialiser.h"
#include "distMatrixReader.hpp"
#include "cluster_pair.h"
#include "rapidNJ.h"
#include "rapidNJDisk.h"
#include "rapidNJMem.hpp"
#include "simpleNJ.h"
#include "dataloader.hpp"
#include "dataloaderStockholm.hpp"
#include "dataloaderPhylip.hpp"
#include "JCdistance.hpp"
#include "hammingDistance.hpp"
#include "KimuraDistance.hpp"
#include "getopt_pp/getopt_pp.h"
#include "bitStringUtils.hpp"
#include <iomanip>
#include "bootstrapper.hpp"
#ifdef __APPLE__
#include <sys/types.h>
#include <sys/sysctl.h>
#endif
using namespace std;

timeval start,end;
bool distanceMatrixInput = true;
distType** distanceMatrix;
vector<string>* sequenceNames;
int matrixSize = -1;
int numCores = 1;

#ifdef TIMING
float totalGpuComputation = 0.0f;
float totalTransfer = 0.0f;
float totalDistanceCorrection = 0.0f;
float totalOther = 0.0f;
float totalHddReading = 0.0f;
#endif

namespace options {
  bool verbose;
  string fileName;
  int memSize;
  int cores;
  string cacheDir;
  string percentageMemoryUsage;
  string distMethod;
  string inputFormat;
  string outputFormat;
  bool fastdist;
  int replicates;
  string inputtype;
  bool popcnt;
  bool rapidNJ;
  bool simpleNJ;
  bool gpu;
};

void printTime(string message){
  double startm = (start.tv_sec*1000.0 + start.tv_usec/1000.0)/1000;
  gettimeofday(&end,NULL);
  double endm = (end.tv_sec*1000.0 + end.tv_usec/1000.0)/1000;
  cout << message << " " << (endm -startm ) << " sec \n";
}

void printTime(){
  double startm = (start.tv_sec*1000.0 + start.tv_usec/1000.0)/1000;
  gettimeofday(&end,NULL);
  double endm = (end.tv_sec*1000.0 + end.tv_usec/1000.0)/1000;
  cerr << (endm -startm );
}


int getMatrixSize(string filename){
  ifstream is;
  is.open(filename.data(),ifstream::in);  
  if(!is.is_open()){
    cout << "Could not read file: " << filename << "\n";
    exit(1);
  }
  char buf[256];
  is.read(buf, 256);
  is.close();
  return atoi(buf);
}

string guessPhylipType(string filename){
  ifstream is;
  is.open(filename.data(),ifstream::in);  
  if(!is.is_open()){
    cout << "Could not read file: " << filename << "\n";
    exit(1);
  }
  char buf[256];
  is.read(buf, 256);
  is.close();
  int i = 0;
  bool foundNumber = false;
  for(; i < 256; i++){
    if(!foundNumber && buf[i] > 32) {
      foundNumber = true;
    } else if(foundNumber && (buf[i] == 32 || buf[i] == 11)){
      break;
    } else if(buf[i] == 10){
      //phylip distance matrix
      return "pd";
    }
  }  
  for(; i < 256; i++){
    if(buf[i] > 32){
      //alignment
      return "pa";
    } else if(buf[i] == 10){
      //distance matrix
      return "pd";
    }
  }
  return "pd";
}


void configureNumberOfCores(){
  // Configure number of cores to use
  numCores= sysconf(_SC_NPROCESSORS_ONLN);
  if(options::cores > 0){
    if(options::cores > numCores){
      cout << "WARNING: the system only have " << numCores << ". Using " << options::cores << " cores will result in bad performance." << endl;
    }
    numCores = options::cores;
  }
  if (options::verbose) {
    cout << "Using " << numCores << " core(s)" << endl;
  }
}

/*Returns the system memory size in MB */
double getMemSize(){  
  if(options::memSize != -1){
    return options::memSize;
  }
#ifdef __APPLE__
  int mib[2];
  int64_t physical_memory;
  size_t length;
  mib[0] = CTL_HW;
  mib[1] = HW_MEMSIZE;
  length = sizeof(int64_t);
  sysctl(mib, 2, &physical_memory, &length, NULL, 0);
  return (double) physical_memory / 1024.0 / 1024.0;
#else
  ifstream stream;
  stream.open("/proc/meminfo", ifstream::in);
  int bufSize = 4096;
  char buffer[bufSize];
  while(stream.good()){
    stream.getline(buffer,bufSize);
    string s(buffer,9);
    if(!s.compare("MemTotal:")){
      char memSize[50] = {'-','1'};
      bool foundSize = false;
      int j = 0;
      for(int i = 9; i < bufSize; i++){
	if(buffer[i] != 32){
	  foundSize = true;
	  memSize[j] = buffer[i];
	  j++;
	} else if(foundSize){
	  //finished reading size
	  return atof(memSize) / 1024;
	}
      }
    }
  }
#endif
  cerr << "Could not read memory size. Please state the amount of available memory using the '-m'option." << endl;
  exit(1);
  return -1;
} 

void runRapidNJ(int matrixSize){
  distMatrixReader* reader;
  if(distanceMatrixInput){
    reader = new distMatrixReader(options::verbose, options::fileName, matrixSize, false);
    if(options::verbose){
      cout << "Reading data... \n";
    }
    reader->read_data();    
  } else {
    reader = new distMatrixReader(options::verbose, matrixSize, false, sequenceNames, distanceMatrix);
    reader->initializeData();
  }  
  if(options::verbose){
    cout << "Computing phylogetic tree... \n";
  }
  
  rapidNJ* sorted = new rapidNJ(reader, matrixSize);
  sorted->run();
  //TODO delete rd
  delete sorted;  
}

void runSimpleNJ(int matrixSize){
  if(options::verbose){
    cout << "Reading data... \n";  
  }
  if(!distanceMatrixInput){
    //TODO fix this
    cerr << "Use distance matrix as input" << endl;
    exit(1);
  }
  distMatrixReader* reader = new distMatrixReader(options::verbose, options::fileName, matrixSize, false);
  reader->read_data();
  simpleNJ* njs = new simpleNJ(reader, matrixSize);
  njs->run();
}


void runRapidMNJ(int matrixSize, int sortedMatrixSize){
  if(options::verbose){    
    cout << "Reading data... \n";  
  }
  distMatrixReader* reader;
  if(distanceMatrixInput){
    reader = new distMatrixReader(options::verbose, options::fileName, matrixSize, true);
    reader->read_data();
  }
  else {
    reader = new distMatrixReader(options::verbose, matrixSize, true, sequenceNames, distanceMatrix);
    reader->initializeData();
  }  
  if(options::verbose){
    cout << "Computing phylogetic tree... \n";
  }  
  rapidNJMem* nj = new rapidNJMem(reader,matrixSize,sortedMatrixSize,options::verbose);
  nj->run();
  delete nj;
}

void runDiskNJ(int matrixSize, int datastructureSize){
  if(options::verbose){
    cout << "Reading data... \n";
  }
  rdDataInitialiser* reader;
  string cacheDir;
  if(options::cacheDir == ""){
    cacheDir = options::fileName;
    cacheDir = cacheDir.substr(0, cacheDir.find_last_of("/"));
    if(options::fileName == cacheDir){
      cacheDir = ".";
    }
  } else {
    cacheDir = options::cacheDir;
  }
  if(!distanceMatrixInput){
    //TODO fix this
    cerr << "Multiple Alignment input for rapidNJ-disk is not supported yet. Use a distance matrix as input" << endl;
    exit(1);
  }
  reader = new rdDataInitialiser(options::verbose, datastructureSize, cacheDir, options::fileName);
  bool status = reader->read_data();
  if(!status){
    cout << "Could not read data \n";
    exit(1);
  }
  if(options::verbose){
    cout << "Computing phylogetic tree... \n";
  }
  rapidNJDisk *rd = new rapidNJDisk(reader, options::verbose);
  rd->run();
  delete rd;
  //TODO delete rd    
  delete reader;
}

void computeTree(){
  // Compute the memory requirements for the three different algorithms.
  bool autoDecide = true;
  double matrixSized = (double) matrixSize;
  double systemMemory = getMemSize() * 1024.0 * 1024.0;    
  double matrixMemUsage = ((double) sizeof(distType)) *  matrixSized * matrixSized; 
  double sortedMatrixMemUsage = matrixSized * matrixSized * ((double)sizeof(cluster_pair));
  int sortedMatrixSize_half = (int) ((systemMemory - (matrixMemUsage/2.0)) / (matrixSized*sizeof(cluster_pair)));
  sortedMatrixSize_half = min(sortedMatrixSize_half,matrixSize);
  int datastructureSizeDisk = (int) (systemMemory / (distType)(matrixSize*(sizeof(cluster_pair)+sizeof(distType))));
  datastructureSizeDisk = min(datastructureSizeDisk,matrixSize);
  // select which algorithm to use based on either parameters or memory requirements
  if(options::rapidNJ || options::cacheDir != "" || options::percentageMemoryUsage != "" || options::simpleNJ) {
    autoDecide = false;
  }
  if(options::verbose){
    cout << "Matrix size: " << matrixSize << endl;
    cout << (systemMemory /1024 /1024) << " MB of memory is available" << endl;
  }
  if(options::rapidNJ || (autoDecide && sortedMatrixMemUsage + matrixMemUsage <= systemMemory)) {
    if(options::verbose){
      cout << "Using RapidNJ \n";
      cout << "Using " << (matrixMemUsage /1024 /1024) << " MB for distance matrix" << endl;
      cout << "Using " << (sortedMatrixMemUsage/1024/1024) << " MB for sortedMatrix" << endl;
      cout << "Total memory consumption is " << (matrixMemUsage + sortedMatrixMemUsage)/1024/1024 << " MB" << endl;
    }
    if(sortedMatrixMemUsage > systemMemory - matrixMemUsage){
      cout << "WARNING: There's not enough memory to use RapidNJ. Consider using another algorithm." << endl;
    }
    runRapidNJ(matrixSize);
  } else if(options::percentageMemoryUsage != ""  || (autoDecide && sortedMatrixSize_half >= matrixSize * MIN_SORTED_MATRIX_SIZE)){
    if(options::verbose){
      cout << "Using Memory efficient RapidNJ \n";
    }
    if(options::percentageMemoryUsage != ""){
      // try to use the user supplied argument
      int percentage;
      percentage = atoi(options::percentageMemoryUsage.data());
      if(percentage < 0 || percentage > 100){
	cerr << "The memory use percentage must be >=0 and <=100 " << endl;
	exit(1);
      }
      int tempSize = (int) (matrixSize * (percentage / 100.0));
      if(tempSize > sortedMatrixSize_half){
	cout << "WARNING: Not enough memory for " << percentage << "% of the sorted matrix. Reduce the size of the sorted matrix or use RapidDiskNJ." << endl;
      }
      sortedMatrixSize_half = tempSize;
    }
    if(sortedMatrixSize_half < matrixSize * MIN_SORTED_MATRIX_SIZE) {
      cout << "WARNING: There might not be enough memory for the memory efficient RapidNJ algorithm. Consider using another algorithm." << endl;
    }
    if(options::verbose){     
      cout << "Sorted matrix has " << sortedMatrixSize_half << " columns" << endl;
    }
    
    runRapidMNJ(matrixSize, sortedMatrixSize_half);
  } else if(options::simpleNJ) {
    if(options::verbose){
      cout << "Using naive NJ \n";
    }    
    runSimpleNJ(matrixSize);
  } else {
    if(options::verbose){
      cout << "Using RapidDiskNJ algorithm\n";
      cout << "Sorted matrix has " << datastructureSizeDisk << " columns" << endl;
    }
    runDiskNJ(matrixSize, datastructureSizeDisk);
  }
  //cout << "\n";
}

void computeDistanceMatrixGPU(){
  dataloader* dl;
#ifndef ENABLEGPU
  cerr << "GPU distance estimation is not enabled. Please recompile rapidNJ with CUDA support." << endl;
  exit(1);
#endif
  if(options::verbose){
    cout << "Using GPU to build distance matrix" << endl;
  }
  // load data 
  if (options::verbose) {
    cout << "Reading data...\n";
  }
  InputType type = UNKNOWN;
  if(options::inputtype == "d") type = DNA;
  if(options::inputtype == "p") type = PROTEIN;
  if(options::inputFormat == "sth"){
    dl = new dataloaderStockholm();    
    dl->readData(options::fileName, options::fastdist | options::gpu, options::verbose, true, type, true);
  } else if(options::inputFormat == "pa") {
    cerr << "GPU distance estimation with phylip formatted input are not supported yet." << endl;
    exit(1);
  } else {
    cerr << "Unkown input format " << options::inputFormat << endl;
    exit(0);
  }
  sequenceNames = dl->getSequenceNames();
  matrixSize = dl->getSequenceCount();

#ifdef TIMING
  gettimeofday(&end,NULL);
  totalHddReading += (end.tv_sec - start.tv_sec)*1000.0 + (end.tv_usec - start.tv_usec)/1000.0;
  gettimeofday(&start,NULL);
#endif

  // process data
  if(options::distMethod == "kim" || options::distMethod == ""){
    if (options::verbose) {
      cout << "Using Kimura algorithm to calculate distances" << endl;
    }
    KimuraDistance* alg = new KimuraDistance(options::verbose, true, dl,false);
    alg->computeDistancesGPU();
    distanceMatrix = alg->getDistanceMatrix();
  } else {
    cout << "unknown method" << endl;
  }
}

dataloader* loadData(){
  // load data
  dataloader* dl;
  if (options::verbose) {
    cout << "Reading data...\n";
  }
  InputType type = UNKNOWN;
  if(options::inputtype == "d") type = DNA;
  if(options::inputtype == "p") type = PROTEIN;
  if(options::inputFormat == "sth"){
    dl = new dataloaderStockholm();
    dl->readData(options::fileName, options::fastdist, options::verbose, true, type,false);
  } else if(options::inputFormat == "pa"){
    //TODO fix this
    cerr << "Phylip alignments cannot be read yet. Use stockholm format for alignments."<< endl;
    exit(1);
    dl = new dataloaderPhylip();
    dl->readData(options::fileName, options::fastdist, options::verbose, true, type,false);
  } else {
    cerr << "Unkown input format " << options::inputFormat << endl;
    exit(0);
  } 
  return dl;
}

void computeDistanceMatrix(){  
#ifdef TIMING
  gettimeofday(&end,NULL);
  totalOther += (end.tv_sec - start.tv_sec)*1000.0 + (end.tv_usec - start.tv_usec)/1000.0;
  gettimeofday(&start,NULL);
#endif

  if(options::gpu){
    computeDistanceMatrixGPU();
    return;
  }
  dataloader* dl = loadData();
#ifdef TIMING
  gettimeofday(&end,NULL);
  totalHddReading += (end.tv_sec - start.tv_sec)*1000.0 + (end.tv_usec - start.tv_usec)/1000.0;
  gettimeofday(&start,NULL);
#endif

  //test if theres enough memory to compute the distance matrix
  double requiredMemory = 0;
  //the bitStrings
  double seqCount = dl->getSequenceCount();
  if(dl->type == DNA){
    requiredMemory += seqCount * dl->getSequenceLength() / 2.0;
  } else {
    requiredMemory += seqCount * dl->getSequenceLength();
  }  
  //the distance matrix
  requiredMemory += seqCount * seqCount * (double)sizeof(distType);
  //convert to MB
  requiredMemory = requiredMemory / 1024.0 / 1024.0;

  double memSize = getMemSize();
  if(requiredMemory > 4000 && sizeof(unsigned int*) == 4){
    //32 bit machine
    cerr << "ERROR: " << requiredMemory << "MB of memory is required to compute the distance matrix. This is not possible on a 32 bit computer." << endl;
    exit(1);
  } else if(memSize < requiredMemory && options::verbose){
    cout << "WARNING: " << requiredMemory << "MB of memory is required to compute the distance matrix. Only " << memSize << "MB is available." << endl;
  }
  if(options::fastdist && options::verbose){
    cout << "Fastdist is enabled" << endl;
  }
  sequenceNames = dl->getSequenceNames();
  matrixSize = dl->getSequenceCount();
  // process data
  if(options::distMethod == "jc"){
    if(dl->type == PROTEIN){
      cerr << "ERROR: The Juke-Cantor model cannot be used to compute distance estimates between protein sequences." << endl;
      exit(1);
    }
    if (options::verbose) {
      cout << "Using JC algorithm to calculate distances" << endl;
    }
    JCdistance* alg = new JCdistance(options::verbose, options::fastdist,dl );
    if(options::fastdist){            
      alg->calculateDistancesMTFastDist(numCores);
    } else {
      alg->calculateDistancesMT(numCores);
    }
    distanceMatrix = alg->getDistanceMatrix();
  } else if(options::distMethod == "kim" || options::distMethod == ""){
    if (options::verbose) {
      cout << "Using Kimura algorithm to calculate distances" << endl;
    }
    KimuraDistance* alg = new KimuraDistance(options::verbose, options::fastdist, dl, options::popcnt);    
    alg->computeDistances(numCores);
    distanceMatrix = alg->getDistanceMatrix();
  } else {
    cerr << "ERROR: Unknown sequence evolution model" << endl;
    exit(1);
  }
}

void printDistanceMatrix(){
  cout << "\t" << matrixSize << endl;
  for (int i = 0; i < matrixSize; i++) {
    cout << (*sequenceNames)[i] << "\t";
    for (int j = 0; j < matrixSize; j++) {
      printf("%.5f ",distanceMatrix[i][j]);
    }
    cout << endl;
  }
}

void bootstrap(){
  //always load alignment unencoded
  bool temp = options::fastdist;
  options::fastdist = false;
  dataloader* dl = loadData();
  options::fastdist = temp;
  bootstrapper* bs = new bootstrapper(dl, options::fastdist, options::verbose);
  bs->run(options::replicates, numCores);  
}


void printUsage(){
  cout << "Rapid neighbour-joining. An implementation of the canonical neighbour-joining method which utilize a fast search heuristic to reduce the running time. RapidNJ can be used to reconstruct large trees using a very small amount of memory by utilizing the HDD as storage." << endl << endl;
  cout << "USAGE: rapidnj INPUT [OPTION1] [OPTION2] ..." << endl;
  cout << "The INPUT can be either a distance matrix in phylip (.phylip) format or a multiple alignment in stockholm (.sth) or phylip format (.phylip)." << endl;
  cout << "OPTIONS:" << endl;
  cout << "\t-h, --help \t\t\tdisplay this help message and exit." << endl;
  cout << "\t-v, --verbose \t\t\tturn on verbose output." << endl;
  cout << "\t-i, --input-format ARG\t\tSpecifies the type of input. pd = distance matrix in phylip format, pa = multiple alignment in phylip format (UNDER DEVELOPMENT), sth = multiple alignment in stockholm format." << endl;
  cout << "\t-o, --output-format ARG\t\tSpecifies the type of output. t = phylogenetic tree in newick format (default), m = distance matrix." << endl;
  cout << "\t-a, --evolution-model ARG\tSpecifies which sequence evolution method to use when computing distance estimates from multiple alignments. jc = juke cantor, kim = Kimura's distance (default)." << endl;
  cout << "\t-m, --memory-size \t\tThe maximum amount of memory which rapidNJ is allowed to use (in MB). Default is 90% of all available memory." << endl;
  cout << "\t-r, --rapidnj \t\t\tDisable all memory optimisations." << endl;
  cout << "\t-k, --rapidnj-mem ARG\t\tForce RapidNJ to use a memory efficient version of rapidNJ. The 'arg' specifies the percentage of a sorted distance matrix which should be stored in memory (arg=10 means 10%)." << endl;
  cout << "\t-d, --rapidnj-disk ARG\t\tForce RapidNJ to use HDD caching where 'arg' is the directory used to store cached files." << endl;
  cout << "\t-s, --simplenj \t\t\tUse a naive implementation of the NJ method." << endl;
  cout << "\t-f, --no-rapiddist \t\tDisable rapid computation of distance estimates and use a naive algorithm for this." << endl;
  cout << "\t-c, --cores ARG \t\tNumber of cores to use for computating distance matrices from multiple alignments. All availalbe cores are used by default." << endl;
  cout << "\t-b  --bootstrap ARG\t\tCompute ARG boostrapped neighbour-joining trees." << endl;
  cout << "\t-t, --alignment-type ARG \tForce the input alignment to be treated as: p = protein alignment, d = DNA alignment." << endl;
  cout << "\t-g  --gpu \t\t\tUse CUDA enabled GPU to compute distance estimates." << endl;
  cout << "\t-j  --popcnt \t\t\tEnable the use of population count SIMD instructions for computation of distance estimates. Requires a CPU which supports SSE4.2 or SSE4a." << endl;
}

int main( int argc, char* argv[] ) {    

using namespace GetOpt;
 GetOpt_pp opts(argc, argv);
 
 if(argc == 1 || opts >> OptionPresent('h',"help")){
   printUsage();
   exit(0);
 }

 opts >> OptionPresent('v', "verbose", options::verbose);
 opts >> Option('i', "input-format", options::inputFormat, "");
 opts >> Option('o', "output-format", options::outputFormat, "");
 opts >> Option('a',"evolution-model", options::distMethod, "");
 opts >> Option('m',"memory-size", options::memSize, -1);
 opts >> OptionPresent('r',"rapidnj", options::rapidNJ);
 opts >> Option('k',"rapidnj-mem", options::percentageMemoryUsage, "");
 opts >> Option('d',"rapidnj-disk", options::cacheDir, "");
 opts >> OptionPresent('s',"simplenj", options::simpleNJ);
 opts >> OptionPresent('f', "no-rapiddist", options::fastdist);
 opts >> Option('c',"cores", options::cores, -1);
 opts >> Option('b',"bootstrap", options::replicates, -1);
 opts >> Option('t',"alignment-type", options::inputtype, "");
 opts >> OptionPresent('g', "gpu", options::gpu);
 opts >> OptionPresent('j', "popcnt", options::popcnt);  

 options::fastdist = !options::fastdist;
  vector<string> fileNames;
  opts >> GlobalOption(fileNames);
  if(fileNames.size() < 1){
    cerr << "ERROR: An input file must be specified!" << endl;
    exit(1);
  }
  if(fileNames.size() > 1){
    cerr << "ERROR: Only one input file can be specified!" << endl;
    exit(1);
  }
  options::fileName = fileNames[0];
  
  if(opts.options_remain()){
    cerr << "ERROR: One or more options were not recognised!" << endl;
    exit(0);      
  }

  if(options::popcnt){
#ifndef __SSE4_2__
    cerr << "SSE4.2 instructions not enabled" << endl;
    exit(0);
#endif
  }

  configureNumberOfCores();

  gettimeofday(&start, NULL);

  if(options::inputFormat == ""){
    // try to determine the input format
    size_t pos = options::fileName.find(".sth");
    if (pos!=string::npos){
      if(options::verbose){
	cout << "Input format determined as stockholm" << endl;
      }
      options::inputFormat="sth";
    } else {
      options::inputFormat = guessPhylipType(options::fileName);
      if(options::verbose){
	cout << "Input format determined as phylip ";
	if(options::inputFormat == "pa"){
	  cout << "alignment" << endl;
	} else {
	  cout << "distance matrix" << endl;
	}
      }
    }
  }
  if(options::replicates > -1){
    //TODO
    bootstrap();
  }
  else if(options::inputFormat == "pd"){
    //input is a distance matrix.
    distanceMatrixInput = true;
    matrixSize = getMatrixSize(options::fileName);
    computeTree();
  } else {
    computeDistanceMatrix();    
    distanceMatrixInput = false;    
    if(options::outputFormat == "" || options::outputFormat == "t"){
      computeTree();
      cout << endl;
    } else {    
      printDistanceMatrix();
    }
  }

#ifdef TIMING
  gettimeofday(&end,NULL);
  totalOther += (end.tv_sec - start.tv_sec)*1000.0 + (end.tv_usec - start.tv_usec)/1000.0;
  gettimeofday(&start,NULL);
#endif

  if(options::verbose){
    cout << endl;
    printTime("Total running time:");
  }

#ifdef TIMING
  cerr << "GpuComputation: " << (totalGpuComputation/1000.0) << endl;
  cerr << "Transfer: " << (totalTransfer/1000.0) << endl;
  cerr << "DistanceCorrection: " << (totalDistanceCorrection/1000.0) << endl;
  cerr << "Reading: " << (totalHddReading/1000.0) << endl;
  cerr << "Other: " << (totalOther/1000.0) << endl;

#endif

  return 0;
}
