#ifndef KIMURADISTANCE_HPP
#define KIMURADISTANCE_HPP

#include "stdinclude.h"
#include "dataloader.hpp"
#include "bitDistance.hpp"

class KimuraDistance{

public:
  KimuraDistance(bool verbose, bool fastdist, dataloader* loader, bool popcnt);
  KimuraDistance(bool verbose, bool fastdist, dataloader* loader, bool popcnt, distType** _distMatrix);
  static void* distThreadFastDist(void* ptr);
  static void* distThread(void* ptr);
  distType** getDistanceMatrix();
  void computeDistances(int);
  void computeDistancesGPU();

private:
  void postProcessDistanceMatrix();
  void computeDistancesMTFastDist(int);
  void computeDistancesMT(int);
  void computeDistancesDNAGPU();
  void computeDistancesProteinGPU();
  void computeDistancesDNAGPU2();

  bool verbose;
  bool fastdist;
  bool popcnt;
  int seqCount;
  dataloader* loader;
  vector<string> sequenceNames;
  long** distanceMatrixTS;
  long** distanceMatrixTV;
  distType** distMatrix;
  distType maxDistance;
  bool gpuInitialised;
};

struct threadStateKimura{
  int seqIdx;
  unsigned int seqCount;
  dataloader* loader;
  distType** distMatrix;
  bool verbose;
  int numThreads;
  distType maxDistance;
  bitDistance* distanceCalculator;
};
#endif
