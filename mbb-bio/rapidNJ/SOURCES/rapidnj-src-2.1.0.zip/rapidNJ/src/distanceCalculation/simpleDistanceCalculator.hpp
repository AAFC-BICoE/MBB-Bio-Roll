#ifndef SIMPLEDISTANCECALCULATOR_H
#define SIMPLEDISTANCECALCULATOR_H

#include "stdinclude.h"
#include "dataloader.hpp"

class simpleDistanceCalculator {

 public:
  simpleDistanceCalculator(bool verbose, dataloader* loader);
  ~simpleDistanceCalculator();
  void calculateDistanceDNA_TV_TS(int, int, unsigned int*);
  distType calculateDistance(int, int);
  int calculateHammingDistance(int i, int j);
  
 private:
  vector<char*> sequences;
  std::string* sequenceNames;
  int seqLength;
};

#endif
