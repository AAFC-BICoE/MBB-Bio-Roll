#include "simpleDistanceCalculator.hpp"

simpleDistanceCalculator::simpleDistanceCalculator(bool verbose, dataloader* loader){
  simpleDistanceCalculator::sequences = *loader->getSequences();
  simpleDistanceCalculator::seqLength = loader->getSequenceLength();
}

int simpleDistanceCalculator::calculateHammingDistance(int i, int j) {
  int distance = 0;
  for (int k = 0; k < seqLength; k++) {
    if(sequences[i][k] != '.' && sequences[i][k] != '-' && sequences[j][k] != '.' && sequences[j][k] != '-'){
      // not a gap
      if(sequences[i][k] != sequences[j][k]){
	distance++;
      }
    }
  }
  return distance;
}


distType simpleDistanceCalculator::calculateDistance(int i, int j) {
  unsigned int distance = 0;
  unsigned int nucleotideCount = 0;
  //distType distance = 0;
  //distType nucleotideCount = 0;
  for (int k = 0; k < seqLength; k++) {
    char c1 = sequences[i][k];
    char c2 = sequences[j][k];
    if(c1 > 64 && c2 > 64){
      // not a gap
      nucleotideCount++;
      if(c1 != c2){
	distance++;
      }
    }
  }
  if(nucleotideCount == 0){
    return 0;
  }
  return ((double) distance / (double)nucleotideCount);
}


/*
distType simpleDistanceCalculator::calculateDistance(int i, int j) {
  distType distance = 0;
  distType nucleotideCount = 0;
  for (int k = 0; k < seqLength; k++) {
    if(sequences[i][k] != '.' && sequences[i][k] != '-' && sequences[j][k] != '.' && sequences[j][k] != '-'){
      // not a gap
      nucleotideCount++;
      if(sequences[i][k] != sequences[j][k]){
	distance++;
      }
    }
  }
  if(nucleotideCount == 0){    
    return -1;
  }
  //cout << distance << "/" << nucleotideCount << endl;
  return distance / nucleotideCount;
}
*/

// Calculates the distance between two sequences. Transversion and Transitions are calculated
void simpleDistanceCalculator::calculateDistanceDNA_TV_TS(int i, int j, unsigned int* result) {
  unsigned int ts = 0;
  unsigned int tv = 0;
  unsigned int length = 0;
  for (int k = 0; k < seqLength; k++) {
    if( sequences[i][k] == '-' || sequences[j][k] == '-'){
      continue;
    }    
    if(sequences[i][k] != sequences[j][k]){    
      if (sequences[i][k] == 'A') {
	if (sequences[j][k] == 'G') {
	  ts++;
	} else {
	  tv++;
	}
      } else if (sequences[i][k] == 'C') {
	if (sequences[j][k] == 'T') {
	  ts++;
	} else {
	  tv++;
      }
      } else if (sequences[i][k] == 'G') {
	if (sequences[j][k] == 'A') {
	  ts++;
	} else {
	  tv++;	  
	}
      } else if (sequences[i][k] == 'T') {
	if (sequences[j][k] == 'C') {
	  ts++;
	} else {
	  tv++;
	}
      }
    }
    length++;
  }
  result[0] = ts;
  result[1] = tv;
  result[2] = length;
}
