#include "KimuraDistance.hpp"
#include "simpleDistanceCalculator.hpp"
#include <math.h>
#include <fstream>
#include <math.h>
#include <pthread.h>
#include <sched.h>
#include <errno.h>
#ifdef __SSE4_2__
#include "bitDistanceProteinPopCnt.hpp"
#include "bitDistanceGapPopCnt.hpp"
#endif
#include "bitDistanceGap.hpp"
#include "bitDistanceProtein.hpp"
#include "dnaBitString.hpp"
#include <sys/time.h>

#ifdef ENABLEGPU
extern "C" void computeDistancesDNA_gpu(unsigned int* ts, unsigned int* tv, unsigned int* gaps);
extern "C" void storeDataDNA_gpu(unsigned int* bitStrings, unsigned int* gapFilters);
extern "C" void initialiseDNA_gpu(unsigned int sequenceCount, unsigned int bitStringCount, unsigned int _bsStride);
extern "C" void computeDistancesProtein_gpu(unsigned int* bitStrings,unsigned int* dist, unsigned int* gaps);
extern "C" void getResultsProtein_gpu(unsigned int* dist, unsigned int* gaps);
extern "C" void initialiseProtein_gpu(unsigned int sequenceCount, unsigned int _bsStride, unsigned int bitStringCount);

extern "C" void computeDistancesDNA2_gpu(float* results);
extern "C" void storeDataDNA2_gpu(unsigned int* bitStrings, unsigned int* gapFilters);
extern "C" void initialiseDNA2_gpu(unsigned int sequenceCount, unsigned int bitStringCount, unsigned int _bsStride);
#endif

#ifdef TIMING
extern float totalDistanceCorrection;
extern timeval start,end;
extern float totalTransfer;
extern float totalOther;
#endif


static int dayhoff_pams[]={
 195,    196,    197,    198,    199,    200,    200,    201,    202,  203,    
  204,    205,    206,    207,    208,    209,    209,    210,    211,  212,    
  213,    214,    215,    216,    217,    218,    219,    220,    221,  222,    
  223,    224,    226,    227,    228,    229,    230,    231,    232,  233,    
  234,    236,    237,    238,    239,    240,    241,    243,    244,  245,    
  246,    248,    249,    250,    252,    253,    254,    255,    257,  258,    
  260,    261,    262,    264,    265,    267,    268,    270,    271,  273,    
  274,    276,    277,    279,    281,    282,    284,    285,    287,  289,    
  291,    292,    294,    296,    298,    299,    301,    303,    305,  307,    
  309,    311,    313,    315,    317,    319,    321,    323,    325,  328,    
  330,    332,    335,    337,    339,    342,    344,    347,    349,  352,    
  354,    357,    360,    362,    365,    368,    371,    374,    377,  380,    
  383,    386,    389,    393,    396,    399,    403,    407,    410,  414,    
  418,    422,    426,    430,    434,    438,    442,    447,    451,  456,    
  461,    466,    471,    476,    482,    487,    493,    498,    504,  511,    
  517,    524,    531,    538,    545,    553,    560,    569,    577,  586,    
  595,    605,    615,    626,    637,    649,    661,    675,    688,  703,    
  719,    736,    754,    775,    796,    819,    845,    874,    907,  945,
  988};

KimuraDistance::KimuraDistance(bool verbose, bool fastdist, dataloader* loader, bool popcnt) {
  KimuraDistance::verbose = verbose;
  KimuraDistance::loader = loader;
  KimuraDistance::fastdist = fastdist;
  KimuraDistance::popcnt = popcnt;
  KimuraDistance::seqCount = loader->getSequenceCount();
  KimuraDistance::sequenceNames = *loader->getSequenceNames();  
  KimuraDistance::gpuInitialised = false;
  distMatrix = new distType*[seqCount];
  for (int i = 0; i < seqCount; i++) {
    distMatrix[i] = new distType[seqCount];
  } 
}

KimuraDistance::KimuraDistance(bool verbose, bool fastdist, dataloader* loader, bool popcnt, distType** _distMatrix) {
  KimuraDistance::verbose = verbose;
  KimuraDistance::loader = loader;
  KimuraDistance::fastdist = fastdist;
  KimuraDistance::popcnt = popcnt;
  KimuraDistance::seqCount = loader->getSequenceCount();
  KimuraDistance::sequenceNames = *loader->getSequenceNames();  
  KimuraDistance::gpuInitialised = false;  
  distMatrix = _distMatrix;
}


void KimuraDistance::computeDistances(int numThreads) {  
  maxDistance = 0.0;
  if(fastdist){
    computeDistancesMTFastDist(numThreads);
  } else {
    computeDistancesMT(numThreads);
  }
}

void KimuraDistance::computeDistancesGPU() { 
#ifndef ENABLEGPU
  cout << "Computation of distance estimators using GPU is not enabled!" << endl;
  exit(1);
#endif
  if(loader->type == PROTEIN){
    computeDistancesProteinGPU();
  } else {
    //computeDistancesDNAGPU();
    computeDistancesDNAGPU2();
  }
}

void KimuraDistance::computeDistancesProteinGPU() { 
#ifdef ENABLEGPU
  unsigned int* bitStrings = loader->bitStringsGPU;
  long paddedLength = (loader->getSequenceLength() + 127) & ~127;

#ifdef TIMING
  gettimeofday(&end,NULL);
  totalTransfer += (end.tv_sec - start.tv_sec)*1000.0 + (end.tv_usec - start.tv_usec)/1000.0;
  gettimeofday(&start,NULL);
#endif

  //allocate memory for the results
  size_t resultMemSize = seqCount * seqCount * sizeof(unsigned int);
  unsigned int* resultDist = (unsigned int*) malloc(resultMemSize);
  unsigned int* resultGap = (unsigned int*) malloc(resultMemSize);

  if(!gpuInitialised){
    initialiseProtein_gpu(seqCount, loader->bsStride, paddedLength);
    gpuInitialised = true;
  }

#ifdef TIMING
  gettimeofday(&end,NULL);
  totalTransfer += (end.tv_sec - start.tv_sec)*1000.0 + (end.tv_usec - start.tv_usec)/1000.0;
  gettimeofday(&start,NULL);
#endif

  computeDistancesProtein_gpu(bitStrings,resultDist,resultGap);
  if(verbose) cout << "Processing results matrix..." << endl;
  for(int i = 0; i < seqCount-1; i++){
    for (int j = i+1; j < seqCount; j++) {
      distType total = (long) resultDist[i*seqCount + j];
      distType lengthWithoutGaps = paddedLength - resultGap[i*seqCount + j];	      
      //cout << "TEST: " << paddedLength << " " << resultGap[i*seqCount + j] << " " << lengthWithoutGaps << endl;
      distType distance;
      if(lengthWithoutGaps == 0) {
	distance = 0.0f;
      } else {
	distance = total / lengthWithoutGaps;
      }
      if ( distance < 0.75) {
	if (distance > 0.0){
	  distance = - log(1.0 - distance - (distance * distance * 0.20));
	}
      } else {
	if (distance > 0.930) {
	  distance = 10.0;
      } else {
	  int table_index = (int) ((distance*1000.0) - 750.0);
	  distance = (distType) (dayhoff_pams[ table_index ] / 100.0);
	}
      }
      if(distance > maxDistance){
	maxDistance = distance;
      }
      distMatrix[i][j] = distance;
    }
  }
  cout << "Post processing matrix." << endl;
  postProcessDistanceMatrix();
  cout << "Done!" << endl;
#ifdef TIMING
  gettimeofday(&end,NULL);
  totalDistanceCorrection += (end.tv_sec - start.tv_sec)*1000.0 + (end.tv_usec - start.tv_usec)/1000.0;
  gettimeofday(&start,NULL);
#endif
#endif
}

void KimuraDistance::computeDistancesDNAGPU2() {
#ifdef ENABLEGPU
  unsigned int* bitStrings = loader->bitStringsGPU;
  unsigned int* gapFilters = loader->gapFiltersGPU;

#ifdef TIMING
  gettimeofday(&end,NULL);
  totalOther += (end.tv_sec - start.tv_sec)*1000.0 + (end.tv_usec - start.tv_usec)/1000.0;
  gettimeofday(&start,NULL);
#endif

  if(!gpuInitialised){
    initialiseDNA2_gpu(seqCount, loader->getBitStringsCount(), loader->bsStride);
    gpuInitialised = true;
  }

  storeDataDNA2_gpu(bitStrings, gapFilters);

  size_t resultMemSize = seqCount * seqCount * sizeof(unsigned int);
  float* results = (float*) malloc(resultMemSize);

#ifdef TIMING
  gettimeofday(&end,NULL);
  totalTransfer += (end.tv_sec - start.tv_sec)*1000.0 + (end.tv_usec - start.tv_usec)/1000.0;
  gettimeofday(&start,NULL);
#endif

  computeDistancesDNA2_gpu(results);
  
  for(int i = 0; i < seqCount-1; i++){
    for (int j = i+1; j < seqCount; j++) {
      distType distance = results[i*seqCount + j];      
      if(distance > maxDistance){
	maxDistance = distance;
      }
      distMatrix[i][j] = distance;
    }
  }
  postProcessDistanceMatrix();
#ifdef TIMING
  gettimeofday(&end,NULL);
  totalDistanceCorrection += (end.tv_sec - start.tv_sec)*1000.0 + (end.tv_usec - start.tv_usec)/1000.0;
  gettimeofday(&start,NULL);
#endif
#endif
}

void KimuraDistance::computeDistancesDNAGPU() {
#ifdef ENABLEGPU
  unsigned int* bitStrings = loader->bitStringsGPU;
  unsigned int* gapFilters = loader->gapFiltersGPU;

#ifdef TIMING
  gettimeofday(&end,NULL);
  totalOther += (end.tv_sec - start.tv_sec)*1000.0 + (end.tv_usec - start.tv_usec)/1000.0;
  gettimeofday(&start,NULL);
#endif

  if(!gpuInitialised){
    initialiseDNA_gpu(seqCount, loader->getBitStringsCount(), loader->bsStride);
    gpuInitialised = true;
  }

  storeDataDNA_gpu(bitStrings, gapFilters);

  size_t resultMemSize = seqCount * seqCount * sizeof(unsigned int);
  unsigned int* resultTS = (unsigned int*) malloc(resultMemSize);
  unsigned int* resultTV = (unsigned int*) malloc(resultMemSize);
  unsigned int* resultGap = (unsigned int*) malloc(resultMemSize);

#ifdef TIMING
  gettimeofday(&end,NULL);
  totalTransfer += (end.tv_sec - start.tv_sec)*1000.0 + (end.tv_usec - start.tv_usec)/1000.0;
  gettimeofday(&start,NULL);
#endif

  computeDistancesDNA_gpu(resultTS, resultTV, resultGap);
  
  for(int i = 0; i < seqCount-1; i++){
    for (int j = i+1; j < seqCount; j++) {
      distType lengthWithoutGaps = resultGap[i*seqCount + j];	      
      distType ts = float(resultTS[i*seqCount + j]) / lengthWithoutGaps;	
      distType tv = float(resultTV[i*seqCount + j]) / lengthWithoutGaps;
      distType temp1 = 1.0-2.0*ts-tv;
      distType temp2 = 1.0-2.0*tv;
      distType distance = -1;
      if(!(temp1 <= 0 || temp2 <= 0)){
	distance = -0.5*log(1.0-2.0*ts-tv)-0.25*log(1.0-2.0*tv);
      }
      if(distance > maxDistance){
	maxDistance = distance;
      }
      distMatrix[i][j] = distance;
    }
  }
  postProcessDistanceMatrix();
#ifdef TIMING
  gettimeofday(&end,NULL);
  totalDistanceCorrection += (end.tv_sec - start.tv_sec)*1000.0 + (end.tv_usec - start.tv_usec)/1000.0;
  gettimeofday(&start,NULL);
#endif
#endif
}
  
void KimuraDistance::computeDistancesMTFastDist(int numThreads) { 
  /*  
  pthread_attr_t thread_attr;
  struct sched_param thread_param;
  int thread_policy;
  int ret;
  // set thread priorities CAN ONLY BE EXECUTED AS SUPERUSER 
  pthread_attr_init (&thread_attr);
  ret = pthread_attr_setschedpolicy (&thread_attr, SCHED_FIFO);
  if(ret != 0){
    cout << "ERROR" << endl;
    exit(1);
  }
  ret=  pthread_attr_setinheritsched (&thread_attr, PTHREAD_EXPLICIT_SCHED);
  if(ret != 0){
    cout << "ERROR" << endl;
    exit(1);
  }
  int newPrio = sched_get_priority_max(SCHED_FIFO);
  thread_param.sched_priority = newPrio;
  ret = pthread_attr_setschedparam (&thread_attr, &thread_param);
  if(ret != 0){
    cout << "ERROR" << endl;
    exit(1);
  }
  ret = pthread_setschedparam(pthread_self(),SCHED_FIFO, &thread_param);
  if(ret != 0){
    cout << "ERROR could not set new priority: " << ret << endl;
    cout << strerror(errno) << endl;
    exit(1);
  }
  */

#ifdef TIMING
  gettimeofday(&end,NULL);
  totalOther += (end.tv_sec - start.tv_sec)*1000.0 + (end.tv_usec - start.tv_usec)/1000.0;
  gettimeofday(&start,NULL);
#endif
  
  // Start threads
  pthread_t* threads = new pthread_t[numThreads-1];
  threadStateKimura** threadStates = new threadStateKimura*[numThreads-1];
  //start threads
  for (int i = 0; i < numThreads-1; i++) {
    threadStates[i] = new threadStateKimura();
    threadStates[i]->seqIdx = i;
    threadStates[i]->seqCount = seqCount;
    threadStates[i]->loader = loader;
    threadStates[i]->distMatrix = distMatrix;
    threadStates[i]->numThreads = numThreads;
    if(loader->type == PROTEIN){
      if(popcnt){
#ifdef __SSE4_2__
	threadStates[i]->distanceCalculator = new bitDistanceProteinPopCnt(verbose, loader);
#endif
      } else {
	threadStates[i]->distanceCalculator = new bitDistanceProtein(verbose, loader);
      }     
    } else {
      if(popcnt){
#ifdef __SSE4_2__
	threadStates[i]->distanceCalculator = new bitDistanceGapPopCnt(verbose, loader);
#endif	
      } else {
	threadStates[i]->distanceCalculator = new bitDistanceGap(verbose, loader);
      }
    }
    pthread_create(&threads[i], NULL, KimuraDistance::distThreadFastDist, (void*)threadStates[i]);
    //pthread_create(&threads[i], &thread_attr, KimuraDistance::distThreadFastDist, (void*)threadStates[i]);
  }
  //use this thread to do some work
  long data[3];
  bitDistance* distanceCalculator = NULL;
  if(loader->type == PROTEIN){
    if(popcnt){    
#ifdef __SSE4_2__
      distanceCalculator = new bitDistanceProteinPopCnt(verbose, loader);
#endif
    } else {
      distanceCalculator = new bitDistanceProtein(verbose, loader);
    }
  } else {
    if(popcnt){
#ifdef __SSE4_2__      
      distanceCalculator = new bitDistanceGapPopCnt(verbose, loader);
#endif      
    } else {
      distanceCalculator = new bitDistanceGap(verbose, loader);
    }    
  }
  for (int i = numThreads-1; i < seqCount-1; i+=numThreads) {
    for (int j = i+1; j < seqCount; j++) {
      if(loader->type == PROTEIN){
	distanceCalculator->calculateDistance(i,j,data);
	long total = data[0] + data[1];
	distType distance;
	if(data[2] == 0) {
	  distance = -1.0f;
	} else {
	  distance = total / (distType) data[2];
	}
	if ( distance < 0.75) {
	  if (distance > 0.0){
	    distance = - log(1.0 - distance - (distance * distance * 0.20));
	  }
	} else {
	  if (distance > 0.930) {
	    distance = 10.0;
	  } else {	  
	    int table_index = (int) ((distance*1000.0) - 750.0);
	  distance = (distType) (dayhoff_pams[ table_index ] / 100.0);
	  }
	}
	if(distance > maxDistance){
	  maxDistance = distance;
	}
	distMatrix[i][j] = distance;
      } else {
	distanceCalculator->calculateDistance(i,j,data);
	distType distance = -1;
	if(data[2] != 0){
	  distType ts = float(data[1]) / float(data[2]);	
	  distType tv = float(data[0]) / float(data[2]);	
	  distType temp1 = 1.0-2.0*ts-tv;
	  distType temp2 = 1.0-2.0*tv;	 
	  if(!(temp1 <= 0 || temp2 <= 0)){
	    distance = -0.5*log(1.0-2.0*ts-tv)-0.25*log(1.0-2.0*tv);
	  }
	  if(distance > maxDistance){
	    maxDistance = distance;
	  }
	}       
	distMatrix[i][j] = distance;
      }
    }
  }
  for (int i = 0; i < numThreads-1; i++) {
    pthread_join(threads[i],NULL);
    if(maxDistance < threadStates[i]->maxDistance){
      maxDistance = threadStates[i]->maxDistance;
    }    
  }
  postProcessDistanceMatrix();

#ifdef TIMING
  gettimeofday(&end,NULL);
  totalDistanceCorrection += (end.tv_sec - start.tv_sec)*1000.0 + (end.tv_usec - start.tv_usec)/1000.0;
  gettimeofday(&start,NULL);
#endif
}

// fastdist thread entry point
void* KimuraDistance::distThreadFastDist(void* ptr) {
  distType maxDistance = 0.0;
  threadStateKimura* state = (threadStateKimura*) ptr;
  long data[3];
  distType** distMatrix = state->distMatrix;
  int numThreads = state->numThreads;
  for (unsigned int i = state->seqIdx; i < state->seqCount-1; i+=numThreads) {
    for (unsigned int j = i+1; j < state->seqCount; j++) {
      if(state->loader->type == PROTEIN){
	state->distanceCalculator->calculateDistance(i,j,data);
	long total = data[0] + data[1];
	distType distance;	
	if(data[2] == 0) {
	  distance = -1.0f;
	} else {
	  distance = total / (distType) data[2];
	}
	if (distance < 0.75) {
	  if (distance > 0.0){
	    distance = - log( 1.0 - distance - (distance * distance * 0.20));
	  }
	} else {
	  if (distance > 0.930) {
	    distance = 10.0;
	  } else {
	    int table_index = (int) ((distance*1000.0) - 750.0);
	    distance = (distType) (dayhoff_pams[ table_index ] / 100.0);
	  }
	}
	if(distance > maxDistance){
	  maxDistance = distance;
	}
	distMatrix[i][j] = distance;      
      } else {
	state->distanceCalculator->calculateDistance(i,j,data);
	distType distance = -1;
	if(data[2] != 0){
	  distType ts = float(data[1]) / float(data[2]);	
	  distType tv = float(data[0]) / float(data[2]);
	  distType temp1 = 1.0-2.0*ts-tv;
	  distType temp2 = 1.0-2.0*tv;

	  if(!(temp1 <= 0 || temp2 <= 0)){
	    distance = -0.5*log(1.0-2.0*ts-tv)-0.25*log(1.0-2.0*tv);
	  }
	  if(distance > maxDistance){
	    maxDistance = distance;
	  }
	}
	distMatrix[i][j] = distance;
      }
    }
  }
  state->maxDistance = maxDistance;  
  return NULL;
}

void KimuraDistance::computeDistancesMT(int numThreads) {
  pthread_t* threads = new pthread_t[numThreads-1];
  threadStateKimura** threadStates = new threadStateKimura*[numThreads-1];  
  //start threads
  for (int i = 0; i < numThreads-1; i++) {
    threadStates[i] = new threadStateKimura();
    threadStates[i]->seqIdx = i;
    threadStates[i]->seqCount = seqCount;
    threadStates[i]->loader = loader;
    threadStates[i]->distMatrix = distMatrix;
    threadStates[i]->numThreads = numThreads;
    pthread_create(&threads[i], NULL, KimuraDistance::distThread, (void*)threadStates[i]);
  }
  //use this thread to do some work
  simpleDistanceCalculator* calculator = new simpleDistanceCalculator(verbose, loader);
  for (int i = numThreads-1; i < seqCount-1; i+=numThreads) {
    for (int j = i+1; j < seqCount; j++){
      if(loader->type == PROTEIN) {
	//Protein distance
	distType distance = calculator->calculateDistance(i,j);
	if ( distance < 0.75) {
	  if (distance > 0.0){ 
	    distance = - log(1.0 - distance - (distance * distance * 0.20));
	  }
	} else {
	  if (distance > 0.930) {
	  distance = 10.0;
	  } else {
	    int table_index = (int) ((distance*1000.0) - 750.0);
	    distance = (distType) (dayhoff_pams[ table_index ] / 100.0);
	  }
	}
	if(distance > maxDistance){
	  maxDistance = distance;
	}
	distMatrix[i][j] = distance;
      } else {
	unsigned int result[3];
	calculator->calculateDistanceDNA_TV_TS(i,j,result);
	distType distance = -1;
	if(result[2] != 0) {
	  distType ts = float(result[0]) / float(result[2]);	
	  distType tv = float(result[1]) / float(result[2]);
	  distType temp1 = 1.0-2.0*ts-tv;
	  distType temp2 = 1.0-2.0*tv;
	  if(!(temp1 <= 0 || temp2 <= 0)){
	    distance = -0.5*log(1.0-2.0*ts-tv)-0.25*log(1.0-2.0*tv);
	  }
	  if(distance > maxDistance){
	    maxDistance = distance;
	  }
	}
	distMatrix[i][j] = distance;
      }
    }
  }

  for (int i = 0; i < numThreads-1; i++) {
    pthread_join(threads[i],NULL);
    if(maxDistance < threadStates[i]->maxDistance){
      maxDistance = threadStates[i]->maxDistance;
    }
  }
  postProcessDistanceMatrix();
}

// Naive thread entry point
void* KimuraDistance::distThread(void* ptr) {
  distType maxDistance = 0.0;
  threadStateKimura* state = (threadStateKimura*) ptr;
  distType** distMatrix = state->distMatrix;
  int numThreads = state->numThreads;
  simpleDistanceCalculator* calculator = new simpleDistanceCalculator(state->verbose, state->loader);
  for (unsigned int i = state->seqIdx; i < state->seqCount-1; i+=numThreads) {
    for (unsigned int j = i+1; j < state->seqCount; j++) {
      if(state->loader->type == PROTEIN){
	distType distance = calculator->calculateDistance(i,j);
	if (distance < 0.75) {
	  if (distance > 0.0) {
	    distance = - log( 1.0 - distance - (distance * distance * 0.20));
	  }
	} else {
	  if (distance > 0.930) {
	    distance = 10.0;
	  } else {
	    int table_index = (int) ((distance*1000.0) - 750.0);
	    distance = (distType) (dayhoff_pams[ table_index ] / 100.0);
	  }
	}
	if(distance > maxDistance){
	  maxDistance = distance;
	}
	distMatrix[i][j] = distance;
      } else {
	unsigned int result[3];
	calculator->calculateDistanceDNA_TV_TS(i,j,result);
	distType distance = -1;
	if(result[2] != 0) { 
	  distType ts = float(result[0]) / float(result[2]);	
	  distType tv = float(result[1]) / float(result[2]);
	  distType temp1 = 1.0-2.0*ts-tv;
	  distType temp2 = 1.0-2.0*tv;
	  if(!(temp1 <= 0 || temp2 <= 0)){
	    distance = -0.5*log(1.0-2.0*ts-tv)-0.25*log(1.0-2.0*tv);
	  }
	  if(distance > maxDistance){
	    maxDistance = distance;
	  }
	}
	distMatrix[i][j] = distance;
      }
    }
  }
  state->maxDistance = maxDistance;
  return NULL;
}

void KimuraDistance::postProcessDistanceMatrix(){
  for (int i =0; i < seqCount; i++) {
    for (int j = 0; j < seqCount-1; j++) {
      if (j < i) {
	distMatrix[i][j] = distMatrix[j][i];
      } else if (i == j) {
	distMatrix[i][j] = 0.0;
      }
      if(distMatrix[i][j] == -1){
	distMatrix[i][j] = maxDistance * 2;
      } else if(distMatrix[i][j] < 0.00001){
	distMatrix[i][j] = 0.0;
      }
    }
  }
}

distType** KimuraDistance::getDistanceMatrix(){  
  return distMatrix;
}

