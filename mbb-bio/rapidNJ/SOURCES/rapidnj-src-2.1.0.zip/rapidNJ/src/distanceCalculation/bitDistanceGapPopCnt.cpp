#ifdef __SSE4_2__
#include "bitDistanceGapPopCnt.hpp"
#include <math.h>
#include <pthread.h>
#include "bitStringUtils.hpp"
#include <nmmintrin.h>

v4ui bitDistanceGapPopCnt::mask1 = {0x55555555,0x55555555,0x55555555,0x55555555};

bitDistanceGapPopCnt::bitDistanceGapPopCnt(bool verbose, dataloader* loader) {
  bitDistanceGapPopCnt::verbose = verbose;
  bitDistanceGapPopCnt::bitStrings = (v4ui**) loader->getBitStrings();
  bitDistanceGapPopCnt::gapFilters = (v4ui**) loader->getGapFilters();
  bitDistanceGapPopCnt::seqCount = loader->getSequenceCount();
  bitDistanceGapPopCnt::seqLength = loader->getSequenceLength();
  bitDistanceGapPopCnt::bitStringsCount = loader->getBitStringsCount();
  bitDistanceGapPopCnt::sequenceNames = *loader->getSequenceNames();
  numItr = bitStringsCount / 2; // at least 3 since bitstrings are padded to a multiple of 6  
}

int bitDistanceGapPopCnt::printSums(v4ui value, unsigned int bits) {
  v4ui_vector v;
  v.v = value;
  int sum = 0;
  for (int i = 0; i < 4; i++) {
    for (unsigned int j = 0; j < (32/bits); j++) {
      unsigned int val = (unsigned int) v.d[i] >> (j*bits) & ((unsigned int) pow(2,bits) - 1);
      sum += val;
      cout << val << " + ";
    }
  }
  cout << " = " << sum << endl;
  return sum;
}

void bitDistanceGapPopCnt::calculateDistance(int seq1, int seq2, long* retVal) {
  unsigned long long totalTS = 0;
  unsigned long long totalTV = 0;  
  unsigned long long totalResidues = 0;
  bitDistanceGapPopCnt::seq1 = seq1;
  bitDistanceGapPopCnt::seq2 = seq2;
  bitDistanceGapPopCnt::idx1 = 0;
  bitDistanceGapPopCnt::idx2 = 0;
  for (int k = 0; k < numItr; k++) {
    countTsTvAndGaps(totalTS,totalTV,totalResidues);
  }
  retVal[0] = totalTV;
  retVal[1] = totalTS;
  retVal[2] = totalResidues;
}

void bitDistanceGapPopCnt::printDistances() {
  for (int i = 0; i < seqCount; i++) {
    cout << sequenceNames[i] << "\t";
    for (int j = 0; j < seqCount; j++) {
      if (i <= j) {
	cout << "[" << distanceMatrixTS[i][j] << "," << distanceMatrixTV[i][j] << "]\t";
      } else {
	cout << "[" << distanceMatrixTS[j][i] << "," << distanceMatrixTV[j][i] << "]\t";
      }
    }
    cout << endl;
  }
}

void bitDistanceGapPopCnt::countTsTvAndGaps(unsigned long long& sum_ts, unsigned long long& sum_tv, unsigned long long& sum_gf) {
  v4ui_vector r0, r1, tv0, tv1, ts0, ts1, gf0, gf1;

  // Process 2x128 bit strings and gap filters.
  r0.v = _mm_xor_si128(bitStrings[seq1][idx1],bitStrings[seq2][idx2]);
  gf0.v = _mm_and_si128(gapFilters[seq1][idx1++],gapFilters[seq2][idx2++]);
  r1.v = _mm_xor_si128(bitStrings[seq1][idx1],bitStrings[seq2][idx2]);
  gf1.v = _mm_and_si128(gapFilters[seq1][idx1++],gapFilters[seq2][idx2++]);
  
  // Count transversions
  tv0.v = _mm_and_si128(_mm_srli_epi32(r0.v, 1),mask1);
  tv1.v = _mm_and_si128(_mm_srli_epi32(r1.v, 1),mask1);  

  // Count transitions
  ts0.v = _mm_andnot_si128(tv0.v,_mm_and_si128(r0.v,mask1));
  ts1.v = _mm_andnot_si128(tv1.v,_mm_and_si128(r1.v,mask1));

  // Handle gaps
  tv0.v = _mm_and_si128(tv0.v,gf0.v);
  tv1.v = _mm_and_si128(tv1.v,gf1.v);
  ts0.v = _mm_and_si128(ts0.v,gf0.v);
  ts1.v = _mm_and_si128(ts1.v,gf1.v);

  // combine vectors  
  tv0.v = _mm_or_si128(tv0.v,_mm_slli_epi32(tv1.v,1));
  ts0.v = _mm_or_si128(ts0.v,_mm_slli_epi32(ts1.v,1));
  gf0.v = _mm_or_si128(gf0.v,_mm_slli_epi32(gf1.v,1));

  // count ts, tv and gaps
  sum_tv += _mm_popcnt_u64(tv0.ul[0]);
  sum_tv += _mm_popcnt_u64(tv0.ul[1]);
  sum_ts += _mm_popcnt_u64(ts0.ul[0]);
  sum_ts += _mm_popcnt_u64(ts0.ul[1]);
  sum_gf += _mm_popcnt_u64(gf0.ul[0]);
  sum_gf += _mm_popcnt_u64(gf0.ul[1]);
}


bitDistanceGapPopCnt::~bitDistanceGapPopCnt(){
}
#endif
