#include "bitDistance.hpp"

bitDistance::bitDistance(void){

}

bitDistance::~bitDistance(){

}

