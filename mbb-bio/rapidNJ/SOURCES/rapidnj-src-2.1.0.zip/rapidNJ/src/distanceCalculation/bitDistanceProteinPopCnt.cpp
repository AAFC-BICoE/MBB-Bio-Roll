#ifdef __SSE4_2__
#include "bitDistanceProteinPopCnt.hpp"
#include <nmmintrin.h>

v4ui bitDistanceProteinPopCnt::mask1of8 = {0x01010101,0x01010101,0x01010101,0x01010101};
v4ui bitDistanceProteinPopCnt::gapMask = {0x2d2d2d2d,0x2d2d2d2d,0x2d2d2d2d,0x2d2d2d2d}; //matches '-' characters
const int mode = _SIDD_UBYTE_OPS | _SIDD_CMP_EQUAL_EACH;

bitDistanceProteinPopCnt::bitDistanceProteinPopCnt(bool verbose, dataloader* loader) {
  bitDistanceProteinPopCnt::verbose = verbose;
  bitDistanceProteinPopCnt::bitStrings = (v4ui**) loader->getBitStrings();
  bitDistanceProteinPopCnt::seqCount = loader->getSequenceCount();
  bitDistanceProteinPopCnt::seqLength = loader->getSequenceLength();
  bitDistanceProteinPopCnt::bitStringsCount = loader->getBitStringsCount();
  bitDistanceProteinPopCnt::sequenceNames = *loader->getSequenceNames();
  bitDistanceProteinPopCnt::paddedSeqLength = (seqLength + 127) & ~127;
  numItr8Bit_cache = bitStringsCount / 8; // bitstrings are padded to a multiple of 8
}

v4ui_vector test;

void bitDistanceProteinPopCnt::calculateDistance(int seq1, int seq2, long* retVal) {
  numItr8Bit = numItr8Bit_cache;
  /*numItr16Bit = numItr16Bit_cache;
  numItr32Bit = numItr32Bit_cache;
  numItrTop = numItrTop_cache;*/
  bitDistanceProteinPopCnt::seq1 = seq1;
  bitDistanceProteinPopCnt::seq2 = seq2;
  idx = 0;
  unsigned long long sumDist = 0;
  unsigned long long sumGap = 0;
  for (int k = 0; k < numItr8Bit; k++) {
    sum8_8BitVectors(sumDist, sumGap);        
  }
  retVal[0] = paddedSeqLength - sumGap - sumDist;
  retVal[1] = 0;
  retVal[2] = paddedSeqLength - sumGap;
  //cout << seq1 << " " << seq2 << ": " << paddedSeqLength - sumGap - sumDist << " " <<  paddedSeqLength - sumGap << endl;
}

inline void bitDistanceProteinPopCnt::sum8_8BitVectors(unsigned long long& sumDist,unsigned long long& sumGap) {
  v4ui_vector r, g;
  /*for(int i = 0; i < 8; i++){
    g.v = _mm_or_si128(_mm_cmpistrm(bitStrings[seq1][idx],gapMask,mode),_mm_cmpistrm(bitStrings[seq2][idx],gapMask,mode));
    r.v = _mm_andnot_si128(g.v,_mm_cmpistrm(bitStrings[seq1][idx],bitStrings[seq2][idx],mode));    
    sumDist += _mm_popcnt_u32(r.d[0]);
    sumGap += _mm_popcnt_u32(g.d[0]);
    idx++;
    }*/

  g.v = _mm_or_si128(_mm_cmpistrm(bitStrings[seq1][idx],gapMask,mode),_mm_cmpistrm(bitStrings[seq2][idx],gapMask,mode));
  r.v = _mm_andnot_si128(g.v,_mm_cmpistrm(bitStrings[seq1][idx],bitStrings[seq2][idx],mode));    
  sumDist += _mm_popcnt_u32(r.d[0]);
  sumGap += _mm_popcnt_u32(g.d[0]);
  idx++;
  
  g.v = _mm_or_si128(_mm_cmpistrm(bitStrings[seq1][idx],gapMask,mode),_mm_cmpistrm(bitStrings[seq2][idx],gapMask,mode));
  r.v = _mm_andnot_si128(g.v,_mm_cmpistrm(bitStrings[seq1][idx],bitStrings[seq2][idx],mode));    
  sumDist += _mm_popcnt_u32(r.d[0]);
  sumGap += _mm_popcnt_u32(g.d[0]);
  idx++;

  g.v = _mm_or_si128(_mm_cmpistrm(bitStrings[seq1][idx],gapMask,mode),_mm_cmpistrm(bitStrings[seq2][idx],gapMask,mode));
  r.v = _mm_andnot_si128(g.v,_mm_cmpistrm(bitStrings[seq1][idx],bitStrings[seq2][idx],mode));    
  sumDist += _mm_popcnt_u32(r.d[0]);
  sumGap += _mm_popcnt_u32(g.d[0]);
  idx++;

  g.v = _mm_or_si128(_mm_cmpistrm(bitStrings[seq1][idx],gapMask,mode),_mm_cmpistrm(bitStrings[seq2][idx],gapMask,mode));
  r.v = _mm_andnot_si128(g.v,_mm_cmpistrm(bitStrings[seq1][idx],bitStrings[seq2][idx],mode));    
  sumDist += _mm_popcnt_u32(r.d[0]);
  sumGap += _mm_popcnt_u32(g.d[0]);
  idx++;

  g.v = _mm_or_si128(_mm_cmpistrm(bitStrings[seq1][idx],gapMask,mode),_mm_cmpistrm(bitStrings[seq2][idx],gapMask,mode));
  r.v = _mm_andnot_si128(g.v,_mm_cmpistrm(bitStrings[seq1][idx],bitStrings[seq2][idx],mode));    
  sumDist += _mm_popcnt_u32(r.d[0]);
  sumGap += _mm_popcnt_u32(g.d[0]);
  idx++;
  
  g.v = _mm_or_si128(_mm_cmpistrm(bitStrings[seq1][idx],gapMask,mode),_mm_cmpistrm(bitStrings[seq2][idx],gapMask,mode));
  r.v = _mm_andnot_si128(g.v,_mm_cmpistrm(bitStrings[seq1][idx],bitStrings[seq2][idx],mode));    
  sumDist += _mm_popcnt_u32(r.d[0]);
  sumGap += _mm_popcnt_u32(g.d[0]);
  idx++;

  g.v = _mm_or_si128(_mm_cmpistrm(bitStrings[seq1][idx],gapMask,mode),_mm_cmpistrm(bitStrings[seq2][idx],gapMask,mode));
  r.v = _mm_andnot_si128(g.v,_mm_cmpistrm(bitStrings[seq1][idx],bitStrings[seq2][idx],mode));    
  sumDist += _mm_popcnt_u32(r.d[0]);
  sumGap += _mm_popcnt_u32(g.d[0]);
  idx++;

  g.v = _mm_or_si128(_mm_cmpistrm(bitStrings[seq1][idx],gapMask,mode),_mm_cmpistrm(bitStrings[seq2][idx],gapMask,mode));
  r.v = _mm_andnot_si128(g.v,_mm_cmpistrm(bitStrings[seq1][idx],bitStrings[seq2][idx],mode));    
  sumDist += _mm_popcnt_u32(r.d[0]);
  sumGap += _mm_popcnt_u32(g.d[0]);
  idx++;
}

/*
inline void bitDistanceProteinPopCnt::sum8_8BitVectors(unsigned long long& sumDist,unsigned long long& sumGap) {
  v4ui r, g;
  v4ui rTotal = {0x00000000,0x00000000, 0x00000000,0x00000000};
  v4ui gTotal = {0x00000000,0x00000000, 0x00000000,0x00000000};

  //should be unrolled automatically by the compiler
  for(int i = 0; i < 8; i++){ 
    v4ui mask = _mm_slli_epi32(mask1of8,i);
    r = _mm_cmpeq_epi8(bitStrings[seq1][idx],bitStrings[seq2][idx]);
    r = _mm_andnot_si128(r,mask);
    g = _mm_or_si128(_mm_cmpeq_epi8(bitStrings[seq1][idx],gapMask),_mm_cmpeq_epi8(bitStrings[seq2][idx],gapMask));
    gTotal = _mm_or_si128(_mm_and_si128(g,mask),gTotal);
    rTotal = _mm_or_si128(_mm_andnot_si128(g,r),rTotal);
    idx++;
  }
  
  //count the number of mutations and gaps
  v4ui_vector temp;
  temp.v = rTotal;  
  sumDist += _mm_popcnt_u64(temp.ul[0]);
  sumDist += _mm_popcnt_u64(temp.ul[1]);
  temp.v = gTotal;
  sumGap += _mm_popcnt_u64(temp.ul[0]);
  sumGap += _mm_popcnt_u64(temp.ul[1]);
}*/



bitDistanceProteinPopCnt::~bitDistanceProteinPopCnt(){
  
}
#endif
