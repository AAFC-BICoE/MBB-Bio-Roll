#include "dataloader.hpp"

dataloader::dataloader(void){
  type = UNKNOWN;
}

dataloader::~dataloader(){

}
