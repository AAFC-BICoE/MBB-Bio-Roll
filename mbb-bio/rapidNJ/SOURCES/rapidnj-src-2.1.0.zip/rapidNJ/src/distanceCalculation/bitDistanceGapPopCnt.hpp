#ifndef bitDistanceGapPopCnt_HPP_INCLUDED
#define bitDistanceGapPopCnt_HPP_INCLUDED

#include "stdinclude.h"
#include "dataloader.hpp"
#include "bitDistance.hpp"

class bitDistanceGapPopCnt : public bitDistance {

public:
  bitDistanceGapPopCnt(bool verbose, dataloader* loader);
  ~bitDistanceGapPopCnt();
  void calculateDistances();
  void calculateDistance(int, int, long* retVal);
  void printDistances();
  long** distanceMatrixTS;
  long** distanceMatrixTV;

private:
  bool verbose;
  v4ui** bitStrings;
  v4ui** gapFilters;
  int seqCount;
  int seqLength;
  int bitStringsSize;
  int bitStringsCount;
  static v4ui mask1;
  std::vector<string> sequenceNames;
  int seq1, seq2, idx1, idx2;
  int numItr;

  void initialiseDataStructures();
  void countTsTvAndGaps(unsigned long long& sum_ts, unsigned long long& sum_tv, unsigned long long& sum_gf);
  int printSums(v4ui, unsigned int);
};

#endif // bitDistanceGapPopCnt_HPP_INCLUDED
