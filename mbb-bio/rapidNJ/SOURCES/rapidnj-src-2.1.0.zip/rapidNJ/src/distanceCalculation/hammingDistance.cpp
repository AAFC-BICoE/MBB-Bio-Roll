#include "simpleDistanceCalculator.hpp"
#include "hammingDistance.hpp"
#include <math.h>

hammingDistance::hammingDistance(bool verbose, bool fastdist, dataloader* loader) {
  hammingDistance::verbose = verbose;
  hammingDistance::loader = loader;
  hammingDistance::fastdist = fastdist;
  hammingDistance::seqCount = loader->getSequenceCount();
  hammingDistance::seqLength = loader->getSequenceLength();  
  hammingDistance::sequenceNames = *loader->getSequenceNames();
}

void hammingDistance::computeHammingDistance(){
  simpleDistanceCalculator* nhc = new simpleDistanceCalculator(verbose, loader);
  distanceMatrix = new distType*[seqCount];
  for(int i = 0; i < seqCount; i++){
    distanceMatrix[i] = new distType[seqCount];
    for(int j = i+1; j < seqCount; j++){
      distanceMatrix[i][j] = nhc->calculateHammingDistance(i,j);
    }
  }
  postProcessDistanceMatrix();
}

void hammingDistance::postProcessDistanceMatrix(){
  for (int i = 0; i < seqCount; i++) {
    for (int j = 0; j < seqCount; j++) {
      if(i > j){
	distanceMatrix[i][j] = distanceMatrix[j][i];
      } else if(j == i){
	distanceMatrix[i][j] = 0;
      } 
    }
  }
}

void hammingDistance::printDistances(){
  for (int i = 0; i < seqCount; i++) {
    cout << sequenceNames[i] << "\t";
    for (int j = 0; j < seqCount; j++) {
      cout << distanceMatrix[i][j] << "\t";
    }
    cout << endl;
  }
  cout << endl;
}

// Test method
void hammingDistance::getTsTv() {
  simpleDistanceCalculator* sc = new simpleDistanceCalculator(verbose, loader);
  unsigned int distances[2];
  distanceMatrixTS = new int*[seqCount];
  distanceMatrixTV = new int*[seqCount];
  for(int i = 0; i < seqCount; i++){
    distanceMatrixTS[i] = new int[seqCount];
    distanceMatrixTV[i] = new int[seqCount];
    for(int j = i+1; j < seqCount; j++){
      sc->calculateDistanceDNA_TV_TS(i,j, distances);
      distanceMatrixTS[i][j] = distances[0];
      distanceMatrixTV[i][j] = distances[1];
    }
  }
  for (int i = 0; i < seqCount; i++) {
    cout << sequenceNames[i] << "\t";
    for (int j = 0; j < seqCount; j++) {
      if(i <= j){
	cout << "[" << distanceMatrixTS[i][j] << "," << distanceMatrixTV[i][j] << "]\t";
      } else {
	cout << "[" << distanceMatrixTS[j][i] << "," << distanceMatrixTV[j][i] << "]\t";
      }
    }
    cout << endl;
  }
}

distType** hammingDistance::getDistanceMatrix(){
  return distanceMatrix;
}

