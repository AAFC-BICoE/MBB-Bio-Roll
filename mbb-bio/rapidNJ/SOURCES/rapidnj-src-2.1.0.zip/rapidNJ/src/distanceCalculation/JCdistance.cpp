#include "JCdistance.hpp"
#include "simpleDistanceCalculator.hpp"
#include <math.h>
#include <fstream>
#include <math.h>
#include <pthread.h>
#include <sched.h>

using namespace std;

JCdistance::JCdistance(bool verbose, bool fastdist, dataloader* loader) {
  JCdistance::verbose = verbose;
  JCdistance::loader = loader;
  JCdistance::fastdist = fastdist;
  JCdistance::seqCount = loader->getSequenceCount();
  JCdistance::seqLength = loader->getSequenceLength();
  JCdistance::sequenceNames = *loader->getSequenceNames();
  maxDistance = 0.0;
  jcDistMatrix = new distType*[seqCount];
  for (int i = 0; i < seqCount; i++) {
    jcDistMatrix[i] = new distType[seqCount];
  }
}

  /*  
  pthread_attr_t thread_attr;
  struct sched_param thread_param;
  int thread_policy;
  int ret;

  // set thread priorities
  pthread_attr_init (&thread_attr);
  ret = pthread_attr_setschedpolicy (&thread_attr, SCHED_FIFO);
  if(ret != 0){
    cout << "ERROR" << endl;
    exit(1);
  }
  ret=  pthread_attr_setinheritsched (&thread_attr, PTHREAD_EXPLICIT_SCHED);
  if(ret != 0){
    cout << "ERROR" << endl;
    exit(1);
  }
  int newPrio = 99;
  thread_param.sched_priority = newPrio;
  ret = pthread_attr_setschedparam (&thread_attr, &thread_param);
  if(ret != 0){
    cout << "ERROR" << endl;
    exit(1);
  }  
  pthread_setschedparam(pthread_self(),SCHED_FIFO, &thread_param);
  */

void JCdistance::calculateDistancesMTFastDist(int numThreads) { 
  // Start threads
  pthread_t* threads = new pthread_t[numThreads-1];
  threadStateJC** threadStates = new threadStateJC*[numThreads-1];
  //start threads
  for (int i = 0; i < numThreads-1; i++) {
    threadStates[i] = new threadStateJC();
    threadStates[i]->seqIdx = i;
    threadStates[i]->seqCount = seqCount;
    threadStates[i]->loader = loader;
    threadStates[i]->jcDistMatrix = jcDistMatrix;
    threadStates[i]->seqLength = seqLength;
    threadStates[i]->numThreads = numThreads;
    //ret = pthread_create(&threads[i], &thread_attr, JCdistance::distJCThread, (void*)threadStates[i]);
    pthread_create(&threads[i], NULL, JCdistance::distJCThread, (void*)threadStates[i]);
  }
  //use this thread to do some work
  long distances[3];
  bitDistance* bitDistCalculator = new bitDistanceGap(verbose, loader);
  for (int i = numThreads-1; i < seqCount; i+=numThreads) {
    for (int j = i+1; j < seqCount; j++) {
      bitDistCalculator->calculateDistance(i,j,distances);
      long total = distances[0] + distances[1];
      distType distance;
      if(distances[2] == 0){
	distance = 0;
      } else {
	distance = total / (distType) distances[2];	
      }
      distance = -0.75 * log( 1.0 - (4.0 / 3.0)* distance);
      if(maxDistance < distance){
	maxDistance = distance;
      }
      jcDistMatrix[i][j] = distance;      
    }
  }  
  for (int i = 0; i < numThreads-1; i++) {
    pthread_join(threads[i],NULL);
    if(maxDistance < threadStates[i]->maxDistance){
      maxDistance = threadStates[i]->maxDistance;
    }
  }
  delete bitDistCalculator;
  postProcessDistanceMatrix();
}

// fastdist thread entry point
void* JCdistance::distJCThread(void* ptr) {
  distType maxDistance = 0.0;
  threadStateJC* state = (threadStateJC*) ptr;
  long distances[3];
  distType** jcDistMatrix = state->jcDistMatrix;
  int numThreads = state->numThreads;
  bitDistance* bitDistCalculator = new bitDistanceGap(state->verbose, state->loader);
  for (unsigned int i = state->seqIdx; i < state->seqCount; i+=numThreads) {
    for (unsigned int j = i+1; j < state->seqCount; j++) {
      bitDistCalculator->calculateDistance(i,j,distances);
      long total = distances[0] + distances[1];
      distType distance;
      if(distances[2] == 0){
	distance = 0;
      } else {
	distance = total / (distType) distances[2];	
      }
      distance = -0.75 * log( 1.0 - (4.0 / 3.0)* distance);
      if(maxDistance < distance){
	maxDistance = distance;
      }      
      jcDistMatrix[i][j] = distance;
    }
  }
  state->maxDistance = maxDistance;
  return NULL;

}

void JCdistance::calculateDistancesMT(int numThreads) {
  pthread_t* threads = new pthread_t[numThreads-1];
  threadStateJC** threadStates = new threadStateJC*[numThreads-1];  
  //start threads
  for (int i = 0; i < numThreads-1; i++) {
    threadStates[i] = new threadStateJC();
    threadStates[i]->seqIdx = i;
    threadStates[i]->seqCount = seqCount;
    threadStates[i]->loader = loader;
    threadStates[i]->jcDistMatrix = jcDistMatrix;
    threadStates[i]->seqLength = seqLength;
    threadStates[i]->numThreads = numThreads;
    pthread_create(&threads[i], NULL, JCdistance::distJCThreadNaive, (void*)threadStates[i]);
  }
  //use this thread to do some work
  simpleDistanceCalculator* calculator = new simpleDistanceCalculator(verbose, loader);
  for (int i = numThreads-1; i < seqCount; i+=numThreads) {
    for (int j = i+1; j < seqCount; j++) {
      distType distance = calculator->calculateDistance(i,j);
      distance = -0.75 * log( 1.0 - (4.0 / 3.0)* distance);
      if(maxDistance < distance){
	maxDistance = distance;
      }
      jcDistMatrix[i][j] = distance;
    }
  }
  for (int i = 0; i < numThreads-1; i++) {
    pthread_join(threads[i],NULL);
    if(maxDistance < threadStates[i]->maxDistance){
      maxDistance = threadStates[i]->maxDistance;
    }
  }
  postProcessDistanceMatrix();
}

// Naive thread entry point
void* JCdistance::distJCThreadNaive(void* ptr) { 
  distType maxDistance = 0.0;
  threadStateJC* state = (threadStateJC*) ptr;
  distType** jcDistMatrix = state->jcDistMatrix;
  int numThreads = state->numThreads;
  simpleDistanceCalculator* calculator = new simpleDistanceCalculator(state->verbose, state->loader);
  for (unsigned int i = state->seqIdx; i < state->seqCount; i+=numThreads) {
    for (unsigned int j = i+1; j < state->seqCount; j++) {
      distType distance = calculator->calculateDistance(i,j);
      distance = -0.75 * log( 1.0 - (4.0 / 3.0)* distance);
      if(maxDistance < distance){
	maxDistance = distance;
      }
      jcDistMatrix[i][j] = distance;
    }
  }
  state->maxDistance = maxDistance;
  return NULL;
}

void JCdistance::postProcessDistanceMatrix(){
  for (int i =0; i < seqCount; i++) {
    for (int j = 0; j < seqCount; j++) {
      if (j < i) {
	jcDistMatrix[i][j] = jcDistMatrix[j][i];
      } else if (i == j) {
	jcDistMatrix[i][j] = 0.0;
      }
      if(jcDistMatrix[i][j] < 0.00001){
	jcDistMatrix[i][j] = 0.0;
      }
      if(jcDistMatrix[i][j] == -1){
	jcDistMatrix[i][j] = maxDistance * 2;
      }
    }
  }
}

distType** JCdistance::getDistanceMatrix(){  
  return jcDistMatrix;
}
