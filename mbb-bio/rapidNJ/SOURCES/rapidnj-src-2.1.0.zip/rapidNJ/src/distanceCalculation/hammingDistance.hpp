#ifndef NAIVEHAMMING_H
#define NAIVEHAMMING_H

#include "stdinclude.h"
#include "dataloader.hpp"
#include <fstream>

using namespace std;

class hammingDistance {
  
 public:
  hammingDistance(bool, bool fastdist, dataloader* loader);
  void computeHammingDistance();
  distType** getDistanceMatrix();  
  ~hammingDistance();
  void getTsTv();
  void printDistances();
  
 private:
  void postProcessDistanceMatrix();

  char** sequences;
  bool verbose;
  int seqLength;
  int seqCount;
  int** distanceMatrixTS;
  int** distanceMatrixTV;
  distType** distanceMatrix;
  vector<string> sequenceNames;
  static const int BUFFER_SIZE = 16384;
  bool fastdist;
  dataloader* loader;

  void readHeader();
  void parseName(char* input, int seq);
  int compareSequences(int i, int j);
  void createDataStructures();
  void initializeData(string);
  
};

#endif
