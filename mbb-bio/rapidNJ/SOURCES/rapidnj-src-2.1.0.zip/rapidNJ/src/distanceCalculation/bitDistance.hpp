#ifndef BITDISTANCE_H
#define BITDISTANCE_H

#include <stdinclude.h>
#include <fstream>

using namespace std;

class bitDistance {

public:
  bitDistance(void);
  virtual ~bitDistance();
  virtual void calculateDistance(int seq1, int seq2, long* retVal) = 0;

protected:
  
};

#endif

