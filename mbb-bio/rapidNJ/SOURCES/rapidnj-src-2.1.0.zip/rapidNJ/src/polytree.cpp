/*This class is a very efficient implementation af a bifurcating phylogenetic tree.
* It can be serialised to Newick format. 
*/

#include "stdinclude.h"
#include "polytree.h"

using namespace std;

/* 
 * size - number of leafs
*/
polytree::polytree(int size, vector<string> sequenceNames){
  distances = new double[size*2];
  left_indexes = new int[size];
  right_indexes = new int[size];
  leaf_names = new string[size];
  polytree::size = size;
  current_index = 0;
  leaf_index = 0;  
  if(sequenceNames.size() > 0){
    for(int k = 0; k < size; k++){
      addLeaf(sequenceNames[k]);
    }
  }
}

void polytree::addLeaf(string name){
  leaf_names[leaf_index] = name;
  leaf_index++;  
}

void polytree::addInternalNode(double left_dist, double right_dist, int left_index, int right_index){  
  left_indexes[current_index] = left_index;
  right_indexes[current_index] = right_index;
  distances[left_index] = left_dist;
  distances[right_index] = right_dist;
  current_index++;
}

void polytree::serialize_tree(int left_index, int right_index, double distance){


  //    return;


  cout << "(";
  if(left_index < size){
    cout << "'" << leaf_names[left_index] << "'";
    cout << ":";
    int length = sprintf(buffer,"%.5g", distance);
    string s = "";
    s.append(buffer,length);
    cout << s;
  } else {
    if(right_index >= size){
      cout << "(";
    }
    serialize_node(left_indexes[left_index - size] , right_indexes[left_index - size], left_index);
    if(right_index >= size){
      cout << "):";
      int length = sprintf(buffer,"%.5g", distance);
      string s = "";
      s.append(buffer,length);
      cout << s;
    }
  }
  cout << ",";
  if(right_index < size){
    cout << "'" << leaf_names[right_index] << "'";
    cout << ":";
    int length = sprintf(buffer,"%.5g", distance);
    string s = "";
    s.append(buffer,length);
    cout << s;
  } else { 
    serialize_node(left_indexes[right_index - size], right_indexes[right_index - size],right_index);    
  }
  cout << ");";
}

void polytree::serialize_node(int left_index, int right_index, int index){
  if(left_index < size){
    // leaf node
    cout << "'" << leaf_names[left_index] << "'";
    cout << ":";
    int length = sprintf(buffer,"%.5g", distances[left_index]);
    string s = "";
    s.append(buffer,length);
    cout << s;
  } else {
    // serialize the left tree recursively
    cout << "(";
    serialize_node(left_indexes[left_index - size], right_indexes[left_index-size], left_index);
    cout << "):";
    int length = sprintf(buffer,"%.5g", distances[left_index]);
    string s = "";
    s.append(buffer,length);
    cout << s;
  }
  cout << ",";
  if(right_index < size){
    // leaf node
    cout << "'" << leaf_names[right_index] << "'";
    cout << ":";
    int length = sprintf(buffer,"%.5g", distances[right_index]);
    string s = "";
    s.append(buffer,length);
    cout << s;
  }
  else{
    // serialize the right tree recursively
    cout << "(";
    serialize_node(left_indexes[right_index - size], right_indexes[right_index-size], right_index);
    cout << "):";
    int length = sprintf(buffer,"%.5g", distances[right_index]);
    string s = "";
    s.append(buffer,length);
    cout << s;
  }
}

polytree::~polytree(void){
  delete[] distances;
  delete[] left_indexes;
  delete[] right_indexes;
  delete[] leaf_names;
}
