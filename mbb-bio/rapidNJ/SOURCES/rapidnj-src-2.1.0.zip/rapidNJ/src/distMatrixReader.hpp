#ifndef DISTMATRIXREADER_H
#define DISTMATRIXREADER_H
#include "polytree.h"
#include <string>
#include "stdinclude.h"
#include <fstream>
#include <vector>

using namespace std;

class distMatrixReader {
  
 public:
  distMatrixReader(bool verbose, std::string filename, int matrixSize, bool halfMatrix);
  distMatrixReader(bool verbose, int matrixSize, bool halfMatrix, vector<string>* sequenceNames, distType** matrix);
  ~distMatrixReader(void);
  void read_data();
  distType** getMatrix();  
  string getFileName();
  void initializeData();
  vector<string> sequenceNames;

  void printMatrix(){
    for(int i = 0; i < matrixSize; i++){
      int rowSize = matrixSize;
      if(halfMatrix){
	rowSize = i+1;
      }
      for(int j = 0; j < rowSize; j++){
	cout << matrix[i][j] << "\t";
      }
      cout << endl;
    }
  }  


 private:
  distType** matrix;
  polytree* mytree;
  //  node** nodes;
  int matrixSize;
  int curRow;
  int curCol;
  bool verbose;
  string filename;
  static const int bufsize = 65536;
  char* buf;
  bool halfMatrix;
  
  void createDatastructures();
  inline void parseData(char* input);	
};

#endif
