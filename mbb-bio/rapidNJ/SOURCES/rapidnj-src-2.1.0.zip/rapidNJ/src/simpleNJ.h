#ifndef SIMPLENJ_H
#define SIMPLENJ_H

#include "polytree.h"
#include "distMatrixReader.hpp"

class simpleNJ
{
 public:
  simpleNJ(distMatrixReader* datareader, int matrixSize);
  ~simpleNJ(void);
  void run();
  
 private:
  distType** matrix;
  polytree* mytree;
  int matrixSize;	
  distType* separationsums;
  distType* separations;
  int clusterCount;
  int min1;
  int min2;
  int* activeRows;
  int nextId;
  distMatrixReader* reader;
  
  void findMin();
  void initialize();
  void mergeMinNodes();
  void updateMatrix();
};
#endif
