/*
 * Copyright (c) 2003, The Institute for Genomic Research (TIGR).  All
 * rights reserved.
 */

/* 
 * This file is automagically updated by 'make update-version' 
 */

static const char gVersionStr[] = "libSlice Version 1.10";
static const char gRevisionStr[] = "$Revision$";
