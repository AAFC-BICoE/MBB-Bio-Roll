#ifndef ASSEMBLY_STATS_HH
#define ASSEMBLY_STATS_HH 1

#include "LaunchPad.hh"

#endif
