all = [
    'mcalc_builder',
    'extensions',
    'vclean',
    'colorrules',
    'histogram',
]
