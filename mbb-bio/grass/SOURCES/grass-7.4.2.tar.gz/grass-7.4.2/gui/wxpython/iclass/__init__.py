all = [
    'digit',
    'plots',
    'dialogs',
    'g.gui.iclass',
    'toolbars',
    'statistics',
    'frame',
]
