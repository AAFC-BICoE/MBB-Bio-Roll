all = [
    'wizard',
    'base',
    'dialogs',
]
