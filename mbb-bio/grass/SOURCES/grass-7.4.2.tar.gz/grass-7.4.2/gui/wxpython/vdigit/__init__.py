all = [
    'preferences',
    'main',
    'wxdigit',
    'dialogs',
    'mapwindow',
    'wxdisplay',
    'g.gui.vdigit',
    'toolbars',
]
