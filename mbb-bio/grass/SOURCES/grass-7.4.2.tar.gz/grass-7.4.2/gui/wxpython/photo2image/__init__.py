all = [
    'ip2i_manager',
    'ip2i_mapdisplay',
    'ip2i_toolbars',
]
