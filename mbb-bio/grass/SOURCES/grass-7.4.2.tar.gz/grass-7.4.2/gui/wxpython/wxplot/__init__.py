all = [
    'scatter',
    'base',
    'dialogs',
    'profile',
    'histogram',
]
