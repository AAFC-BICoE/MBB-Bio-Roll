void plot(double, double, double, double, int, int);
