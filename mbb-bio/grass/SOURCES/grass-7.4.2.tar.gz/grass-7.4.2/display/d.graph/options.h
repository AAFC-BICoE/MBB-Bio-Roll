
extern float hsize;
extern float vsize;
extern int mapunits;
extern FILE *infile;
