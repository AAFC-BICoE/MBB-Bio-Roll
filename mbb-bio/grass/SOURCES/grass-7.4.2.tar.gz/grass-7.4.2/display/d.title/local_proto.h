#include <grass/raster.h>

/* fancy.c */
void fancy(struct Cell_head *, struct Categories *, FILE *);

/* normal.c */
void normal(struct Cell_head *, struct Categories *, int, FILE *);
