#!/bin/sh
autoreconf --force --install -v
