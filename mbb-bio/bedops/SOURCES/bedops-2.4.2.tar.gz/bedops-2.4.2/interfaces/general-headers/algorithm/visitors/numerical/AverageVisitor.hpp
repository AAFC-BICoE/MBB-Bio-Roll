/*
  FILE: AverageVisitor.hpp
  AUTHOR: Shane Neph & Scott Kuehn
  CREATE DATE: Thu Aug 23 17:42:22 PDT 2007
  PROJECT: windowing-visitors
  ID: $Id:$
*/

//
//    BEDOPS
//    Copyright (C) 2011, 2012, 2013 Shane Neph, Scott Kuehn and Alex Reynolds
//
//    This program is free software; you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation; either version 2 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License along
//    with this program; if not, write to the Free Software Foundation, Inc.,
//    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
//

// Macro Guard
#ifndef CLASS_WINDOW_AVERAGE_VISITOR_H
#define CLASS_WINDOW_AVERAGE_VISITOR_H


// Files included
#include "data/measurement/NaN.hpp"


namespace Visitors {


  //=========
  // Average
  //=========
  template <
            typename Process,
            typename BaseVisitor
           >
  struct Average : BaseVisitor {

    typedef BaseVisitor BaseClass;
    typedef Process ProcessType;
    typedef typename BaseClass::reference_type T1;
    typedef typename BaseClass::mapping_type T2;

    explicit Average(const ProcessType& pt = ProcessType())
        : pt_(pt), sum_(0), counter_(0)
      { /* */ }

    inline void Add(T2* bt) {
      sum_ += *bt;
      ++counter_;
    }

    inline void Delete(T2* bt) {
      sum_ -= *bt;
      --counter_;
    }

    inline void DoneReference() {
      static const Signal::NaN nan = Signal::NaN();
      if ( counter_ > 0 )
        pt_.operator()(sum_/counter_);
      else
        pt_.operator()(nan);
    }

    inline void End() {
      sum_ = 0;
      counter_ = 0;
    }

    virtual ~Average()
      { /* */ }

  protected:
    ProcessType pt_;
    double sum_;
    int counter_;
  };


} // namespace Visitors

#endif // CLASS_WINDOW_AVERAGE_VISITOR_H
