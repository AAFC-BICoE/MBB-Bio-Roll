#!/bin/bash

source bwa-0.6.1

bwa index -a bwtsw Reference/prim-ab-81-scaffolds.fa
