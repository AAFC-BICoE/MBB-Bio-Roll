/* MULTIPLET.C;                                 Last update: March 14, 1997. */
/*   - a subroutine to evaluate multiplet counts in a protein sequence.      */
/* Dependencies:   called by saps.c; calls mpcluster.c                       */
/* Bugs:                                                                     */

/*   Volker Brendel, Department of Mathematics, Stanford University,  */
/*   Stanford CA 94305; (415) 723-9256, volker@gnomic.stanford.edu    */

#include <stdio.h>
#include <ctype.h>
#include <math.h>
#include "def.h"
extern char AAUC[25];
extern char CHPN[25];
extern char NAUC[12];

#define TRUE			1
#define FALSE			0
#define MAX_NL		       24
#define MAX_MPLETS	      500
#define MAX_APLETS	      500
#define MAX_MPLET_SIZE		5
#define MAX_APLET_SIZE		8
#define MAX_EXCEPTIONS	       50

/***********************************/
/* Compile options specified here: */
/***********************************/
#define FORAGG		/* alternatives: FORAGG - evaluate all multiplet
			   sizes together; FOREAS - evaluate all sizes
			   separately */

int MIN_MPLET_SIZE= 2;
int MIN_APLET_SIZE= 2;

typedef struct {
	char letter;	/* for exception mplet, the letter of the mplet */
	char first;	/* for exception aplet, first letter of the pair */
	char second;	/* for exception aplet, 2nd letter of the pair */
	int location;	/* - position in the sequence of the exception */
	int size;	/* - size of the exception */
	} except;

int mplet_count_l_s[MAX_NL][MAX_MPLET_SIZE+1];
int mplet_criti_l_s[MAX_NL][MAX_MPLET_SIZE+1];
int mplet_posit_l_n[MAX_NL][MAX_MPLETS];
int mplet_size_l_n[MAX_NL][MAX_MPLETS];
int mplet_count_l[MAX_NL];
int mplet_criti_l[MAX_NL];
int mplet_count;
int mplet_criti[2];
int mplet_dist[MAX_MPLETS];
int mplet_exception_count;
except mplet_exception[MAX_EXCEPTIONS];

int aplet_count_ll_s[MAX_NL][MAX_NL][MAX_APLET_SIZE+1];
int aplet_criti_ll_s[MAX_NL][MAX_NL][MAX_APLET_SIZE+1];
int aplet_posit_ll_n[MAX_NL][MAX_NL][MAX_APLETS];
int aplet_size_ll_n[MAX_NL][MAX_NL][MAX_APLETS];
int aplet_count_ll[MAX_NL][MAX_NL];
int aplet_criti_ll[MAX_NL][MAX_NL];
int aplet_count;
int aplet_exception_count;
except aplet_exception[MAX_EXCEPTIONS];

#define DISTANCE_BINS		4
int distances[DISTANCE_BINS]= { 0, 5, 10, 20 };
int distance_count[DISTANCE_BINS];

int lcount[MAX_NL];
double frqcy[MAX_NL];
int last_mp_pos;
int last_mp_size;


multiplet(pseq,numaa,ABC,cseq,clgth,outfp,pstyle,tabfp,tabflag)
FILE *outfp, *tabfp;
int pseq[], numaa, cseq[], clgth, pstyle, tabflag;
char ABC[];
{
int i,j,k;
int letter, last_letter, first, second;
int mp_size, ap_size;
int flag;
int pgnum= 0;
#ifdef FOREAS
int npflag;
#endif

double p;
double mean, var;

int aid, NUM_LETTERS;
static int pmask[2][24]= {
	{0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23},
	{0,0,0,0,0,1,2,0,2,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0} };
static char CHG[4]= "0+-";
char SYMB[25], aname[11];

if (ABC[0]=='L')
  {aid= 0; NUM_LETTERS= 24; strcpy(SYMB,ABC); strcpy(aname,"amino acid");}
if (ABC[0]=='0')
  {aid= 1; NUM_LETTERS=  3; strcpy(SYMB,CHG); strcpy(aname,"charge");}

for (i=0; i<NUM_LETTERS; i++)
  {for (j=0;j<MAX_MPLET_SIZE+1;j++)
     {mplet_count_l_s[i][j]= 0; mplet_criti_l_s[i][j]= 0; }
   for (j=0;j<NUM_LETTERS;j++)
     {aplet_count_ll[i][j]= 0;
      for (k=0;k<=MAX_APLET_SIZE;k++)
	aplet_count_ll_s[i][j][k]= 0;
     }
   mplet_count_l[i]= 0;
   lcount[i]= 0;
  }
for (i=0; i<DISTANCE_BINS; i++)   distance_count[i]= 0;
aplet_count= mplet_count= 0;
mplet_exception_count= aplet_exception_count= 0;
mp_size=ap_size= 1;
last_letter= first= second= -1;
last_mp_pos= 1;
last_mp_size= 0;


/* RECORD ALL MPLETS AND APLETS: */
for (i=0; i<numaa; i++)
  {letter= pmask[aid][pseq[i]];
   lcount[letter]++;
   if (letter==last_letter)   mp_size++;
   else
     {if (mp_size>=MIN_MPLET_SIZE)
	record_mplet(last_letter,mp_size,i-mp_size+1,SYMB);
      mp_size= 1;
     }
   if (ap_size%2)
     {if (letter==second)   ap_size++;
      else
	{if (ap_size>=MIN_APLET_SIZE)
	   record_aplet(first,second,ap_size,i-ap_size+1,SYMB);
	 ap_size= 2;
	 first= last_letter;
	 second= letter;
	}
     }
   else
     {if (letter==first)   ap_size++;
      else
	{if (first>=0 && ap_size>=MIN_APLET_SIZE)
	   record_aplet(first,second,ap_size,i-ap_size+1,SYMB);
	 ap_size= 2;
	 first= last_letter;
	 second= letter;
	}
     }
   last_letter= letter;
  }

if (mp_size>=MIN_MPLET_SIZE)
  record_mplet(last_letter,mp_size,i-mp_size+1,SYMB);

if (ap_size>=MIN_APLET_SIZE)
  record_aplet(first,second,ap_size,i-ap_size+1,SYMB);


/* FOR EACH LETTER (AND SIZE), CALCULATE THE CRITICAL NUMBER OF MPLETS: */
for( i=0;i<NUM_LETTERS;i++)
  {frqcy[i]= (double)lcount[i]/(double)numaa;
   p= frqcy[i]*frqcy[i]*(1.0-frqcy[i]);
   mean= (double)numaa * p;
   var= mean * (1.0-p);
   mplet_criti_l[i]=  ceil(mean+4.0*sqrt(var));
#ifdef FOREAS
   for (j=MIN_MPLET_SIZE; j<=MAX_MPLET_SIZE; j++)
     {p= pow(frqcy[i],(double)j)*(1.0-frqcy[i])*(1.0-frqcy[i]);
      mean= (double)numaa * p;
      var= mean * (1.0-p);
      mplet_criti_l_s[i][j]=  ceil( mean+4.0*sqrt(var) );
     }
#endif
  }


/* FOR EACH PAIR OF LETTERS (AND SIZE), CALCULATE THE CRITICAL NUMBER OF
   APLETS: */
for (i=0; i<NUM_LETTERS;i++)
  {for (j=i+1; j<NUM_LETTERS; j++)
     {p= (2.0-frqcy[i]-frqcy[j]-2.0*frqcy[i]*frqcy[j]+
	frqcy[i]*frqcy[i]*frqcy[j]+frqcy[i]*frqcy[j]*frqcy[j]) *
	frqcy[i]*frqcy[j]/(1.0-frqcy[i]*frqcy[j]);
      mean= (double)numaa * p;
      var= mean * (1.0-p);
      aplet_criti_ll[i][j]= ceil( mean+4.0*sqrt(var) );
#ifdef FOREAS
      for (k=MIN_APLET_SIZE; k<=MAX_APLET_SIZE; k++)
	{h= k/2;
	 if (k%2)    p= pow(frqcy[i],(double)h)*pow(frqcy[j],(double)(h+1)) *
		(1.0-frqcy[i])*(1.0-frqcy[i]) +
		 pow(frqcy[i],(double)(h+1))*pow(frqcy[j],(double)h) *
		(1.0-frqcy[j])* (1.0-frqcy[j]);
	 else    p= 2.0 * pow(frqcy[i],(double)h)*pow(frqcy[j],(double)h) *
		(1.0-frqcy[i])*(1.0-frqcy[j]);
	 mean= (double)numaa * p;
	 var= mean * (1.0-p);
	 aplet_criti_ll_s[i][j][k]= ceil( mean+4.0*sqrt(var) );
	}
#endif
     }
  }


/* CALCULATE THE CRITICAL NUMBER OF TOTAL MPLETS: */
p= 0.0;
if (aid==0)   p+= frqcy[0]*frqcy[0]*(1.-frqcy[0]);
for (i=1; i<NUM_LETTERS; i++)   p+= frqcy[i]*frqcy[i]*(1.-frqcy[i]);
mean= (double)numaa * p;
var= mean * (1.0-p);
mplet_criti[0]= (floor(mean-3.0*sqrt(var)) > 0) ? (int)floor(mean-3.0*sqrt(var)) : 0;
mplet_criti[1]= ceil(mean+3.0*sqrt(var));


/* GENERATE HISTOGRAM OF DISTANCES BETWEEN MPLETS: */
mplet_dist[mplet_count]= numaa-last_mp_pos-last_mp_size+1;
for (i=0;i<=mplet_count;i++)
  {for (j=0; j<DISTANCE_BINS; j++)
     if (mplet_dist[i] >= distances[j] &&
	  (j+1==DISTANCE_BINS || mplet_dist[i] < distances[j+1]) )
	distance_count[j]++;
  }


/* OUTPUT: TOTAL NUMBER OF MPLETS AND ALTPLETS */
if (pstyle%2==0 || (pstyle==1 &&
	(mplet_count<mplet_criti[0] || mplet_count>mplet_criti[1]) ) ) {
fprintf(outfp,"\n%1d. Total number of %s ", ++pgnum, aname);
fprintf(outfp,"multiplets: %3d  (Expected range: %3d--%3d)", mplet_count,
	mplet_criti[0], mplet_criti[1] );
if (mplet_count<mplet_criti[0])
  {fprintf(outfp," low");
   if (tabflag) {
   fprintf(tabfp,"MU Low %s multiplet count: ", aname);
   fprintf(tabfp,"%3d (critical value: %3d)\n", mplet_count, mplet_criti[0]);
   }
  }
if (mplet_count>mplet_criti[1])
  {fprintf(outfp," high");
   if (tabflag) {
   fprintf(tabfp,"MU High %s multiplet count: ", aname);
   fprintf(tabfp,"%3d (critical value: %3d)\n", mplet_count, mplet_criti[1]);
   }
  }
fprintf(outfp,"\n");
} /* end-of-if-pstyle */

if (pstyle%2==0 ) {

if (aid==1)
  {fprintf(outfp,"   %d +plets (f+: %.1lf%%), %d -plets (f-: %.1lf%%)\n",
	mplet_count_l[1],frqcy[1]*100.0,
	mplet_count_l[2],frqcy[2]*100.0 );
   fprintf(outfp,
	"   Total number of charge altplets: %d (Critical number: %d)\n",
	aplet_count, aplet_criti_ll[1][2] );
  }
fprintf(outfp,"\n");

if (aid==0) {
/* OUTPUT: DISTANCES, HISTOGRAM OF DISTANCES FOR ALL MPLETS */
if ( mplet_count < mplet_criti[0] || mplet_count > mplet_criti[1] )
  {fprintf(outfp,"%8d  ", 1);
   if (pseq[0]==pseq[1])   fprintf(outfp,"%c", AAUC[pseq[0]] );
   else   fprintf(outfp,".");
   for( i=1; i<numaa-1 ; ++i )
     {if (i%10 == 0)   fprintf(outfp," ");
      if (i%60 == 0)   fprintf(outfp,"\n%8d  ", i+1 );
      if (pseq[i-1]==pseq[i] || pseq[i+1]==pseq[i])
        fprintf(outfp,"%c", AAUC[pseq[i]] );
      else   fprintf(outfp,".");
     }
   if ((numaa-1)%10 == 0)   fprintf(outfp," ");
   if ((numaa-1)%60 == 0)   fprintf(outfp,"\n%8d  ", numaa );
   if (pseq[numaa-2]==pseq[numaa-1])
     fprintf(outfp,"%c", AAUC[pseq[numaa-1]] );
   else   fprintf(outfp,".");
   fprintf(outfp,"\n\n");
  }
 } /* end-of-if-aid */

flag= FALSE;
for (i=0;i<DISTANCE_BINS-1;i++)
  {if (!flag)
     {fprintf(outfp,
	"%1d. Histogram of spacings between consecutive %s multiplets:\n   ",
	++pgnum, aname );
      flag= TRUE;
     }
   fprintf(outfp,"(%d-%d) %d   ", distances[i]+1, distances[i+1],
	distance_count[i] );
  }
fprintf(outfp,"(>=%d) %d", distances[i]+1, distance_count[i] );
if (flag) fprintf(outfp,"\n");

} /* end-of-if-pstyle */


/* MULTIPLET CLUSTERS: */
if (aid==0)   mpcluster(numaa,++pgnum);


if (pstyle%2==0 ) {
fprintf(outfp,"\n");


/* OUTPUT: INDIVIDUALLY SIGNIFICANT MPLETS: */
flag= FALSE;
for (i=0;i<NUM_LETTERS;i++)
#ifdef FOREAS
  {npflag= 1;
   for (j=MIN_MPLET_SIZE;j<=MAX_MPLET_SIZE;j++)
     {if ( mplet_count_l_s[i][j] > mplet_criti_l_s[i][j] )
#endif
#ifdef FORAGG
     {if ( mplet_count_l[i] > mplet_criti_l[i] )
#endif
	{if (!flag) 
	  {fprintf(outfp,
		"%1d. Significant specific %s multiplet counts:\n",
		++pgnum, aname );
#ifdef FOREAS
	    fprintf(outfp,
  "Letter\tCount\t%%\tMplet size\tObserved (critical) number of multiplets\n");
#endif
#ifdef FORAGG
	    fprintf(outfp,
		"\nLetter\tCount\t%%\tObserved (Critical number)\n");
#endif
	    flag= TRUE;
	   }
#ifdef FOREAS
	 fprintf(outfp,"%c\t%d\t%.1lf\t%d\t\t%d (%d)\n", SYMB[i],lcount[i],
		frqcy[i]*100.0,j, mplet_count_l_s[i][j],
		mplet_criti_l_s[i][j] );
#endif
#ifdef FORAGG
	 fprintf(outfp,"%c\t%d\t%.1lf\t%d (%d)\n at ", SYMB[i], lcount[i],
		frqcy[i]*100.0, mplet_count_l[i], mplet_criti_l[i] );
#endif
#ifdef FOREAS
         if (npflag) {
	 fprintf(outfp," at ");
#endif
	 for (k=0;k<mplet_count_l[i];k++)
	   {if (k>0) fprintf(outfp,"  ");
	    if (k>0 && k%5==0) fprintf(outfp,"\n    ");
	    fprintf(outfp,"%4d (l=%2d)", mplet_posit_l_n[i][k],
			mplet_size_l_n[i][k]);
	   }
	 fprintf(outfp,"\n");
#ifdef FOREAS
         npflag= 0; }
#endif
	}
     }
#ifdef FOREAS
  }
#endif
if (flag) fprintf(outfp,"\n");


/* OUTPUT: INDIVIDUALLY SIGNIFICANT APLETS: */
flag= FALSE;
for (i=0; i<NUM_LETTERS;i++)
  {for (j=i+1; j<NUM_LETTERS; j++)
#ifdef FOREAS
     {for (h=0; h<=MAX_APLET_SIZE; h++)
        {if ( aplet_count_ll_s[i][j][h] + aplet_count_ll_s[j][i][h]
		> aplet_criti_ll_s[i][j][h] )
#endif
#ifdef FORAGG
        {if ( aplet_count_ll[i][j] > aplet_criti_ll[i][j] )
#endif
	   {if (!flag)
	      {fprintf(outfp,
		"%1d. Significant specific %s altplet counts:\n",
		++pgnum, aname );
#ifdef FOREAS
	       fprintf(outfp,
		"\nLetters\t\tAltplet size\tObserved (Critical number)\n");
#endif
#ifdef FORAGG
	       fprintf(outfp,
		"Letters\t\tObserved (Critical number)\n");
#endif
	       flag= TRUE;
	      }
#ifdef FOREAS
	    fprintf(outfp,"%c%c\t\t%d\t\t%d (%d)\n at ", SYMB[i], SYMB[j], h,
		aplet_count_ll_s[i][j][h] + aplet_count_ll_s[j][i][h],
		aplet_criti_ll_s[i][j][h] );
#endif
#ifdef FORAGG
	    fprintf(outfp,"%c%c\t\t%d (%d)\n at ", SYMB[i], SYMB[j],
		aplet_count_ll[i][j], aplet_criti_ll[i][j] );
#endif
	    for (k=0;k<aplet_count_ll[i][j];k++)
		 {if (k>0) fprintf(outfp,"  ");
		  if (k>0 && k%5==0) fprintf(outfp,"\n    ");
		  fprintf(outfp,"%4d (l=%2d)",
			aplet_posit_ll_n[i][j][k],
			aplet_size_ll_n[i][j][k]);
		 }
	    fprintf(outfp,"\n");
	   }
        }
#ifdef FOREAS
     }
#endif
  }
if (flag) fprintf(outfp,"\n");
} /* end-of-if-pstyle */


if (mplet_exception_count>0)
 {if (clgth)
   {fprintf(outfp,
	"%1d. Long %s multiplets (>=%2d; Letter/Length/Position/Codons):",
	++pgnum, aname, MAX_MPLET_SIZE );
    for (i=0;i<mplet_exception_count;i++)
     {fprintf(outfp,"\n    ");
      fprintf(outfp,"%c_%2d at %4d to %4d: ",SYMB[mplet_exception[i].letter],
		mplet_exception[i].size,mplet_exception[i].location,
		mplet_exception[i].location+mplet_exception[i].size-1);
      for (j=3*mplet_exception[i].location-3;
	   j<3*(mplet_exception[i].location+mplet_exception[i].size-1);
	   j+=3)
       fprintf(outfp," %c%c%c",NAUC[cseq[j]],NAUC[cseq[j+1]],NAUC[cseq[j+2]]);
     }
   }
  else
   {fprintf(outfp,
	"%1d. Long %s multiplets (>=%2d; Letter/Length/Position):\n    ",
	++pgnum, aname, MAX_MPLET_SIZE );
    for (i=0;i<mplet_exception_count;i++)
     {if (i>0) fprintf(outfp,"  ");
      if (i>0 && i%6==0) fprintf(outfp,"\n    ");
      fprintf(outfp,"%c/%d/%d",SYMB[mplet_exception[i].letter],
		mplet_exception[i].size,mplet_exception[i].location);
     }
   }
  fprintf(outfp,"\n\n");
 }

if (aplet_exception_count>0)
 {if (clgth)
   {fprintf(outfp,
	"%1d. Long %s altplets (>=%2d; Letters/Length/Position/COdons):\n    ",
	++pgnum, aname, MAX_APLET_SIZE );
    for (i=0;i<aplet_exception_count;i++)
     {fprintf(outfp,"\n    ");
      fprintf(outfp,"%c%c_%2d at %4d to %4d: ",SYMB[aplet_exception[i].first],
		SYMB[aplet_exception[i].second], aplet_exception[i].size,
		aplet_exception[i].location,
		aplet_exception[i].location+aplet_exception[i].size-1);
      for (j=3*aplet_exception[i].location-3;
	   j<3*(aplet_exception[i].location+aplet_exception[i].size-1);
	   j+=3)
       fprintf(outfp," %c%c%c",NAUC[cseq[j]],NAUC[cseq[j+1]],NAUC[cseq[j+2]]);
     }
   }
  else
   {fprintf(outfp,
	"%1d. Long %s altplets (>=%2d; Letters/Length/Position):\n    ",
	++pgnum, aname, MAX_APLET_SIZE );
    for (i=0;i<aplet_exception_count;i++)
     {if (i>0)   fprintf(outfp,"  ");
      if (i>0 && i%6==0) fprintf(outfp,"\n    ");
      fprintf(outfp,"%c%c/%d/%d", SYMB[aplet_exception[i].first],
		SYMB[aplet_exception[i].second], aplet_exception[i].size,
		aplet_exception[i].location);
     }
   }
  fprintf(outfp,"\n\n");
 }

} /* main() */



record_mplet(letter,size,position,SYMB)
int letter;		/* The letter of which this is an mplet */
int size;		/* the length of the mplet */
int position;		/* The position in the sequence of the mplet */
char SYMB[];
{
int num_mplets;
int distance;

if (SYMB[0]=='0' && letter==0)   return(0);

if (size >= MAX_MPLET_SIZE)
  {if (mplet_exception_count >= MAX_EXCEPTIONS)
     {fprintf(stderr,"Too many mplet exceptions: %d max.\n", MAX_EXCEPTIONS);
      return(0);
     }
   else
     {mplet_exception[mplet_exception_count].letter= letter;
      mplet_exception[mplet_exception_count].location= position;
      mplet_exception[mplet_exception_count].size= size;
      mplet_exception_count++;
     }
  }

num_mplets= mplet_count_l[letter]++;
if (size>MAX_MPLET_SIZE)
  mplet_count_l_s[letter][MAX_MPLET_SIZE]++;
else
  mplet_count_l_s[letter][size]++;

distance= position - last_mp_pos - last_mp_size;
mplet_dist[mplet_count]= distance;
last_mp_pos= position;
last_mp_size= size;

++mplet_count;
if (num_mplets >= MAX_MPLETS)
  {fprintf(stderr,"Too many mplets of '%c' recorded.\n", SYMB[letter]);
   return(0);
  }
else
  {mplet_size_l_n[letter][num_mplets]= size;
   mplet_posit_l_n[letter][num_mplets]= position;
   return(1);
  }

} /* record_mplet() */



record_aplet(first,second,size,position,SYMB)
int first;		/* - first letter of the alternation pair */
int second;		/* - second letter of the alternation pair */
int size;		/* - length of the aplet */
int position;		/* - position in the sequence of the aplet */
char SYMB[];
{
int num_aplets;

if (first>second)   swapint(&first,&second);

if (first==second || (SYMB[0]=='0' && (first==0 || second==0)) )   return(0);

if (size >= MAX_APLET_SIZE)
  {if (aplet_exception_count >= MAX_EXCEPTIONS)
     {fprintf(stderr,"Too many aplet exceptions: %d max.\n", MAX_EXCEPTIONS);
      return(0);
     }
   else
     {aplet_exception[aplet_exception_count].first= first;
      aplet_exception[aplet_exception_count].second= second;
      aplet_exception[aplet_exception_count].location= position;
      aplet_exception[aplet_exception_count].size= size;
      aplet_exception_count++;
     }
  }

aplet_count++;
num_aplets= aplet_count_ll[first][second]++;
if (size>MAX_APLET_SIZE)
  aplet_count_ll_s[first][second][MAX_APLET_SIZE]++;
else
  aplet_count_ll_s[first][second][size]++;
if (num_aplets >= MAX_APLETS)
  {fprintf(stderr,"Too many aplets of '%c%c' recorded.\n",
		SYMB[first],SYMB[second]);
   return(0);
  }
else
  {aplet_size_ll_n[first][second][num_aplets]= size;
   aplet_posit_ll_n[first][second][num_aplets]= position;
   return(1);
  }

} /* record_aplet() */



swapint(p1,p2) int *p1,*p2;
{
int temp;	temp= *p1;	*p1= *p2;	*p2= temp;
}
