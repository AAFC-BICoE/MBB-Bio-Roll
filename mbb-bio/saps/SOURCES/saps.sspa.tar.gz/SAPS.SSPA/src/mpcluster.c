/* MPCLUSTER.C;                                 Last update: March 19, 1997. */
/*   - a subroutine to identify multiplet clusters in protein sequences.     */
/* Dependencies:   called by multiplet.c; calls mFct.c, tFct.c               */
/* Bugs:                                                                     */

/*   Volker Brendel, Department of Mathematics, Stanford University,  */
/*   Stanford CA 94305; (415) 723-9256, volker@gnomic.stanford.edu    */

#include <stdio.h>
#include "def.h"
#define WNDLGTH1     30
#define WNDLGTH2     45
#define WNDLGTH3     60
extern int protein[PROTLGTH], occpos[PROTLGTH];
extern pstyle, tabflag;
extern int af[23];
extern char sfname[81];
extern FILE *outfp, *tabfp;
extern char AAUC[25];

mpcluster(numaa,pgnum)
int numaa, pgnum;
{
int i,j ,l;
int count;
int swp[100];
int lmax[100];
float prop= 0;
double t, tmax[100];
int min1, min2, min3;
int mFct();
double tFct();
int prti;
int prtpos[20], prtlgt[20];
double prttvl[20];
int swc= 0;
int prc= 0;
int totct= 0;
int last_letter, mpl, pst;
int realpos[PROTLGTH], reall[100];

last_letter= protein[0]; mpl= 1; pst= 0;
for (i=1;i<numaa;++i)
  {if (protein[i]==last_letter)   {++mpl; continue;}
   if (mpl>1)   {occpos[++totct]= ++pst;   realpos[totct]= i-mpl;}
   else ++pst;
   last_letter= protein[i];   mpl= 1;
  }
if (mpl>1)   {occpos[++totct]= ++pst;   realpos[totct]= i-mpl;}
else ++pst;
prop= (float)totct/(float)pst;

min1 = mFct(7.0,WNDLGTH1,prop);
min2 = mFct(7.0,WNDLGTH2,prop);
min3 = mFct(7.0,WNDLGTH3,prop);

for( i=1; i<totct; ++i )
  {if( i+min1-1 <= totct )
     {if( occpos[i+min1-1] - occpos[i] + 1 <= WNDLGTH1 )
        {swp[swc] = i; ++swc; continue;}
     }
   else		continue;
   if( i+min2-1 <= totct )
     {if( occpos[i+min2-1] - occpos[i] + 1 <= WNDLGTH2 )
        {swp[swc] = i; ++swc; continue;}
     }
   else		continue;
   if( i+min3-1 <= totct )
     {if( occpos[i+min3-1] - occpos[i] + 1 <= WNDLGTH3 )
        {swp[swc] = i; ++swc;}
     }
  }

for( i=0; i<swc; ++i )
  {count=1; tmax[i]=0; lmax[i]=0;
   for( j=1; swp[i]+j <= totct; ++j )
     {++count;
      if( count < min1 )	continue;
      l = occpos[swp[i]+j] - occpos[swp[i]] + 1;
      t = tFct(count,l,prop);
      if (t > tmax[i])
	{tmax[i]=t; lmax[i]=l;
	 reall[i]= realpos[swp[i]+j] - realpos[swp[i]] + 1;
	}
      if (l>75)   break;
     }
  }

if( swc==1 )
  {prtpos[0] = realpos[swp[0]];
   prtlgt[0] = reall[0]; prttvl[0] = tmax[0];
   prc = 1;
  }
if( swc>1 )
   {prti= 0;
    prc= 0;
    for( i=1; i<swc; ++i )
      {if( occpos[swp[i]] > occpos[swp[prti]] + lmax[prti] + 8)
   	 {prtpos[prc]= realpos[swp[prti]];
	  prtlgt[prc]= reall[prti];
	  prttvl[prc]= tmax[prti];
   	  ++prc;
	  prti= i;
	 }
       else
         {if( occpos[swp[i]] + lmax[i] == 
	      occpos[swp[prti]] + lmax[prti] )
	    {if (tmax[i] > tmax[prti])   prti= i;}
	  else
	    {count=0;
             for( j=swp[prti]; occpos[j]<=occpos[swp[i]]+lmax[i]-1; ++j)
	       {++count;
	        if( occpos[j] == occpos[totct] )	break;
	       }
	     l =  occpos[swp[i]] + lmax[i] - occpos[swp[prti]];
	     t =  tFct(count,l,prop);
	     if (tmax[i] > tmax[prti])		prti = i;
	     if (t > tmax[prti])  {lmax[prti] = l;  tmax[prti] = t;}
	       {tmax[i]=t; lmax[i]=l;
	        reall[i]= realpos[swp[i]] +reall[i] - realpos[swp[prti]];
	       }
	    }
	  }
      }
    prtpos[prc]= realpos[swp[prti]];
    prtlgt[prc]= reall[prti];
    prttvl[prc]= tmax[prti];
    ++prc;
   }

if (pstyle==1 && prc==0)   return;

if (pstyle%2==0)   fprintf(outfp,"\n");
fprintf(outfp,"%1d. Clusters of amino acid multiplets",pgnum);
fprintf(outfp," (cmin = %2d/%2d or %2d/%2d or %2d/%2d):",
	min1, WNDLGTH1, min2, WNDLGTH2, min3, WNDLGTH3);
for( j=0; j<prc; ++j )
     pr_mpcluster(numaa,j+1,prtpos[j],prtlgt[j],prttvl[j]);
if (prc==0)   fprintf(outfp,"  none\n");
else   fprintf(outfp,"\n");

}



pr_mpcluster(numaa,num,wstart,wlgth,tval)
int numaa, num, wstart, wlgth;
double tval;
{
int i, j, q;
int cf[20];
int last_letter, mpl, scnt= 0, mcnt= 0;

for( i=0;i<=19;++i )   cf[i]= 0;

last_letter= protein[wstart+wlgth];   mpl= 1;
for( i=wstart+wlgth+1;i < numaa;++i )
  {if (protein[i]==last_letter)   {++mpl; continue;}
   wlgth+= mpl; break;
  }

fprintf(outfp,"\n\n %1d) From %4d to %4d:   ", num, wstart+1, wstart+wlgth);

if (wlgth <= 55)
  {for( i=wstart; i < wstart+wlgth; ++i )
      fprintf(outfp,"%c", AAUC[protein[i]] );
  }
else  fprintf(outfp,"see sequence above" );

last_letter= protein[wstart];   mpl= 1;
for( i=wstart+1;i < wstart+wlgth;++i )
  {if (protein[i]==last_letter)   {++mpl; if (i<wstart+wlgth-1) continue;}
   if (mpl==1)   ++scnt;
   else   ++mcnt;
   last_letter= protein[i];   mpl= 1;
  }
if (mpl>1)   ++mpl;

q= (int)(4.*(float)wstart/(float)numaa)%4 +1;
fprintf(outfp,"\n    quartile: %1d;  size: %2d;  ", q, wlgth);
fprintf(outfp,"multiplets: %3d, ", mcnt);
fprintf(outfp,"singlets: %3d;  t-value: %5.2f\n", scnt, tval );

if (tabflag)   fprintf(tabfp,
  "MU Cluster at %4d-%4d (%1d.q.): %2d m, %2d s in %3d r (t-value: %4.1f)\n",
  wstart+1, wstart+wlgth, q, mcnt, scnt, wlgth, tval);

if (pstyle%2==0)
  {q= 0;
   for( i=wstart; i < wstart+wlgth; ++i )
     for( j=0;j<20;++j )
        if ( AAUC[protein[i]] == AAUC[j] )   {++cf[j]; break;}
   for( i=0; i<=19; ++i )  
     {if ( 100.*(float)cf[i]/(float)wlgth >= 10.0 )
        {if (q==0)   fprintf(outfp,"  ");
	 if ((++q)%5==0)   fprintf(outfp,"\n  ");
         fprintf(outfp, "  %c: %2d (%4.1f%%);", AAUC[i], cf[i],
		100.*(float)cf[i]/(float)wlgth ); 
	}
     }
   if ( 100.*(float)(cf[0]+cf[4]+cf[9]+cf[13]+cf[17])/(float)wlgth >= 25.0 )
     {if (q%4==0)   {fprintf(outfp,"\n  "); ++q;}
      fprintf(outfp,"  LVIFM: %2d (%4.1f%%);", cf[0]+cf[4]+cf[9]+cf[13]+cf[17],
		100.*(float)(cf[0]+cf[4]+cf[9]+cf[13]+cf[17])/(float)wlgth );
     }
   if ( 100.*(float)(cf[3]+cf[7])/(float)wlgth >= 15.0 )
     {if (q%4==0)   fprintf(outfp,"\n  ");
      fprintf(outfp,"  ST: %2d (%4.1f%%);", cf[3]+cf[7],
		100.*(float)(cf[3]+cf[7])/(float)wlgth );
     }
  }

}
