/* FATP.C;                                      Last update: March 19, 1997. */
/*   - a subroutine to identify charge patterns in protein sequences.        */
/* Dependencies:   called by pgrep.c and saps.c                              */
/* Bugs:                                                                     */

/*   Volker Brendel, Department of Mathematics, Stanford University,  */
/*   Stanford CA 94305; (415) 723-9256, volker@gnomic.stanford.edu    */

#include <stdio.h>
#include <math.h>
#include "def.h"
#define SLEVEL 0.01
#define MINLGTH	6
#define NUMPAT 12
extern int pstyle, tabflag;
extern FILE *outfp, *tabfp;
extern int af[23], pf[9];
extern int protein[PROTLGTH];
extern char AAUC[25], CHPN[25], H0UC[25];
extern char sfname[81];
extern int pfnflag, gfcount;

char Psym[NUMPAT][6] =
	{"  (+)","  (-)","  (*)","  (0)"," (+0)"," (-0)"," (*0)",
	 "(+00)","(-00)","(*00)"," (H.)","(H..)"};
int RUPAprinted;

fatp(numaa)   /* ... finds finite automata type patterns ... */
int numaa;
{
int i, j, l; 
float cprop[4];
double Lfrq;
int pbeg[NUMPAT], pend[NUMPAT], perr[NUMPAT], pins[NUMPAT], pdel[NUMPAT];
int state_p[NUMPAT];
int pat[NUMPAT], let[NUMPAT]; 
int c_pat[NUMPAT], c_let[NUMPAT], r_pat[NUMPAT], r_let[NUMPAT]; 
int l_pat[NUMPAT], l_let[NUMPAT];
int r_ext[NUMPAT];
int mlen0_p[NUMPAT]; int mlen1_p[NUMPAT]; int mlen2_p[NUMPAT]; 
int clength[NUMPAT]; 
int mlen23_p[4];
int rcount[4];
int posr[4][50];
int npos[4];
double mlen;
double lambda, rho, lFunct();
int r1, r2, r3;
int k, h;
static int atrans[7][12][3] =    /* ... automata transitions (# of pattern, */
 {                               /* current state, input letter) ...        */
  { {1,0,0},
    {2,0,0},		/* automaton  1:  (0) 3-times */
    {99,0,0},
    {99,99,99}, {99,99,99}, {99,99,99}, {99,99,99}, {99,99,99}, {99,99,99},
    {99,99,99}, {99,99,99}, {99,99,99}
  },
  { {0,1,1},
    {2,99,99},		/* automaton  2:  (0) extension */
    {2,99,99},
    {99,99,99}, {99,99,99}, {99,99,99}, {99,99,99}, {99,99,99}, {99,99,99},
    {99,99,99}, {99,99,99}, {99,99,99}
  },
  { {1,0,0},   
    {1,2,0},		/* automaton  3:  (01) 4-times */
    {3,0,0},
    {1,4,0}, {5,0,0}, {1,6,0}, {7,0,0}, {1,99,0}, {99,99,99},
    {99,99,0}, {99,99,99}, {99,99,99}
  },
  { {1,2,99},
    {8,0,99},		/* automaton  4:  (01) extension */
    {3,4,99},
    {99,6,99}, {5,99,99}, {99,6,99}, {7,99,99}, {99,0,99}, {5,6,99},
    {99,99,99}, {99,99,99}, {99,99,99}
  },
  { {1,0,0},
    {1,2,0},		/* automaton  5:  (011) 4-times */
    {1,3,0},
    {4,0,0}, {1,5,0}, {1,6,0}, {7,0,0}, {1,8,0}, {1,9,0},
    {10,0,0}, {1,11,0}, {1,99,0}
  },
  { {1,8,99},
    {5,2,99},		/* automaton  6:  (011) extension */
    {3,0,99},
    {7,4,99}, {99,0,99}, {99,6,99}, {7,0,99}, {99,4,99}, {7,9,99},
    {7,10,99}, {7,99,99}, {99,99,99}
  },
  { {6,1,99},
    {10,2,99},		/* automaton  7:  (110) extension */
    {0,3,99},
    {0,4,99}, {0,5,99}, {0,99,99}, {99,7,99}, {8,5,99}, {99,9,99},
    {99,5,99}, {8,9,99}, {99,99,99}
  }
 };
int Pnum[8][23];

for(i=0;i<23;++i)
  {if (CHPN[i]=='0')
     {Pnum[0][i]= 1; Pnum[1][i]= 0; Pnum[2][i]= 1;
      Pnum[3][i]= 0; Pnum[4][i]= 1; Pnum[5][i]= 0;
     }
   if (CHPN[i]=='+')
     {Pnum[0][i]= 0; Pnum[1][i]= 1; Pnum[2][i]= 2;
      Pnum[3][i]= 2; Pnum[4][i]= 0; Pnum[5][i]= 1;
     }
   if (CHPN[i]=='-')
     {Pnum[0][i]= 2; Pnum[1][i]= 2; Pnum[2][i]= 0;
      Pnum[3][i]= 1; Pnum[4][i]= 0; Pnum[5][i]= 1;
     }
   if (H0UC[i]=='H')
     {Pnum[6][i]= 0; Pnum[7][i]= 1;}
   if (H0UC[i]=='0')
     {Pnum[6][i]= 1; Pnum[7][i]= 0;}
  }

for( i=0;i<4;++i )   rcount[i]=0;
RUPAprinted= 0;

cprop[0] = (float) pf[0]/numaa;
cprop[1] = (float) pf[1]/numaa;
cprop[2] = 1. - cprop[0] - cprop[1];
cprop[3] = cprop[0] + cprop[1];
 
/*    The automata and amino acid -> number substitutions are specified
      for the core (c), right (r) extension, and left (l) extension,
      as is the desired length of the core; the minimal significant
      lengths are calculated based on the length of the sequence and
      its composition and number of errors allowed (0, 1, or 2); also
      the 2/3 value of mlen0 (for count statistics).
*/

/* pattern  1: (+) 3-times with automaton 2 extension */ 
c_pat[0]=0; c_let[0]=0; r_pat[0]=1; r_let[0]=0; l_pat[0]=1; l_let[0]=0;
clength[0]=3; 
if ( cprop[0]*(1.-cprop[0]) == 0 )
  {mlen0_p[0]=9999; mlen1_p[0]=9999; mlen2_p[0]=9999;}
else
  {mlen=lFunct(numaa,0,cprop[0],0,1-cprop[0],1);
   mlen0_p[0]=(int)(2*mlen) - (int)mlen; 
   mlen23_p[0]=(int)(4*mlen/3) - (int)(2*mlen/3);
	if ( mlen23_p[0] < 3 )	mlen23_p[0]=3;
   mlen=lFunct(numaa,1,cprop[0],1,1-cprop[0],1);
   mlen1_p[0]=(int)(2*mlen) - (int)mlen; 
   mlen=lFunct(numaa,2,cprop[0],2,1-cprop[0],2);
   mlen2_p[0]=(int)(2*mlen) - (int)mlen; 
  }

/* pattern  2: (-) 3-times with automaton 2 extension */ 
c_pat[1]=0; c_let[1]=2; r_pat[1]=1; r_let[1]=2; l_pat[1]=1; l_let[1]=2;
clength[1]=3; 
if ( cprop[1]*(1.-cprop[1]) == 0 )
  {mlen0_p[1]=9999; mlen1_p[1]=9999; mlen2_p[1]=9999;}
else
  {mlen=lFunct(numaa,0,cprop[1],0,1-cprop[1],1);
   mlen0_p[1]=(int)(2*mlen) - (int)mlen; 
   mlen23_p[1]=(int)(4*mlen/3) - (int)(2*mlen/3);
	if ( mlen23_p[1] < 3 )	mlen23_p[1]=3;
   mlen=lFunct(numaa,1,cprop[1],1,1-cprop[1],1);
   mlen1_p[1]=(int)(2*mlen) - (int)mlen; 
   mlen=lFunct(numaa,2,cprop[1],2,1-cprop[1],2);
   mlen2_p[1]=(int)(2*mlen) - (int)mlen; 
  }

/* pattern  3: (+ or -) 3-times with automaton 2 extension */ 
c_pat[2]=0; c_let[2]=4; r_pat[2]=1; r_let[2]=4; l_pat[2]=1; l_let[2]=4;
clength[2]=3; 
if ( cprop[3]*(1.-cprop[3]) == 0 )
  {mlen0_p[2]=9999; mlen1_p[2]=9999; mlen2_p[2]=9999;}
else
  {mlen=lFunct(numaa,0,cprop[3],0,1-cprop[3],1);
   mlen0_p[2]=(int)(2*mlen) - (int)mlen; 
   mlen23_p[2]=(int)(4*mlen/3) - (int)(2*mlen/3);
	if ( mlen23_p[2] < 3 )	mlen23_p[2]=3;
   mlen=lFunct(numaa,1,cprop[3],1,1-cprop[3],1);
   mlen1_p[2]=(int)(2*mlen) - (int)mlen; 
   mlen=lFunct(numaa,2,cprop[3],2,1-cprop[3],2);
   mlen2_p[2]=(int)(2*mlen) - (int)mlen; 
  }

/* pattern  4: (0) 3-times with automaton 2 extension */ 
c_pat[3]=0; c_let[3]=1; r_pat[3]=1; r_let[3]=1; l_pat[3]=1; l_let[3]=1;
clength[3]=3; 
if ( cprop[2]*(1.-cprop[2]) == 0 )
  {mlen0_p[3]=9999; mlen1_p[3]=9999; mlen2_p[3]=9999;}
else
  {mlen=lFunct(numaa,0,cprop[2],0,1-cprop[2],1);
   mlen0_p[3]=(int)(2*mlen) - (int)mlen; 
   mlen23_p[3]=(int)(4*mlen/3) - (int)(2*mlen/3);
	if ( mlen23_p[3] < 3 )	mlen23_p[3]=3;
   mlen=lFunct(numaa,1,cprop[2],1,1-cprop[2],1);
   mlen1_p[3]=(int)(2*mlen) - (int)mlen; 
   mlen=lFunct(numaa,2,cprop[2],2,1-cprop[2],2);
   mlen2_p[3]=(int)(2*mlen) - (int)mlen; 
  }

/* pattern  5: (+0) 4-times with automaton 4 extension */ 
c_pat[4]=2; c_let[4]=0; r_pat[4]=3; r_let[4]=0; l_pat[4]=3; l_let[4]=1;
clength[4]=8;
if ( cprop[0]*cprop[2] == 0  ||  cprop[1]==1  )
  {mlen0_p[4]=9999; mlen1_p[4]=9999; mlen2_p[4]=9999;}
else
  {lambda = sqrt( (double)cprop[0] * (double)cprop[2] );
   rho = ( (double)cprop[0] + (double)cprop[2] -
	2*(double)cprop[0]*(double)cprop[2] ) / lambda;
   mlen=lFunct(numaa,0,lambda,0,rho,1); 
   mlen0_p[4]=(int)(2*mlen) - (int)mlen; 
   mlen=lFunct(numaa,1,lambda,1,rho,1);
   mlen1_p[4]=(int)(2*mlen) - (int)mlen; 
   mlen=lFunct(numaa,2,lambda,2,rho,2);
   mlen2_p[4]=(int)(2*mlen) - (int)mlen; 
  }

/* pattern  6: (-0) 4-times with automaton 4 extension */ 
c_pat[5]=2; c_let[5]=2; r_pat[5]=3; r_let[5]=2; l_pat[5]=3; l_let[5]=3;
clength[5]=8;
if ( cprop[1]*cprop[2] == 0  ||  cprop[2]==1  )
  {mlen0_p[5]=9999; mlen1_p[5]=9999; mlen2_p[5]=9999;}
else
  {lambda = sqrt( (double)cprop[1] * (double)cprop[2] );
   rho = ( (double)cprop[1] + (double)cprop[2] -
	2*(double)cprop[1]*(double)cprop[2] ) / lambda;
   mlen=lFunct(numaa,0,lambda,0,rho,1); 
   mlen0_p[5]=(int)(2*mlen) - (int)mlen; 
   mlen=lFunct(numaa,1,lambda,1,rho,1);
   mlen1_p[5]=(int)(2*mlen) - (int)mlen; 
   mlen=lFunct(numaa,2,lambda,2,rho,2);
   mlen2_p[5]=(int)(2*mlen) - (int)mlen; 
  }
/* pattern  7: (*0) 4-times with automaton 4 extension */ 
c_pat[6]=2; c_let[6]=4; r_pat[6]=3; r_let[6]=4; l_pat[6]=3; l_let[6]=5;
clength[6]=8;
if ( cprop[3] == 0 )
  {mlen0_p[6]=9999; mlen1_p[6]=9999; mlen2_p[6]=9999;}
else
  {lambda = sqrt( (double)cprop[3] * (double)cprop[2] );
   rho = ( (double)cprop[3] + (double)cprop[2] -
	2*(double)cprop[3]*(double)cprop[2] ) / lambda;
   mlen=lFunct(numaa,0,lambda,0,rho,1); 
   mlen0_p[6]=(int)(2*mlen) - (int)mlen; 
   mlen=lFunct(numaa,1,lambda,1,rho,1);
   mlen1_p[6]=(int)(2*mlen) - (int)mlen; 
   mlen=lFunct(numaa,2,lambda,2,rho,2);
   mlen2_p[6]=(int)(2*mlen) - (int)mlen; 
  }

/* pattern  8: (+00) 4-times with automaton 5 extension */ 
c_pat[7]=4; c_let[7]=0; r_pat[7]=5; r_let[7]=0; l_pat[7]=6; l_let[7]=0;
clength[7]=12;
if ( cprop[0]*cprop[2] == 0  ||  cprop[1]==1  )
  {mlen0_p[7]=9999; mlen1_p[7]=9999; mlen2_p[7]=9999;}
else
  {lambda = exp( log((double)cprop[0] * (double)cprop[2] * 
					(double)cprop[2])/3. );
   rho = ( (1.-(double)cprop[0]*(double)cprop[2]*(double)cprop[2])
	* (double)cprop[2]
	* ( (double)cprop[2]*(double)cprop[2]
	   + 2*(double)cprop[0]*(double)cprop[0]
	   + (double)cprop[1] * ((double)cprop[2]+ 2*(double)cprop[1])  )    )
	/ ( (double)cprop[2]*(double)cprop[2]*(double)cprop[2]
	   + (double)cprop[0]*(double)cprop[2] + (double)cprop[0]
	   + (double)cprop[1] * 
		(1. + (double)cprop[2] + (double)cprop[2]*(double)cprop[2])  );
   mlen=lFunct(numaa,0,lambda,0,rho,1); 
   mlen0_p[7]=(int)(2*mlen) - (int)mlen; 
   mlen=lFunct(numaa,1,lambda,1,rho,1);
   mlen1_p[7]=(int)(2*mlen) - (int)mlen; 
   mlen=lFunct(numaa,2,lambda,2,rho,2);
   mlen2_p[7]=(int)(2*mlen) - (int)mlen; 
  }

/* pattern  9: (-00) 4-times with automaton 5 extension */ 
c_pat[8]=4; c_let[8]=2; r_pat[8]=5; r_let[8]=2; l_pat[8]=6; l_let[8]=2;
clength[8]=12;
if ( cprop[1]*cprop[2] == 0  ||  cprop[2]==1  )
  {mlen0_p[8]=9999; mlen1_p[8]=9999; mlen2_p[8]=9999;}
else
  {lambda = exp( log((double)cprop[1] * (double)cprop[2] * 
					(double)cprop[2])/3. );
   rho = ( (1.-(double)cprop[1]*(double)cprop[2]*(double)cprop[2])
	* (double)cprop[2]
	* ( (double)cprop[2]*(double)cprop[2]
	   + 2*(double)cprop[1]*(double)cprop[1]
	   + (double)cprop[0] * ((double)cprop[2]+ 2*(double)cprop[1])  )    )
	/ ( (double)cprop[2]*(double)cprop[2]*(double)cprop[2]
	   + (double)cprop[1]*(double)cprop[2] + (double)cprop[1]
	   + (double)cprop[0] * 
		(1. + (double)cprop[2] + (double)cprop[2]*(double)cprop[2])  );
   mlen=lFunct(numaa,0,lambda,0,rho,1); 
   mlen0_p[8]=(int)(2*mlen) - (int)mlen; 
   mlen=lFunct(numaa,1,lambda,1,rho,1);
   mlen1_p[8]=(int)(2*mlen) - (int)mlen; 
   mlen=lFunct(numaa,2,lambda,2,rho,2);
   mlen2_p[8]=(int)(2*mlen) - (int)mlen; 
  }

/* pattern 10: (*00) 4-times with automaton 5 extension */ 
c_pat[9]=4; c_let[9]=4; r_pat[9]=5; r_let[9]=4; l_pat[9]=6; l_let[9]=4;
clength[9]=12;
if ( cprop[3] == 0 )
  {mlen0_p[9]=9999; mlen1_p[9]=9999; mlen2_p[9]=9999;}
else
  {lambda = exp( log((double)cprop[3] * (double)cprop[2] * 
					(double)cprop[2])/3. );
   rho = ( (1.-(double)cprop[3]*(double)cprop[2]*(double)cprop[2])
	* (double)cprop[2]
	* ( (double)cprop[2]*(double)cprop[2]
	   + 2*(double)cprop[3]*(double)cprop[3]
	   + (double)cprop[0] * ((double)cprop[2]+ 2*(double)cprop[3])  )    )
	/ ( (double)cprop[2]*(double)cprop[2]*(double)cprop[2]
	   + (double)cprop[3]*(double)cprop[2] + (double)cprop[3]
	   + (double)cprop[0] * 
		(1. + (double)cprop[2] + (double)cprop[2]*(double)cprop[2])  );
   mlen=lFunct(numaa,0,lambda,0,rho,1); 
   mlen0_p[9]=(int)(2*mlen) - (int)mlen; 
   mlen=lFunct(numaa,1,lambda,1,rho,1);
   mlen1_p[9]=(int)(2*mlen) - (int)mlen; 
   mlen=lFunct(numaa,2,lambda,2,rho,2);
   mlen2_p[9]=(int)(2*mlen) - (int)mlen; 
  }

/* pattern 11: (H.) 4-times with automaton 4 extension */ 
c_pat[10]=2; c_let[10]=6; r_pat[10]=3; r_let[10]=6; l_pat[10]=3; l_let[10]=7;
clength[10]=8;
Lfrq= (double) af[16]/numaa;
if ( Lfrq*(1.0-Lfrq) == 0 )
  {mlen0_p[10]=9999; mlen1_p[10]=9999; mlen2_p[10]=9999;}
else
  {lambda = sqrt( Lfrq * (1.0-Lfrq) );
   rho = ( Lfrq + (1.0-Lfrq) - 2*Lfrq*(1.0-Lfrq) ) / lambda;
   mlen=lFunct(numaa,0,lambda,0,rho,1); 
   mlen0_p[10]=(int)(2*mlen) - (int)mlen; 
   mlen=lFunct(numaa,1,lambda,1,rho,1);
   mlen1_p[10]=(int)(2*mlen) - (int)mlen; 
   mlen=lFunct(numaa,2,lambda,2,rho,2);
   mlen2_p[10]=(int)(2*mlen) - (int)mlen; 
  }

/* pattern 12: (H..) 4-times with automaton 5 extension */ 
c_pat[11]=4; c_let[11]=6; r_pat[11]=5; r_let[11]=6; l_pat[11]=6; l_let[11]=6;
clength[11]=12;
Lfrq= (double) af[16]/numaa;
if ( Lfrq*(1.0-Lfrq) == 0 )
  {mlen0_p[11]=9999; mlen1_p[11]=9999; mlen2_p[11]=9999;}
else
  {lambda = exp( log(Lfrq * (1.0-Lfrq) * (1.0-Lfrq))/3.);
   rho = ( (1.-Lfrq*(1.0-Lfrq)*(1.0-Lfrq)) * (1.0-Lfrq)
	  * ((1.0-Lfrq)*(1.0-Lfrq) + 2*Lfrq*Lfrq) )
	/ ( (1.0-Lfrq) * (1.0-Lfrq)* (1.0-Lfrq) + (1.0-Lfrq)*Lfrq + Lfrq );
   mlen=lFunct(numaa,0,lambda,0,rho,1); 
   mlen0_p[11]=(int)(2*mlen) - (int)mlen; 
   mlen=lFunct(numaa,1,lambda,1,rho,1);
   mlen1_p[11]=(int)(2*mlen) - (int)mlen; 
   mlen=lFunct(numaa,2,lambda,2,rho,2);
   mlen2_p[11]=(int)(2*mlen) - (int)mlen; 
  }


if (pstyle%2==0)
  {fprintf(outfp,"\npattern");
   for( l=0; l<NUMPAT; ++l )   fprintf(outfp,"%s|", Psym[l] );
   fprintf(outfp,"\nlmin0   ");
   for( l=0; l<NUMPAT; ++l )
     {if (mlen0_p[l] < 9999)   fprintf(outfp,"%3d | ", mlen0_p[l] );
      else   fprintf(outfp," NA | ");
     }
   fprintf(outfp,"\nlmin1   ");
   for( l=0; l<NUMPAT; ++l )
     {if (mlen1_p[l] < 9999)   fprintf(outfp,"%3d | ", mlen1_p[l] );
      else   fprintf(outfp," NA | ");
     }
   fprintf(outfp,"\nlmin2   ");
   for( l=0; l<NUMPAT; ++l )
     {if (mlen2_p[l] < 9999)   fprintf(outfp,"%3d | ", mlen2_p[l] );
      else   fprintf(outfp," NA | ");
     }
   fprintf(outfp,
    "\n (Significance level: %8.6f; Minimal displayed length: %2d)\n",
    SLEVEL, MINLGTH);
  }


for( l=0; l<NUMPAT; ++l ) 	/* initializing for core pattern search */
  {state_p[l]=0; pat[l]=c_pat[l]; let[l]=c_let[l]; r_ext[l]=0;
   pbeg[l]=numaa; pend[l]=numaa; perr[l]=0; pins[l]=0, pdel[l]=0;
  }


for( i=0; i<numaa; ++i )   /* start of i-loop through the sequence */
  {for( l=0; l<NUMPAT; ++l )   /* start of l-loop through the patterns */
     {state_p[l] = atrans[pat[l]][state_p[l]][Pnum[let[l]][protein[i]]];
        /* ... the new state is derived from the transition table pat[l],
           given the current state and the input (0,1,or 2, according
           to the Pnum[let[l]] translation of protein[i]
        */

      if ( l<4 && r_ext[l]==1 )
        {if ( state_p[l]==1 )
	   {npos[l]=i;
	    if ( i-pbeg[l] >= mlen23_p[l] )
			{posr[l][rcount[l]]=pbeg[l]; ++rcount[l];}
	   }
	 if ( state_p[l]==99 )
	   {if ( i-npos[l]-1 >= mlen23_p[l] )
			{posr[l][rcount[l]]=npos[l]+1; ++rcount[l];}
	   }
	}

      if (state_p[l]==0)
	{if (r_ext[l]==1)
	   {if (l==4 || l==5 || l==6 || l==10)
	      {if (i-pend[l]==5)   ++pins[l];
	       else if (i-pend[l]!=2)   ++perr[l];
	      }
	    if (l==7 || l==8 || l==9 || l==11)
	      {if (i-pend[l]==6)   ++perr[l];
	       if (i-pend[l]==4)   ++pins[l];
	       if (i-pend[l]==5)   ++pdel[l];
	      }
	   }
	 pend[l]= i;
	}

      if ( state_p[l]==99 )		/* core pattern found */
	 {if (r_ext[l]==0)  {pat[l]=r_pat[l];let[l]=r_let[l];r_ext[l]=1; 
			     state_p[l]=0;
			     pbeg[l]=i-clength[l]+1; pend[l]=i;
			     continue; 
			    }		/* ... setup for right extension */
	  state_p[l]=0; 
          for( j=pbeg[l]-1; j>0; --j )   /* now extending to the left: */
            {state_p[l] = 
		atrans[l_pat[l]][state_p[l]][Pnum[l_let[l]][protein[j]]];
	     if (state_p[l]==0)
	       {if (l==4 || l==5 || l==6 || l==10)
		  {if (pbeg[l]-j==5)   ++pins[l];
		   else if (pbeg[l]-j!=2)   ++perr[l];
		  }
		if (l==7 || l==8 || l==9 || l==11)
		  {if (pbeg[l]-j==6)   ++perr[l];
		   if (pbeg[l]-j==5)   ++pdel[l];
		   if (pbeg[l]-j==4)   ++pins[l];
		  }
		pbeg[l]= j; 
	       }
             if (state_p[l]==99)  break;
            }

          /* ... establish the proper endpoints for patterns: */
	  if (l>3)
	    {if ((l<=6 || l==10) && pbeg[l]>0)
	       {if (Pnum[l_let[l]][protein[pbeg[l]-1]]==0)   --pbeg[l];
	        if (Pnum[r_let[l]][protein[pend[l]+1]]==0)   ++pend[l];
	       }
	     if (l>6 && l!=10 && pbeg[l]>0)
	       {if (Pnum[l_let[l]][protein[pbeg[l]]]==0 &&
		    Pnum[l_let[l]][protein[pbeg[l]-1]]==1)
		  {--pbeg[l];
		   if (pbeg[l]>0  &&
		       Pnum[l_let[l]][protein[pbeg[l]-1]]==1)  --pbeg[l];
		  }
	        if (pend[l]+1<numaa && Pnum[r_let[l]][protein[pend[l]+1]]==0)
	          {++pend[l];
		   if (pend[l]+1<numaa && Pnum[r_let[l]][protein[pend[l]+1]]==1)
		     ++pend[l];
	          }
	       }
	     if (perr[l]+pins[l]+pdel[l]==0 &&
		 pend[l]-pbeg[l]+1 >= mlen0_p[l])
	       pr_window(numaa,l,pbeg[l],pend[l]-pbeg[l]+1,0,0,0);
	     if (perr[l]+pins[l]+pdel[l]==1 &&
		 pend[l]-pbeg[l]+1-perr[l]-pins[l] >= mlen1_p[l])
	       pr_window(numaa,l,pbeg[l],pend[l]-pbeg[l]+1,perr[l],pins[l],
			pdel[l]);
	     if (perr[l]+pins[l]+pdel[l]>=2 &&
		 pend[l]-pbeg[l]+1-perr[l]-pins[l] >= mlen2_p[l])
	       pr_window(numaa,l,pbeg[l],pend[l]-pbeg[l]+1,perr[l],pins[l],
			pdel[l]);
	     perr[l]= pins[l]= pdel[l]= 0;
	    }

          /* ... establish the suitable output for runs (printing with
             0, 1, or 2 errors: */
	  if (l<4)
	    {r1=0; r2=0; if (j==-1)  ++j;
	     for( k=j+1; k<=i; ++k )
	     {if ( Pnum[c_let[l]][protein[k]] == 0 )   ++r1;
	      else	break;
	     }
	     for( h=k+1; h<=i; ++h )
	     {if ( Pnum[c_let[l]][protein[h]] == 0 )   ++r2;
	      else	break;
	     }
	     r3 = i-j-3-r1-r2;
	      /* ... the run is (0)r1 * (0)r2 * (0)r3, where * indicates
                 mismatches ... */
	     if ( r1>1 && r2>1 && r3>1 && r1+r2+r3 >= mlen2_p[l] )
			pr_window(numaa,l,j+1,i-j-1,2,0,0);
	      /* ... if significant, print with 2 errors ... */
	     else   /* ... if significant, print the longer of the two 1-error 
		       runs or the longest 0-error run ... */
	     {if ( r1>r3 )
	      {if ( r1+r2 >= mlen1_p[l] && r1>1 && r2>1 )    
			pr_window(numaa,l,j+1,r1+r2+1,1,0,0);
	       else
	       {if ( r2 >= mlen0_p[l] )
			pr_window(numaa,l,j+r1+2,r2,0,0,0);
	       }
	      }
	      else
	       {if ( r2+r3 >= mlen1_p[l] && r2>1 && r3>1 )    
			pr_window(numaa,l,j+r1+2,r2+r3+1,1,0,0);
	        else
	         {if ( r2 >= mlen0_p[l] )
			pr_window(numaa,l,j+r1+2,r2,0,0,0);
	          if ( r3 >= mlen0_p[l] )
			pr_window(numaa,l,j+r1+r2+3,r3,0,0,0);
	         }
	       }
	     }
	    }

	  /* setup for new core pattern search: */
	  pbeg[l]=numaa; 
          state_p[l]=0; pat[l]=c_pat[l]; let[l]=c_let[l]; r_ext[l]=0; 
          if (l==4 && CHPN[protein[i]]=='+')  state_p[l]=1;
	  if (l==5 && CHPN[protein[i]]=='-')  state_p[l]=1;
	  if (l==6 &&
		(CHPN[protein[i]]=='+' || CHPN[protein[i]]=='-') )
						 state_p[l]=1;
          if (l==7 && CHPN[protein[i]]=='+')  state_p[l]=1;
	  if (l==8 && CHPN[protein[i]]=='-')  state_p[l]=1;
	  if (l==9 &&
		(CHPN[protein[i]]=='+' || CHPN[protein[i]]=='-') )
						 state_p[l]=1;
	  if (l==10 && H0UC[protein[i]]=='H')  state_p[l]=1;
	  if (l==11 && H0UC[protein[i]]=='H')  state_p[l]=1;
         }
     }   /* end of l-loop through the patterns */
  }
/* end of i-loop through the sequence */


for( l=0; l<NUMPAT; ++l )
  {if ( numaa-pbeg[l] >= mlen0_p[l] )	   /* printing of incomplete */
     {					   /* significant patterns:  */
      state_p[l]=0; 
      for( j=pbeg[l]-1; j>0; --j )   /* now extending to the left: */
        {state_p[l] = 
		atrans[l_pat[l]][state_p[l]][Pnum[l_let[l]][protein[j]]];
	 if (state_p[l]==0)
	   {if (l==4 || l==5 || l==6 || l==10)
	      {if (pbeg[l]-j==5)   ++pins[l];
	       else if (pbeg[l]-j!=2)   ++perr[l];
	      }
	    if (l==7 || l==8 || l==9 || l==11)
	      {if (pbeg[l]-j==6)   ++perr[l];
	       if (pbeg[l]-j==5)   ++pdel[l];
	       if (pbeg[l]-j==4)   ++pins[l];
	      }
	    pbeg[l]= j; 
	   }
         if (state_p[l]==99)  break;
        }

      /* ... establish the proper endpoints for patterns: */
      if (l>3)
	{if ((l<=6 || l==10) && pend[l]+1<numaa)
	   {if (Pnum[l_let[l]][protein[pbeg[l]-1]]==0)   --pbeg[l];
	    if (Pnum[r_let[l]][protein[pend[l]+1]]==0)   ++pend[l];
	   }
	 if (l>6 && l!=10 && pbeg[l]>0)
	   {if (Pnum[l_let[l]][protein[pbeg[l]]]==0 &&
		Pnum[l_let[l]][protein[pbeg[l]-1]]==1)   --pbeg[l];
	    if (pend[l]+1<numaa && Pnum[r_let[l]][protein[pend[l]+1]]==0)
	      {++pend[l];
	       if (pend[l]+1<numaa && Pnum[r_let[l]][protein[pend[l]+1]]==1)
		 ++pend[l];
	      }
	   }
	 pr_window(numaa,l,pbeg[l],pend[l]-pbeg[l]+1,perr[l],pins[l],pdel[l]);
	 perr[l]= pins[l]= pdel[l]= 0;
	}

      /* ... establish the suitable output for runs (printing with
         0, 1, or 2 errors: */
      if (l < 4)
	{r1=0; r2=0; if (j == -1)  ++j;
	 for( k=j+1; k<numaa; ++k )
	   {if ( Pnum[c_let[l]][protein[k]] == 0 )   ++r1;
	    else	break;
	   }
	 for( h=k+1; h<numaa; ++h )
	   {if ( Pnum[c_let[l]][protein[h]] == 0 )   ++r2;
	    else	break;
	   }
	 r3 = numaa-j-3-r1-r2;
	  /* ... the run is (0)r1 * (0)r2 * (0)r3, where * indicates
             mismatches ... */
	 if ( r1>1 && r2>1 && r3>1 && r1+r2+r3 >= mlen2_p[l] )
			pr_window(numaa,l,j+1,numaa-j-1,2,0,0);
	  /* ... if significant, print with 2 errors ... */
	 else   /* ... if significant, print the longer of the two 1-error 
		   runs or the longest 0-error run ... */
	   {if ( r1>r3 )
	      {if ( r1+r2 >= mlen1_p[l] && r1>1 && r2>1 )    
			pr_window(numaa,l,j+1,r1+r2+1,1,0,0);
	       else
	         {if ( r2 >= mlen0_p[l] )
			pr_window(numaa,l,j+r1+2,r2,0,0,0);
	         }
	      }
	    else
	      {if ( r2+r3 >= mlen1_p[l] && r2>1 && r3>1 )    
			pr_window(numaa,l,j+r1+2,r2+r3+1,1,0,0);
	       else
	         {if ( r2 >= mlen0_p[l] )
			pr_window(numaa,l,j+r1+2,r2,0,0,0);
	          if ( r3 >= mlen0_p[l] )
			pr_window(numaa,l,j+r1+r2+3,r3,0,0,0);
	         }
	      }
	   }
        }
     }
   if ( pbeg[l] < npos[l]+1 )	pbeg[l]=npos[l]+1;
   if ( l<4 && numaa-pbeg[l]>=mlen23_p[l] && pbeg[l]!=posr[l][rcount[l]] )
     {posr[l][rcount[l]]=pbeg[l]; ++rcount[l];}
  }

if (pstyle%2==0 && !RUPAprinted) {
  fprintf(outfp,"There are no charge runs or patterns exceeding the given");
  fprintf(outfp," minimal lengths.");}
    

if (pstyle%2==0)   {
/* ... run count statistics (runs >= 2/3 mlen0): */
fprintf(outfp,"\n\nRun count statistics:\n");
if (mlen0_p[0]<9999) {
fprintf(outfp,"\n  +  runs >= %3d:  %2d", mlen23_p[0], rcount[0]);
if ( rcount[0]>0 )
  {fprintf(outfp,", at");
   for( l=0; l<rcount[0]; ++l )
     {fprintf(outfp," %4d;", posr[0][l] +1);
      if ( (l+1)%8==0 )  fprintf(outfp,"\n                      ");
     } 
  }    
 }
if (mlen0_p[1]<9999) {
fprintf(outfp,"\n  -  runs >= %3d:  %2d", mlen23_p[1], rcount[1]);
if ( rcount[1]>0 )
  {fprintf(outfp,", at");
   for( l=0; l<rcount[1]; ++l )
     {fprintf(outfp," %4d;", posr[1][l] +1);
      if ( (l+1)%8==0 )  fprintf(outfp,"\n                      ");
     } 
  }    
 }
if (mlen0_p[2]<9999) {
fprintf(outfp,"\n  *  runs >= %3d:  %2d", mlen23_p[2], rcount[2]);
if ( rcount[2]>0 )
  {fprintf(outfp,", at");
   for( l=0; l<rcount[2]; ++l )
     {fprintf(outfp," %4d;", posr[2][l] +1);
      if ( (l+1)%8==0 )  fprintf(outfp,"\n                      ");
     } 
  }    
 }
if (mlen0_p[3]<9999) {
fprintf(outfp,"\n  0  runs >= %3d:  %2d", mlen23_p[3], rcount[3]);
if ( rcount[3]>0 )
  {fprintf(outfp,", at");
   for( l=0; l<rcount[3]; ++l )
     {fprintf(outfp," %4d;", posr[3][l] +1);
      if ( (l+1)%8==0 )  fprintf(outfp,"\n                      ");
     } 
  }    
 }
fprintf(outfp,"\n");   }

} /* end fatp() */



pr_window(numaa,patnum,wstart,wlgth,nerr,nins,ndel)
int numaa, patnum, wstart, wlgth, nerr, nins, ndel;
{
int i,j,q;
int posct= 0;
int negct= 0;
int cf[20];
static char ID[12][3]=
  {"PR","NR","MR","ZR","P2","N2","M2","P3","N3","M3","H2","H3"};

for( i=0; i<=19; ++i )  cf[i]=0;

/* RESTRICTIVE OUTPUT OPTION: /
if (patnum<10) return;
/* END OPTION */

if (wlgth-nerr-nins < MINLGTH) return;
	/* Ignore significant, but short runs/patterns */

if (patnum==2)
  {for( i=wstart; i < wstart+wlgth; ++i )
     {if (CHPN[protein[i]]=='+')  {++posct; continue;}
      if (CHPN[protein[i]]=='-')  {++negct; continue;}
     }
   if (posct<2 || negct<2)   return;
  }

if (pfnflag)
  {if (pstyle==1)    fprintf(outfp,"File: %s\n", sfname);
   ++gfcount; pfnflag= 0;
  }

++RUPAprinted;

if (pstyle%2==0)   fprintf(outfp,"\n");
fprintf(outfp,"%s %3d(%1d,%1d,%1d); at %4d-%4d:   ",
  Psym[patnum], wlgth-nerr-nins, nerr, nins, ndel, wstart+1, wstart+wlgth );
if (wlgth <= 46)
  {for( i=wstart; i < wstart+wlgth; ++i )
     fprintf(outfp, "%c", AAUC[protein[i]] );
  }
else
  {fprintf(outfp, "see sequence");
   if (pstyle%2==0)   fprintf(outfp," above");
   else   fprintf(outfp," file: %s", sfname);
  }

q= (int)(4.*(float)wstart/(float)numaa)%4 +1;
if (pstyle%2==0)
 {fprintf(outfp, "\n      (%1d. quartile)               ", q );
  if (wlgth <= 46 && patnum<10)
    {for( i=wstart; i < wstart+wlgth; ++i )
       fprintf(outfp, "%c", CHPN[protein[i]] );
    }
 }
fprintf(outfp,"\n");

if (tabflag)
  {fprintf(tabfp,"%s %3d(%1d,%1d,%1d) at %4d-%4d (%1d.q.)  ",
	ID[patnum], wlgth-nerr-nins, nerr, nins, ndel,
	wstart+1,wstart+wlgth,q );
   if (wlgth <= 40)
     {for( i=wstart; i < wstart+wlgth; ++i )
	fprintf(tabfp,"%c", AAUC[protein[i]] );
     }
   fprintf(tabfp,"\n");
  }

if (pstyle%2==0 && patnum==3  && wlgth>=30 )
  {q= 0;
   for( i=wstart; i < wstart+wlgth; ++i )
     for( j=0;j<20;++j )
        if ( AAUC[protein[i]] == AAUC[j] )   {++cf[j]; break;}
   for( i=0; i<=19; ++i )  
     {if ( 100.*(float)cf[i]/(float)wlgth >= 10.0 )
        {if (q==0)   fprintf(outfp,"    ");
	 if ((++q)%5==0)   fprintf(outfp,"\n    ");
         fprintf(outfp, "  %c: %2d (%4.1f%%);", AAUC[i], cf[i],
		100.*(float)cf[i]/(float)wlgth ); 
	}
     }
   if ( 100.*(float)(cf[0]+cf[4]+cf[9]+cf[13]+cf[17])/(float)wlgth >= 25.0 )
     {if (q%4==0)   {fprintf(outfp,"\n    "); ++q;}
      fprintf(outfp,"  LVIFM: %2d (%4.1f%%);", cf[0]+cf[4]+cf[9]+cf[13]+cf[17],
		100.*(float)(cf[0]+cf[4]+cf[9]+cf[13]+cf[17])/(float)wlgth );
     }
   if ( 100.*(float)(cf[3]+cf[7])/(float)wlgth >= 15.0 )
     {if (q%4==0)   {fprintf(outfp,"\n    "); ++q;}
      fprintf(outfp,"  ST: %2d (%4.1f%%);", cf[3]+cf[7],
		100.*(float)(cf[3]+cf[7])/(float)wlgth );
     }
   fprintf(outfp,"\n");
  }
    
}



double lFunct(L,n,lambda,s,rho,M)   /* ... calculates the minimal significant */ 
int L, n, s, M;			    /* length of runs and patterns ...        */
double lambda, rho;
{

double l;
double N, m;  

N = (double) L;
m = (double) M;

	l = ( log(N) + n*(log(log(N)) -log(-log(lambda))) )/ -log(lambda)
	    + s
            + ( -s*log(1.-lambda) -log(rho) + log(m) + log(-log(1.-SLEVEL)) )
		/ log(lambda);

return(l);

}
