/* mFct.C;                                   Last update: February 17, 1993. */
/*   - a function returning the minimal significant count of successes       */
/*   (occurring with probability p) in a window of length l (significance    */
/*   level corresponds to f standard deviations above the mean).             */
/* Dependencies:   called by aacluster.c, chcluster.c                        */
/* Bugs:                                                                     */

/*   Volker Brendel, Department of Mathematics, Stanford University,  */
/*   Stanford CA 94305; (415) 723-9256, volker@gnomic.stanford.edu    */

#include <math.h>

mFct(f,l,p)
int l;
float f, p;
{
double m;
double L, F, P;

	L = (double) l;
	P = (double) p;
	F = (double) f;

	if( P == 0. || P == 1. )  m=0.;
	else
	m = L*P + F*sqrt(L*P*(1.-P));

return ((int)m);

}
