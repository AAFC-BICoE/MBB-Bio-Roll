/* FIND_HSS.C;                                  Last update: March 19, 1997. */
/*   - a subroutine to find high scoring segments in protein sequences.      */
/* Dependencies:   called by hsseg.c, pscore.c.                              */
/* Bugs:                                                                     */

/*   Volker Brendel, Department of Mathematics, Stanford University,  */
/*   Stanford CA 94305; (415) 723-9256, volker@gnomic.stanford.edu    */

#include <stdio.h>
#include <math.h>
#include "def.h"

extern int pstyle;
extern int protein[PROTLGTH];
extern FILE *infp, *outfp, *plotfp;
extern float scr[23];
extern float prthrd[3];
extern char AAUC[25], CHPN[25];
extern char sfname[81];
extern int pfnflag, gfcount;
extern char outbuf[20][90];
extern int oblc, pobflag;

int pcnt, pc[2][5];

find_hss(scn,numaa,ibeg,prlevel,mprlgth,ploty)
int scn, numaa, ibeg, mprlgth, ploty;
float prlevel;
{				/* searching for high scoring segments for */
int i, ia, j, ja, jend;         /* scoring scheme scn */
float psum[PROTLGTH], pmax= 0.0;
float pmsum, pmmax;
int imbeg;
int iend, etype;
static int count, excend, pidx;
float cutoff;
float pfct();

psum[0]= 0.0;
if (ibeg==0)   {count= 0; excend= 0; pidx= -1;}

/* calculating the partial sums psum[i]: */
for( i=0; ibeg+i < numaa; ++i )
   {psum[i+1]= psum[i] + scr[protein[ibeg+i]];
    if (ploty && ibeg+i > pidx)
      {if (psum[i+1]>0.0)
	 fprintf(plotfp,"%5d %5.1f\n",ibeg+i+1,psum[i+1]);
       else
	 fprintf(plotfp,"%5d %5.1f\n",ibeg+i+1,0.0);
       ++pidx;
      }

    if ( psum[i+1]<=0 )
      {if ( psum[i]==0 )
         {if (ibeg+i==numaa-1)   goto prcount;
	  return (ibeg+1);
	 }
       if (iend>excend)   {etype=1; excend= ibeg+i;}
       else   etype= 2;
       if (pmax >= prthrd[2])
         {if (iend-ibeg < mprlgth)
	    {pmmax= 0.0;
	     for( ja= (iend>mprlgth) ? iend-mprlgth : 0; ja<=ibeg; ++ja )
	       {pmsum= 0.0;
		jend= (ja+mprlgth-1 < numaa) ? ja+mprlgth-1 : numaa-1;
		for( j=ja;j<=jend;++j)   pmsum+= scr[protein[j]];
		if (pmsum>=pmmax)   {imbeg= ja; pmmax= pmsum;}
	       }
	     if (pmmax >= prthrd[2])
	       {ibeg= imbeg;
		iend= (ibeg+mprlgth <= numaa) ? ibeg+mprlgth : numaa;
		pmax= pmmax;
	       }
	     else
	       {if (ibeg+i==numaa-1)   goto prcount;
		return (iend+1);
	       }
	    }
	  ++count;
          pcnt= -1;   for (i=0;i<5;++i)   pc[0][i]=pc[1][i]= 0;
	  if (pstyle%2==0 && pobflag)
  	    {for (i=0;i<=oblc;++i)   fprintf(outfp,"%s",outbuf[i]);
   	     pobflag= 0;
  	    }
	  if (pstyle==1)   fprintf(outfp,"#%2d)", scn);
	  else   fprintf(outfp,"\n");
	  fprintf(outfp," %1d) From %4d to %4d", count, ibeg+1, iend );
	  if (pstyle==4)   fprintf(outfp," (type %d)", etype );
	  fprintf(outfp,":  length=%3d, score=%5.2f", iend-ibeg, pmax );
	  if ( pmax >= prthrd[1] )   fprintf(outfp,"  *");
	  if ( pmax >= prthrd[0] )   fprintf(outfp,"*");
	  ia= iend; cutoff= .25*pmax;
	  while ( (ia=find_pocket(scn,ia,ibeg+1,cutoff)) > ibeg+1 );
	  pr_hss(scn,ibeg+1,iend);
	 }
       if (ibeg+i==numaa-1)   goto prcount;
       return (iend+1);
      }
    if ( psum[i+1]>pmax )
      {pmax= psum[i+1]; iend= ibeg+i+1;}
   }

if (iend>excend)   {etype=1; excend= ibeg+i;}
else   etype= 2;
if (pmax >= prthrd[2])
  {if (iend-ibeg < mprlgth)
     {pmmax= 0.0;
      for( ja= (iend>mprlgth) ? iend-mprlgth : 0; ja<=ibeg; ++ja )
        {pmsum= 0.0;
	 jend= (ja+mprlgth-1 < numaa) ? ja+mprlgth-1 : numaa-1;
	 for( j=ja;j<=jend;++j)   pmsum+= scr[protein[j]];
	 if (pmsum>=pmmax)   {imbeg= ja; pmmax= pmsum;}
	}
      if (pmmax >= prthrd[2])
	{ibeg= imbeg;
	 iend= (ibeg+mprlgth <= numaa) ? ibeg+mprlgth : numaa;
	 pmax= pmmax;
	}
      else goto prcount;
     }
   ++count;
   pcnt= -1;   for (i=0;i<5;++i)   pc[0][i]=pc[1][i]= 0;
   if (pstyle%2==0 && pobflag)
     {for (i=0;i<=oblc;++i)   fprintf(outfp,"%s",outbuf[i]);
      pobflag= 0;
     }
   if (pstyle==1)   fprintf(outfp,"#%2d)", scn);
   else   fprintf(outfp,"\n");
   fprintf(outfp," %1d) From %4d to %4d", count, ibeg+1, iend );
   if (pstyle==4)   fprintf(outfp," (type %d)", etype );
   fprintf(outfp,":  length=%3d, score=%5.2f", iend-ibeg, pmax );
   if ( pmax >= prthrd[1] )   fprintf(outfp,"  *");
   if ( pmax >= prthrd[0] )   fprintf(outfp,"*");
   ia= iend; cutoff= .25*pmax;
   while ( (ia=find_pocket(scn,ia,ibeg+1,cutoff)) > ibeg+1 );
   pr_hss(scn,ibeg+1,iend);
  }

prcount:

if (psum[i+1]<0)   psum[i+1]= 0.0;

if (ploty)
 {fprintf(plotfp,"\n%5d %5.1f\n%5d %5.1f\n", 1, prthrd[0], numaa, prthrd[0]);
  fprintf(plotfp,"\n%5d %5.1f\n%5d %5.1f\n", 1, prthrd[1], numaa, prthrd[1]);
  fprintf(plotfp,"\n%5d %5.1f\n%5d %5.1f\n", 1, prthrd[2], numaa, prthrd[2]);
 }

if (count==0)
  {if (pstyle%4==0)
     {fprintf(outfp,"\n# of segments (>=%2d residues", mprlgth);
      fprintf(outfp,") exceeding M_%4.2f: none\n", prlevel );
     }
  }
else
  {if (pstyle==1)
     {fprintf(outfp,"#%2d) %s: # of segments (>=%2d residues",
		scn, sfname, mprlgth);
      fprintf(outfp,") exceeding M_%4.2f: %2d\n", prlevel, count);
     }
   else if (pstyle%4==0)
     {fprintf(outfp,"\n# of segments (>=%2d residues", mprlgth);
      fprintf(outfp,") exceeding M_%4.2f: %2d\n", prlevel, count);
     }
  }

return (numaa);

}



find_pocket(scn,ia,iz,cutoff)
int scn, ia, iz;
float cutoff;
{
int i;
float psum[PROTLGTH];
int iend;
float pmin= 0.0;

psum[0]= 0.0;
for( i=0; ia-i>iz; ++i )
  {psum[i+1]= psum[i] + scr[protein[ia-i-2]];
   if ( psum[i+1]>=0 )
     {if (psum[i]==0)   return(ia-1);
      if (-pmin>=cutoff)
	{if (pstyle==1)   fprintf(outfp,"\n#%2d)    ", scn);
	 else   fprintf(outfp,"\n    ");
	 fprintf(outfp,
		"(pocket at %4d to %4d:   length=%3d, score=%5.2f)",
		iend, ia-1, ia-iend, pmin );
         pc[0][++pcnt]= iend; pc[1][pcnt]= ia-1;
	}
      return (iend-1);
     }
   if ( psum[i+1]<pmin )
     {pmin= psum[i+1]; iend= ia-i-1;}

  }

return(ia-i);

}



float pfct(nhss,x)   /* returns Poisson probability of observing nhss or */
int nhss;            /* more distinct segments with score greater than or */
float x;             /* equal to S, where S is the score exceeded at least */
{                    /* once with probability x */
int i;
float mu;
float ps= 1.0;
float p= 1.0;

mu= -log(1.0-x);
for( i=1; i<nhss; ++i)   {ps*= mu/i; p+= ps;}
return ( 1.000000 - p*exp(-mu) );
}



pr_hss(scn,x,y)
int scn, x, y;
{
int i,j,q;
int cf[20];
 
for( i=0; i<=19; ++i )  cf[i]=0;
 
if (pfnflag)   {++gfcount; pfnflag= 0;}

j= (pcnt>4) ? 4 : pcnt;
for( i=0; i<y-x+1; ++i )
  {if (i%10 == 0)   fprintf(outfp," ");
   if (i%50 == 0)
     {if (pstyle==1)   fprintf(outfp,"\n#%2d)", scn);
      else   fprintf(outfp,"\n");
      fprintf(outfp,"  %6d  ", x+i);
     }
   if (x+i == pc[0][j])   fprintf(outfp," |");
   fprintf(outfp,"%c", AAUC[protein[x+i-1]] );
   if (x+i == pc[1][j])   {fprintf(outfp,"| "); --j;}
  }
fprintf(outfp,"\n");

q= 0;
for( i=x-1; i<y; ++i )
  for( j=0;j<20;++j )
    if ( AAUC[protein[i]] == AAUC[j] ) {++cf[j]; break;}
  for( i=0; i<=19; ++i )
    {if ( 100.*(float)cf[i]/(float)(y-x+1)>= 10.0 )
       {if (q==0)
	  {if (pstyle==1)   fprintf(outfp,"#%2d)  ",scn);
	   else   fprintf(outfp,"  ");
	  } 
        if ((++q)%5==0)
	  {if (pstyle==1)   fprintf(outfp,"\n#%2d)  ",scn);
	   else   fprintf(outfp,"\n  ");
	  } 
        fprintf(outfp, "  %c: %2d(%4.1f%%);", AAUC[i], cf[i],
             100.*(float)cf[i]/(float)(y-x+1) );
       }
    }
fprintf(outfp,"\n");

}
