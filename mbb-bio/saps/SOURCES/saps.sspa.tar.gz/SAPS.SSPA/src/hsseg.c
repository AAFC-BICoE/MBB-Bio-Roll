/* HSSEG.C;                                    Last update: August 31, 1995. */
/*   - a subroutine to set up search for high scoring segments in protein    */
/*   sequences.                                                              */
/* Dependencies:   called by saps.c; calls find_hss.c, ftoa.c                */
/* Bugs:                                                                     */

/*   Volker Brendel, Department of Mathematics, Stanford University,  */
/*   Stanford CA 94305; (415) 723-9256, volker@gnomic.stanford.edu    */

#include <stdio.h>
#include <math.h>
#include "def.h"
#define NUMSCRSC      8  /* number of scoring schemes */
#define MAXSCORE     20
#define MINSCORE    -20
#define JMAX         40
extern FILE *outfp;
extern int protein[PROTLGTH];
extern char AAUC[25];
extern char CHPN[25];
extern int pstyle, tabflag;
extern int af[23];


float pr[23], expscore, pesc;
double dAIL;
struct {
  char name[50];
  int stype;
  float scr[23];
  float prlevel[3];
  int mprlgth;
 } scrsc[NUMSCRSC+1];   /* NUMSCRSC scoring schemes */
 
        
char outbuf[20][90]; int oblc, pobflag= 0;
int OBLCMAX= 20;

hsseg(numaa,iflag)   /* iflag= 0: initial setup */
int numaa, iflag;    /* iflag= 1: charge scoring schemes */
		     /* iflag= 2: general scoring schemes */
		     /* iflag= 10+aa: sensitivity analysis for amino acid aa */
{
int i,j, jj;
int IA,IE;
int ull;
int ibeg= 0;
float offset, maxoffset;

if (iflag==0)
  {for( i=0;i<=22;++i )   pr[i]=(float)af[i]/(float)numaa;
   init_scrsc();   /* initialize scoring schemes */
   return;
  }
if (iflag==1)   {IA= 1; IE=4;}
if (iflag==2)   {IA= 5; IE=6;}
if (iflag>=10)
  {strcpy(scrsc[0].name,"segments of ");
   scrsc[0].name[strlen(scrsc[0].name)]= AAUC[iflag-10];
   scrsc[0].name[strlen(scrsc[0].name)+1]= '\0';
   scrsc[0].stype= 4;
   for( i=0;i<20;++i)
     {if (i==iflag-10)   scrsc[0].scr[i]= 2;
      else
	{if (pstyle==4)  scrsc[0].scr[i]= -10;
	 else   scrsc[0].scr[i]= -1;
	}
     }
   scrsc[0].prlevel[0]= 0.01; scrsc[0].prlevel[1]= 0.05;
   scrsc[0].prlevel[2]= 0.05; scrsc[0].mprlgth= 10;
   IA= 0; IE= 0;
  }

for( i=IA;i<=IE;++i )
  {if (pstyle%2==0)
     {oblc= 0;   if (pstyle==2) pobflag= 1;
      for (j=0;j<OBLCMAX;++j) for (jj=0;jj<90;++jj) outbuf[j][jj]= '\0';
      strcpy(outbuf[oblc],"\n\n");
      ull= 13 + strlen(scrsc[i].name);
      for( j=0;j<=ull;++j)   outbuf[oblc][2+j]= '_';
      if (pstyle!=2)   fprintf(outfp,"%s",outbuf[oblc]);
      strcpy(outbuf[++oblc],"\n"); strcat(outbuf[oblc],"High scoring ");
      strcat(outbuf[oblc],scrsc[i].name); strcat(outbuf[oblc],":\n");
      if (pstyle!=2)   fprintf(outfp,"%s",outbuf[oblc]);
     }
   offset= -3.0; maxoffset= 0.0;
   if (iflag>=10)
     {for( j=0; j<23; ++j )
        if ( -scrsc[i].scr[j]-1 > maxoffset )   maxoffset= -scrsc[i].scr[j]-1;
     }
 
   while ((offset+= 3)<= maxoffset)
     {if (offset > 0.0 && pstyle%2==0)
        {oblc= 0;
	 for (j=0;j<OBLCMAX;++j) for (jj=0;jj<90;++jj) outbuf[j][jj]= '\0';
	 if (pstyle!=2)
	   fprintf(outfp,"\n\nIncreasing all negative scores by 3:\n");
	 else
	   {pobflag= 1;
	    strcpy(outbuf[oblc],"\n\nIncreasing all negative scores by 3:\n");
	   }
	}
      setup_scr(i,offset);
      if (pstyle%2==0)
        {if (pesc==0)
           {if (pstyle%4==0)
	      fprintf(outfp,"\n! no positive scoring segments possible !\n");
            continue;
           }
         if (expscore<= -0.001)
           {if (pstyle==4)
	      fprintf(stderr,"\n - now scoring for %s", scrsc[i].name );
            siglim(numaa,i);
           }
         else
           {if (pstyle%4==0)
              fprintf(outfp,"\n! expected score > -.001; too big !\n");
            continue;
           }
         if ( dAIL>=.10 )
           {ibeg= 0;
            while ( (ibeg=find_hss(i,numaa,ibeg,scrsc[i].prlevel[2],
				   scrsc[i].mprlgth,0)) < numaa );
           }
         else
           {if (pstyle%4==0) fprintf(outfp,
		"\n Average information/letter: %7.3f < .10; too small !\n",dAIL);
            continue;
           }
        }
      else
        {if ( pesc>0 && expscore<= -0.001 )
           {siglim(numaa,i);
	    if ( dAIL>=.10 )
	      {ibeg= 0;
	       while ( (ibeg=find_hss(i,numaa,ibeg,scrsc[i].prlevel[2],
				      scrsc[i].mprlgth,0)) < numaa );}
           }
        }
      }   /* end of while loop */
   if (pstyle%2==0 && pobflag)
     {if (i==0)   fprintf(outfp,"\n");
      fprintf(outfp,"\nThere are no high scoring %s.", scrsc[i].name);
      if (i==IE)   fprintf(outfp,"\n");
     }
  }   /* end of for i loop */
}



init_scrsc()   /* initialize scoring schemes */
{

strcpy(scrsc[1].name,"positive charge segments");
scrsc[1].stype= 3;
scrsc[1].scr[0] =   -1;  scrsc[1].scr[1] =   -1;  scrsc[1].scr[2] =   -1;
scrsc[1].scr[3] =   -1;  scrsc[1].scr[4] =   -1;  scrsc[1].scr[5] =    2;
scrsc[1].scr[6] =   -2;  scrsc[1].scr[7] =   -1;  scrsc[1].scr[8] =   -2;
scrsc[1].scr[9] =   -1;  scrsc[1].scr[10]=    2;  scrsc[1].scr[11]=   -1;
scrsc[1].scr[12]=   -1;  scrsc[1].scr[13]=   -1;  scrsc[1].scr[14]=   -1;
scrsc[1].scr[15]=   -1;  scrsc[1].scr[16]=   -1;  scrsc[1].scr[17]=   -1;
scrsc[1].scr[18]=   -1;  scrsc[1].scr[19]=   -1;
scrsc[1].scr[20]=    0;  scrsc[1].scr[21]=    0;  scrsc[1].scr[22]=    0;
if (CHPN[16]=='+')   scrsc[1].scr[16]= 1;
scrsc[1].prlevel[0]= 0.01; scrsc[1].prlevel[1]= 0.05; scrsc[1].prlevel[2]= 0.05;
scrsc[1].mprlgth= 20;

strcpy(scrsc[2].name,"negative charge segments");
scrsc[2].stype= 3;
scrsc[2].scr[0] =   -1;  scrsc[2].scr[1] =   -1;  scrsc[2].scr[2] =   -1;
scrsc[2].scr[3] =   -1;  scrsc[2].scr[4] =   -1;  scrsc[2].scr[5] =   -2;
scrsc[2].scr[6] =    2;  scrsc[2].scr[7] =   -1;  scrsc[2].scr[8] =    2;
scrsc[2].scr[9] =   -1;  scrsc[2].scr[10]=   -2;  scrsc[2].scr[11]=   -1;
scrsc[2].scr[12]=   -1;  scrsc[2].scr[13]=   -1;  scrsc[2].scr[14]=   -1;
scrsc[2].scr[15]=   -1;  scrsc[2].scr[16]=   -1;  scrsc[2].scr[17]=   -1;
scrsc[2].scr[18]=   -1;  scrsc[2].scr[19]=   -1;
scrsc[2].scr[20]=    0;  scrsc[2].scr[21]=    0;  scrsc[2].scr[22]=    0;
scrsc[2].prlevel[0]= 0.01; scrsc[2].prlevel[1]= 0.05; scrsc[2].prlevel[2]= 0.05;
scrsc[2].mprlgth= 20;

strcpy(scrsc[3].name,"mixed charge segments");
scrsc[3].stype= 2;
scrsc[3].scr[0] =   -1;  scrsc[3].scr[1] =   -1;  scrsc[3].scr[2] =   -1;
scrsc[3].scr[3] =   -1;  scrsc[3].scr[4] =   -1;  scrsc[3].scr[5] =    1;
scrsc[3].scr[6] =    1;  scrsc[3].scr[7] =   -1;  scrsc[3].scr[8] =    1;
scrsc[3].scr[9] =   -1;  scrsc[3].scr[10]=    1;  scrsc[3].scr[11]=   -1;
scrsc[3].scr[12]=   -1;  scrsc[3].scr[13]=   -1;  scrsc[3].scr[14]=   -1;
scrsc[3].scr[15]=   -1;  scrsc[3].scr[16]=   -1;  scrsc[3].scr[17]=   -1;
scrsc[3].scr[18]=   -1;  scrsc[3].scr[19]=   -1;
scrsc[3].scr[22]=    0;  scrsc[3].scr[21]=    0;  scrsc[3].scr[22]=    0;
if (CHPN[16]=='+')   scrsc[3].scr[16]= 0;
scrsc[3].prlevel[0]= 0.01; scrsc[3].prlevel[1]= 0.05; scrsc[3].prlevel[2]= 0.05;
scrsc[3].mprlgth= 20;

strcpy(scrsc[4].name,"uncharged segments");
scrsc[4].stype= 0;
scrsc[4].scr[0] =    1;  scrsc[4].scr[1] =    1;  scrsc[4].scr[2] =    1;
scrsc[4].scr[3] =    1;  scrsc[4].scr[4] =    1;  scrsc[4].scr[5] =   -8;
scrsc[4].scr[6] =   -8;  scrsc[4].scr[7] =    1;  scrsc[4].scr[8] =   -8;
scrsc[4].scr[9] =    1;  scrsc[4].scr[10]=   -8;  scrsc[4].scr[11]=    1;
scrsc[4].scr[12]=    1;  scrsc[4].scr[13]=    1;  scrsc[4].scr[14]=    1;
scrsc[4].scr[15]=    1;  scrsc[4].scr[16]=    1;  scrsc[4].scr[17]=    1;
scrsc[4].scr[18]=    1;  scrsc[4].scr[19]=    1;
scrsc[4].scr[20]=    0;  scrsc[4].scr[21]=    0;  scrsc[4].scr[22]=    0;
if (CHPN[16]=='+')   scrsc[4].scr[16]= -2;
scrsc[4].prlevel[0]= 0.01; scrsc[4].prlevel[1]= 0.05; scrsc[4].prlevel[2]= 0.05;
scrsc[4].mprlgth= 20;

strcpy(scrsc[5].name,"hydrophobic segments");
scrsc[5].stype= 4;
scrsc[5].scr[0] =    2;  scrsc[5].scr[1] =    1;  scrsc[5].scr[2] =    1;
scrsc[5].scr[3] =   -4;  scrsc[5].scr[4] =    2;  scrsc[5].scr[5] =   -8;
scrsc[5].scr[6] =   -8;  scrsc[5].scr[7] =   -4;  scrsc[5].scr[8] =   -8;
scrsc[5].scr[9] =    2;  scrsc[5].scr[10]=   -8;  scrsc[5].scr[11]=   -2;
scrsc[5].scr[12]=   -4;  scrsc[5].scr[13]=    2;  scrsc[5].scr[14]=   -4;
scrsc[5].scr[15]=    1;  scrsc[5].scr[16]=   -2;  scrsc[5].scr[17]=    2;
scrsc[5].scr[18]=    1;  scrsc[5].scr[19]=    1;
scrsc[5].scr[20]=    0;  scrsc[5].scr[21]=    0;  scrsc[5].scr[22]=    0;
scrsc[5].prlevel[0]= 0.01; scrsc[5].prlevel[1]= 0.05; scrsc[5].prlevel[2]= 0.05;
scrsc[5].mprlgth= 15;

strcpy(scrsc[6].name,"transmembrane segments"); /* (t/u; 11-l.a.) */
scrsc[6].stype= 4;
scrsc[6].scr[0] =    5;  scrsc[6].scr[1] =    2;  scrsc[6].scr[2] =    2;
scrsc[6].scr[3] =   -2;  scrsc[6].scr[4] =    5;  scrsc[6].scr[5] =  -16;
scrsc[6].scr[6] =  -17;  scrsc[6].scr[7] =   -2;  scrsc[6].scr[8] =  -17;
scrsc[6].scr[9] =    5;  scrsc[6].scr[10]=  -16;  scrsc[6].scr[11]=   -6;
scrsc[6].scr[12]=  -10;  scrsc[6].scr[13]=    5;  scrsc[6].scr[14]=  -10;
scrsc[6].scr[15]=   -1;  scrsc[6].scr[16]=   -8;  scrsc[6].scr[17]=    2;
scrsc[6].scr[18]=   -1;  scrsc[6].scr[19]=   -1;
scrsc[6].scr[20]=    0;  scrsc[6].scr[21]=    0;  scrsc[6].scr[22]=    0;
scrsc[6].prlevel[0]= 0.01; scrsc[6].prlevel[1]= 0.05;
if (tabflag) scrsc[6].prlevel[2]= 0.05; else scrsc[6].prlevel[2]= 0.30;
scrsc[6].mprlgth= 15;

}


 
float scr[23];
int stype;   /* type of scoring scheme:
		stype=0: special case (1 0 -1 .. -m scores)
		stype=1: special case (m m-1 .. 0 -1 scores)
		stype=2: special case (1 0 -1 scores)
		stype=3: special case (2 1 0 -1 -2 scores)
		stype=4: special case (m m-1 ... 0 -1 ... -n scores)
	      */
int asize;   /* alphabet size */
float nscr[MAXSCORE - MINSCORE +1];
float npr[MAXSCORE - MINSCORE +1];
int lowscr, highscr;
double dpr[MAXSCORE - MINSCORE +1], dlambda, dk;



setup_scr(snum,offset)   /* set up combined initial scores */
int snum; float offset;
{
int i, j, ja;
float tempscr, temppr;
char disp[15];

for( i=0; i<= MAXSCORE - MINSCORE; ++i )   npr[i]=dpr[i]=0.0;

stype= scrsc[snum].stype;
lowscr=highscr= 0;
for( i=0; i<23; ++i )
  {if (scrsc[snum].scr[i]<0)   scr[i]= scrsc[snum].scr[i] + offset;
   else   scr[i]= scrsc[snum].scr[i];
   if (scr[i]<lowscr)   {lowscr= scr[i]; continue;}
   if (scr[i]>highscr)   highscr= scr[i];
  }

asize= 1;
nscr[0]= scr[0]; npr[0]= pr[0];
for( i=1;i<=22;++i )   /* ... combining equal scores ... */
  {for( j=0;j<asize;++j )
     {if (scr[i]==nscr[j])   {npr[j]+= pr[i]; break;}
      if (j==asize-1)   {++asize; nscr[asize-1]=scr[i];}
     }
  }
for( i=asize-1; i>0; --i )   /* ... sorting scores in ascending order ... */
  {for( j=0;j<i;++j )
     {if ( nscr[j+1] < nscr[j] )
        {tempscr= nscr[j]; nscr[j]= nscr[j+1]; nscr[j+1]= tempscr;
         temppr= npr[j]; npr[j]= npr[j+1]; npr[j+1]= temppr;
        }
     }
  }
if (stype==4)
  {for( i=lowscr; i<=highscr; ++i )
   for( j=0; j<=22; ++j )    if (scr[j]==i)   dpr[i-lowscr]+= pr[j];
  }

/* Now:  asize= size of alphabet
         nscr[i]= score of letter i (in ascending order, i.e. lowest score
                  is nscr[0], highest score is nscr[asize-1]
         npr[i]= frequency of letter i in the sequence
  
   For stype==4:   dpr[i] gives the frequency of score i (between lowscr
                   and highscr), which may be 0
*/

expscore= 0.0; pesc= 0.0;
for( i=asize-1; i>=0; --i )   
  {if (pstyle%2==0)
     {if (asize<=4)
        {strcpy(outbuf[++oblc],"\nscore= ");
         ftoa(nscr[i],6,2,disp);
         ja= strlen(outbuf[oblc]);
         for(j=0;j<6;++j)  outbuf[oblc][ja+j]= disp[j];
	 strcat(outbuf[oblc]," frequency= ");
         ftoa(npr[i],7,3,disp);
         ja= strlen(outbuf[oblc]);
         for(j=0;j<7;++j)  outbuf[oblc][ja+j]= disp[j];
	 strcat(outbuf[oblc],"  ( ");
         ja= strlen(outbuf[oblc]);
         for( j=0; j<=22; ++j )
           if ( scr[j]==nscr[i] )   outbuf[oblc][ja++]= AAUC[j];
	 strcat(outbuf[oblc]," )");
         if (pstyle%4==0)   fprintf(outfp,"%s",outbuf[oblc]);
        }
      else
        {if ((asize-1-i)%5 == 0)   strcpy(outbuf[++oblc],"\n");
         strcat(outbuf[oblc]," ");
         ftoa(nscr[i],6,2,disp);
         ja= strlen(outbuf[oblc]);
         for(j=0;j<6;++j)  outbuf[oblc][ja+j]= disp[j];
         strcat(outbuf[oblc]," (");
         ja= strlen(outbuf[oblc]);
         for( j=0; j<=22; ++j )
           if ( scr[j]==nscr[i] )   outbuf[oblc][ja++]= AAUC[j];
	 strcat(outbuf[oblc],")");
         if ( pstyle%4==0 && ((asize-1-i-4)%5==0 || i==0) )
	   fprintf(outfp,"%s",outbuf[oblc]);
        }
     }
   expscore+= npr[i]*nscr[i];
   if ( nscr[i] > 0.0 )   pesc+= npr[i]*nscr[i];
                          /* pesc= expected score|score is positive;
                             must be > 0 for the scoring scheme to work */
  }

if (pstyle%2==0)
  {strcpy(outbuf[++oblc],"\n\n Expected score/letter: ");
   ftoa(expscore,7,3,disp);
   ja= strlen(outbuf[oblc]);
   for(j=0;j<7;++j)  outbuf[oblc][ja+j]= disp[j];
   if (pstyle%4==0)   fprintf(outfp,"%s",outbuf[oblc]);
  }

}



float lambda, k;
float prthrd[3];


siglim(numaa,snum)   /* - establishes significance limits for score statistic */
int numaa, snum;
{
int i, j, ja;
float cvfct(), xfct(), function();
float rtbis();
float a;
float cv, x, v, w;
float meanlgth, stdlgth;
float b, p1, p2, q1, q2, t;
float nfr[5];
char disp[15];

switch (stype) {

 case 0:	/* stype=0: special case (1 0 -1 .. -m scores) */
   i= 1;
   while( function((float)i)<0 )   ++i;
   lambda= rtbis(function,0.001,(float)i,.000001);
   k= 0.0;
   for( i=0;i<asize;++i )   k+= nscr[i] * npr[i] * exp(nscr[i]*lambda);
   k*= (1. - exp(-lambda) );
   break;

 case 1:	/* stype=1: special case (m m-1 .. 0 -1 scores) */
   i= 1;
   while ( function((float)i)<0 )   ++i;
   lambda= rtbis(function,0.001,(float)i,.000001);
   x=k= 0.0;
   for( i=0; i<asize; ++i )   
     {x+= nscr[i] * npr[i];
      k+= nscr[i] * npr[i] * exp(nscr[i]*lambda);
     }
   k= x*x/k;
   k*= (1. - exp(-lambda) );
   break;

 case 2:	/* stype=2: special case (1 0 -1 scores) */
   lambda= log(npr[0]/npr[asize-1]);
   k= (npr[0]-npr[asize-1])*(npr[0]-npr[asize-1]) / npr[0];
   break;

 case 3:	/* stype=3: special case (2 1 0 -1 -2 scores) */
   i= 1;
   while ( function((float)i)<0 )   ++i;
   lambda= rtbis(function,0.001,(float)i,.000001);
   for( i= -2; i<=2; ++i )
     {for( j=0; j<=4; ++j )
        {if ( nscr[j]==i )   {nfr[i+2]=npr[j]; break;}
         nfr[i+2]=0.0;
        }
     }
   a= -3*nfr[4]*nfr[4]*exp(2*lambda)
       -2*(nfr[4]*nfr[4] + nfr[3]*nfr[4])*exp(lambda)
        +(-3*nfr[4]*nfr[4] - 2*nfr[3]*nfr[4] + nfr[3]*nfr[3]
         + 4*nfr[4] - 4*nfr[4]*nfr[2]);
   q1= (sqrt(a) - (nfr[3] + nfr[4]*(exp(lambda)-1) )  )/(2*nfr[4]);
   q2= 1-q1;
   b= -3*nfr[0]*nfr[0]*exp(-2*lambda)
       -2*(nfr[0]*nfr[0] + nfr[0]*nfr[1])*exp(-lambda)
        +(-3*nfr[0]*nfr[0] - 2*nfr[0]*nfr[1] + nfr[1]*nfr[1]
         + 4*nfr[0] - 4*nfr[0]*nfr[2]);
   p1= (sqrt(b) - (nfr[1] + nfr[0]*(exp(-lambda)-1) )  )/(2*nfr[0]);
   p2= 1-p1;
   t= 1 - nfr[2] - nfr[3] - 2*nfr[4] - nfr[3]*q1 - nfr[4]*q1*q1;
   k= (1.-exp(-lambda))*(1.+exp(-lambda)*q2)*(1.+p2)*t/
       (1.+p2*exp(lambda));
   break;
 
 case 4:	/* stype=4: special case (m m-1 ... 0 -1 ... -n scores) */
   if (pstyle==4)   karlin(lowscr,highscr,dpr,&dlambda,&dk,&dAIL,1);
   else   karlin(lowscr,highscr,dpr,&dlambda,&dk,&dAIL,0);
   k= dk; lambda= dlambda;
   break;
 }

if (stype!=4)
 {dAIL= 0.;
  for(i=0;i<asize;++i)   dAIL+= nscr[i]*npr[i]*exp(lambda*nscr[i]);
  dAIL*= lambda/log(2.0);
 }

if (dAIL < 0.10) return;

if (pstyle%4==0)
  {fprintf(outfp,";    Average information/letter: %7.3f\n", dAIL);
   fprintf(outfp," Minimal length of displayed segments set to: %3d\n",
                scrsc[snum].mprlgth);
  }

cv= cvfct(numaa);
x= xfct(scrsc[snum].prlevel[0]);
prthrd[0]= cv + x;

v=w= 0.0;
for(i=0;i<asize;++i)
  {v+= npr[i]*nscr[i]*exp(lambda*nscr[i]);
   w+= npr[i]*nscr[i]*nscr[i]*exp(lambda*nscr[i]);
  }
w-= v*v;
meanlgth= prthrd[0]/v;
stdlgth= 1.96 * sqrt(prthrd[0]*w/v) / v;

if (pstyle%4==0)
  {fprintf(outfp,
        "\nM_%4.2f= %5.2f  (cv= %5.2f, lambda= %8.5f, k= %8.5f, x= %5.2f;",
        scrsc[snum].prlevel[0], prthrd[0], cv, lambda, k, x );
   fprintf(outfp,
        "\n                90%% confidence interval for segment length:");
   fprintf(outfp," %3.0f +- %3.0f)", meanlgth, stdlgth);
  }
else if (pstyle%2==0)
  {strcpy(outbuf[++oblc],"\n M_");
   ftoa(scrsc[snum].prlevel[0],5,2,disp);
   ja= strlen(outbuf[oblc]);
   for(j=1;j<5;++j)  outbuf[oblc][ja+j-1]= disp[j];
   strcat(outbuf[oblc],"= ");
   ftoa(prthrd[0],6,2,disp);
   ja= strlen(outbuf[oblc]);
   for(j=0;j<6;++j)  outbuf[oblc][ja+j]= disp[j];
   strcat(outbuf[oblc],"; ");
  }

x= xfct(scrsc[snum].prlevel[1]);
prthrd[1]= cv + x;
if (pstyle%4==0)   fprintf(outfp,"\nM_%4.2f= %5.2f  (x= %5.2f)",
        scrsc[snum].prlevel[1], prthrd[1], x);
else if (pstyle%2==0)
  {strcat(outbuf[oblc],"M_");
   ftoa(scrsc[snum].prlevel[1],5,2,disp);
   ja= strlen(outbuf[oblc]);
   for(j=1;j<5;++j)  outbuf[oblc][ja+j-1]= disp[j];
   strcat(outbuf[oblc],"= ");
   ftoa(prthrd[1],6,2,disp);
   ja= strlen(outbuf[oblc]);
   for(j=0;j<6;++j)  outbuf[oblc][ja+j]= disp[j];
  }
   
if (scrsc[snum].prlevel[2]>scrsc[snum].prlevel[1])
  {x= xfct(scrsc[snum].prlevel[2]);
   prthrd[2]= cv + x;
   if (pstyle%4==0)   fprintf(outfp,";     M_%4.2f= %5.2f  (x= %5.2f)\n",
        scrsc[snum].prlevel[2], prthrd[2], x);
   else if (pstyle%2==0)
     {strcat(outbuf[oblc],";     M_");
      ftoa(scrsc[snum].prlevel[2],5,2,disp);
      ja= strlen(outbuf[oblc]);
      for(j=1;j<5;++j)  outbuf[oblc][ja+j-1]= disp[j];
      strcat(outbuf[oblc],"= ");
      ftoa(prthrd[2],6,2,disp);
      ja= strlen(outbuf[oblc]);
      for(j=0;j<6;++j)  outbuf[oblc][ja+j]= disp[j];
      strcat(outbuf[oblc],"\n");
     }
  }
else
  {prthrd[2]= prthrd[1];
   if (pstyle%4==0) fprintf(outfp,"\n");
   if (pstyle%2==0) strcat(outbuf[oblc],"\n");
  }

}



float cvfct(numaa)   /* returns centering value */
int numaa;
{
return ( log((float)numaa)/lambda );
}


float xfct(t)   /* returns correction x corresponding to significance level t */
float t;
{
return ( (log(k)-log(-log(1.0-t)))/lambda );
}



float function(x)
float x;
{
int i;
float y= -1.0;

for( i=0; i<=22; ++i )   y+= pr[i] * exp( x*scr[i] );

return(y);
}



float rtbis(func,x1,x2,xacc)
float x1,x2,xacc;
float (*func)();
{
int j;
float dx,f,fmid,xmid,rtb;

f=(*func)(x1);
fmid=(*func)(x2);
if (f*fmid >= 0.0)
  {fprintf(stderr,"\nhsseg.c: Value for lambda too small; adjusted to 0.05.\n");
   return(0.05);
  }
rtb = f < 0.0 ? (dx=x2-x1,x1) : (dx=x1-x2,x2);
for (j=1;j<=JMAX;j++) {
    fmid=(*func)(xmid=rtb+(dx *= 0.5));
    if (fmid <= 0.0) rtb=xmid;
    if (fabs(dx) < xacc || fmid ==0.0) return(rtb);
   }
fprintf(stderr,"\nhsseg.c: ");
fprintf(stderr,
  "Value for lambda may be inaccurate due to insufficient iterations.\n");
return(rtb);

}
