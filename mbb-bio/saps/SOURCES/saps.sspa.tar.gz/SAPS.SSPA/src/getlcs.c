/* GETLCS.C;                                 Last update: September 1, 1995. */
/*   - a subroutine to read a coding sequence in library file format.        */
/* Dependencies:                                                             */
/* Bugs:                                                                     */

/*   Volker Brendel, Department of Mathematics, Stanford University,  */
/*   Stanford CA 94305; (415) 723-9256, volker@gnomic.stanford.edu    */

#include <stdio.h>
#include "def.h"
#define shnflag 1
extern int codtoaa[4][4][4];

getlcs(infp,outfp,sfname,pstyle,cseq,clgth,pseq,molwt)
FILE *infp, *outfp;
char sfname[];
int pstyle, cseq[], *clgth, pseq[];
float *molwt;
{
char inpline[LINELGTH];
int n= 0, j,l= 0, nsflag= 0, wflag= 0;
static float aamw[24] =
 { 113.16, 71.09, 57.05, 87.08, 99.14, 128.17, 129.12, 101.11,
   115.09, 113.16, 156.19, 97.12, 114.11, 147.18, 128.14, 163.18,
   137.14, 131.19, 103.15, 186.21, 114.60, 128.63, 119.40, 0.00 };

for (j=0;j<LINELGTH;++j)   inpline[j]= 'x';
for (j=0;j<81;++j)   sfname[j]= '\0';

fgets(inpline,LINELGTH,infp);
if (inpline[0]=='>')
 {if (shnflag)
   {for (j=4;inpline[j]!='\n' && inpline[j]!=':';++j)
     {if (inpline[j]!=' ')   {sfname[l++]= inpline[j]; nsflag= 1;}
      else if (nsflag) break;
     }
   }
  else
    for (j=4;inpline[j]!='\n' && inpline[j]!=':';++j)   sfname[l++]= inpline[j];
 }

while (fgets(inpline,LINELGTH,infp) && inpline[0]!='>')
 {l=strlen(inpline);
  for (j=0;j<l;j++)
   {if (inpline[j]=='T' || inpline[j]=='U' || inpline[j]=='t' || inpline[j]=='u')
     {cseq[n++] =  0; continue;}
    if (inpline[j]=='C' || inpline[j]=='c')   {cseq[n++] =  1; continue;}
    if (inpline[j]=='A' || inpline[j]=='a')   {cseq[n++] =  2; continue;}
    if (inpline[j]=='G' || inpline[j]=='g')   {cseq[n++] =  3; continue;}
    if (inpline[j]=='N' || inpline[j]=='n')   {cseq[n++] = 10; wflag= 1; continue;}
   }
 }

if (wflag)
 {fprintf(outfp,"\nWARNING: coding sequence %s contains wildcard symbols.\n",
		sfname);
  fprintf(outfp,"NOT USED.\n");
  n= -1;
 }
else if (n%3!=0)
 {fprintf(outfp,"\nWARNING: coding sequence %s of length %d not divisible by 3.\n",
		sfname,n);
  fprintf(outfp,"NOT USED.\n");
  n= -1;
 }
else
 {for (j=0;j<n/3;++j)
   {pseq[j]= codtoaa[cseq[3*j]][cseq[3*j+1]][cseq[3*j+2]];
    *molwt+= aamw[pseq[j]];
   }
  *clgth= n;
  if (pseq[j-1]==23) n= n/3 -1;   else n= n/3;
 }

if (inpline[0]=='>') fseek(infp,(long) -strlen(inpline),1);

return(n);

} /* end getlcs() */
