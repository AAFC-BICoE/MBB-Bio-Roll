/* SAPS.C;                                      Last update: April 11, 1996. */
/*   - program Statistical Analysis of Protein Sequences.                    */
/* Dependencies:   getlibp.c getips.c pr_seq.c resuse.c chcluster.c mFct.c   */
/*                 tFct.c hsseg.c karlin.c find_hss.c fatp.c                 */
/*                 rpeat.c multiplet.c mpcluster.c period.c spacings.c       */
/*                 aacluster.c dist.c                                        */
/* Bugs:                                                                     */

/*   Volker Brendel, Department of Mathematics, Stanford University,  */
/*   Stanford CA 94305; (415) 723-9256, volker@gnomic.stanford.edu    */

#include <stdio.h>
#include <time.h>
#include <math.h>
#include "def.h"
#include "abc.h"
#include "doc.h"

int pstyle= 2, tabflag= 0;
int prmtypes= 0;
FILE *infp, *outfp, *qfp, *tabfp, *plotfp;
char sfname[81], spcname[81], qfname[81], qname[81], label[81];
int af[23], pf[9];
float aq[20][4], pq[9][4];
int protein[PROTLGTH], occpos[PROTLGTH], cseq[PROTLGTH*3+3];
char *cname[4]= { "positive", "negative", "neutral", "positive and negative" };
char symb[3]= {'+','-','0'};
int pfnflag= 0, aflag= 0, qflag= 0;
char aletters[60];
int fcount= 0, gfcount= 0;
int clgth, tncseq= 0, tnumaa= 0;

#define QFNN 10
char *QFNAMES[QFNN]=
 { "BACSU", "CHICK", "DROME", "ECOLI", "HUMAN", "MOUSE", "RAT", "XENLA",
   "YEAST", "swp23s" };


main(argc,argv)
int argc;
char *argv[];
{
int i,j, anum= 0, numaa;
FILE *listfp;
static char libname[60], lstname[60], inpline[LINELGTH];
int libop= 0, listop= 0, pipeop= 0;
float molwt= 18.0;
time_t tlc;
outfp= stdout;

time(&tlc);
strcpy(spcname,INCLDIR);

#define USAGE "Usage:\
 %s [-dtv] [-T] [-s species] [-H] [-a XY...] [-o outfname] [-p]\n\
        [-b/B libname] [-l lstname] [seqfname(s)]\n\n\
  -d: documented output; -t: terse output; -v: verbose output.\n\
  -T: append computer-readable summary output to file `saps.table'.\n\
  -s species:  use species.q for quantile comparisons.\n\
  -H: count H as positive charge.\n\
  -a XY...: analyze spacings of amino acids X, Y, ....\n\
  -o outfname:  redirect output to file `outfname' [default: stdout].\n\
  -p:  read protein sequence data from stdin.\n\
  -b libname:  read protein sequence data from library file libname.\n\
  -B libname:  read coding sequence data from library file libname.\n\
  -l lstname:  read protein sequence data from files specified in\n\
                the list file LST_lstname.\n\
  seqfname(s):  read protein sequence data from individual file(s).\n"

if (argc<2)   {fprintf(stderr,USAGE,argv[0]); exit(0);}

for (i=1;i<argc;++i)
  {if ( *argv[i]=='-' )   switch ( *(argv[i]+1) )   {
	case 'd':
		pstyle= 0;
		++anum;
		break;
	case 't':
		pstyle= 1;
		++anum;
		break;
	case 'v':
		pstyle= 4;
		prmtypes= 1; /* print all overlapping charge clusters */
		++anum;
		break;
	case 'T':
		tabflag= 1;
                if ( (tabfp= fopen( "saps.table", "a" )) == NULL )
                   {fprintf(stderr,"File `saps.table' cannot be opened.\n");
                    perror("saps.table"); exit(-1);}
		++anum;
		break;
	case 's':
		qflag= 1;
		strcpy(qname,argv[i+1]);
		strcat(qname,".q");
		anum+= 2;
                break;
	case 'H':
		CHPN[16]= '+';
		CHCZ[16]= '*';
		++anum;
		break;
	case 'a':
		aflag= 1;
		strcpy(aletters,argv[i+1]);
		anum+= 2;
		break;
	case 'o':
		if ( (outfp = fopen( argv[i+1], "w" )) == NULL )
		   {fprintf(stderr,"File %s cannot be opened.\n", argv[i+1]);
		    perror(argv[i+1]); exit(-1);}
		anum+= 2;
		break;
	case 'p':
		pipeop= 1;
		++anum;
		break;
        case 'b':
                libop= 1;
                strcat(libname,argv[i+1]);
                if ( (infp= fopen( libname, "r" )) == NULL )
                   {fprintf(stderr,"File %s cannot be opened.\n",libname);
                    perror(libname); exit(-1);}
                anum+= 2;
                break;
        case 'B':
                libop= 2;
                strcat(libname,argv[i+1]);
                if ( (infp= fopen( libname, "r" )) == NULL )
                   {fprintf(stderr,"File %s cannot be opened.\n",libname);
                    perror(libname); exit(-1);}
                anum+= 2;
                break;
        case 'l':
                listop= 1;
                strcat(lstname,"LST_");
                strcat(lstname,argv[i+1]);
                if ( (listfp = fopen( lstname, "r" )) == NULL )
                   {fprintf(stderr,"File %s cannot be opened.\n", lstname);
                    perror(lstname); exit(-1);}
                fgets( inpline, LINELGTH, listfp );
                fgets( inpline, LINELGTH, listfp );
                anum+= 2;
                break;
        default:
                break;
        }
  }

fprintf(stderr,"NOW EXECUTING:  ");
for (i=0;i<argc;++i)   fprintf(stderr," %s", argv[i]);
fprintf(stderr,"\n");

if (qflag)
 {strcpy(qfname,spcname); strcat(qfname,qname);
  if ( (qfp = fopen( qfname, "r" )) == NULL )
    {fprintf(stderr,"File %s cannot be opened.\n", qfname);
      perror(qfname); exit(-1); }
  for (j=0;j<4;++j)   fscanf(qfp,"%f",&aq[0][0]); /* - ignore column labels */
  for (i=0;i<20;++i)
    {fscanf(qfp,"%s",label);   /* - ignore row labels */
     for (j=0;j<4;++j)   fscanf(qfp,"%f",&aq[i][j]);
    }
  for (j=0;j<4;++j)   fscanf(qfp,"%f",&pq[0][0]); /* - ignore column labels */
  for (i=0;i< 9;++i)
    {fscanf(qfp,"%s",label);   /* - ignore row labels */
     for (j=0;j<4;++j)   fscanf(qfp,"%f",&pq[i][j]);
    }
  fclose(qfp);
 }
  
fprintf(outfp,"SAPS.  Version of April 11, 1996.\n");
fprintf(outfp,"Date run: %s\n", ctime(&tlc) );
fflush(outfp);
if (pstyle==0)   fprintf(outfp,HEADER);

if (libop==1)
  {fprintf(outfp,"\nLibrary file: %s\n",libname);
   while (numaa=getlibp(protein,infp,&molwt))
     {++fcount;
      if (pstyle==4 || fcount%100 == 0)   fprintf(stderr,
	"\n - now processing protein %4d (%s)", fcount, sfname);
      fprintf(outfp,"\n\n");
      for (j=0;j<80;++j)   fprintf(outfp,"*");
      fprintf(outfp,"\nProtein %4d (File: %s)\n", fcount, sfname);
      if (pstyle%2==0)
       {fprintf(outfp,"\nnumber of residues: %4d;   ", numaa);
        fprintf(outfp,"molecular weight: %5.1f kdal\n", molwt/1000);
       }
      molwt= 18.0;
      if (tabflag)   fprintf(tabfp,"FN %s\n", sfname);
      doit(numaa);
     }
  }
if (libop==2)
  {fprintf(outfp,"\nLibrary file: %s\n",libname);
   while (numaa=getlcs(infp,outfp,sfname,pstyle,cseq,&clgth,protein,&molwt))
     {if (numaa==-1) continue;
      ++fcount;
      if (pstyle==4 || fcount%100 == 0)   fprintf(stderr,
	"\n - now processing coding sequence %4d (%s)", fcount, sfname);
      fprintf(outfp,"\n\n");
      for (j=0;j<80;++j)   fprintf(outfp,"*");
      fprintf(outfp,"\nProtein %4d (File: %s)\n", fcount, sfname);
      if (pstyle%2==0)
       {fprintf(outfp,"\nnumber of residues: %4d;   ", numaa);
        fprintf(outfp,"molecular weight: %5.1f kdal\n", molwt/1000);
       }
      molwt= 18.0;
      if (tabflag)   fprintf(tabfp,"FN %s\n", sfname);
      doit(numaa);
     }
  }
 
while (1)
  {if (listop)
     {if ( fscanf(listfp, "%s", sfname) == EOF )
        {fclose(listfp); listop= 0; continue;}
      if ( (infp = fopen( sfname, "r" )) == NULL )
        {fprintf(stderr,"File %s cannot be opened.\n", sfname);
	 perror(sfname); continue;}
      ++fcount;
      if (pstyle==4 || fcount%25 == 0)   fprintf(stderr,
	"\nFile %4d (%s) has been opened for reading.", fcount, sfname);
     }
   else
     {if (anum+1==argc)   break;
      ++anum;
      if ( (infp = fopen( argv[anum], "r" )) == NULL )
        {fprintf(stderr,"File %s cannot be opened.\n", argv[anum]);
	 perror(argv[anum]); continue;}
      ++fcount;
      strcpy(sfname,argv[anum]);
     }
   if (listop==0 && pipeop==0 && anum+1==argc && fcount==1)
     fprintf(outfp,"File: %s\n", sfname);
   else
     {fprintf(outfp,"\n\n");
      for (i=0;i<80;++i)   fprintf(outfp,"*");
      fprintf(outfp,"\nProtein %4d (File: %s)\n", fcount, sfname);
     }
   if (tabflag)   fprintf(tabfp,"FN %s\n", sfname);
   numaa= getips(infp,outfp,tabfp,pstyle,tabflag,protein,&molwt,cseq,&clgth);
   if (clgth)
    {if (clgth!=3*numaa+3 && clgth!=3*numaa)
      {fprintf(outfp,"\nWARNING: coding/protein sequence inconsistency -");
       fprintf(outfp," length %d != 3*%d(+3) = %d (+3)).\n",clgth,numaa,3*numaa);
       clgth= 0;   fprintf(outfp,"NOT USED.\n");
      }
     else
      {for (i=0;i<numaa;++i)
	{if ((cseq[3*i]==10 || cseq[3*i+1]==10 || cseq[3*i+2]==10))
	  {if (protein[i]!=22)
	    {fprintf(outfp,"\nWARNING: coding/protein sequence inconsistency -");
	     fprintf(outfp," residue %d: X != %c\n",i+1,AAUC[protein[i]]);
	     clgth= 0;   fprintf(outfp,"NOT USED.\n");   break;
	    }
	  }
	 else
          {if (protein[i]!=codtoaa[cseq[3*i]][cseq[3*i+1]][cseq[3*i+2]])
	    {fprintf(outfp,"\nWARNING: coding/protein sequence inconsistency -");
	     fprintf(outfp," residue %d: %c != %c\n",i+1,
		AAUC[codtoaa[cseq[3*i]][cseq[3*i+1]][cseq[3*i+2]]],
		AAUC[protein[i]]);
	     clgth= 0;   fprintf(outfp,"NOT USED.\n");   break;
	    }
	  }
        }
      }
    }
   if (pstyle%2==0)
    {fprintf(outfp,"\nnumber of residues: %4d;   ", numaa);
     fprintf(outfp,"molecular weight: %5.1f kdal\n", molwt/1000);
    }
   molwt= 18.0;
   doit(numaa);
   fclose(infp);
  }

if (fcount>1)
 {fprintf(outfp,"\n");
  if (tncseq)
   {fprintf(outfp,"----------------------------------------");
    fprintf(outfp,"----------------------------------------");
    fprintf(outfp,"\nSUMMARY CUMULATIVE STATISTICS");
    fprintf(outfp," (%d coding sequences, %d non-stop codons):",tncseq,tnumaa);
    coduse(outfp,pstyle,cseq,0,0,2); propuse(outfp,tnumaa,af,2);
   }
  fprintf(stderr,"\n%5d files analyzed.\n", fcount);
 }
fprintf(stderr,"\n");

exit(0);
}



doit(numaa)
int numaa;
{
int i, j;
int CBLGTH= 4;

if (qflag==0)
 {for (i=0;i<strlen(sfname);++i)   if (sfname[i]=='_') break;
  if (i<strlen(sfname))
   {strcpy(qname,sfname+i+1);
    for (i=0;i<QFNN;++i)   if (strcmp(qname,QFNAMES[i])==0) break;
    if (i==QFNN) {--i; strcpy(qname,QFNAMES[i]);}
    strcpy(qfname,spcname); strcat(qfname,QFNAMES[i]);
   }
  else
   {strcpy(qname,QFNAMES[QFNN-1]); strcpy(qfname,spcname); strcat(qfname,qname);}
  strcat(qfname,".q");
  if ( (qfp = fopen( qfname, "r" )) == NULL )
    {fprintf(stderr,"File %s cannot be opened.\n", qfname);
      perror(qfname); exit(-1); }
  for (j=0;j<4;++j)   fscanf(qfp,"%f",&aq[0][0]); /* - ignore column labels */
  for (i=0;i<20;++i)
    {fscanf(qfp,"%s",label);   /* - ignore row labels */
     for (j=0;j<4;++j)   fscanf(qfp,"%f",&aq[i][j]);
    }
  for (j=0;j<4;++j)   fscanf(qfp,"%f",&pq[0][0]); /* - ignore column labels */
  for (i=0;i<9;++i)
    {fscanf(qfp,"%s",label);   /* - ignore row labels */
     for (j=0;j<4;++j)   fscanf(qfp,"%f",&pq[i][j]);
    }
  fclose(qfp);
 }

if (pstyle==1)  
 {resuse(protein,numaa,af,pf,outfp,pstyle,aq,pq,1,tabfp,tabflag,AAUC,CHPN);
  if (clgth)
   {if (clgth==3*numaa+3) coduse(outfp,pstyle,cseq,clgth-3,clgth,1);
    else                  coduse(outfp,pstyle,cseq,clgth,clgth,1);
    propuse(outfp,numaa,af,1);
    ++tncseq; tnumaa+= numaa;
    fprintf(outfp,"\n");
   }
  hsseg(numaa,0);
  chcluster(numaa);
  fprintf(outfp,"\n");
  fatp(numaa);
  fprintf(outfp,"\n");
  hsseg(numaa,0);
  hsseg(numaa,1);
  hsseg(numaa,2);
  multiplet(protein,numaa,AAUC,cseq,clgth,outfp,pstyle,tabfp,tabflag);
  multiplet(protein,numaa,CHPN,cseq,clgth,outfp,pstyle,tabfp,tabflag);
  spacings(numaa);
 }
else
 {pr_seq(outfp,protein,numaa,AAUC,1);
  fprintf(outfp,"\n");
  fprintf(outfp,"----------------------------------------");
  fprintf(outfp,"----------------------------------------");
  fprintf(outfp,"\nCOMPOSITIONAL ANALYSIS (extremes relative to: %s)\n",qname);
  if (pstyle==0)   fprintf(outfp,COMP_DOC);
  resuse(protein,numaa,af,pf,outfp,pstyle,aq,pq,1,tabfp,tabflag,AAUC,CHPN);
  if (clgth)
   {if (pstyle%4==0)
     {fprintf(outfp,"\ncDNA:"); pr_seq(outfp,cseq,clgth,NAUC,1);}
    if (clgth==3*numaa+3) coduse(outfp,pstyle,cseq,clgth-3,clgth,0);
    else                  coduse(outfp,pstyle,cseq,clgth,clgth,0);
    propuse(outfp,numaa,af,0);
    ++tncseq; tnumaa+= numaa;
    fprintf(outfp,"\n");
   }
  hsseg(numaa,0);
  fprintf(outfp,"----------------------------------------");
  fprintf(outfp,"----------------------------------------");
  fprintf(outfp,"\nCHARGE DISTRIBUTIONAL ANALYSIS\n");
  if (pstyle==0)   fprintf(outfp,CHDA_DOC);
  pr_seq(outfp,protein,numaa,CHPN,1);
  fprintf(outfp,"\nA. CHARGE CLUSTERS.\n");
  if (pstyle==0)   fprintf(outfp,CLUS_DOC);
  chcluster(numaa);
  fprintf(outfp,"\n\nB. HIGH SCORING (UN)CHARGED SEGMENTS.\n");
  if (pstyle==0)   fprintf(outfp,HSSG_DOC);
  hsseg(numaa,1);
  fprintf(outfp,"\n\nC. CHARGE RUNS AND PATTERNS.\n");
  if (pstyle==0)   fprintf(outfp,RUPA_DOC);
  fatp(numaa);
  fprintf(outfp,"\n");
  fprintf(outfp,"----------------------------------------");
  fprintf(outfp,"----------------------------------------");
  fprintf(outfp,"\nDISTRIBUTION OF OTHER AMINO ACID TYPES\n");
  if (pstyle==0)   fprintf(outfp,DAAT_DOC);
  fprintf(outfp,"\n1. HIGH SCORING SEGMENTS.");
  hsseg(numaa,2);
  fprintf(outfp,"\n\n2. SPACINGS OF C.\n");
  dist(numaa,18,0);
  if (aflag)
   {fprintf(outfp,"\n\n3. DISTRIBUTION OF COMMAND-LINE SPECIFIED RESIDUES.");
    for (i=0;i<strlen(aletters);++i)
     {for (j=0;j<23;++j)
       {if (AAUC[j]!=aletters[i])   continue;
        else   break;
       }
      if (j>22)   continue;
      if (pstyle==4)
       {fprintf(outfp,
		"\n_____________________________________________________\n");
	fprintf(outfp,"%c spacings:", AAUC[j] );
	dist(numaa,j,1);
       }
      if (af[j]>=7)
       {aacluster(numaa,j); hsseg(numaa,10+j); fprintf(outfp,"\n");}
     }
    for (i=0;i<strlen(aletters);++i)
     {if (aletters[i]=='a')
       {aacluster(numaa,50); fprintf(outfp,"\n"); continue;}
      if (aletters[i]=='p')
       {aacluster(numaa,51); fprintf(outfp,"\n"); continue;}
      if (aletters[i]=='q')
       {aacluster(numaa,52); fprintf(outfp,"\n"); continue;}
      if (aletters[i]=='s')
       {aacluster(numaa,53); fprintf(outfp,"\n"); continue;}
     }
   }
  fprintf(outfp,"\n");
  fprintf(outfp,"----------------------------------------");
  fprintf(outfp,"----------------------------------------");
  fprintf(outfp,"\nREPETITIVE STRUCTURES.\n");
  if (pstyle==0)   fprintf(outfp,REPE_DOC);
  fprintf(outfp,
     "\nA. SEPARATED, TANDEM, AND PERIODIC REPEATS: amino acid alphabet.");
  if (numaa>500)   CBLGTH= 5;
  if (numaa>2000)   CBLGTH= 6;
  fprintf(outfp,"\nRepeat core block length: %2d\n", CBLGTH);
  rpeat(numaa,1,CBLGTH,CBLGTH,0,0);
  fprintf(outfp,
     "\nB. SEPARATED AND TANDEM REPEATS: 11-letter reduced alphabet.");
  fprintf(outfp,"\n   (i= LVIF; += KR; -= ED; s= AG; o= ST; n= NQ; a= YW;");
     fprintf(outfp," p= P; h= H; m= M; c= C)");
  CBLGTH+= 4;
  fprintf(outfp,"\nRepeat core block length: %2d\n", CBLGTH);
  rpeat(numaa,2,CBLGTH,CBLGTH,0,0);
  fprintf(outfp,"\n");
  fprintf(outfp,"----------------------------------------");
  fprintf(outfp,"----------------------------------------");
  fprintf(outfp,"\n\nMULTIPLETS.\n");
  if (pstyle==0)   fprintf(outfp,MULT_DOC);
  fprintf(outfp,"\nA. AMINO ACID ALPHABET.\n");
  multiplet(protein,numaa,AAUC,cseq,clgth,outfp,pstyle,tabfp,tabflag);
  fprintf(outfp,"\nB. CHARGE ALPHABET.\n");
  multiplet(protein,numaa,CHPN,cseq,clgth,outfp,pstyle,tabfp,tabflag);
  fprintf(outfp,"----------------------------------------");
  fprintf(outfp,"----------------------------------------");
  fprintf(outfp,"\nPERIODICITY ANALYSIS.\n");
  if (pstyle==0)   fprintf(outfp,PERD_DOC);
  period(numaa,1,1,10,0,numaa-1,4);
  period(numaa,2,1,10,0,numaa-1,5);
  fprintf(outfp,"----------------------------------------");
  fprintf(outfp,"----------------------------------------");
  fprintf(outfp,"\nSPACING ANALYSIS.\n");
  if (pstyle==0)   fprintf(outfp,SPAC_DOC);
  spacings(numaa);
 }

if (tabflag)   fprintf(tabfp,"//\n");

} /* end doit() */
