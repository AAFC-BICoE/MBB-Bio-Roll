/* GETIPS.C;                                   Last update: August 30, 1995. */
/*   - a subroutine to read a protein sequence in minimal EMBL file format.  */
/* Dependencies:   called by aaruns.c, mproc.c, pgrep.c, pmagic.c, pmotif.c, */
/*   propeat.c, prorep.c, prostat.c, pscore.c, psearch.c, pword.c, ranseq.c, */
/*   saps.c, tscore.c, zipscan.c                                             */
/* Bugs:                                                                     */

/*   Volker Brendel, Department of Mathematics, Stanford University,  */
/*   Stanford CA 94305; (415) 723-9256, volker@gnomic.stanford.edu    */

#include <stdio.h>
#include "def.h"

getips(infp,outfp,tabfp,pstyle,tabflag,pseq,molwt,cseq,clgth)
FILE *infp, *outfp, *tabfp;
int pstyle, tabflag;
int pseq[], cseq[], *clgth;
float *molwt;
{
int i= 0, j, k= 0, ch, numaa;
char inpline[LINELGTH];
int embl= 0, sline= 0;
long offset;
static float aamw[23] =
 { 113.16, 71.09, 57.05, 87.08, 99.14, 128.17, 129.12, 101.11,
   115.09, 113.16, 156.19, 97.12, 114.11, 147.18, 128.14, 163.18,
   137.14, 131.19, 103.15, 186.21, 114.60, 128.63, 119.40 };

for (j=0;j<LINELGTH;++j)   inpline[j]= 'x';

/*FORMAT:
  The first line of the file is a header to be printed, the first line
  of the sequence is preceded by a line beginning with 'SQ', and subsequent
  symbols are A-Z (one-letter-symbols) as part of the sequence or irrelevant
  characters (like numbers and blanks);  non-standard symbols for ambiguous
  or missing monomers are ignored.
*/

fgets(inpline,LINELGTH,infp);
if (inpline[0]=='I' && inpline[1]=='D' && inpline[2]==' ' && inpline[3]==' ' &&
    inpline[4]==' ' )
 {embl= 1;
  if (pstyle%4==0)   fprintf(outfp,"\nSWISS-PROT ANNOTATION:\n");
 }
if (pstyle%2==0)   fputs(inpline,outfp);
while (sline==0)		
 {if (fgets(inpline,LINELGTH,infp)==NULL)
   {fprintf(stderr,"\nSequence file not in minimal EMBL format!\n"); exit(-1);}
  if (inpline[0]=='C' && inpline[1]=='Q')
   {while (1)
     {if (fgets(inpline,LINELGTH,infp)==NULL)
       {fprintf(stderr,"\nSequence file not in minimal EMBL format!\n");
	exit(-1);
       }
      if (inpline[0]=='S' && inpline[1]=='Q')   break;
      for (j=0;j<strlen(inpline);++j)
       {if (inpline[j]=='T' || inpline[j]=='U' ||
	    inpline[j]=='t' || inpline[j]=='u' )
	  {cseq[k++]= 0; continue;}
	 if (inpline[j]=='C' || inpline[j]=='c' )   {cseq[k++]= 1; continue;}
	 if (inpline[j]=='A' || inpline[j]=='a' )   {cseq[k++]= 2; continue;}
	 if (inpline[j]=='G' || inpline[j]=='g' )   {cseq[k++]= 3; continue;}
	 if (inpline[j]=='N' || inpline[j]=='n' )   {cseq[k++]=10; continue;}
       }
     }
    *clgth= k;
   }
  else *clgth= 0;
  if (inpline[0]=='S' && inpline[1]=='Q')   sline= 1;
  if (embl && pstyle%2==0)
   {if (inpline[0]=='D' && inpline[1]=='E')   fputs(inpline,outfp);
    if (pstyle%4==0 &&
          ( (inpline[0]=='R' && (inpline[1]=='A' || inpline[1]=='L'))
	    || (inpline[0]=='C' && inpline[1]=='C')
	    || (inpline[0]=='F' && inpline[1]=='T') ) )   fputs(inpline,outfp);
   }
  if (embl && tabflag && inpline[0]=='D' && inpline[1]=='E')
	fputs(inpline,tabfp);
 }						
offset= ftell(infp);
fseek(infp,offset,0);

while ( (ch=fgetc(infp)) != EOF )
  {if (ch=='L')   {pseq[i++]= 0; *molwt+=  aamw[0]; continue;}
   if (ch=='A')   {pseq[i++]= 1; *molwt+=  aamw[1]; continue;}
   if (ch=='G')   {pseq[i++]= 2; *molwt+=  aamw[2]; continue;}
   if (ch=='S')   {pseq[i++]= 3; *molwt+=  aamw[3]; continue;}
   if (ch=='V')   {pseq[i++]= 4; *molwt+=  aamw[4]; continue;}
   if (ch=='K')   {pseq[i++]= 5; *molwt+=  aamw[5]; continue;}
   if (ch=='E')   {pseq[i++]= 6; *molwt+=  aamw[6]; continue;}
   if (ch=='T')   {pseq[i++]= 7; *molwt+=  aamw[7]; continue;}
   if (ch=='D')   {pseq[i++]= 8; *molwt+=  aamw[8]; continue;}
   if (ch=='I')   {pseq[i++]= 9; *molwt+=  aamw[9]; continue;}
   if (ch=='R')   {pseq[i++]=10; *molwt+= aamw[10]; continue;}
   if (ch=='P')   {pseq[i++]=11; *molwt+= aamw[11]; continue;}
   if (ch=='N')   {pseq[i++]=12; *molwt+= aamw[12]; continue;}
   if (ch=='F')   {pseq[i++]=13; *molwt+= aamw[13]; continue;}
   if (ch=='Q')   {pseq[i++]=14; *molwt+= aamw[14]; continue;}
   if (ch=='Y')   {pseq[i++]=15; *molwt+= aamw[15]; continue;}
   if (ch=='H')   {pseq[i++]=16; *molwt+= aamw[16]; continue;}
   if (ch=='M')   {pseq[i++]=17; *molwt+= aamw[17]; continue;}
   if (ch=='C')   {pseq[i++]=18; *molwt+= aamw[18]; continue;}
   if (ch=='W')   {pseq[i++]=19; *molwt+= aamw[19]; continue;}
   if (ch=='B')   {pseq[i++]=20; *molwt+= aamw[20]; continue;}
   if (ch=='Z')   {pseq[i++]=21; *molwt+= aamw[21]; continue;}
   if (ch=='X')   {pseq[i++]=22; *molwt+= aamw[22]; continue;}
  }

return (i);

} /* end getips() */
