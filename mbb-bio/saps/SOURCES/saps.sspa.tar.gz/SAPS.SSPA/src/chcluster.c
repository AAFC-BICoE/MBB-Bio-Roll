/* CHCLUSTER.C;                                Last update:  March 19, 1997. */
/*   - a subroutine to identify charge clusters in protein sequences.        */
/* Dependencies:   called by saps.c; calls mFct.c, tFct.c                    */
/* Bugs:                                                                     */

/*   Volker Brendel, Department of Mathematics, Stanford University,  */
/*   Stanford CA 94305; (415) 723-9256, volker@gnomic.stanford.edu    */

#include <stdio.h>
#include "def.h"
#define WNDLGTH1     30
#define WNDLGTH2     45
#define WNDLGTH3     60
extern int protein[PROTLGTH], occpos[PROTLGTH];
extern pstyle, tabflag;
extern FILE *outfp, *tabfp;
extern char sfname[81];
extern int prmtypes;
extern char AAUC[25], CHPN[25];
extern int pf[9];

float Sfact; /* significance factor */

chcluster(numaa)
int numaa;
{
int i,j,l;
float cprop[4];
int count;
int sign;
int swc[3], swp[3][PROTLGTH];
int lmax[PROTLGTH], lsh[PROTLGTH];
double t, tmax[PROTLGTH];
int minp1, minn1, minpn1, min;
int minp2, minn2, minpn2;
int minp3, minn3, minpn3;
int mFct();
double tFct();
int prti, prc[3];
int prtpos[3][20], prtlgt[3][20], prtpn[20];
double prttvl[3][20];
int totct= 0;
int oflag; /* overlap flag */

swc[0]= swc[1]= swc[2]= 0;
prc[0]= prc[1]= prc[2]= 0;
for( j=0;j<20;++j)   prtpn[j]= 1;

cprop[0]= (float)pf[0]/numaa;
cprop[1]= (float)pf[1]/numaa;
cprop[2]= 1. - cprop[0] - cprop[1];
cprop[3]= cprop[0] + cprop[1];

Sfact= 4.0;
if (numaa>= 750)   Sfact= 4.5;
if (numaa>=1500)   Sfact= 5.0;

/* ... establishing the critical numbers for p, n, and pn clusters: */
minp1 = mFct(Sfact,WNDLGTH1,cprop[0]);
minn1 = mFct(Sfact,WNDLGTH1,cprop[1]);
minpn1= mFct(Sfact,WNDLGTH1,cprop[3]);
minp2 = mFct(Sfact,WNDLGTH2,cprop[0]);
minn2 = mFct(Sfact,WNDLGTH2,cprop[1]);
minpn2= mFct(Sfact,WNDLGTH2,cprop[3]);
minp3 = mFct(Sfact,WNDLGTH3,cprop[0]);
minn3 = mFct(Sfact,WNDLGTH3,cprop[1]);
minpn3= mFct(Sfact,WNDLGTH3,cprop[3]);

for( i=0;i<numaa;++i )
  {if (CHPN[protein[i]]=='+')
    {++totct; occpos[totct]= i; continue;}
   if (CHPN[protein[i]]=='-')
    {++totct; occpos[totct]= -i; continue;}
  }

/* ... looping through all charge positions: 
   the starting points of significant windows are recorded in swp[x][swc[l]],
   where x=0 corresponds to n-clusters, x=1 corresponds to np-clusters, x=2 
   corresponds to p-clusters, and l is the count of significant clusters.
*/
for( i=1;i<totct;++i )
  {if (i+minpn1-1 <= totct)
     {if ( abs(occpos[i+minpn1-1]) - abs(occpos[i]) + 1 <= WNDLGTH1 )
        {swp[1][swc[1]]= i; ++swc[1]; goto skipped;}
     }
   else   goto skipped;
   if (i+minpn2-1 <= totct)
     {if ( abs(occpos[i+minpn2-1]) - abs(occpos[i]) + 1 <= WNDLGTH2 )
        {swp[1][swc[1]]= i; ++swc[1]; goto skipped;}
     }
   else   goto skipped;
   if (i+minpn3-1 <= totct)
     {if ( abs(occpos[i+minpn3-1]) - abs(occpos[i]) + 1 <= WNDLGTH3 )
        {swp[1][swc[1]]= i; ++swc[1];}
     }
/* ... the above established whether or not i defines the starting point
   of a significant pn-cluster, depending on whether or not minpnx charges
   occur within a segment of length at most WNDLGTHx
*/

   skipped:
   if (occpos[i]>0)  {min= minp1; sign=  1;}   /* i might start a p-cluster */
   else		     {min= minn1; sign= -1;}   /* i might start a n-cluster */
   if (i+min-1 > totct)  continue;
   if ( abs(occpos[i+min-1]) - abs(occpos[i]) + 1 > WNDLGTH1 )   goto wind2;
   count= 1;
   for( j=1;;++j )
     {if (sign*occpos[i+j] > 0)   ++count;
      else 			  --count;   /* ... establishing net charge */
      if (count >= min)   
        {if ( abs(occpos[i+j]) - abs(occpos[i]) <= WNDLGTH1 )
	   {swp[sign+1][swc[sign+1]]= i; ++swc[sign+1]; break;
		/* ... i does start a cluster of length <= WNDLGTH1 */
	   }
        }
      if ( abs(occpos[i+j]) - abs(occpos[i]) + 1 > WNDLGTH1 )   goto wind2;
		/* ... i does not start a cluster of length <= WNDLGTH1 */
     }
   continue;

   wind2:
   if (occpos[i]>0)  {min= minp2; sign=  1;}
   else		     {min= minn2; sign= -1;}
   if (i+min-1 > totct)   continue;
   if ( abs(occpos[i+min-1]) - abs(occpos[i]) + 1 > WNDLGTH2 )   goto wind3;
   count= 1;
   for( j=1;;++j )
     {if (sign*occpos[i+j] > 0)   ++count;
      else 			  --count;
      if (count >= min)   
        {if ( abs(occpos[i+j]) - abs(occpos[i]) <= WNDLGTH2 )
	   {swp[sign+1][swc[sign+1]]= i; ++swc[sign+1]; break;
		/* ... i does start a cluster of length <= WNDLGTH2 */
	   }
        }
      if ( abs(occpos[i+j]) - abs(occpos[i]) + 1 > WNDLGTH2 )   goto wind3;
		/* ... i does not start a cluster of length <= WNDLGTH2 */
     }
   continue;

   wind3:
   if (occpos[i]>0)  {min= minp3; sign=  1;}
   else		     {min= minn3; sign= -1;}
   if (i+min-1 > totct)   continue;
   if ( abs(occpos[i+min-1]) - abs(occpos[i]) + 1 > WNDLGTH3 )   continue;
   count= 1;
   for( j=1;;++j )
     {if (sign*occpos[i+j] > 0)   ++count;
      else 			  --count;
      if (count >= min)   
        {if ( abs(occpos[i+j]) - abs(occpos[i]) <= WNDLGTH3 )
	   {swp[sign+1][swc[sign+1]] = i; ++swc[sign+1]; break;
		/* ... i does start a cluster of length <= WNDLGTH3 */
	   }
        }
      if ( abs(occpos[i+j]) - abs(occpos[i]) + 1 > WNDLGTH3 )   break;
     }
   continue;
  }
/* ... end of looping through all charge positions */ 


/* ... now the clusters will be optimized such that the segments of highest 
   concentration are printed: 
*/
if (swc[2]==0 || cprop[0]<0.05)   goto mixed;
   /* - there are no p-clusters or the frequency of + is below threshold */
for( i=0;i<swc[2];++i )
  {count= 1; tmax[i]= 0; lmax[i]= 0;
   for( j=1; swp[2][i]+j <= totct; ++j )
     {if (occpos[swp[2][i]+j] > 0)	++count;
      else				--count;
      if (count < minp1)		continue;
      l= abs(occpos[swp[2][i]+j]) - abs(occpos[swp[2][i]]) + 1;
      t= tFct(count,l,cprop[0]);
      if (l<=20)   {if (t>=Sfact)   {tmax[i]= t; lmax[i]= l;} }
      else
	{if ( (lmax[i]<=20 && t>=Sfact) || t>tmax[i] )  
	   {tmax[i]= t; lmax[i]= l;}
	}
      if (l > 74 && swp[2][i]+j+1 <= totct &&
	  abs(occpos[swp[2][i]+j+1]) - abs(occpos[swp[2][i]+j]) > 3)   break;
     }
   if (lmax[i]<=20)
     {count= 1; 
      for( j=1; j<20 && abs(occpos[swp[2][i]])+j < numaa; ++j )
        {if ( CHPN[protein[abs(occpos[swp[2][i]])+j]] == '+' )   
           {++count; continue;}
         if ( CHPN[protein[abs(occpos[swp[2][i]])+j]] == '-' )
           {--count; continue;}
        }
      if (count>=minp1)   tmax[i]= tFct(count,20,cprop[0]);
      else   tmax[i]= 0.0;
      lsh[i]= 0;
      for( j=1; j<=20-count && abs(occpos[swp[2][i]])-j >= 0; ++j )
        {if ( CHPN[protein[abs(occpos[swp[2][i]])+20-j]] == '+' )   
              --count;
         if ( CHPN[protein[abs(occpos[swp[2][i]])+20-j]] == '-' )   
              ++count;
         if ( CHPN[protein[abs(occpos[swp[2][i]])-j]] == '+' )
              ++count;
         if ( CHPN[protein[abs(occpos[swp[2][i]])-j]] == '-' )
              --count;
         t= tFct(count,20,cprop[0]);
	 if (count>=minp1 && t > tmax[i])   {tmax[i]= t; lsh[i]= j;}
        }
      if (tmax[i]>=Sfact)   lmax[i]= 20;
     }
  }

if (swc[2]==1)   /* ... there is only one p-cluster ... */
  {if (lmax[0] > 20)
     {prtpos[2][0]= abs(occpos[swp[2][0]]); 
      prtlgt[2][0]= lmax[0]; prttvl[2][0]= tmax[0];
      prc[2]= 1;
     }
   if (lmax[0] == 20)
     {prtpos[2][0]= abs(occpos[swp[2][0]]) - lsh[0]; 
      if (numaa-prtpos[2][0] < 20)   prtlgt[2][0]= numaa - prtpos[2][0];
      else   prtlgt[2][0]= 20;
      prttvl[2][0]= tmax[0];
      prc[2]= 1;
     }
  }
else   /* ... there are several p-clusters ... */
  {prti= 0;
   prc[2]= 0;
   for( i=1;i<swc[2];++i )
     {if ( abs(occpos[swp[2][i]]) > abs(occpos[swp[2][prti]]) + lmax[prti] + 8)
      /* ... clusters [prti] and [i] do not overlap; 
         target cluster [prti] for printing */
        {if (lmax[prti] > 20)
  	   {prtpos[2][prc[2]]= abs(occpos[swp[2][prti]]);
	    prtlgt[2][prc[2]]= lmax[prti];
	    prttvl[2][prc[2]]= tmax[prti];
   	    ++prc[2];
	   }
         if (lmax[prti] == 20)
   	   {prtpos[2][prc[2]]= abs(occpos[swp[2][prti]]) - lsh[prti];
	    if (numaa-prtpos[2][prc[2]] < 20)
	      prtlgt[2][prc[2]]= numaa - prtpos[2][prc[2]];
	    else   prtlgt[2][prc[2]]= 20;
	    prttvl[2][prc[2]]= tmax[prti];
   	    ++prc[2];
	   }
	 prti= i;
	}
      else
        {if ( abs(occpos[swp[2][i]]) + lmax[i] == 
	      abs(occpos[swp[2][prti]]) + lmax[prti] )
	    {if ( tmax[i] >= tmax[prti]+.50 )		prti= i;}
            /* ... clusters [prti] and [i] have the same end point;
               target the optimal one of the two for printing */
	 else
	   {count= 0;
            for( j=swp[2][prti]; 
		 abs(occpos[j])<=abs(occpos[swp[2][i]])+lmax[i]-1; ++j)
	      {if (occpos[j] > 0)	++count;
	       else			--count;
	       if (occpos[j] == occpos[totct])   break;
	      }
	    l =  abs(occpos[swp[2][i]]) + lmax[i] - abs(occpos[swp[2][prti]]);
	    t =  tFct(count,l,cprop[0]);
	    if ( t > tmax[prti] )  {lmax[prti] = l;  tmax[prti] = t;}
	    if ( tmax[i] > tmax[prti] )		prti = i;
             /* ... clusters [prti] and [i] overlap but do not have the same
                end point; target the optimal cluster of either one of the two
                and their fusion for printing */
	   }
	}
     }
   if (lmax[prti] > 20)
     {prtpos[2][prc[2]]= abs(occpos[swp[2][prti]]);
      prtlgt[2][prc[2]]= lmax[prti];
      prttvl[2][prc[2]]= tmax[prti];
      ++prc[2];
     }
   if (lmax[prti] == 20)
     {prtpos[2][prc[2]]= abs(occpos[swp[2][prti]]) - lsh[prti];
      if (numaa-prtpos[2][prc[2]] < 20)
	      prtlgt[2][prc[2]]= numaa - prtpos[2][prc[2]];
      else   prtlgt[2][prc[2]]= 20;
      prttvl[2][prc[2]]= tmax[prti];
      ++prc[2];
     }
  }


mixed:
if (swc[1]==0 || cprop[3]<0.05)   goto negative;
   /* - there are no pn-clusters or the frequency of +- is below threshold */
for( i=0;i<swc[1];++i )
  {count= 1; tmax[i]= 0; lmax[i]= 0;
   for( j=1;swp[1][i]+j <= totct;++j )
     {++count;
      if (count < minpn1)   continue;
      l= abs(occpos[swp[1][i]+j]) - abs(occpos[swp[1][i]]) + 1;
      t= tFct(count,l,cprop[3]);
      if (l<=20)   {if (t>=Sfact)   {tmax[i]= t; lmax[i]= l;} }
      else
        {if ( (lmax[i]<=20 && t>=Sfact) || t>tmax[i] )
           {tmax[i]= t; lmax[i]= l;}
        }
      if (l > 74 && swp[1][i]+j+1 <= totct &&
	  abs(occpos[swp[1][i]+j+1]) - abs(occpos[swp[1][i]+j]) > 3)   break;
     }
   if (lmax[i]<=20)
     {count= 1; 
      for( j=1; j<20 && abs(occpos[swp[1][i]])+j < numaa; ++j )
        {if ( CHPN[protein[abs(occpos[swp[1][i]])+j]] == '+' )   
           {++count; continue;}
         if ( CHPN[protein[abs(occpos[swp[1][i]])+j]] == '-' )
           {++count; continue;}
        }
      if (count>=minpn1)   tmax[i]= tFct(count,20,cprop[0]);
      else   tmax[i]= 0.0;
      lsh[i]= 0;
      for( j=1; j<=20-count && abs(occpos[swp[1][i]])-j >= 0; ++j )
        {if ( CHPN[protein[abs(occpos[swp[1][i]])+20-j]] == '+' )   
              --count;
         if ( CHPN[protein[abs(occpos[swp[1][i]])+20-j]] == '-' )   
              --count;
         if ( CHPN[protein[abs(occpos[swp[1][i]])-j]] == '+' )
              ++count;
         if ( CHPN[protein[abs(occpos[swp[1][i]])-j]] == '-' )
              ++count;
         t= tFct(count,20,cprop[0]);
	 if (count>=minpn1 && t > tmax[i])   {tmax[i]= t; lsh[i]= j;}
        }
      if (tmax[i]>=Sfact)   lmax[i]= 20;
     }
  }

if (swc[1]==1)   /* ... there is only one pn-cluster ... */
  {if (lmax[0] >= 20)
     {prtpos[1][0]= abs(occpos[swp[1][0]]);
      if (numaa-prtpos[1][0] < 20)   prtlgt[1][0]= numaa - prtpos[1][0];
      else   prtlgt[1][0]= lmax[0];
      prttvl[1][0]= tmax[0];
      prc[1]= 1;
     }
  }
else   /* ... there are several pn-clusters ... */
  {prti= 0;
   prc[1]= 0;
   for( i=1;i<swc[1];++i )
     {if (abs(occpos[swp[1][i]]) > abs(occpos[swp[1][prti]]) + lmax[prti] + 8)
      /* ... clusters [prti] and [i] do not overlap; 
         target cluster [prti] for printing */
        {if (lmax[prti] >= 20)
  	   {prtpos[1][prc[1]]= abs(occpos[swp[1][prti]]);
	    if (numaa-prtpos[1][prc[1]]+1 < 20)
              prtlgt[1][prc[1]]= numaa - prtpos[1][prc[1]] + 1;
	    else   prtlgt[1][prc[1]]= lmax[prti];
	    prttvl[1][prc[1]]= tmax[prti];
   	    ++prc[1];
	   }
	  prti= i;
	}
      else
        {if ( abs(occpos[swp[1][i]]) + lmax[i] == 
		abs(occpos[swp[1][prti]]) + lmax[prti] )
	   {if (tmax[i] >= tmax[prti]+.50)		prti= i;}
           /* ... clusters [prti] and [i] have the same end point;
               target the optimal one of the two for printing */
	 else
	   {count= 0;
            for( j=swp[1][prti]; 
		  abs(occpos[j])<=abs(occpos[swp[1][i]])+lmax[i]-1; ++j)
	      {++count;
	       if (occpos[j] == occpos[totct])   break;
	      }
	    l=  abs(occpos[swp[1][i]]) + lmax[i] - abs(occpos[swp[1][prti]]);
	    t=  tFct(count,l,cprop[3]);
	    if (t > tmax[prti])   {lmax[prti]= l;  tmax[prti]= t;}
	    if (tmax[i] > tmax[prti])   prti= i;
             /* ... clusters [prti] and [i] overlap but do not have the same
                end point; target the optimal cluster of either one of the two
                and their fusion for printing */
	   }
	}
     }
   if (lmax[prti] >= 20)
     {prtpos[1][prc[1]]= abs(occpos[swp[1][prti]]);
      if (numaa-prtpos[1][prc[1]] < 20)
              prtlgt[1][prc[1]]= numaa - prtpos[1][prc[1]];
      else   prtlgt[1][prc[1]]= lmax[prti];
      prttvl[1][prc[1]]= tmax[prti];
      ++prc[1];
     }
  }


negative:
if (swc[0]==0 || cprop[1]<0.05)   goto printing;
   /* - there are no n-clusters or the frequency of - is below threshold */
for( i=0;i<swc[0];++i )
  {count= 1; tmax[i]= 0; lmax[i]= 0;
   for( j=1;swp[0][i]+j <= totct;++j )
     {if (occpos[swp[0][i]+j] < 0)	++count;
      else				--count;
      if (count < minn1)		continue;
      l= abs(occpos[swp[0][i]+j]) - abs(occpos[swp[0][i]]) + 1;
      t= tFct(count,l,cprop[1]);
      if (l<=20)   {if (t>=Sfact)   {tmax[i]= t; lmax[i]= l;} }
      else
        {if ( (lmax[i]<=20 && t>=Sfact) || t>tmax[i] )
           {tmax[i]= t; lmax[i]= l;}
        }
      if (l > 74 && swp[0][i]+j+1 <= totct &&
	  abs(occpos[swp[0][i]+j+1]) - abs(occpos[swp[0][i]+j]) > 3)   break;
     }
   if (lmax[i]<=20)
     {count= 1; 
      for( j=1; j<20 && abs(occpos[swp[0][i]])+j < numaa; ++j )
        {if ( CHPN[protein[abs(occpos[swp[0][i]])+j]] == '-' )   
           {++count;   continue;}
         if ( CHPN[protein[abs(occpos[swp[0][i]])+j]] == '+' )
           {--count;   continue;}
        }
      if (count>=minn1)   tmax[i]= tFct(count,j,cprop[1]);
      else   tmax[i]= 0.0;
      lsh[i]= 0;
      for( j=1; j<20-count && abs(occpos[swp[0][i]])-j >= 0; ++j )
        {if ( CHPN[protein[abs(occpos[swp[0][i]])+20-j]] == '-' )   
              --count;
         if ( CHPN[protein[abs(occpos[swp[0][i]])+20-j]] == '+' )   
              ++count;
         if ( CHPN[protein[abs(occpos[swp[0][i]])-j]] == '-' )
              ++count;
         if ( CHPN[protein[abs(occpos[swp[0][i]])-j]] == '+' )
              --count;
         t= tFct(count,20,cprop[1]);
	 if (count>=minn1 && t > tmax[i])   {tmax[i]= t; lsh[i]= j;}
        }
      if (tmax[i]>=Sfact)   lmax[i]= 20;
     }
  }

if (swc[0]==1)   /* ... there is only one n-cluster ... */
  {if (lmax[0] > 20)
     {prtpos[0][0]= abs(occpos[swp[0][0]]);
      prtlgt[0][0]= lmax[0]; prttvl[0][0]= tmax[0];
      prc[0]= 1;
     }
   if (lmax[0] == 20)
     {prtpos[0][0]= abs(occpos[swp[0][0]]) - lsh[0];
      if (numaa-prtpos[0][0] < 20)   prtlgt[0][0]= numaa - prtpos[0][0];
      else prtlgt[0][0]= 20;
      prttvl[0][0]= tmax[0];
      prc[0]= 1;
     }
  }
else   /* ... there are several n-clusters ... */
   {prti= 0;
    prc[0]= 0;
    for( i=1;i<swc[0];++i )
      {if (abs(occpos[swp[0][i]]) > abs(occpos[swp[0][prti]]) + lmax[prti] + 8)
       /* ... clusters [prti] and [i] do not overlap; 
          target cluster [prti] for printing */
         {if (lmax[prti] > 20)
   	   {prtpos[0][prc[0]]= abs(occpos[swp[0][prti]]);
	    prtlgt[0][prc[0]]= lmax[prti];
	    prttvl[0][prc[0]]= tmax[prti];
   	    ++prc[0];
	   }
          if (lmax[prti] == 20)
   	   {prtpos[0][prc[0]]= abs(occpos[swp[0][prti]]) - lsh[prti];
            if (numaa-prtpos[0][prc[0]] < 20)
              prtlgt[0][prc[0]]= numaa - prtpos[0][prc[0]];
            else   prtlgt[0][prc[0]]= 20;
	    prttvl[0][prc[0]]= tmax[prti];
   	    ++prc[0];
	   }
	  prti= i;
	 }
       else
         {if (abs(occpos[swp[0][i]]) + lmax[i] == 
	      abs(occpos[swp[0][prti]]) + lmax[prti] )
	    {if (tmax[i] >= tmax[prti]+.50)   prti= i;}
            /* ... clusters [prti] and [i] have the same end point;
               target the optimal one of the two for printing */
	  else
	    {count= 0;
             for( j=swp[0][prti]; 
		  abs(occpos[j])<=abs(occpos[swp[0][i]])+lmax[i]-1; ++j)
	     {if (occpos[j] < 0)	++count;
	      else			--count;
	      if (occpos[j] == occpos[totct])   break;
	     }
	     l=  abs(occpos[swp[0][i]]) + lmax[i] - abs(occpos[swp[0][prti]]);
	     t=  tFct(count,l,cprop[1]);
	     if (t > tmax[prti] )   {lmax[prti]= l;  tmax[prti]= t;}
	     if (tmax[i] > tmax[prti])   prti= i;
             /* ... clusters [prti] and [i] overlap but do not have the same
                end point; target the optimal cluster of either one of the two
                and their fusion for printing */
	    }
	  }
      }
    if (lmax[prti] > 20)
     {prtpos[0][prc[0]]= abs(occpos[swp[0][prti]]);
      prtlgt[0][prc[0]]= lmax[prti];
      prttvl[0][prc[0]]= tmax[prti];
      ++prc[0];
     }
    if (lmax[prti] == 20)
     {prtpos[0][prc[0]]= abs(occpos[swp[0][prti]]) - lsh[prti];
      if (numaa-prtpos[0][prc[0]] < 20)
              prtlgt[0][prc[0]]= numaa - prtpos[0][prc[0]];
      else   prtlgt[0][prc[0]]= 20;
      prttvl[0][prc[0]]= tmax[prti];
      ++prc[0];
     }
   }


printing:

if (pstyle==1)
  {if (prc[2]==0 && prc[1]==0 && prc[0]==0)
     {fprintf(outfp,"\nThere are no significant charge clusters."); return;}
  }

if (pstyle%2==0)   fprintf(outfp,"\n");
fprintf(outfp,"\nPositive charge clusters");
if (cprop[0]<0.05)
  fprintf(outfp,":  not evaluated (frequency of + < 5%%, too low)", cprop[0] );
else
  fprintf(outfp," (cmin = %2d/%2d or %2d/%2d or %2d/%2d):",
	minp1, WNDLGTH1, minp2, WNDLGTH2, minp3, WNDLGTH3);
count= 0;
for( i=0;i<prc[2];++i )
  {oflag= 0;
   for( j=0;j<prc[1];++j )   /* for all pn-clusters */
     {if (prmtypes==0  &&  prtpos[1][j] >= prtpos[2][i] - 15
         && prtpos[1][j]+prtlgt[1][j] <= prtpos[2][i]+prtlgt[2][i] + 15 )
        {prtpn[j]= 0;   continue;}
     /* ... pn-clusters that begin within 15 residues to the left and end
	within 15 residues to the right of the p-cluster to be printed
        are not to be printed (unless the printing option was set to
	prmtypes==1).
     */
      if (prmtypes==0  &&  prtpos[2][i] >= prtpos[1][j] - 15
         &&  prtpos[2][i]+prtlgt[2][j] <= prtpos[1][j]+prtlgt[1][j] + 15
	 &&  prttvl[2][i]>=Sfact-0.5  &&  prttvl[1][j]>=Sfact-0.5 )
	{oflag= 1;   prtpn[j]= 2;}
     /* ... p-clusters that begin within 15 residues to the left and end
	within 15 residues to the right of a printable pn-cluster are
        labelled as `embedded' (unless the printing option was set to
	prmtypes==1).
     */
     }
   if (prttvl[2][i]>=Sfact-0.5)
     {if (tabflag && prttvl[2][i]>=Sfact)
	{if (oflag)   fprintf(tabfp,"EP ");
	 else   fprintf(tabfp,"DP ");
	}
      pr_chcluster(numaa,++count,prtpos[2][i],prtlgt[2][i],prttvl[2][i],oflag);
     }
  }
if (count==0 && cprop[0]>=0.05)   fprintf(outfp,"  none\n");
else   fprintf(outfp,"\n");

if (pstyle%2==0)   fprintf(outfp,"\n");
fprintf(outfp,"\nNegative charge clusters");
if (cprop[1]<0.05)
  fprintf(outfp,":  not evaluated (frequency of - < 5%%, too low)", cprop[1] );
else
  fprintf(outfp," (cmin = %2d/%2d or %2d/%2d or %2d/%2d):",
	minn1, WNDLGTH1, minn2, WNDLGTH2, minn3, WNDLGTH3);
count= 0;
for( i=0;i<prc[0];++i )
  {oflag= 0;
   for( j=0;j<prc[1];++j )   /* for all pn-clusters */
     {if (prmtypes==0  &&  prtpos[1][j] >= prtpos[0][i] - 15
         && prtpos[1][j]+prtlgt[1][j] <= prtpos[0][i]+prtlgt[0][i] + 15 )
        {prtpn[j]= 0;   continue;}
     /* ... pn-clusters that begin within 15 residues to the left and end
	within 15 residues to the right of the n-cluster to be printed
        are not to be printed (unless the printing option was set to
	prmtypes==1.
     */
      if (prmtypes==0  &&  prtpos[0][i] >= prtpos[1][j] - 15
         &&  prtpos[0][i]+prtlgt[0][j] <= prtpos[1][j]+prtlgt[1][j] + 15
	 &&  prttvl[0][i]>=Sfact-0.5  &&  prttvl[1][j]>=Sfact-0.5 )
	{oflag= 1;   prtpn[j]= 2;}
     /* ... n-clusters that begin within 15 residues to the left and end
	within 15 residues to the right of a printable pn-cluster are
        labelled as `embedded' (unless the printing option was set to
	prmtypes==1.
     */
     }
   if (prttvl[0][i]>=Sfact-0.5)
     {if (tabflag && prttvl[0][i]>=Sfact)
	{if (oflag)   fprintf(tabfp,"EN ");
	 else   fprintf(tabfp,"DN ");
	}
      pr_chcluster(numaa,++count,prtpos[0][i],prtlgt[0][i],prttvl[0][i],oflag);
     }
  }
if (count==0 && cprop[1]>=0.05)   fprintf(outfp,"  none\n");
else   fprintf(outfp,"\n");

if (pstyle%2==0)   fprintf(outfp,"\n");
count= 0;
fprintf(outfp,"\nMixed charge clusters");
if (cprop[3]<0.05)
  fprintf(outfp,":  not evaluated (frequency of +- < 5%%, too low)", cprop[3] );
else
  fprintf(outfp," (cmin = %2d/%2d or %2d/%2d or %2d/%2d):",
	minpn1, WNDLGTH1, minpn2, WNDLGTH2, minpn3, WNDLGTH3);
for( i=0;i<prc[1];++i )
  if (prtpn[i]>0 && prttvl[1][i]>=Sfact-0.5)
   {if (tabflag && prttvl[1][i]>=Sfact)
      {if (prtpn[i]==2)   fprintf(tabfp,"EM ");
       else   fprintf(tabfp,"DM ");
      }
    pr_chcluster(numaa,++count,prtpos[1][i],prtlgt[1][i],prttvl[1][i],
		 prtpn[i]-1);
   }
if (count==0 && cprop[3]>=0.05)   fprintf(outfp,"  none\n");
else   fprintf(outfp,"\n");

}



pr_chcluster(numaa,num,wstart,wlgth,tval,oflag)
int numaa, num, wstart, wlgth, oflag;
double tval;
{
int i, j, q;
int pos= 0;
int neg= 0;
int cf[20];

for( i=0;i<=19;++i )   cf[i]= 0;


if (oflag) /* indicate enveloping/embedded clusters: */
  fprintf(outfp,"\n\n %1d)*From %4d to %4d:   ", num, wstart+1, wstart+wlgth);
else /* distinct clusters: */
  fprintf(outfp,"\n\n %1d) From %4d to %4d:   ", num, wstart+1, wstart+wlgth);

if (wlgth <= 55)
  {for( i=wstart; i < wstart+wlgth; ++i )
	fprintf(outfp,"%c", AAUC[protein[i]] );
  }
else	fprintf(outfp,"see sequence above" );

fprintf(outfp,"\n                         " );
for( i=wstart;i < wstart+wlgth;++i )
 {if (wlgth <= 55)   fprintf(outfp,"%c", CHPN[protein[i]] );
  else	if (i==wstart)   fprintf(outfp,"see sequence above" );
  if ( CHPN[protein[i]] == '+' )  ++pos;
  if ( CHPN[protein[i]] == '-' )  ++neg;
 }

q= (int)(4.*(float)wstart/(float)numaa)%4 +1;
fprintf(outfp,"\n    quartile: %1d; size: %2d, +count: %2d, -count: %2d,",
	         q, wlgth, pos, neg );
fprintf(outfp," 0count: %2d; t-value: %5.2f", wlgth-pos-neg,tval );
if (tval>=Sfact)   fprintf(outfp," *\n");
else               fprintf(outfp,"\n");

if (tabflag && tval>=Sfact)
  {fprintf(tabfp,"%4d-%4d (%1d.q.): %2d,%2d/%3d (t-value: %4.1f *)\n",
	wstart+1, wstart+wlgth, q, pos, neg, wlgth, tval);
  }

if (pstyle%2==0)
  {q= 0;
   for( i=wstart; i < wstart+wlgth; ++i )
     for( j=0;j<20;++j )
        if ( AAUC[protein[i]] == AAUC[j] )   {++cf[j]; break;}
   for( i=0; i<=19; ++i )  
     {if ( 100.*(float)cf[i]/(float)wlgth >= 10.0 )
        {if (q==0)   fprintf(outfp,"  ");
	 if ((++q)%5==0)   fprintf(outfp,"\n  ");
         fprintf(outfp, "  %c: %2d (%4.1f%%);", AAUC[i], cf[i],
		100.*(float)cf[i]/(float)wlgth ); 
	}
     }
   if ( 100.*(float)(cf[0]+cf[4]+cf[9]+cf[13]+cf[17])/(float)wlgth >= 25.0 )
     {if (q%4==0)   {fprintf(outfp,"\n  "); ++q;}
      if (q==3)   ++q;
      fprintf(outfp,"  LVIFM: %2d (%4.1f%%);", cf[0]+cf[4]+cf[9]+cf[13]+cf[17],
		100.*(float)(cf[0]+cf[4]+cf[9]+cf[13]+cf[17])/(float)wlgth );
     }
   if ( 100.*(float)(cf[3]+cf[7])/(float)wlgth >= 15.0 )
     {if (q%4==0)   fprintf(outfp,"\n  ");
      fprintf(outfp,"  ST: %2d (%4.1f%%);", cf[3]+cf[7],
		100.*(float)(cf[3]+cf[7])/(float)wlgth );
     }
  }

}
