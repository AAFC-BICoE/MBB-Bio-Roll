/* FTOA.C;                                   Last update: February 17, 1993. */
/*   - a function returning a character string displaying the floating point */
/*   argument val in format %n.mf.                                           */
/* Dependencies:   called by hsseg.c, pscore.c                               */
/* Bugs:                                                                     */

/*   Volker Brendel, Department of Mathematics, Stanford University,  */
/*   Stanford CA 94305; (415) 723-9256, volker@gnomic.stanford.edu    */

#include <stdio.h>
#include <math.h>
extern FILE *outfp;

ftoa(val,n,m,a)
float val;
int n, m;
char *a;
{
int i, j, b[15], c[15];
char sign= ' ';
double x;

if (n>15 || m>12)   return(0);
n= n-m-2;

if (val<0)   {val= -val; sign= '-';}
while (val>pow(10.,(double)n))   ++n;
if (n>15)   return(0);

for (i=n-1;i>0;--i)
  {x= pow(10.,(double)i);
   b[n-1-i]= val/x;   val-= (float)b[n-1-i]*x;
  }
   b[n-1-i]= val;   val-= (float)b[n-1-i];

val= val*pow(10.,(double)m);   val= (float)(floor(2*val) -  (int)val);
for (i=m-1;i>0;--i)
  {x= pow(10.,(double)i);
   c[m-1-i]= val/x;   val-= (float)c[m-1-i]*x;
   if (c[m-1-i]==10)
     {c[m-1-i]= 0;
      for (j=0; n-1-j>=0; ++j)
        {if (++b[n-1-j]<10) break; else b[n-1-j]= 0;}
      if (b[0]==0) {++n; b[0]= 1;   for (j=1; j<n;  ++j) b[j]=0;}
     }
  }
   c[m-1-i]= val;

a[0]= sign;
for (i=0;i<n-1;++i)
  {if (b[i]>0)   break;
   else   {a[1+i]= sign;   a[i]= ' ';}
  }
for ( ;i<n;++i)   a[1+i]= b[i] + '0';
a[1+i]= '.';
for (i=0;i<m;++i)   a[n+2+i]= c[i] + '0';

return(n+m+2);
}
