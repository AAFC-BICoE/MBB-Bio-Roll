/* SPACINGS.C;                                  Last update: April 11, 1996. */
/*   - a subroutine to find significant spacings between specified residues  */
/*   (residue types) in protein sequences.                                   */
/* Dependencies:   called by saps.c.                                         */
/* Bugs:                                                                     */

/*   Volker Brendel, Department of Mathematics, Stanford University,  */
/*   Stanford CA 94305; (415) 723-9256, volker@gnomic.stanford.edu    */

#include <stdio.h>
#include <math.h>
#include "def.h"
extern char AAUC[25];
extern char CHPN[25];
extern char CHCZ[25];
extern FILE *outfp;
extern int protein[PROTLGTH];
extern int af[23];
extern int pf[9];

#define F_MIN 100
#define NUMAA_MIN1 100
#define NUMAA_MIN2 500

struct space {
	int posn;
	int spcg;
	char symb[20];
	struct space *next;
	struct space *prev;
} *sheadp;

struct outspace {
	int posn;
	int spcg;
	char symb;
	int rank;
	int cnt;
	float pval;
	int rkflag;
	struct outspace *next;
} *outsheadp;

int NLET;


spacings(numaa)
int numaa;
{
int i,j,l,ai;
int jbeg, lastj;
int r, rscan;
struct space *nodep;
double p_fct(), rmn(), rmx();
int f[20];
char ABC[25], SYMB[20];
outsheadp= NULL;

for (ai=0;ai<3;++ai)
  {if (ai==0)   /* amino acid alphabet */
     {strcpy(ABC,AAUC);
      NLET=20;
      for (i=0;i<NLET;++i)   {f[i]= af[i]; SYMB[i]= ABC[i];}
      p_fct(numaa,0,0,0);
     }
   if (ai==1)   /* +-0 charge alphabet */
     {strcpy(ABC,CHPN);
      NLET=2;
      f[0]= pf[0]; f[1]= pf[1];
      SYMB[0]= '+'; SYMB[1]= '-';
     }
   if (ai==2)   /* *0 charge alphabet */
     {strcpy(ABC,CHCZ);
      NLET=1;
      f[0]= pf[2];
      SYMB[0]= '*';
     }

   for (i=0;i<NLET;++i) /* i-loop through alphabet */
   for (rscan=1;rscan<=1;rscan+=1)   /* RSCAN > 1 NOT USED CURRENTLY */
     {if ( (rscan==1 && (f[i]<3 || numaa<NUMAA_MIN1)) ||
	   (rscan>1  && (f[i]<F_MIN || numaa< NUMAA_MIN2)) )   continue;
      sheadp= NULL;
      r= 0;
      lastj= -1;
      for (j=0;j<numaa;++j) /* j-loop through sequence */
	{if (ABC[protein[j]]!=SYMB[i])   continue;
	 if (++r==1)   jbeg= j;
	 if (r<rscan)   continue;
	 nodep= (struct space *) malloc(sizeof(struct space));
	 nodep->posn= lastj;
	 nodep->spcg= j-lastj;
	 for (l=0;l<=NLET;++l)   nodep->symb[l]= SYMB[l];
	 nodep->next= NULL;    nodep->prev= NULL;
	 Ins_node(&sheadp,(struct space *) NULL,nodep);
					/* recursive insertion procedure */
	 lastj= jbeg;
	 r= 0;
	 j= jbeg;
	}
      nodep= (struct space *) malloc(sizeof(struct space));
      nodep->posn= lastj;
      nodep->spcg= numaa-lastj;
      for (l=0;l<=NLET;++l)   nodep->symb[l]= SYMB[l];
      nodep->next= NULL;
      nodep->prev= NULL;
      Ins_node(&sheadp,(struct space *) NULL,nodep);
					/* recursive insertion procedure */

      Pr_nodes(sheadp,numaa,i,f[i],rscan,0);
     } /* end-of-for-i-for-rscan */
  } /* end-of-for-ai */

outfct(numaa,outsheadp);
}



Ins_node(sheadpp,currp,nodep)
struct space **sheadpp;
struct space *currp, *nodep;
{

if (*sheadpp == NULL)   {*sheadpp = nodep; nodep->prev= currp;}
else
  {if (Comp_nodes(*sheadpp,nodep) == 0)   /* this is the comparison line */
     Ins_node(&((*sheadpp)->next),*sheadpp,nodep);
   else   Ins_nh(sheadpp,nodep);
  }

}



Ins_nh(sheadpp,nodep)   /* inserts nodep node before *sheadpp node */
struct space **sheadpp;
struct space *nodep;
{
struct space *temptr;

temptr = *sheadpp;
*sheadpp = nodep;
nodep->next = temptr;
nodep->prev = temptr->prev;
temptr->prev = nodep;

}



int Comp_nodes(sheadptr,nodep)    /* - comparison function; returns 1 if */
struct space *sheadptr;           /* nodep is to be inserted immediately */
struct space *nodep;             /* in front of headnode; else returns 0 */
{
int result= 1;

if ( sheadptr->spcg > nodep->spcg ||
     (sheadptr->spcg == nodep->spcg && sheadptr->posn > nodep->posn) )
  result= 0;
return(result);

}



Pr_nodes(nodep,numaa,let,n,rscan,flag)
struct space *nodep;
int numaa;
int let, n, rscan, flag;
{
int rank= 1;
double p_fct(), rmn(), rmx(), pval;
struct space *fnodep, *tempnodep;
struct outspace *outnodep;
int cnt;
int j, matchn;

cnt= n+2-rscan;   /* number of r-scans for n markers */

if (flag==0)   /* - establishes whether significant distances have occurred;
		  if so, then print (i.e., call Pr_nodes with flag==1) */
  {fnodep= nodep;
   while (nodep != NULL)
     {if (
	  (rscan==1 && rank<2 && 
	   ((pval=p_fct(numaa,n,rank,nodep->spcg))<=.01 || pval>=.99)
	  )
	  || 
	  (rscan==1 && rank>cnt-1 && 
	   ( ((pval=rmn(numaa,n,cnt-rank+1,nodep->spcg,rscan))<=.01 &&
		nodep->spcg >= 2) || pval>=.99
	   )
	  )
	 )
	{Pr_nodes(fnodep,numaa,let,n,rscan,1);
         return;
        }
      nodep= nodep->next;
      ++rank;
     }
  }

if (flag==1)
  {while (nodep != NULL)
     {if (rank<3)
	{if (rscan==1)
	   {pval= p_fct(numaa,n,rank,nodep->spcg);
	    if (rank==1 && (pval<=.01 || pval>=.99) )
	      {outnodep= (struct outspace *) malloc(sizeof(struct outspace));
	       outnodep->posn= nodep->posn;
	       outnodep->spcg= nodep->spcg;
	       outnodep->symb= nodep->symb[let];
	       outnodep->rank= rank;
	       outnodep->cnt= cnt;
	       outnodep->pval= pval;
	       if ( (pval= p_fct(numaa,n,2,(nodep->next)->spcg)) <= .05 ||
		     pval >= .95 )   outnodep->rkflag= 1;
	       else   outnodep->rkflag= 0;
	       outnodep->next= NULL;
	       Ins_outnode(&outsheadp,outnodep);
	      }
	    if (rank==2 && 
		(p_fct(numaa,n,1,(nodep->prev)->spcg) <= .01 ||
		 p_fct(numaa,n,1,(nodep->prev)->spcg) >= .99   ) &&
		(pval<=.05 || pval>=.95) )
	      {outnodep= (struct outspace *) malloc(sizeof(struct outspace));
	       outnodep->posn= nodep->posn;
	       outnodep->spcg= nodep->spcg;
	       outnodep->symb= nodep->symb[let];
	       outnodep->rank= rank;
	       outnodep->cnt= cnt;
	       outnodep->pval= pval;
	       outnodep->rkflag= 1;
	       outnodep->next= NULL;
	       Ins_outnode(&outsheadp,outnodep);
	      }
	   }
        }
/* .. ABOVE PRINTS THE PROBABILITIES THAT THE FIRST AND SECOND MAXIMUM
   IN A RANDOM SEQUENCE EXCEED THE OBSERVED ONES; THUS P=0.01 MEANS THE
   OBSERVED MAXIMUM IS SIGNIFICANTLY LARGE AND P=0.99 MEANS THAT THE
   OBSERVED MAXIMUM IS SIGNIFICANTLY SMALL.
*/
      if (rank>cnt-1 &&
	   ( ((pval=rmn(numaa,n,cnt-rank+1,nodep->spcg,rscan))<=.01 &&
	      nodep->spcg >= 2) || pval>=.99
	   )
	 )
	{if (rscan==1)
	   {outnodep= (struct outspace *) malloc(sizeof(struct outspace));
	    outnodep->posn= nodep->posn;
	    outnodep->spcg= nodep->spcg;
	    outnodep->symb= nodep->symb[let];
	    outnodep->rank= rank;
	    outnodep->cnt= cnt;
	    outnodep->pval= pval;
	    outnodep->rkflag= 0;
	    outnodep->next= NULL;
	    Ins_outnode(&outsheadp,outnodep);
	   }
/* .. ABOVE PRINTS THE PROBABILITIES THAT THE FIRST AND SECOND MINIMUM
   IN A RANDOM SEQUENCE EXCEED THE OBSERVED ONES; THUS P=0.01 MEANS THE
   OBSERVED MINIMUM IS SIGNIFICANTLY LARGE AND P=0.99 MEANS THAT THE
   OBSERVED MINIMUM IS SIGNIFICANTLY SMALL.
*/
	 /* Print spacings tying the printed minimum: */
	 matchn=0; tempnodep= nodep;
	 while (tempnodep->prev != NULL  &&
	        (tempnodep->prev)->spcg == nodep->spcg)
	   {tempnodep= tempnodep->prev;   ++matchn;}
	 for (j=0;j<matchn;++j)
	   {outnodep= (struct outspace *) malloc(sizeof(struct outspace));
	    outnodep->posn= tempnodep->posn;
	    outnodep->spcg= tempnodep->spcg;
	    outnodep->symb= nodep->symb[let];
	    outnodep->rank= rank-j-1;
	    outnodep->cnt= cnt;
	    outnodep->pval= pval;
	    outnodep->rkflag= 0;
	    outnodep->next= NULL;
	    Ins_outnode(&outsheadp,outnodep);
	    tempnodep= tempnodep->next;
	   }
	}
      nodep= nodep->next;
      ++rank;
     }
  }

}



outfct(numaa,nodep)
int numaa;
struct outspace *nodep;
{
int q;

if (nodep==NULL)
  {if (numaa<NUMAA_MIN1)
    fprintf(outfp,"\nNot evaluated (sequence length < %d aa, too short).\n\n",
	NUMAA_MIN1);
   else
    fprintf(outfp,"\nThere are no unusual spacings.\n\n");
   return;
  }

fprintf(outfp,
  "\nLocation (Quartile) Spacing     Rank       P-value   Interpretation\n\n");
while (nodep != NULL)
  {q= (int) (4.0*((float)(nodep->posn+1) +
		  (float)nodep->spcg/2.0)/(float)numaa)%4 +1;
   fprintf(outfp,"%4d-%4d  (%1d.)     %c(%4d)%c   %3d of %3d   %6.4f   ",
	nodep->posn+1, nodep->posn+1 + nodep->spcg, q, nodep->symb,
	nodep->spcg, nodep->symb, nodep->rank, nodep->cnt, nodep->pval );
   if (nodep->rank == 1)
     {if (nodep->rkflag==0)
       {if (nodep->pval <= .05) fprintf(outfp,"large maximal spacing\n");
        if (nodep->pval >= .95) fprintf(outfp,"small maximal spacing\n");
       }
      else
       {if (nodep->pval <= .05) fprintf(outfp,"large %2d. maximal spacing\n", nodep->rank);
        if (nodep->pval >= .95) fprintf(outfp,"small %2d. maximal spacing\n", nodep->rank);
       }
     }
   else if (nodep->rank == 2)
     {if (nodep->pval <= .05)  fprintf(outfp,"large %2d. maximal spacing\n",
	nodep->rank);
      if (nodep->pval >= .95)  fprintf(outfp,"small %2d. maximal spacing\n",
	nodep->rank);
     }
   else if (nodep->rank > nodep->cnt -1)
     {if (nodep->pval <= .01)  fprintf(outfp,"large minimal spacing\n");
      if (nodep->pval >= .99)  fprintf(outfp,"small minimal spacing\n");
     }
   else   fprintf(outfp,"  matching minimum\n");
   nodep= nodep->next;
  }

fprintf(outfp,"\n\n");
}



Ins_outnode(sheadpp,nodep)
struct outspace **sheadpp;
struct outspace *nodep;
{

if (*sheadpp == NULL)   *sheadpp = nodep;
else
  {if (Comp_outnodes(*sheadpp,nodep) == 0)   /* this is the comparison line */
     Ins_outnode(&((*sheadpp)->next),nodep);
   else   Ins_outnh(sheadpp,nodep);
  }

}



Ins_outnh(sheadpp,nodep)   /* inserts nodep node before *sheadpp node */
struct outspace **sheadpp;
struct outspace *nodep;
{
struct outspace *temptr;

temptr = *sheadpp;
*sheadpp = nodep;
nodep->next = temptr;

}



int Comp_outnodes(sheadptr,nodep)    /* - comparison function; returns 1 if */
struct outspace *sheadptr;           /* nodep is to be inserted immediately */
struct outspace *nodep;             /* in front of headnode; else returns 0 */
{
int result= 1;

if ( sheadptr->posn < nodep->posn ||
     (sheadptr->posn == nodep->posn && sheadptr->spcg < nodep->spcg) )
   result= 0;
return(result);

}



double p_fct(N,n,k,l)   /* - returns the probability that in a sequence  */
int N;			/* of length N containing n markers there are at */
int n;			/* least k distances between the markers of      */
int k, l;		/* lengths at least l                            */
			/* Reference: Thesis, Don Morris                 */
{
int i,j1,n1,i1;
static double lof[PROTLGTH];
double x,y,p;
int sign= 1;

if (n==0)
  {lof[0]= 0.0;    lof[1]= 0.0;
   for (i=2;i<=N;++i)   lof[i]= lof[i-1] + log((double)i);
   return;
  }

p= 0;
x= lof[N]-lof[n]-lof[N-n];

j1= N-k*l;
if (l!=0)
  {if (n+1 < (N-n)/l)   n1= n+1;
   else   n1= (N-n)/l;
  }
else   n1= n+1;

for (i1=k;i1<=n1;++i1)
  {y= -x+lof[i1-1]-lof[k-1]-lof[i1-k];
   y+= lof[n+1]-lof[i1]-lof[n-i1+1];
   y+= lof[j1]-lof[n]-lof[j1-n];
   if (y>=18)
     {fprintf(outfp,
	"\nProbability calculation unfeasable; returning -1.\n");
      return(-1);
     }
   if (sign)   p+= exp(y);
   else   p-= exp(y);
   j1-= l;
   if (sign==0)   sign= 1;
   else   sign= 0;
  }

return(p);

}



double rmx(N,n,k,l,r)
int N, n, k, l, r;
{
int i;
double x, nn=(double)n, mu, p= 0.0;

x= (float)l/(float)N *nn - log(nn) - (r-1)*log(log(nn));
mu= exp(-x)/fact(r-1);
if (mu<=0.00001)   return(0.0);
for(i=0;i<k;++i)   p+= pow(mu,(double)i)/fact(i);
p= 1.0 - exp(-mu*p);

return(p);
/*.. PROBABILITY THAT THE k-TH MAXIMUM EXCEEDS LENGTH l;
 REF.: S. KARLIN & C. MACKEN (1991), J. AMER. STAT. ASSOC. 86: 27-35,
       EQU. (6.8).
*/
}



double rmn(N,n,k,l,r)
int N, n, k, l, r;
{
int i;
double x, nn=(double)n, lambda, p= 0.0;

if (r>1)
  {x= (float)l/(float)N *pow(nn,1.0+1.0/(double)r);
   lambda= pow(x,(double)r)/fact(r);
   if (lambda<=0.00001)   return(1.0);
   for(i=0;i<k;++i)   p+= pow(lambda,(double)i)/fact(i);
   p= exp(-lambda*p);
  }
/*.. PROBABILITY THAT THE k-TH MINIMUM EXCEEDS LENGTH l;
 REF.: S. KARLIN & C. MACKEN (1991), J. AMER. STAT. ASSOC. 86: 27-35,
       EQU. (6.9).
*/
else
  {x= (float)l/(float)N;
   k-= 1;
   for(i=0;i<=k;++i)   p+= fact(k)/(fact(i)*fact(k-i)) * pow(-1.,(double)i)
	* pow( (1.-x*(nn+1+i-k)),nn );
   if (k==1)   p*= fact(n+1)/(fact(k)*fact(n+1-k));
  }

return(p);
/*.. PROBABILITY THAT THE k-TH MINIMUM EXCEEDS LENGTH l;
 REF.: S. KARLIN & H. TAYLOR, VOL.II CHAPT. 13 ?
*/
}



int fact(k)
int k;
{
register int i; int result=1;
for (i=1;i<=k;++i) result*=i;
return(result);
}
