/* DIST.C;                                   Last update: February 17, 1993. */
/*   - a subroutine to display distances between residue types in protein    */
/*   sequences.                                                              */
/* Dependencies:   called by pmotif.c saps.c.                                */
/* Bugs:                                                                     */

/*   Volker Brendel, Department of Mathematics, Stanford University,  */
/*   Stanford CA 94305; (415) 723-9256, volker@gnomic.stanford.edu    */

#include <stdio.h>
#include "def.h"
extern char AAUC[25];
extern FILE *outfp;
extern int protein[PROTLGTH], occpos[PROTLGTH];

dist(numaa,aa,nbd)
int numaa, aa, nbd;   /* aa ~ residue type; 
			 nbd=1 ~ display neighbor distance matrix */
{
int i, l;
int spc= 0;
int prevs= 0;
int nchar= 3;
int cn= 1;

fprintf(outfp,"\n\nH2N");
for( i=0; i<numaa; ++i )   /* start of i-loop through the sequence */
  {if ( protein[i]!=aa )   {++spc; continue;}
   if ( spc>2 || i<3 )   fprintf(outfp,"-%d", spc);
   if ( protein[i+1]==aa )   
     {if ( protein[i-1]!=aa && protein[i-2]!=aa && protein[i-3]!=aa )
        fprintf(outfp,"\n");
      fprintf(outfp,"%c%c   at %4d", AAUC[aa], AAUC[aa], i+1);   
      if ( prevs==0 )   {fprintf(outfp,"\n"); prevs= i+1;}
      else   {fprintf(outfp,"   (l=%4d)\n", i+3-prevs ); prevs= i+1;}
      if ( protein[i+2]!=aa && protein[i+3]!=aa && protein[i+4]!=aa )
        fprintf(outfp,"  ");
      spc= 0; nchar= 3;
      continue;
     }
   if ( protein[i+2]==aa )   
     {if ( protein[i-1]!=aa && protein[i-2]!=aa && protein[i-3]!=aa )
        fprintf(outfp,"\n");
      fprintf(outfp,"%c%c%c  at %4d", AAUC[aa], AAUC[protein[i+1]], 
					AAUC[aa], i+1);   
      if ( prevs==0 )   {fprintf(outfp,"\n"); prevs= i+1;}
      else   {fprintf(outfp,"   (l=%4d)\n", i+4-prevs ); prevs= i+1;}
      if ( protein[i+3]!=aa && protein[i+4]!=aa && protein[i+5]!=aa )
        fprintf(outfp,"   ");
      spc= 0; nchar= 3;
      continue;
     }
   if ( protein[i+3]==aa )   
     {if ( protein[i-1]!=aa && protein[i-2]!=aa && protein[i-3]!=aa )
        fprintf(outfp,"\n");
      fprintf(outfp,"%c%c%c%c at %4d", AAUC[aa], AAUC[protein[i+1]], 
		                       AAUC[protein[i+2]], AAUC[aa], i+1);   
      if ( prevs==0 )   {fprintf(outfp,"\n"); prevs= i+1;}
      else   {fprintf(outfp,"   (l=%4d)\n", i+5-prevs ); prevs= i+1;}
      if ( protein[i+4]!=aa && protein[i+5]!=aa && protein[i+6]!=aa )
        fprintf(outfp,"    ");
      spc= 0; nchar= 3;
      continue;
     }
   if ( spc>2 || i<3 )   fprintf(outfp,"-%c", AAUC[aa]);
   if (spc < 10)   nchar+= 4; else if (spc < 100)   nchar+= 5;
	else   nchar+= 6;
   if ( nchar>71 )   {fprintf(outfp,"\n     "); nchar= 3;}
   spc= 0;
  }
fprintf(outfp,"-%d-COOH\n", spc);

if (!nbd)   return;

fprintf(outfp,"\n%c distance matrix:", AAUC[aa]);
fprintf(outfp,"\n 1st column:  %c residue number/ position in sequence",
	AAUC[aa]);
fprintf(outfp,"\n column labelled i:  distance to the i-th previous %c\n",
	AAUC[aa]);
fprintf(outfp,
"               1     2     3     4     5     6     7     8     9    10\n");
fprintf(outfp,
"r.#/ pos.|____________________________________________________________\n");
fprintf(outfp,"         |");
 
for( i=0; i<numaa; ++i )
  {if ( protein[i]==aa )
     {occpos[cn]=i+1;
      fprintf(outfp,"\n%3d) %4d|  ", cn, i+1);
      for( l=cn-1; l>=0 && cn-l<11; --l )
        fprintf(outfp,"%4d  ", occpos[cn]-occpos[l]-1 );
      ++cn;
     }
  }
fprintf(outfp,"\n            %4d\n", numaa-occpos[cn-1] );
 
}
