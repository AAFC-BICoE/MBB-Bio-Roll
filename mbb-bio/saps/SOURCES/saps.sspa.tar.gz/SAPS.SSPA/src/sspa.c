/* SSPA.C;                                      Last update: March 19, 1997. */
/*   - Significant Segment Pair Alignment                                    */
/*   - a program to compare a query protein sequence against a list or       */
/*   library of protein sequence files; sspa identifies all significant      */
/*   high scoring matching segment pairs between the query sequence and      */
/*   entries in the search list/library.                                     */
/* Dependencies:   getlibp.c getips.c karlin.c                               */
/* Bugs:                                                                     */

/*   Volker Brendel, Department of Mathematics, Stanford University,  */
/*   Stanford CA 94305; (415) 723-9256, volker@gnomic.stanford.edu    */

#include <stdio.h>
#include <math.h>
#include "uascii.gbl"
#include "def.h"
#include "abc.h"

#define CHECKFLAG  0
#define MAXRANGE 101

int pstyle= 2, libop= 0, tabflag= 0, mflag= 0, fflag= 0, sflag= 0, qflag= 0;
int xflag= 0, ocdsflag= 0;
FILE *infp, *outfp, *tabfp, *matfp, *frqfp, *libfp;
static FILE *hspfp, *sp1fp, *sp2fp;
char inpline[LINELGTH];
int protein[PROTLGTH], cseq[2][PROTLGTH*3+3];
int psize[2], rcnt[2][24];
char SEQ[2][PROTLGTH], *S[2];
char qfname[60], sfname[81];
int fcount= 0, gfcount= 0, ghcount= 0;
int clgth[2];

int minsc, maxsc, tssize= 0, smat[23][23];
float sf[24];
double pr[MAXRANGE +1], lambda, K, AIL, lowp= 0.01;
int MIN_NDID= 3;
int tscore= -1, drpoff, MAJORDIAG;
float DFACT= 1.0;

struct hit {
  char pname1[60], pname2[60];
  int beg1, end1, beg2, end2;
  float pval;
  int score, length;
  int ndid, prct_id, ndps, prct_ps;
  int label;
  struct hit *nexth;
 };

extern int karlin();


main(argc,argv)
int argc;
char *argv[];
{
int i,j,k, numaa;
int pmt[23], tsmat[23][23];
char ch, ch2[2], aa[23];
int anum= 0;
FILE *listfp;
static char lstname[60], libname[60], matname[60], ffname[60];
int listop= 0;
float molwt= 18.0;
long tlc;
outfp= stdout;

time(&tlc);

#define USAGE "Usage:\
 %s [-tTv] [-m matname] [-fF aafreq] [-c cutoff] [-C tscore] [-d DFACT] [-a tssize]\n\
  [-x] [-i MIN_NDID] [-o] [-sS] -q qfname [-b/B libname] [-l lstname] [seqfname(s)]\n\n\
  -t: terse output;   -T: very terse output;   -v: verbose output.\n\
  -m matname:   use scoring matrix `matname' [default: PBLO62].\n\
  -f aafreq:   take search sequence frequencies from file `aafreq'.\n\
  -F aafreq:   take query and search sequence frequencies from file `aafreq'.\n\
  -c cutoff:   set significance level for printing [default: 0.01].\n\
  -C tscore:   set threshold score for printing [default: -c 0.01 - score].\n\
  -d DFACT:   set drop-off factor to DFACT [default: 1.0]\n\
  -a tssize:   make p-value adjustment for total search size = tssize (residues).\n\
  -x:   report only maximal scoring segments (excursions returning to 0).\n\
  -i MIN_NDID:   report only hits with at least MIN_NDID different identities.\n\
  -s:   automatically calculate alignment score.\n\
  -S:   interactively select matching segments for alignment score determination.\n\
  -o:   output matching and non-matching segments in files LIBsp1, LIBsp2, LIBhsp.\n\
  -q qfname:   name of query protein file.\n\
  -b libname:  read protein sequence data from library file libname.\n\
  -B libname:  read coding sequence data from library file libname.\n\
  -l lstname:  read protein sequence data from files specified in the list\n\
                 file LST_lstname.\n\
  seqfname(s):  read protein sequence data from individual file(s).\n"
 
if (argc<2)   {fprintf(stderr,USAGE,argv[0]); exit(0);}

for (i=1;i<argc;++i)
  {if ( *argv[i]=='-' )   switch ( *(argv[i]+1) )   {
        case 't':
                pstyle= 1; ++anum; break;
        case 'T':
                pstyle= 3; ++anum; break;
        case 'v':
                pstyle= 4; ++anum; break;
        case 'm':
        case 'M':
		mflag= 1; strcat(matname,argv[i+1]); anum+= 2; break;
        case 'f':
		fflag= 1; strcat(ffname,argv[i+1]); anum+= 2; break;
        case 'F':
		fflag= 2; strcat(ffname,argv[i+1]); anum+= 2; break;
                if ( (frqfp= fopen( ffname, "r" )) == NULL )
                   {fprintf(stderr,"File %s cannot be opened.\n", ffname);
                    perror(ffname); exit(-1);}
		for (j=0;j<20;++j)
		 {fscanf(frqfp,"%d", &k); fscanf(frqfp,"%f",&sf[j] );}
                anum+= 2;
                break;
        case 'c':
		lowp= atof(argv[i+1]);
		if (lowp > 1.0)
		 {fprintf(stderr,"\nSET CUTOFF <= 1.0.  EXITING.\n"); exit(0);}
		anum+= 2; break;
        case 'C':
		tscore= atoi(argv[i+1]); anum+= 2; break;
        case 'd':
		DFACT= atof(argv[i+1]); anum+= 2; break;
        case 'x':
		xflag= 1; ++anum; break;
        case 'a':
		tssize= atoi(argv[i+1]); anum+= 2; break;
        case 'i':
		MIN_NDID= atoi(argv[i+1]); anum+= 2; break;
        case 's':
                sflag= 1; ++anum; break;
        case 'S':
                sflag= 2; ++anum; break;
        case 'o':
		ocdsflag= 1; ++anum; break;
        case 'q':
                qflag= 1;
		strcat(qfname,argv[i+1]);
		if ( (infp = fopen( qfname, "r" )) == NULL )
		  {fprintf(stderr,"File %s cannot be opened.\n", qfname);
		   perror(qfname); exit(-1);}
		fprintf(stderr,"File %s has been opened for reading.\n", qfname);
                anum+= 2;
                break;
	case 'b':
                libop= 1;
                strcat(libname,argv[i+1]);
                if ( (libfp= fopen( libname, "r" )) == NULL )
                  {fprintf(stderr,"File %s cannot be opened.\n", libname);
                   perror(libname); exit(-1);}
                fprintf(stderr,
		  "\nLibrary file %s has been opened for reading.\n", libname);
                anum+= 2;
                break;
        case 'B':
                libop= 2;
                strcat(libname,argv[i+1]);
                if ( (libfp= fopen( libname, "r" )) == NULL )
                   {fprintf(stderr,"File %s cannot be opened.\n",libname);
                    perror(libname); exit(-1);}
                anum+= 2;
                break;
        case 'l':
                listop= 1;
                strcat(lstname,"LST_");
                strcat(lstname,argv[i+1]);
                if ( (listfp = fopen( lstname, "r" )) == NULL )
                   {fprintf(stderr,"File %s cannot be opened.\n", lstname);
                    perror(lstname); exit(-1);}
                fprintf(stderr,
		  "\nList %s has been opened for reading.\n", lstname);
                fgets( inpline, LINELGTH, listfp );
                fgets( inpline, LINELGTH, listfp );
                anum+= 2;
                break;
        default:
                break;
        }
  }
 
if (qflag==0)   {fprintf(stderr,USAGE,argv[0]); exit(0);}

fprintf(stderr,"\nNOW EXECUTING:  ");
for (i=0;i<argc;++i)   fprintf(stderr," %s", argv[i]);
fprintf(stderr,"\n\n");


/******************************************************************************/
/* READ IN SCORING MATRIX:                                                    */
/*                                                                            */
if (!mflag) {strcpy(matname,INCLDIR); strcat(matname,"PBLO62");}
if ( (matfp= fopen( matname, "r" )) == NULL )
  {fprintf(stderr,"File %s cannot be opened.\n", matname);
   perror(matname); exit(-1);}
fprintf(stderr,"Read scoring matrix file %s.\n", matname);

i= 0;
while ((ch=fgetc(matfp)) != '\n')
  if  (ch > 62 && ch < 91) aa[i++]= ch;
if (i!=23)
 {fprintf(outfp,"\nERROR: Matrix %s has less than 23 column labels.\n");
  exit(0);
 }
for (i=maxsc=minsc=0;i<23;++i)
 {fscanf(matfp,"%s",ch2);
  for (j=0;j<=i;++j)
   {fscanf(matfp,"%d",&k);
    if (k>maxsc) maxsc=k;   if (k<minsc) minsc=k;
    tsmat[i][j]= tsmat[j][i]= k;
   }
 }
for (i=0;i<23;++i) for (j=0;j<23;++j)
  {if (aa[j]!=AAUC[i]) continue; pmt[i]= j;}
for (i=0;i<23;++i) for (j=0;j<23;++j) smat[i][j]= tsmat[pmt[i]][pmt[j]];

if (maxsc-minsc+1 > MAXRANGE)
 {fprintf(stderr,
    "\nERROR: Matrix %s has a score range (%3d) exceeding the maximum (%3d).\n",
    matname, maxsc-minsc+1, MAXRANGE); exit(0);
 }
/*                                                                            */
/******************************************************************************/

/******************************************************************************/
/* READ IN FREQUENCY FILE:                                                    */
/*                                                                            */
if (fflag)
 {if ( (frqfp= fopen( ffname, "r" )) == NULL )
   {fprintf(stderr,"File %s cannot be opened.\n", ffname);
	perror(ffname); exit(-1);}
  for (j=0;j<20;++j)
   {fscanf(frqfp,"%d", &k); fscanf(frqfp,"%f",&sf[j]);}
 }
/*                                                                            */
/******************************************************************************/


/******************************************************************************/
/* OPEN OUTPUT FILES LIBhsp, LIBsp1, LIBsp2:                                  */
/*                                                                            */
if (ocdsflag)
 {if ( (hspfp= fopen("LIBhsp","a")) == NULL )
   {fprintf(stderr,"File LIBhsp cannot be opened.\n");
        perror("LIBhsp"); exit(-1);}
  else fprintf(stderr,"File LIBhsp has been opened for appending.\n");
  if ( (sp1fp= fopen("LIBsp1","a")) == NULL )
   {fprintf(stderr,"File LIBsp1 cannot be opened.\n");
        perror("LIBsp1"); exit(-1);}
  else fprintf(stderr,"File LIBsp1 has been opened for appending.\n");
  if ( (sp2fp= fopen("LIBsp2","a")) == NULL )
   {fprintf(stderr,"File LIBsp2 cannot be opened.\n");
        perror("LIBsp2"); exit(-1);}
  else fprintf(stderr,"File LIBsp2 has been opened for appending.\n");
 }
/*                                                                            */
/******************************************************************************/

if (pstyle!=3)
 {fprintf(outfp,"SSPA.   Version of March 19, 1997.\n");
  fprintf(outfp,"Date run: %s", ctime(&tlc) );
  fprintf(outfp,"\nMatrix: %s;   Significance level: %f.", matname, lowp);
  if (tssize) fprintf(outfp,
    "\n Adjustment made for total search size: %7d residues.", tssize);
  if (fflag==1) fprintf(outfp,
    "\n\nSearch sequence residue frequencies replaced according to file: %s.",
    ffname);
  if (fflag==2) fprintf(outfp,
    "\n\nQuery and search sequence residue frequencies replaced according to file: %s.",
    ffname);
 }
else
 fprintf(outfp,"Matrix: %s\n", matname);


/******************************************************************************/
/* SET UP QUERY SEQUENCE:                                                     */
/*                                                                            */
if (pstyle!=3)
  fprintf(outfp,"\n\nQuery sequence: %s\n", qfname);
else
  fprintf(outfp,"Sequence 1: %s\n", qfname);
numaa= getips(infp,outfp,tabfp,pstyle,tabflag,protein,&molwt,cseq[0],&clgth[0]);
fclose(infp);
psize[0]= numaa;
for (i=0;i<psize[0];++i)   SEQ[0][i]= protein[i];
SEQ[0][psize[0]]= '\0';   S[0]= SEQ[0];
for (i=0;i<24;++i)   rcnt[0][i]= 0;
for (i=0;i<psize[0];++i)   ++rcnt[0][protein[i]];
if (pstyle%2==0)
 {fprintf(outfp,"\nnumber of residues: %4d;   ", numaa);
  fprintf(outfp,"molecular weight: %5.1f kdal\n", molwt/1000);
  prt_seq(0,psize[0]);
 }
molwt= 18.0;
/*                                                                            */
/******************************************************************************/


/******************************************************************************/
/* DETERMINE PARAMETERS USING FILE-SUPPLIED RESIDUE FREQUENCIES (FOR ALL      */
/* SEARCH SEQUENCES):                                                         */
/*                                                                            */
if (fflag)
 {for (i=0;i<= MAXRANGE;++i) pr[i]= 0.0;
  if (fflag==1)
   {for (i=0;i<23;++i) for (j=0;j<23;++j) 
      pr[smat[i][j]-minsc]+= ((float)rcnt[0][i]/psize[0]) * sf[j];
   }
  else
   {for (i=0;i<23;++i) for (j=0;j<23;++j) 
      pr[smat[i][j]-minsc]+= sf[i] * sf[j];
   }
  if (!karlin(minsc,maxsc,pr,&lambda,&K,&AIL,0))
   {fprintf(outfp,"\n\nERROR: karlin.c() returned 0.\n"); exit(0);}
  if (pstyle%2==0)
    fprintf(outfp,"\nLambda= %6.3f   K= %6.3f   H= %6.3f.\n\n",lambda,K,AIL);
 }
/*                                                                            */
/******************************************************************************/


/******************************************************************************/
/* READ IN SEARCH SEQUENCE(S):                                                */
/*                                                                            */
if (libop==1)
  {fprintf(outfp,"\n\nLibrary file: %s \n\n", libname);
   fprintf(outfp,"________________________________________");
   fprintf(outfp,"________________________________________\n");
   while (numaa=getlibp(protein,libfp,&molwt))
     {if (++fcount%100 == 0)
       {fprintf(stderr,
		 " ... now processing protein %4d (%s)\n", fcount, sfname);
	fflush(outfp);
       }
      molwt= 18.0;
      doit(numaa);
     }
  }
if (libop==2)
  {fprintf(outfp,"\nLibrary file: %s\n",libname);
   while (numaa=getlcs(libfp,outfp,sfname,pstyle,cseq[1],&(clgth[1]),protein,&molwt))
     {if (numaa==-1) continue;
      if (++fcount%100 == 0)
       {fprintf(stderr,
	"\n - now processing coding sequence %4d (%s)", fcount, sfname);
	fflush(outfp);
       }
      molwt= 18.0;
      doit(numaa);
     }
  }

if (listop)
  {fprintf(outfp,"\n\nSearch list: %s \n\n", lstname);
   fprintf(outfp,"________________________________________");
   fprintf(outfp,"________________________________________\n");
  }
 
while (1)
  {if (listop)
     {if ( fscanf(listfp, "%s", sfname) == EOF )
        {fclose(listfp); listop= 0; continue;}
      if ( (infp = fopen( sfname, "r" )) == NULL )
        {fprintf(stderr,"File %s cannot be opened.\n", sfname);
	 perror(sfname); continue;}
      if (++fcount%25 == 0)
	fprintf(stderr,"File %4d (%s) has been opened for reading.\n",
		fcount, sfname);
     }
   else
     {if (anum+1==argc)   break;
      ++anum;
      if ( (infp = fopen( argv[anum], "r" )) == NULL )
        {fprintf(stderr,"File %s cannot be opened.\n", argv[anum]);
	 perror(argv[anum]); continue;}
      fprintf(stderr,"File %s has been opened for reading.\n", argv[anum]);
      ++fcount;
      strcpy(sfname,argv[anum]);
     }
   if (pstyle%2==0)
    {fprintf(outfp,"________________________________________");
     fprintf(outfp,"________________________________________\n\n");
     fprintf(outfp,"Search sequence: %s\n", sfname);
    }
   if (pstyle==3)
     fprintf(outfp,"Sequence 2: %s\n", sfname);
   if (pstyle==2)
    numaa= getips(infp,outfp,tabfp,1,tabflag,protein,&molwt,cseq[1],&clgth[1]);
   else
    numaa= getips(infp,outfp,tabfp,pstyle,tabflag,protein,&molwt,cseq[1],&clgth[1]);
   if (pstyle%2==0)
    {if (pstyle==4) fprintf(outfp,"\n");
     fprintf(outfp,"number of residues: %4d;   ", numaa);
     fprintf(outfp,"molecular weight: %5.1f kdal\n", molwt/1000);
    }
   molwt= 18.0;
   doit(numaa);
   fclose(infp);
  }
/*                                                                            */
/******************************************************************************/

if (fcount==0)
 {fprintf(outfp,"\n\nHigh-scoring internal repeats:");
  self(numaa);
 }

/******************************************************************************/
/* PRINT SUMMARY OF SEARCH:                                                   */
/*                                                                            */
fprintf(outfp,"\n");
if (fcount>1)
  {fprintf(stderr,"%5d files searched.\n", fcount);
   fprintf(outfp,"________________________________________");
   fprintf(outfp,"________________________________________\n");
   fprintf(outfp,"________________________________________");
   fprintf(outfp,"________________________________________\n");
   fprintf(outfp,
    "\n%4d of %5d files have matches reported; total number of hits: %d.\n",
    gfcount, fcount, ghcount);
  }
/*                                                                            */
/******************************************************************************/

exit(0);
} /* end main() */



/******************************************************************************/
/* COMPARE QUERY AND GIVEN SEARCH SEQUENCE:                                   */
/*                                                                            */
doit(numaa)
int numaa;
{
int i, j;
int errflag= 0, hcount;
struct hit *oh_headp= NULL, *ch_headp= NULL, *rh_headp= NULL;

for (i=0;i<24;++i)   rcnt[1][i]= 0;
for (i=0;i<numaa;++i)   SEQ[1][i]= protein[i];
psize[1]= numaa;
SEQ[1][psize[1]]= '\0';   S[1]= SEQ[1];
for (i=0;i<psize[1];++i)   ++rcnt[1][protein[i]];
if (libop && pstyle==4)
 {fprintf(outfp,"________________________________________");
  fprintf(outfp,"________________________________________\n\n");
  fprintf(outfp,"Search sequence: %s\n", sfname);
  fprintf(outfp,"\nnumber of residues: %4d\n", numaa);
 }
if (pstyle==4)   prt_seq(1,psize[1]);


/******************************************************************************/
/* DETERMINE PARAMETERS USING SEARCH FILE SPECIFIC RESIDUE FREQUENCIES:       */
/*                                                                            */
if (!fflag)
 {for (i=0;i<= MAXRANGE;++i) pr[i]=0;
  for (i=0;i<23;++i) for (j=0;j<23;++j) 
   pr[smat[i][j]-minsc]+= ((float) rcnt[0][i]*rcnt[1][j])/(psize[0]*psize[1]);
  if (!karlin(minsc,maxsc,pr,&lambda,&K,&AIL,0))
   {fprintf(outfp,"\n\nERROR: karlin.c() returned 0.\n");
    errflag= 1;
    if (pstyle%2==0)
     {fprintf(outfp,"________________________________________");
      fprintf(outfp,"________________________________________\n\n");
     }
   }
  else if (pstyle==4)
   fprintf(outfp,"\nLambda= %6.3f   K= %6.3f   H= %6.3f.\n",lambda,K,AIL);
 }
/*                                                                            */
/******************************************************************************/


/******************************************************************************/
/* DETERMINE, SORT, AND PRINT PAIRWISE HITS:                                  */ 
/*                                                                            */
if (!errflag)
 {if (tssize) lowp/= ((float)tssize/psize[1]);
  if (tscore < 0)   tscore= (int)(log(-K*psize[0]*psize[1]/log(1-lowp))/lambda);
  drpoff= (floor)(DFACT*tscore);
  if ((hcount=det_hits(0,&oh_headp,&ch_headp)))
   {++gfcount;   ghcount+= hcount;
    if (libop && pstyle==2)
     {fprintf(outfp,"________________________________________");
      fprintf(outfp,"________________________________________\n\n");
      fprintf(outfp,"Search sequence: %s\n", sfname);
     }
    if (pstyle%2==0)
     fprintf(outfp,"TSCORE:  %3d;  DFACT:  %4.2f;   NUMBER OF HITS: %3d.\n",
	tscore, DFACT, hcount);

if (CHECKFLAG) {
    fprintf(outfp,"\nDIAGONAL-ORDERED HITS:\n");
    pr_hits(oh_headp);
 }

    order_by_score(&oh_headp);
    if (oh_headp != NULL)   MAJORDIAG= oh_headp->beg1 - oh_headp->beg2;
    if (!sflag)
     {if (pstyle!=3) fprintf(outfp,"\nSCORE-ORDERED HITS:\n");
      pr_hits(oh_headp);
     }
    else
     {fprintf(outfp,"\nOPTIMIZED CONSISTENTLY ORDERED HITS:\n");
      order_cnstly(&oh_headp,&rh_headp);
      while (check_bfpr(oh_headp))
       {order_by_score(&oh_headp); order_cnstly(&oh_headp,&rh_headp);}
      pr_hits(oh_headp);
      sspa_score(oh_headp);
     }

if (CHECKFLAG && ch_headp != NULL) {
    fprintf(outfp,"\nCOMBINED HITS:\n");
    order_by_beg1(&ch_headp);
    pr_hits(ch_headp);
 }

    if (pstyle%2==0 && sflag && rh_headp != NULL)
     {fprintf(outfp,"\nHITS NOT INCLUDED IN THE CONSISTENT ORDERING:\n");
      order_by_beg1(&rh_headp);
      pr_hits(rh_headp);
     }
   
    if (ocdsflag)
     {if ((clgth[0]==3*psize[0]+3 || clgth[0]==3*psize[0]) &&
	  (clgth[1]==3*psize[1]+3 || clgth[1]==3*psize[1])   )
       pr_cds(hspfp,sp1fp,sp2fp,oh_headp);
     }

    free_hits(oh_headp);
    free_hits(ch_headp);
    free_hits(rh_headp);
   }
  else
   {if (!libop && pstyle%2==0)
     {fprintf(outfp,"\nNO HITS.\n");
      fprintf(outfp,
	"\n%s %s SSPA values:   %4.2f/%4.2f   %4.2f/%4.2f   %4.2f/%4.2f\n",
	qfname, sfname,
	0.0, 0.0, 0.0, 0.0, 0.0, 0.0 );
     }
   }
 } /* end-if(!errflag) */
/*                                                                            */
/******************************************************************************/

} /* end doit() */



prt_seq(nseq,numaa)
int nseq, numaa;
{
int i;

for( i=0; i<numaa ; ++i )
  {if (i%10 == 0)   fprintf(outfp," ");
   if (i%60 == 0)   fprintf(outfp,"\n%8d  ", i+1 );
   fprintf(outfp,"%c", AAUC[SEQ[nseq][i]] );
  }
fprintf(outfp,"\n");

} /* end prt_seq() */



int det_hits(self,oh_headpp,ch_headpp)
int self;
struct hit **oh_headpp, **ch_headpp;
{
int i,f,dg,pos1,pos2,lst,dglen,sum,max,bpoint= 0;
int nhsp= 0;
char *let1, *let2;
int nhsppd, tinbsum, inbsum, previnbsum, prevmax;
int nflag= 0, renflag= 0;
int cancomb= 0, cbeg1, cend1, cbeg2, cend2, cmax, bcmax;
struct hit *nodep, *tmp, *ctmp;

for (dg=self ? 1 : 1-psize[0];dg<psize[1];++dg)
 {pos1=(dg<0)? -dg:0;
  pos2=dg+pos1;
  dglen=min2(psize[0]-pos1,psize[1]-pos2);
  let1=S[0]+pos1;
  let2=S[1]+pos2;
  max= tscore;
  nhsppd= sum= tinbsum= inbsum= f= nflag= prevmax= cancomb= renflag= 0;
  for (i=0;i<dglen;++i)
   {if (tinbsum) inbsum+=smat[*let1][*let2];
    if ((sum+=smat[*let1++][*let2++])>max)
     {max=sum;
      lst=i;
      if (nflag) previnbsum= inbsum-sum;
      nflag= 0;
      tinbsum= 1;
      inbsum= 0;
     }
    if (!xflag)   bpoint= max > tscore ? max-drpoff : 0;
    if (sum<=bpoint || i==dglen-1)
     {if (max>tscore)
       {++nhsp;
        nflag= 1;
        if (++nhsppd == 1)
 	 {cbeg1= pos1+f+1; cbeg2= pos2+f+1; bcmax= cmax= max;}
        else
	 {if (-previnbsum < prevmax)
	   {cmax+= previnbsum + max;
	    if (-previnbsum < max)
	     {cancomb= 1;
	      if (cmax > bcmax) bcmax= cmax;
	      cend1= pos1+lst+1; cend2= pos2+lst+1;
	     }
	   }
	  else
	   {renflag= 1;}
	 }

        nodep= (struct hit *) malloc(sizeof(struct hit));
        strcpy(nodep->pname1,qfname);   strcpy(nodep->pname2,sfname);
        nodep->beg1 = pos1+f+1;   nodep->end1 = pos1+lst+1;
        nodep->beg2 = pos2+f+1;   nodep->end2 = pos2+lst+1;
        nodep->score = max;
        nodep->length = lst-f+1;
	nodep->label = 0;
        nodep->nexth = (struct hit*) NULL;
        if (*oh_headpp == NULL)
         {*oh_headpp = nodep; tmp = nodep;}
        else
         {tmp->nexth = nodep; tmp = nodep;}

	if (renflag)
	 {if (cancomb)
	   {nodep= (struct hit *) malloc(sizeof(struct hit));
	    strcpy(nodep->pname1,qfname);   strcpy(nodep->pname2,sfname);
            nodep->beg1 = cbeg1;   nodep->end1 = cend1;
            nodep->beg2 = cbeg2;   nodep->end2 = cend2;
            nodep->score = bcmax;
            nodep->length = cend1-cbeg1+1;
	    nodep->label = 0;
            nodep->nexth = (struct hit*) NULL;
            if (*ch_headpp == NULL)
             {*ch_headpp = nodep; ctmp = nodep;}
            else
             {ctmp->nexth = nodep; ctmp = nodep;}
	   }
	  cancomb= 0; nhsppd= 0; renflag= 0;
	 }

	prevmax= cmax;
	max=tscore;
       }
      f=i+1;
      sum=0;
     } 
   }
  if (cancomb)
   {nodep= (struct hit *) malloc(sizeof(struct hit));
    strcpy(nodep->pname1,qfname);   strcpy(nodep->pname2,sfname);
    nodep->beg1 = cbeg1;   nodep->end1 = cend1;
    nodep->beg2 = cbeg2;   nodep->end2 = cend2;
    nodep->score = bcmax;
    nodep->length = cend1-cbeg1+1;
    nodep->label = 0;
    nodep->nexth = (struct hit*) NULL;
    if (*ch_headpp == NULL)
     {*ch_headpp = nodep; ctmp = nodep;}
    else
     {ctmp->nexth = nodep; ctmp = nodep;}
   }
 }
return (nhsp);

} /* end det_hits() */



pr_hits(nodep)
struct hit *nodep;
{
int i,j,k;
int ip,ip2,ip2l;
char *p1, *p2;
int *c1, *c2;
int nbr_ident, ndid, nbr_pos, ndps, sncnt[23][23];
int nbr_ni, nbr_tn, nbr_tv;
int hitnum= 1;

while (nodep != NULL)
 {nbr_ident= ndid= nbr_pos= ndps= 0;
  for (j=0;j<23;++j) for (k=0;k<23;++k)   sncnt[j][k]= 0;
  nbr_ni= nbr_tn= nbr_tv= 0;

  p1= S[0] + nodep->beg1 -1;   c1= cseq[0] + 3*(nodep->beg1 -1);
  p2= S[1] + nodep->beg2 -1;   c2= cseq[1] + 3*(nodep->beg2 -1);

  for (i=0;i<nodep->length;++i)
   {if (*(p1+i) == *(p2+i))
     {++nbr_ident; ++nbr_pos; ++sncnt[*(p1+i)][*(p2+i)];}
    else if (smat[*(p1+i)][*(p2+i)] > 0)
     {++nbr_pos; ++sncnt[*(p1+i)][*(p2+i)];}
    if (*(c1+3*i)<=3 && *(c2+3*i)<=3)
     {if (*(c1+3*i) == *(c2+3*i)) ++nbr_ni;
      else if ((*(c1+3*i)<=1 && *(c2+3*i)<=1) ||
	       (*(c1+3*i)>=2 && *(c2+3*i)>=2)   )  ++nbr_tn;
      else ++nbr_tv;
     }
    if (*(c1+3*i+1)<=3 && *(c2+3*i+1)<=3)
     {if (*(c1+3*i+1) == *(c2+3*i+1)) ++nbr_ni;
      else if ((*(c1+3*i+1)<=1 && *(c2+3*i+1)<=1) ||
	       (*(c1+3*i+1)>=2 && *(c2+3*i+1)>=2)   )  ++nbr_tn;
      else ++nbr_tv;
     }
    if (*(c1+3*i+2)<=3 && *(c2+3*i+2)<=3)
     {if (*(c1+3*i+2) == *(c2+3*i+2)) ++nbr_ni;
      else if ((*(c1+3*i+2)<=1 && *(c2+3*i+2)<=1) ||
	       (*(c1+3*i+2)>=2 && *(c2+3*i+2)>=2)   )  ++nbr_tn;
      else ++nbr_tv;
     }
   }
  for (j=0;j<23;++j)
   {if (sncnt[j][j] > 0)   ++ndid;
    for (k=j;k<23;++k)
     if (sncnt[j][k] > 0 || sncnt[k][j] > 0)   ++ndps;
   }

  nodep->ndid = ndid;
  nodep->prct_id = (int)((100*nbr_ident)/nodep->length);
  nodep->ndps = ndps;
  nodep->prct_ps = (int)((100*nbr_pos)/nodep->length);
  nodep->pval = 1.0 - exp(-K*psize[0]*psize[1]*exp(-lambda*nodep->score));

  if (pstyle==1)
   {fprintf(outfp,"\nPWHIT %s %s %4d %4d   %4d %4d   %10.2e   S %4d  L %4d",
	nodep->pname1, nodep->pname2, nodep->beg1, nodep->end1,
	nodep->beg2, nodep->end2, nodep->pval, nodep->score, nodep->length );
    fprintf(outfp,"  I %2d %3u%%  P %2d %3u%%", nodep->ndid,
	(unsigned)nodep->prct_id, nodep->ndps, (unsigned)nodep->prct_ps );
   }
  else if (pstyle==3)
   {fprintf(outfp,"%4d %4d %4d\n",nodep->beg1,nodep->beg2,nodep->length);}
  else
   {fprintf(outfp,"\n\n%3d) Diagonal:%5d    ",hitnum++,nodep->beg1 - nodep->beg2);
    fprintf(outfp,"Length:%4d    ",nodep->length);
    fprintf(outfp,"Score:%4d    ",nodep->score);
    fprintf(outfp,"P value: %10.2e\n",nodep->pval);

    for (ip=0;ip<nodep->length;++ip)
     {if (ip==0)
       {fprintf(outfp,"\n%5d  %c",nodep->beg1,AAUC[*p1]);
	p1++;   continue;
       }
      if (ip%10 == 0)  fprintf(outfp," ");
      if (ip%60 == 0 && ip != nodep->length -1)
       {fprintf(outfp,"\n      ");
	for (ip2=0;ip2<60;++ip2)
	 {if (ip2%10 == 0)  fprintf(outfp," ");
	  if (*(p1-60+ip2) == *(p2+ip2))
	    fprintf(outfp,"%c",AAUC[*(p1-60+ip2)]);
	  else
	   {if (smat[*(p1-60+ip2)][*(p2+ip2)] > 0) fprintf(outfp,"+");
	    else fprintf(outfp," ");
	   }
  	 }
	fprintf(outfp,"\n%5d ",nodep->beg2 +ip-60);
	for (ip2=0;ip2<60;++ip2)
	 {if (ip2%10 == 0)  fprintf(outfp," ");
	  fprintf(outfp,"%c",AAUC[*p2]);
	  p2++;
	 }
	fprintf(outfp,"\n\n%5d  ",nodep->beg1 +ip);
       }
      fprintf(outfp,"%c", AAUC[*p1]);
      p1++;
     }
    fprintf(outfp," %5d", nodep->end1);

    if (ip%60 == 0)   {if (ip == 0) ip2l= 0; else ip2l= 60;}
    else
     {if (ip%60 == 1)   {if (ip == 1) ip2l= 1; else ip2l= 61;}
      else   ip2l= ip%60;
     }
    fprintf(outfp,"\n      ");
    for (ip2=0;ip2<ip2l;++ip2)
     {if (ip2%10 == 0)  fprintf(outfp," ");
      if (*(p1-ip2l+ip2) == *(p2+ip2))
	fprintf(outfp,"%c",AAUC[*(p1-ip2l+ip2)]);
      else
       {if (smat[*(p1-ip2l+ip2)][*(p2+ip2)] > 0) fprintf(outfp,"+");
	else fprintf(outfp," ");
       }
     }
    fprintf(outfp,"\n%5d ",nodep->beg2 +ip-ip2l);
    for (ip2=0;ip2<ip2l;++ip2)
     {if (ip2%10 == 0)  fprintf(outfp," ");
      fprintf(outfp,"%c", AAUC[*p2] );
      p2++;
     }
    fprintf(outfp," %5d\n", nodep->end2);

    fprintf(outfp,"\n     Identities (#-distinct, overall %%): %2d %3u%%;   ",
		nodep->ndid, nodep->prct_id );
    fprintf(outfp,"Positives: %2d %3u%%\n", nodep->ndps, nodep->prct_ps );


    if ((clgth[0]==3*psize[0]+3 || clgth[0]==3*psize[0]) &&
	(clgth[1]==3*psize[1]+3 || clgth[1]==3*psize[1])   )
     {c1= cseq[0] + 3*(nodep->beg1 -1);   c2= cseq[1] + 3*(nodep->beg2 -1);
      for (ip=0;ip<nodep->length;++ip)
       {if (ip==0)
	 {fprintf(outfp,"\n%5d  %c%c%c",nodep->beg1,NAUC[*c1],NAUC[*(c1+1)],
					NAUC[*(c1+2)]);
 	  c1+=3;   continue;
         }
        if (ip%5 == 0)  fprintf(outfp," ");
        if (ip%15 == 0)
	 {fprintf(outfp,"\n     ");
	  for (ip2=0;ip2<15;++ip2)
   	   {if (ip2%5 == 0)  fprintf(outfp," ");
	    if (*(c1-45+3*ip2) == *(c2+3*ip2))
	     fprintf(outfp," %c",NAUC[*(c1-45+3*ip2)]);
	    else if ((*(c1-45+3*ip2)<=1 && *(c2+3*ip2)<=1) ||
		    (*(c1-45+3*ip2)>=2 && *(c2+3*ip2)>=2)   )
	 	   fprintf(outfp," +");
	    else   fprintf(outfp,"  ");
	    if (*(c1-44+3*ip2) == *(c2+3*ip2+1))
	     fprintf(outfp,"%c",NAUC[*(c1-44+3*ip2)]);
	    else if ((*(c1-44+3*ip2)<=1 && *(c2+3*ip2+1)<=1) ||
		     (*(c1-44+3*ip2)>=2 && *(c2+3*ip2+1)>=2)   )
		   fprintf(outfp,"+");
	    else   fprintf(outfp," ");
	    if (*(c1-43+3*ip2) == *(c2+3*ip2+2))
	     fprintf(outfp,"%c",NAUC[*(c1-43+3*ip2)]);
	    else if ((*(c1-43+3*ip2)<=1 && *(c2+3*ip2+2)<=1) ||
		     (*(c1-43+3*ip2)>=2 && *(c2+3*ip2+2)>=2)   )
		   fprintf(outfp,"+");
	    else   fprintf(outfp," ");
   	   }
	  fprintf(outfp,"\n%5d",nodep->beg2 +ip-15);
	  for (ip2=0;ip2<15;++ip2)
   	   {if (ip2%5 == 0)  fprintf(outfp," ");
	     fprintf(outfp," %c%c%c",NAUC[*c2],NAUC[*(c2+1)],NAUC[*(c2+2)]);
	    c2+= 3;
	   }
	  fprintf(outfp,"\n\n%5d ",nodep->beg1 +ip);
	 }
        fprintf(outfp," %c%c%c",NAUC[*c1],NAUC[*(c1+1)],NAUC[*(c1+2)]);
        c1+= 3;
       }
      fprintf(outfp," %5d", nodep->end1);

      if (ip%15 == 0)   {if (ip == 0) ip2l= 0; else ip2l= 15;}
      else                            ip2l= ip%15;
      fprintf(outfp,"\n     ");
      for (ip2=0;ip2<ip2l;++ip2)
       {if (ip2%5 == 0)  fprintf(outfp," ");
        if (*(c1-(3*ip2l)+3*ip2) == *(c2+3*ip2))
	 fprintf(outfp," %c",NAUC[*(c1-(3*ip2l)+3*ip2)]);
        else if ((*(c1-(3*ip2l)+3*ip2)<=1 && *(c2+3*ip2)<=1) ||
		 (*(c1-(3*ip2l)+3*ip2)>=2 && *(c2+3*ip2)>=2)   )
	       fprintf(outfp," +");
        else   fprintf(outfp,"  ");
        if (*(c1-(3*ip2l)+3*ip2+1) == *(c2+3*ip2+1))
	 fprintf(outfp,"%c",NAUC[*(c1-(3*ip2l)+3*ip2+1)]);
        else if ((*(c1-(3*ip2l)+3*ip2+1)<=1 && *(c2+3*ip2+1)<=1) ||
		 (*(c1-(3*ip2l)+3*ip2+1)>=2 && *(c2+3*ip2+1)>=2)   )
	       fprintf(outfp,"+");
        else   fprintf(outfp," ");
        if (*(c1-(3*ip2l)+3*ip2+2) == *(c2+3*ip2+2))
	 fprintf(outfp,"%c",NAUC[*(c1-(3*ip2l)+3*ip2+2)]);
        else if ((*(c1-(3*ip2l)+3*ip2+2)<=1 && *(c2+3*ip2+2)<=1) ||
		 (*(c1-(3*ip2l)+3*ip2+2)>=2 && *(c2+3*ip2+2)>=2)   )
	       fprintf(outfp,"+");
        else   fprintf(outfp," ");
       }
      fprintf(outfp,"\n%5d",nodep->beg2 +ip-ip2l);
      for (ip2=0;ip2<ip2l;++ip2)
       {if (ip2%5 == 0)  fprintf(outfp," ");
         fprintf(outfp," %c%c%c",NAUC[*c2],NAUC[*(c2+1)],NAUC[*(c2+2)]);
        c2+= 3;
       }
      fprintf(outfp," %5d\n", nodep->end2);

      fprintf(outfp,"\n     Identities: %3d %3u%%;   ",
		nbr_ni, (int)(100*(float)nbr_ni/(3*nodep->length)) );
      fprintf(outfp,"Transitions: %3d %3u%%;   ",
		nbr_tn, (int)(100*(float)nbr_tn/(3*nodep->length)) );
      fprintf(outfp,"Transversions: %3d %3u%%\n",
		nbr_tv, (int)(100*(float)nbr_tv/(3*nodep->length)) );
     }
   }
  nodep= nodep->nexth;
 }
fprintf(outfp,"\n");

} /* end pr_hits() */



pr_cds(hspfp,sp1fp,sp2fp,nodep)
FILE *hspfp, *sp1fp, *sp2fp;
struct hit *nodep;
{
int i;
char *p1, *p2;
int *c1, *c2;
int hitnum= 0;

while (nodep != NULL)
 {if (++hitnum==1)
   {c1= cseq[0];
    if (nodep->beg1 > 1)
     {fprintf(sp1fp,">SQ;%s_nHSP%d",nodep->pname1,hitnum);
      for (i=0;i<nodep->beg1-1;++i)
       {if (i%20==0) fprintf(sp1fp,"\n");
        fprintf(sp1fp,"%c%c%c",NAUC[*c1],NAUC[*(c1+1)],NAUC[*(c1+2)]);
        c1+= 3;
       }
     }
    c2= cseq[1];
    if (nodep->beg2 > 1)
     {fprintf(sp2fp,">SQ;%s_nHSP%d",nodep->pname2,hitnum);
      for (i=0;i<nodep->beg2-1;++i)
       {if (i%20==0) fprintf(sp2fp,"\n");
        fprintf(sp2fp,"%c%c%c",NAUC[*c2],NAUC[*(c2+1)],NAUC[*(c2+2)]);
        c2+= 3;
       }
     }
   }
  else fprintf(hspfp,"\n");
  fprintf(hspfp,">SQ;%s_HSP%d",nodep->pname1,hitnum);
  for (i=0;i<nodep->length;++i)
   {if (i%20==0) fprintf(hspfp,"\n");
    fprintf(hspfp,"%c%c%c",NAUC[*c1],NAUC[*(c1+1)],NAUC[*(c1+2)]);
    c1+= 3;
   }
  fprintf(hspfp,"\n>SQ;%s_HSP%d",nodep->pname2,hitnum);
  for (i=0;i<nodep->length;++i)
   {if (i%20==0) fprintf(hspfp,"\n");
    fprintf(hspfp,"%c%c%c",NAUC[*c2],NAUC[*(c2+1)],NAUC[*(c2+2)]);
    c2+= 3;
   }
  if (nodep->nexth!=NULL)
   {if ((nodep->nexth)->beg1 - nodep->end1 > 1)
     {fprintf(sp1fp,"\n>SQ;%s_nHSP%d",nodep->pname1,hitnum+1);
      for (i=0;i<(nodep->nexth)->beg1 - nodep->end1-1;++i)
       {if (i%20==0) fprintf(sp1fp,"\n");
        fprintf(sp1fp,"%c%c%c",NAUC[*c1],NAUC[*(c1+1)],NAUC[*(c1+2)]);
        c1+= 3;
       }
     }
    if ((nodep->nexth)->beg2 - nodep->end2 > 1)
     {fprintf(sp2fp,"\n>SQ;%s_nHSP%d",nodep->pname2,hitnum+1);
      for (i=0;i<(nodep->nexth)->beg2 - nodep->end2-1;++i)
       {if (i%20==0) fprintf(sp2fp,"\n");
        fprintf(sp2fp,"%c%c%c",NAUC[*c2],NAUC[*(c2+1)],NAUC[*(c2+2)]);
        c2+= 3;
       }
     }
   }
  else
   {if (nodep->end1 < psize[0])
     {fprintf(sp1fp,"\n>SQ;%s_nHSP%d",nodep->pname1,hitnum+1);
      for (i=0;i<psize[0] - nodep->end1;++i)
       {if (i%20==0) fprintf(sp1fp,"\n");
        fprintf(sp1fp,"%c%c%c",NAUC[*c1],NAUC[*(c1+1)],NAUC[*(c1+2)]);
        c1+= 3;
       }
     }
    if (nodep->end2 < psize[1])
     {fprintf(sp2fp,"\n>SQ;%s_nHSP%d",nodep->pname2,hitnum+1);
      for (i=0;i<psize[1] - nodep->end2;++i)
       {if (i%20==0) fprintf(sp2fp,"\n");
        fprintf(sp2fp,"%c%c%c",NAUC[*c2],NAUC[*(c2+1)],NAUC[*(c2+2)]);
        c2+= 3;
       }
     }
   }
  nodep= nodep->nexth;
 }
fprintf(hspfp,"\n");
fprintf(sp1fp,"\n");
fprintf(sp2fp,"\n");

} /* end pr_cds() */



free_hits(nodep)
struct hit *nodep;
{
struct hit **tnodepp;

if (nodep == NULL) return;
if (nodep->nexth == NULL) {free((struct hit *) nodep); return;}

while (nodep->nexth != NULL)
  {tnodepp = &nodep;
   nodep= nodep->nexth;
   free((struct hit *) *tnodepp);
  }
free((struct hit *) nodep);

} /* end free_hits() */



order_by_beg1(nodepp)
struct hit **nodepp;
{
struct hit *ip= *nodepp, *tmp, *newheadp= NULL;

while (ip != NULL)
 {tmp= ip->nexth;
  ip->nexth = NULL;
  insert_by_beg1(&newheadp,ip);
  ip= tmp;
 } 

*nodepp= newheadp;

} /* end order_by_beg1() */



insert_by_beg1(headpp,nodep)
struct hit **headpp, *nodep;
{

if (*headpp == NULL)
 {*headpp= nodep; nodep->nexth= NULL;}
else
 {while ( (*headpp)->nexth != NULL  && (*headpp)->beg1 < nodep->beg1 )
    headpp= &((*headpp)->nexth);
  if ((*headpp)->nexth == NULL)
   {if ((*headpp)->beg1 < nodep->beg1)
     {(*headpp)->nexth= nodep; nodep->nexth= NULL;}
    else
     {nodep->nexth= *headpp; *headpp= nodep;}
   }
  else
   {nodep->nexth= *headpp; *headpp= nodep;}
 }

} /* end insert_by_beg1 */



order_by_score(nodepp)
struct hit **nodepp;
{
struct hit *ip= *nodepp, *tmp, *newheadp= NULL;

while (ip != NULL)
 {tmp= ip->nexth;
  ip->nexth = NULL;
  insert_by_score(&(newheadp),ip);
  ip= tmp;
 } 

*nodepp= newheadp;

} /* end order_by_score() */



insert_by_score(headpp,nodep)
struct hit **headpp, *nodep;
{

if (*headpp == NULL)
 {*headpp= nodep; nodep->nexth= NULL;}
else
 {while ( (*headpp)->nexth != NULL  && (*headpp)->score > nodep->score )
    headpp= &((*headpp)->nexth);
  if ((*headpp)->nexth == NULL)
   {if ((*headpp)->score > nodep->score)
     {(*headpp)->nexth= nodep; nodep->nexth= NULL;}
    else
     {nodep->nexth= *headpp; *headpp= nodep;}
   }
  else
   {nodep->nexth= *headpp; *headpp= nodep;}
 }

} /* end insert_by_score */



order_cnstly(ohpp,rhpp)
struct hit **ohpp, **rhpp;
{
struct hit *ip= *ohpp, *tmp, *newheadp= NULL;

while (ip != NULL)
 {tmp= ip->nexth;
  ip->nexth = NULL;
  check_cnstcy(&newheadp,ip,&(*rhpp));
  ip= tmp;
 } 

*ohpp= newheadp;

} /* end order_cnstly() */



check_cnstcy(ohpp,nodep,rhpp)
struct hit **ohpp, *nodep, **rhpp;
{

if (*ohpp == NULL)
  *ohpp = nodep;
else
 {switch (comp_hits(*ohpp,nodep,&(*rhpp)))   {
	case 0:
		ins_nh(ohpp,nodep);   /* insert nodep before *ohpp */
		break;
	case 1:
		check_cnstcy(&((*ohpp)->nexth),nodep,&(*rhpp));
		break;
	case 2:
		check_cnstcy(&(*ohpp),nodep,&(*rhpp));
		break;
	default:
		break;   /* ignore nodep altogether */
	}
 }

} /* end check_cnstcy() */



ins_nh(ohpp,nodep)   /* inserts nodep node before *ohpp node */
struct hit **ohpp, *nodep;
{
if (nodep->length < 2  ||  nodep->score < 1) return;

nodep->nexth = *ohpp;
*ohpp = nodep;

} /* end ins_nh() */



ins_hn(ohpp,nodep)   /* inserts nodep node after *ohpp node */
struct hit **ohpp, *nodep;
{
if (nodep->length < 2  ||  nodep->score < 1) return;

nodep->nexth = (*ohpp)->nexth;
(*ohpp)->nexth = nodep;

} /* end ins_hn() */



int comp_hits(headp,nodep,rhpp)
struct hit *headp, *nodep, **rhpp;
/* Comparison function:  returns 0 if nodep is to be inserted immediately
   in front of headnode; returns 1 if comparison is to continue; returns 2
   if nodep should replace headp; and returns 3 if nodep should be ignored
   for the headp list (and be entered into the rhpp list).
*/
{
int adjval, contflag= 1;
int tmpbeg1, tmpend1, tmpbeg2, tmpend2, tmplgth, tmpscr;

/* NODEP OCCURS UPSTREAM OF HEADP; INSERT! */
if (nodep->end1 < headp->beg1  &&  nodep->end2 < headp->beg2)
  {return(0);
  }

/* NODEP OCCURS DOWNSTREAM OF HEADP; CONTINUE! */
if (nodep->beg1 > headp->end1  &&  nodep->beg2 > headp->end2)
  {return(1);
  }

/* OVERLAPPING NODES; ADJUST! */
if (nodep->beg1 <= headp->beg1  &&  nodep->beg2 <= headp->beg2  &&
    ( (nodep->end1 >= headp->beg1  &&  nodep->end1 <= headp->end1
	&& nodep->end2 <= headp->end2) ||
      (nodep->end2 >= headp->beg2  &&  nodep->end2 <= headp->end2
	&& nodep->end1 <= headp->end1)   ) )
  {if ((adjval = adj_hits(&nodep,&headp)) > 0)
    {if (headp->score < 1)
      {tmpbeg1= headp->beg1; tmpend1= headp->end1;
       tmpbeg2= headp->beg2; tmpend2= headp->end2;
       tmplgth= headp->length; tmpscr= headp->score;
       headp->beg1 = nodep->beg1; headp->end1 = nodep->end1;
       headp->beg2 = nodep->beg2; headp->end2 = nodep->end2;
       headp->length = nodep->length; headp->score = nodep->score;
       nodep->beg1 = headp->beg1; nodep->end1 = headp->end1;
       nodep->beg2 = headp->beg2; nodep->end2 = headp->end2;
       nodep->length = headp->length; nodep->score = headp->score;
       contflag= 0;
      }
     else if (nodep->score > 0) return(0);
    }
   else
    {if ((nodep->score == headp->score  &&
          absd(nodep->beg1 - nodep->beg2,MAJORDIAG) <
	  absd(headp->beg1 - headp->beg2,MAJORDIAG)  )  ||
	 (nodep->score != headp->score  &&  adjval == -1) )
      {tmpbeg1= headp->beg1; tmpend1= headp->end1;
       tmpbeg2= headp->beg2; tmpend2= headp->end2;
       tmplgth= headp->length; tmpscr= headp->score;
       headp->beg1 = nodep->beg1; headp->end1 = nodep->end1;
       headp->beg2 = nodep->beg2; headp->end2 = nodep->end2;
       headp->length = nodep->length; headp->score = nodep->score;
       nodep->beg1 = headp->beg1; nodep->end1 = headp->end1;
       nodep->beg2 = headp->beg2; nodep->end2 = headp->end2;
       nodep->length = headp->length; nodep->score = headp->score;
       contflag= 0;
      }
    }
  }

if (contflag  &&
    nodep->end1 >= headp->end1  &&  nodep->end2 >= headp->end2  &&
    ( (nodep->beg1 <= headp->end1  &&  nodep->beg1 >= headp->beg1
	&& nodep->beg2 >= headp->beg2) ||
      (nodep->beg2 <= headp->end2  &&  nodep->beg2 >= headp->beg2
	&& nodep->beg1 >= headp->beg1)   ) )
  {if ((adjval = adj_hits(&headp,&nodep)) > 0)
    {if (headp->score < 1)
      {tmpbeg1= headp->beg1; tmpend1= headp->end1;
       tmpbeg2= headp->beg2; tmpend2= headp->end2;
       tmplgth= headp->length; tmpscr= headp->score;
       headp->beg1 = nodep->beg1; headp->end1 = nodep->end1;
       headp->beg2 = nodep->beg2; headp->end2 = nodep->end2;
       headp->length = nodep->length; headp->score = nodep->score;
       nodep->beg1 = headp->beg1; nodep->end1 = headp->end1;
       nodep->beg2 = headp->beg2; nodep->end2 = headp->end2;
       nodep->length = headp->length; nodep->score = headp->score;
       contflag= 0;
      }
     else if (nodep->score > 1) return(1);
    }
   else
    {if ((nodep->score == headp->score  &&
          absd(nodep->beg1 - nodep->beg2,MAJORDIAG) <
	  absd(headp->beg1 - headp->beg2,MAJORDIAG)  )  ||
	 (nodep->score != headp->score  &&  adjval == -2) )
      {tmpbeg1= headp->beg1; tmpend1= headp->end1;
       tmpbeg2= headp->beg2; tmpend2= headp->end2;
       tmplgth= headp->length; tmpscr= headp->score;
       headp->beg1 = nodep->beg1; headp->end1 = nodep->end1;
       headp->beg2 = nodep->beg2; headp->end2 = nodep->end2;
       headp->length = nodep->length; headp->score = nodep->score;
       nodep->beg1 = headp->beg1; nodep->end1 = headp->end1;
       nodep->beg2 = headp->beg2; nodep->end2 = headp->end2;
       nodep->length = headp->length; nodep->score = headp->score;
       contflag= 0;
      }
    }
  }

/* INCLUDED NODES; COMBINE! */
if (contflag  &&
    nodep->beg1 >= headp->beg1  &&  nodep->beg2 >= headp->beg2  &&
    nodep->end1 <= headp->end1  &&  nodep->end2 <= headp->end2    )
  {if (cmb_hn_hits(&headp,&nodep))   return(2);
  }

if (contflag  &&
    nodep->beg1 <= headp->beg1  &&  nodep->beg2 <= headp->beg2  &&
    nodep->end1 >= headp->end1  &&  nodep->end2 >= headp->end2    )
  {if (cmb_nh_hits(&headp,&nodep))   return(2);
  }

/* HEADP OR NODEP IS OUT OF ORDER; LABEL AND ADD TO rhpp LIST: */
if (nodep->score > headp->score)
 {tmpbeg1= headp->beg1; tmpend1= headp->end1;
  tmpbeg2= headp->beg2; tmpend2= headp->end2;
  tmplgth= headp->length; tmpscr= headp->score;
  headp->beg1 = nodep->beg1; headp->end1 = nodep->end1;
  headp->beg2 = nodep->beg2; headp->end2 = nodep->end2;
  headp->length = nodep->length; headp->score = nodep->score;
  nodep->beg1 = headp->beg1; nodep->end1 = headp->end1;
  nodep->beg2 = headp->beg2; nodep->end2 = headp->end2;
  nodep->length = headp->length; nodep->score = headp->score;
 }
if (nodep->score >= tscore)
 {nodep->label = 3;
  nodep->nexth = NULL;
  if (*rhpp == NULL)   *rhpp= nodep;
  else                 ins_nh(rhpp,nodep);
 }
return(9);

} /* end comp_hits() */



check_bfpr(nodep)
struct hit *nodep;
{

while (nodep != NULL)
  {if (nodep->nexth == NULL) break;
   if (nodep->end1 >= (nodep->nexth)->beg1  ||
       nodep->end2 >= (nodep->nexth)->beg2    )
    {return(1);
    }
   nodep= nodep->nexth;
  }

return(0);

} /* end check_bfpr() */



cmb_hn_hits(node1pp,node2pp)
struct hit **node1pp, **node2pp;
{
int lgth;
char *p1, *p2;
struct hit *nodep;
int node1scr, node1end1, node1end2;
int node2scr, node2beg1, node2end1, node2beg2, node2end2;

node1scr= (*node1pp)->score;
node1end1= (*node1pp)->end1; node1end2= (*node1pp)->end2;
node2scr= (*node2pp)->score;
node2beg1= (*node2pp)->beg1; node2end1= (*node2pp)->end1;
node2beg2= (*node2pp)->beg2; node2end2= (*node2pp)->end2;

lgth= min2((*node2pp)->end1 - (*node1pp)->beg1,
	    (*node2pp)->end2 - (*node1pp)->beg2 );

(*node1pp)->end1 = (*node1pp)->beg1 + lgth;
(*node1pp)->end2 = (*node1pp)->beg2 + lgth;
(*node1pp)->length = lgth + 1;

nodep= (struct hit *) malloc(sizeof(struct hit));
strcpy(nodep->pname1,(*node1pp)->pname1);
strcpy(nodep->pname2,(*node1pp)->pname2);
nodep->beg1 = (*node2pp)->beg1;
nodep->end1 = (*node2pp)->end1;
nodep->beg2 = (*node2pp)->beg2;
nodep->end2 = (*node2pp)->end2;
nodep->length = nodep->end1 - nodep->beg1 +1;
nodep->label = 0;
nodep->nexth = (struct hit*) NULL;

if (adj_hits(node1pp,&nodep) < 0)
 {(*node1pp)->end1 = node1end1; (*node1pp)->end2 = node1end2;
  (*node1pp)->length = (*node1pp)->end1 - (*node1pp)->beg1 + 1;
  (*node1pp)->score = node1scr;
  free((struct hit *)nodep);
  return(0);
 }

(*node2pp)->end1 = node1end1; (*node2pp)->end2 = node1end2;
lgth= min2((*node2pp)->end1 - nodep->beg1,
	    (*node2pp)->end2 - nodep->beg2 );
(*node2pp)->beg1 = (*node2pp)->end1 - lgth;
(*node2pp)->beg2 = (*node2pp)->end2 - lgth;
(*node2pp)->length = lgth + 1;

if (adj_hits(&nodep,node2pp) < 0)
 {(*node1pp)->end1 = node1end1; (*node1pp)->end2 = node1end2;
  (*node1pp)->length = (*node1pp)->end1 - (*node1pp)->beg1 + 1;
  (*node1pp)->score = node1scr;
  (*node2pp)->beg1 = node2beg1; (*node2pp)->end1 = node2end1;
  (*node2pp)->beg2 = node2beg2; (*node2pp)->end2 = node2end2;
  (*node2pp)->length = (*node2pp)->end1 - (*node2pp)->beg1 + 1;
  (*node2pp)->score = node2scr;
  free((struct hit *)nodep);
  return(0);
 }

p1= S[0] + nodep->beg1 -1;
p2= S[1] + nodep->beg2 -1;
while (smat[*p1][*p2] <= 0)
 {nodep->beg1 += 1; nodep->beg2 += 1; nodep->score -= smat[*(p1++)][*(p2++)];}
p1= S[0] + nodep->end1 -1;
p2= S[1] + nodep->end2 -1;
while (smat[*p1][*p2] <= 0)
 {nodep->end1 -= 1; nodep->end2 -= 1; nodep->score -= smat[*(p1--)][*(p2--)];}
nodep->length = nodep->end1 - nodep->beg1 + 1;

if ((*node1pp)->score + nodep->score + (*node2pp)->score > node1scr)
 {if ((*node1pp)->length < 2)
   {(*node1pp)->beg1 = nodep->beg1; (*node1pp)->end1 = nodep->end1;
    (*node1pp)->beg2 = nodep->beg2; (*node1pp)->end2 = nodep->end2;
    (*node1pp)->length = nodep->length; (*node1pp)->score = nodep->score;
    return(1);
   }
  if ((*node2pp)->length < 2)
   {ins_hn(node1pp,nodep);
    return(0);
   }
  ins_hn(node1pp,nodep);
  return(1);
 }
else
 {(*node1pp)->end1 = node1end1; (*node1pp)->end2 = node1end2;
  (*node1pp)->length = (*node1pp)->end1 - (*node1pp)->beg1 + 1;
  (*node1pp)->score = node1scr;
  (*node2pp)->beg1 = node2beg1; (*node2pp)->end1 = node2end1;
  (*node2pp)->beg2 = node2beg2; (*node2pp)->end2 = node2end2;
  (*node2pp)->length = (*node2pp)->end1 - (*node2pp)->beg1 + 1;
  (*node2pp)->score = node2scr;
  free((struct hit *)nodep);
  return(0);
 }

} /* end cmb_hn_hits() */



cmb_nh_hits(node1pp,node2pp)
struct hit **node1pp, **node2pp;
{
int lgth;
char *p1, *p2;
struct hit *nodep;
int node1scr, node1beg1, node1end1, node1beg2, node1end2;
int node2scr, node2beg1, node2beg2;

node1scr= (*node1pp)->score;
node1beg1= (*node1pp)->beg1; node1end1= (*node1pp)->end1;
node1beg2= (*node1pp)->beg2; node1end2= (*node1pp)->end2;
node2scr= (*node2pp)->score;
node2beg1= (*node2pp)->beg1; node2beg2= (*node2pp)->beg2;

lgth= min2((*node1pp)->end1 - (*node2pp)->beg1,
	    (*node1pp)->end2 - (*node2pp)->beg2 );

nodep= (struct hit *) malloc(sizeof(struct hit));
strcpy(nodep->pname1,(*node1pp)->pname1);
strcpy(nodep->pname2,(*node1pp)->pname2);
nodep->beg1 = (*node1pp)->beg1;
nodep->end1 = (*node1pp)->end1;
nodep->beg2 = (*node1pp)->beg2;
nodep->end2 = (*node1pp)->end2;
nodep->length = nodep->end1 - nodep->beg1 +1;
nodep->label = 0;
nodep->nexth = (struct hit*) NULL;

(*node1pp)->beg1 = (*node2pp)->beg1;
(*node1pp)->beg2 = (*node2pp)->beg2;
(*node1pp)->end1 = (*node2pp)->beg1 + lgth;
(*node1pp)->end2 = (*node2pp)->beg2 + lgth;
(*node1pp)->length = lgth + 1;

if (adj_hits(node1pp,&nodep) < 0)
 {(*node1pp)->beg1 = node2beg1; (*node1pp)->end1 = (*node2pp)->end1;
  (*node1pp)->beg2 = node2beg2; (*node1pp)->end2 = (*node2pp)->end2;
  (*node1pp)->length = (*node1pp)->end1 - (*node1pp)->beg1 + 1;
  (*node1pp)->score = node2scr;
  (*node2pp)->beg1 = node1beg1; (*node2pp)->beg2 = node1beg2;
  (*node2pp)->end1 = node1end1; (*node2pp)->end2 = node1end2;
  (*node2pp)->length = (*node2pp)->end1 - (*node2pp)->beg1 + 1;
  (*node2pp)->score = node1scr;
  free((struct hit *)nodep);
  return(0);
 }

lgth= min2((*node2pp)->end1 - nodep->beg1,
	    (*node2pp)->end2 - nodep->beg2 );
(*node2pp)->beg1 = (*node2pp)->end1 - lgth;
(*node2pp)->beg2 = (*node2pp)->end2 - lgth;
(*node2pp)->length = lgth + 1;

if (adj_hits(&nodep,node2pp) < 0)
 {(*node1pp)->beg1 = node2beg1; (*node1pp)->end1 = (*node2pp)->end1;
  (*node1pp)->beg2 = node2beg2; (*node1pp)->end2 = (*node2pp)->end2;
  (*node1pp)->length = (*node1pp)->end1 - (*node1pp)->beg1 + 1;
  (*node1pp)->score = node2scr;
  (*node2pp)->beg1 = node1beg1; (*node2pp)->beg2 = node1beg2;
  (*node2pp)->end1 = node1end1; (*node2pp)->end2 = node1end2;
  (*node2pp)->length = (*node2pp)->end1 - (*node2pp)->beg1 + 1;
  (*node2pp)->score = node1scr;
  free((struct hit *)nodep);
  return(0);
 }

p1= S[0] + nodep->beg1 -1;
p2= S[1] + nodep->beg2 -1;
while (smat[*p1][*p2] <= 0)
 {nodep->beg1 += 1; nodep->beg2 += 1; nodep->score -= smat[*(p1++)][*(p2++)];}
p1= S[0] + nodep->end1 -1;
p2= S[1] + nodep->end2 -1;
while (smat[*p1][*p2] <= 0)
 {nodep->end1 -= 1; nodep->end2 -= 1; nodep->score -= smat[*(p1--)][*(p2--)];}
nodep->length = nodep->end1 - nodep->beg1 + 1;

if ((*node1pp)->score + nodep->score + (*node2pp)->score > node1scr)
 {if ((*node1pp)->length < 2)
   {(*node1pp)->beg1 = nodep->beg1; (*node1pp)->end1 = nodep->end1;
    (*node1pp)->beg2 = nodep->beg2; (*node1pp)->end2 = nodep->end2;
    (*node1pp)->length = nodep->length; (*node1pp)->score = nodep->score;
    return(1);
   }
  if ((*node2pp)->length < 2)
   {ins_hn(node1pp,nodep);
    return(0);
   }
  ins_hn(node1pp,nodep);
  return(1);
 }
else
 {(*node1pp)->beg1 = node2beg1; (*node1pp)->end1 = (*node2pp)->end1;
  (*node1pp)->beg2 = node2beg2; (*node1pp)->end2 = (*node2pp)->end2;
  (*node1pp)->length = (*node1pp)->end1 - (*node1pp)->beg1 + 1;
  (*node1pp)->score = node2scr;
  (*node2pp)->beg1 = node1beg1; (*node2pp)->beg2 = node1beg2;
  (*node2pp)->end1 = node1end1; (*node2pp)->end2 = node1end2;
  (*node2pp)->length = (*node2pp)->end1 - (*node2pp)->beg1 + 1;
  (*node2pp)->score = node1scr;
  free((struct hit *)nodep);
  return(0);
 }

} /* end cmb_nh_hits() */



adj_hits(node1pp,node2pp)
struct hit **node1pp, **node2pp;
{
int i, j;
int mlgth1, mlgth2;
char *p11, *p12, *p21, *p22;
int sum, maxsum= 0, maxlgth= 0;
int score;

mlgth1= min2((*node2pp)->beg1 - (*node1pp)->beg1,
		(*node2pp)->beg2 - (*node1pp)->beg2);
mlgth2= min2((*node2pp)->end1 - (*node1pp)->end1,
		(*node2pp)->end2 - (*node1pp)->end2);

p11= S[0] + (*node1pp)->beg1 + mlgth1 -1;
p12= S[1] + (*node1pp)->beg2 + mlgth1 -1;
p21= S[0] + (*node2pp)->beg1 -1;
p22= S[1] + (*node2pp)->beg2 -1;

for (i=0;i <= (*node1pp)->length - mlgth1;++i)
 {sum= 0;
  for (j=0;j<i;++j) sum+= smat[*(p11 +j)][*(p12 +j)];
  for (j=i;j<(*node1pp)->length - mlgth1;++j) sum+= smat[*(p21 +j)][*(p22 +j)];
  if (sum > maxsum ||
      (sum == maxsum  &&
       i>0 && i<= (*node1pp)->end1 - (*node1pp)->beg1 +1-mlgth1  &&
       smat[*(p11+i-1)][*(p12+i-1)] > 0 && smat[*(p21+i)][*(p22+i)] <= 0) )
   {maxsum= sum; maxlgth= i;
   }
 }

if ((mlgth2==0 && mlgth1 + maxlgth == (*node1pp)->length)  ||
    (*node2pp)->length - maxlgth <= 1                        )
 {return(-1);
 }
if (mlgth1 + maxlgth <= 1)
 {return(-2);
 }

if (maxlgth == 0) (*node1pp)->label = 2;
else if (maxlgth == (*node1pp)->length - mlgth1) (*node2pp)->label = 2;
else (*node1pp)->label = (*node2pp)->label = 2;

(*node1pp)->end1 = (*node1pp)->beg1 + mlgth1 -1 + maxlgth;
(*node1pp)->end2 = (*node1pp)->beg2 + mlgth1 -1 + maxlgth;
p11= S[0] + (*node1pp)->end1 -1;
p12= S[1] + (*node1pp)->end2 -1;
while (smat[*(p11--)][*(p12--)] <= 0)
 {(*node1pp)->end1 -= 1; (*node1pp)->end2 -= 1;}
(*node1pp)->length = (*node1pp)->end1 - (*node1pp)->beg1 +1;
(*node2pp)->beg1 = (*node2pp)->beg1 + maxlgth;
(*node2pp)->beg2 = (*node2pp)->beg2 + maxlgth;
p21= S[0] + (*node2pp)->beg1 -1;
p22= S[1] + (*node2pp)->beg2 -1;
while (smat[*(p21++)][*(p22++)] <= 0)
 {(*node2pp)->beg1 += 1; (*node2pp)->beg2 += 1;}
(*node2pp)->length = (*node2pp)->end1 - (*node2pp)->beg1 +1;

p11= S[0] + (*node1pp)->beg1 -1;
p12= S[1] + (*node1pp)->beg2 -1;
for (i=score=0;i<(*node1pp)->length;++i) score+= smat[*(p11 +i)][*(p12 +i)];
(*node1pp)->score = score;

p21= S[0] + (*node2pp)->beg1 -1;
p22= S[1] + (*node2pp)->beg2 -1;
for (i=score=0;i<(*node2pp)->length;++i) score+= smat[*(p21 +i)][*(p22 +i)];
(*node2pp)->score = score;

return(1);
} /* end adj_hits() */



sspa_score(nodep)
struct hit *nodep;
{
int segnum= 0, answer, ibeg1, iend1, ibeg2, iend2;
int scr, ascore= 0, alength= 0;
int minpsize, maxpsize;
int mrbeg1, mrend1, mrbeg2, mrend2, mrlgth[2], minmrlgth, maxmrlgth;
int sfscr[2], minsfscr, maxsfscr;
int mrsfscr[2], minmrsfscr, maxmrsfscr;
int hrsfscr[2], minhrsfscr, maxhrsfscr;
struct hit *ssgmtp;

mrbeg1= psize[0]; mrend1= 1; mrbeg2= psize[1]; mrend2= 1;
hrsfscr[0]= hrsfscr[1]= 0;

fprintf(outfp,"\nSignificant Aggregate Segment Pairs:\n");
if (sflag==2) fprintf(stderr,"\nSelect segment pairs:\n");

while (nodep != NULL)
  {if (sflag==1)
    {fprintf(outfp,"\nSegment Pair %2d:  %4d to %4d vs %4d to %4d;",
	++segnum, nodep->beg1, nodep->end1, nodep->beg2, nodep->end2 );
     fprintf(outfp," length: %5d; score: %5d", nodep->length, nodep->score);
     ascore+= nodep->score;   alength+= nodep->length;
     hrsfscr[0]+=
	det_score(S[0],nodep->beg1,nodep->end1,S[0],nodep->beg1,nodep->end1);
     hrsfscr[1]+=
	det_score(S[1],nodep->beg2,nodep->end2,S[1],nodep->beg2,nodep->end2);
     if (segnum == 1) {mrbeg1= nodep->beg1; mrbeg2= nodep->beg2;}
     mrend1= nodep->end1; mrend2= nodep->end2;
    }
   else
    {fprintf(stderr,"\n Enter 'q' to quit, 'return' to continue: ");
     fprintf(stderr,
	"\n Enter 'a' to add segment pair #%3d  (%d %d, %d %d), 's' to skip: ",
	segnum+1, nodep->beg1, nodep->end1, nodep->beg2, nodep->end2 );
     if ((answer= getchar())=='q')   {answer= getchar(); break;}
     if (answer=='a')
      {answer= getchar();
       fprintf(outfp,"\nSegment Pair %2d:  %4d to %4d vs %4d to %4d;",
		++segnum, nodep->beg1, nodep->end1, nodep->beg2, nodep->end2 );
       fprintf(outfp," length: %5d; score: %5d", nodep->length, nodep->score);
       ascore+= nodep->score;   alength+= nodep->length;
       hrsfscr[0]+=
	det_score(S[0],nodep->beg1,nodep->end1,S[0],nodep->beg1,nodep->end1);
       hrsfscr[1]+=
	det_score(S[1],nodep->beg2,nodep->end2,S[1],nodep->beg2,nodep->end2);
       if (nodep->beg1 < mrbeg1) mrbeg1= nodep->beg1;
       if (nodep->end1 > mrend1) mrend1= nodep->end1;
       if (nodep->beg2 < mrbeg2) mrbeg2= nodep->beg2;
       if (nodep->end2 > mrend2) mrend2= nodep->end2;
      }
     else if (answer=='s')
      {answer= getchar();
       nodep= nodep->nexth;
       continue;
      }
     else
      {fprintf(stderr,"\n Enter positions of segment in protein 1: ");
       scanf("%d %d",&ibeg1,&iend1);
       answer= getchar();   /* ... this absorbs the return character ... */
       fprintf(stderr,"\n Enter positions of segment in protein 2: ");
       scanf("%d %d",&ibeg2,&iend2);
       answer= getchar();   /* ... this absorbs the return character ... */
       if ((scr= det_score(S[0],ibeg1,iend1,S[1],ibeg2,iend2)) == 0) continue;
       fprintf(outfp,"\nSegment Pair %2d:  %4d to %4d vs %4d to %4d;",
		++segnum, ibeg1, iend1, ibeg2, iend2 );
       fprintf(outfp," length: %5d; score: %5d", iend1-ibeg1+1, scr);
       ascore+= scr;   alength+= iend1-ibeg1+1;
       ssgmtp= (struct hit *) malloc(sizeof(struct hit));
       strcpy(ssgmtp->pname1,qfname);   strcpy(ssgmtp->pname2,sfname);
       ssgmtp->beg1 = ibeg1;   ssgmtp->end1 = iend1;
       ssgmtp->beg2 = ibeg2;   ssgmtp->end2 = iend2;
       ssgmtp->score = scr;
       ssgmtp->length = iend1-ibeg1+1;
       ssgmtp->label = 0;
       ssgmtp->nexth = (struct hit*) NULL;
       pr_hits(ssgmtp);
       hrsfscr[0]+= det_score(S[0],ibeg1,iend1,S[0],ibeg1,iend1);
       hrsfscr[1]+= det_score(S[1],ibeg2,iend2,S[1],ibeg2,iend2);
       if (ibeg1 < mrbeg1) mrbeg1= ibeg1;
       if (iend1 > mrend1) mrend1= iend1;
       if (ibeg2 < mrbeg2) mrbeg2= ibeg2;
       if (iend2 > mrend2) mrend2= iend2;
      }
    }
   nodep= nodep->nexth;
  }

if (sflag==2)
 {while (1)
   {fprintf(stderr,"\n Enter 'q' to quit, 'return' to continue: ");
    if ((answer= getchar())=='q')   {answer= getchar(); break;}
    else
      {fprintf(stderr,"\n Enter positions of segment in protein 1: ");
       scanf("%d %d",&ibeg1,&iend1);
       answer= getchar();   /* ... this absorbs the return character ... */
       fprintf(stderr,"\n Enter positions of segment in protein 2: ");
       scanf("%d %d",&ibeg2,&iend2);
       answer= getchar();   /* ... this absorbs the return character ... */
       if ((scr= det_score(S[0],ibeg1,iend1,S[1],ibeg2,iend2)) == 0) continue;
       fprintf(outfp,"\nSegment Pair %2d:  %4d to %4d vs %4d to %4d;",
		++segnum, ibeg1, iend1, ibeg2, iend2 );
       fprintf(outfp," length: %5d; score: %5d", iend1-ibeg1+1, scr);
       ascore+= scr;   alength+= iend1-ibeg1+1;
       ssgmtp= (struct hit *) malloc(sizeof(struct hit));
       strcpy(ssgmtp->pname1,qfname);   strcpy(ssgmtp->pname2,sfname);
       ssgmtp->beg1 = ibeg1;   ssgmtp->end1 = iend1;
       ssgmtp->beg2 = ibeg2;   ssgmtp->end2 = iend2;
       ssgmtp->score = scr;
       ssgmtp->length = iend1-ibeg1+1;
       ssgmtp->label = 0;
       ssgmtp->nexth = (struct hit*) NULL;
       pr_hits(ssgmtp);
       hrsfscr[0]+= det_score(S[0],ibeg1,iend1,S[0],ibeg1,iend1);
       hrsfscr[1]+= det_score(S[1],ibeg2,iend2,S[1],ibeg2,iend2);
       if (ibeg1 < mrbeg1) mrbeg1= ibeg1;
       if (iend1 > mrend1) mrend1= iend1;
       if (ibeg2 < mrbeg2) mrbeg2= ibeg2;
       if (iend2 > mrend2) mrend2= iend2;
      }
   }
 }

sfscr[0]= det_score(S[0],1,psize[0],S[0],1,psize[0]);
sfscr[1]= det_score(S[1],1,psize[1],S[1],1,psize[1]);
if (sfscr[0]<=sfscr[1]) {minsfscr= sfscr[0]; maxsfscr= sfscr[1];}
else                    {minsfscr= sfscr[1]; maxsfscr= sfscr[0];}
if (psize[0]<=psize[1]) {minpsize= psize[0]; maxpsize= psize[1];}
else                    {minpsize= psize[1]; maxpsize= psize[0];}

mrsfscr[0]= det_score(S[0],mrbeg1,mrend1,S[0],mrbeg1,mrend1);
mrsfscr[1]= det_score(S[1],mrbeg2,mrend2,S[1],mrbeg2,mrend2);
if (mrsfscr[0]<=mrsfscr[1]) {minmrsfscr= mrsfscr[0]; maxmrsfscr= mrsfscr[1];}
else                        {minmrsfscr= mrsfscr[1]; maxmrsfscr= mrsfscr[0];}
mrlgth[0]= mrend1-mrbeg1+1; mrlgth[1]= mrend2-mrbeg2+1;
if (mrlgth[0]<=mrlgth[1])
 {minmrlgth= mrlgth[0]; maxmrlgth= mrlgth[1];}
else
 {minmrlgth= mrlgth[1]; maxmrlgth= mrlgth[0];}

if (hrsfscr[0]<=hrsfscr[1]) {minhrsfscr= hrsfscr[0]; maxhrsfscr= hrsfscr[1];}
else                        {minhrsfscr= hrsfscr[1]; maxhrsfscr= hrsfscr[0];}

fprintf(outfp,"\n\nQuery  sequence:   length= %4d, selfscore= %6d",
	psize[0],sfscr[0]);
fprintf(outfp,"\n     matching region: %4d to %4d",mrbeg1,mrend1);
fprintf(outfp," (%4d aa [%4.2f], selfscore %4d)",
	mrlgth[0],(float)(mrlgth[0])/psize[0],mrsfscr[0]);
fprintf(outfp,"\nSearch sequence:   length= %4d, selfscore= %6d",
	psize[1],sfscr[1]);
fprintf(outfp,"\n     matching region: %4d to %4d",mrbeg2,mrend2);
fprintf(outfp," (%4d aa [%4.2f], selfscore %4d)",
	mrlgth[1],(float)(mrlgth[1])/psize[1],mrsfscr[1]);
fprintf(outfp,"\nAggregate hit length: %6d (%4.2f/%4.2f);", alength,
	(float)alength/maxpsize, (float)alength/minpsize);
fprintf(outfp," aggregate hit score: %6d\n", ascore);
fprintf(outfp,"\nAverage per letter scores:    %6.2f/%6.2f (max: %6.2f)",
	(float)ascore/maxpsize, (float)ascore/minpsize,
	0.5*((float)sfscr[0]/psize[0] + (float)sfscr[1]/psize[1]) );
fprintf(outfp,
	"\n%s %s SSPA values:   %4.2f/%4.2f   %4.2f/%4.2f   %4.2f/%4.2f\n",
	qfname, sfname,
	(float)ascore/maxsfscr, (float)ascore/minsfscr,
	(float)ascore/maxmrsfscr, (float)ascore/minmrsfscr,
	(float)ascore/maxhrsfscr, (float)ascore/minhrsfscr);
fprintf(outfp,"\n________________________________________");
fprintf(outfp,"_____________________________\n");

} /* end sspa_score() */



det_score(p1,beg1,end1,p2,beg2,end2)
char *p1, *p2;
int beg1, end1, beg2, end2;
{
int i, score= 0;

if (beg1 > end1 || beg2 > end2 || end1-beg1 != end2-beg2 )
 {fprintf(stderr,"\nWARNING: inconsistent coordinates entered! Ignored.\n");
  return(0);
 }

for (i=0;i<=end1-beg1;++i)
 score+= smat[*(p1 + beg1 -1 +i)][*(p2 + beg2 -1 +i)];

return(score);

} /* end det_score() */



absd(a,b)
int a,b;
{
return(a-b>0?a-b:b-a);
} /* end absd() */



min2(a,b)
int a,b;
{
return(a<b?a:b);
} /* end min2() */



/******************************************************************************/
/* COMPARE QUERY AND GIVEN SEARCH SEQUENCE:                                   */
/*                                                                            */
self(numaa)
int numaa;
{
int i, j;
int errflag= 0, hcount;
struct hit *oh_headp= NULL, *ch_headp= NULL, *rh_headp= NULL;

psize[1]= numaa;
for (i=0;i<psize[0];++i)   SEQ[1][i]= protein[i];
SEQ[1][psize[1]]= '\0';   S[1]= SEQ[1];
for (i=0;i<24;++i)   rcnt[1][i]= rcnt[0][i];

/******************************************************************************/
/* DETERMINE PARAMETERS USING SEARCH FILE SPECIFIC RESIDUE FREQUENCIES:       */
/*                                                                            */
if (!fflag)
 {for (i=0;i<= MAXRANGE;++i) pr[i]=0;
  for (i=0;i<23;++i) for (j=0;j<23;++j) 
   pr[smat[i][j]-minsc]+= ((float) rcnt[0][i]*rcnt[1][j])/(psize[0]*psize[1]);
  if (!karlin(minsc,maxsc,pr,&lambda,&K,&AIL,0))
   {fprintf(outfp,"\n\nERROR: karlin.c() returned 0.\n");
    errflag= 1;
    if (pstyle%2==0)
     {fprintf(outfp,"________________________________________");
      fprintf(outfp,"________________________________________\n\n");
     }
   }
  else if (pstyle==4)
   fprintf(outfp,"\nLambda= %6.3f   K= %6.3f   H= %6.3f.\n",lambda,K,AIL);
 }
/*                                                                            */
/******************************************************************************/


/******************************************************************************/
/* DETERMINE, SORT, AND PRINT PAIRWISE HITS:                                  */ 
/*                                                                            */
if (!errflag)
 {if (tssize) lowp/= ((float)tssize/psize[1]);
  if (tscore < 0)   tscore= (int)(log(-K*psize[0]*psize[1]/log(1-lowp))/lambda);
  drpoff= (floor)(DFACT*tscore);
  if ((hcount=det_hits(1,&oh_headp,&ch_headp)))
   {
    if (pstyle%2==0)
     fprintf(outfp,"\nTSCORE:  %3d;  DFACT:  %4.2f;   NUMBER OF HITS: %3d.\n",
	tscore, DFACT, hcount);

    fprintf(outfp,"\nDIAGONAL-ORDERED HITS:\n");
    pr_hits(oh_headp);

/*
if (CHECKFLAG) {
    fprintf(outfp,"\nDIAGONAL-ORDERED HITS:\n");
    pr_hits(oh_headp);
 }

    order_by_score(&oh_headp);
    if (oh_headp != NULL)   MAJORDIAG= oh_headp->beg1 - oh_headp->beg2;
    if (!sflag)
     {if (pstyle!=3) fprintf(outfp,"\nSCORE-ORDERED HITS:\n");
      pr_hits(oh_headp);
     }
    else
     {fprintf(outfp,"\nOPTIMIZED CONSISTENTLY ORDERED HITS:\n");
      order_cnstly(&oh_headp,&rh_headp);
      while (check_bfpr(oh_headp))
       {order_by_score(&oh_headp); order_cnstly(&oh_headp,&rh_headp);}
      pr_hits(oh_headp);
      sspa_score(oh_headp);
     }

if (CHECKFLAG && ch_headp != NULL) {
    fprintf(outfp,"\nCOMBINED HITS:\n");
    order_by_beg1(&ch_headp);
    pr_hits(ch_headp);
 }

    if (pstyle%2==0 && sflag && rh_headp != NULL)
     {fprintf(outfp,"\nHITS NOT INCLUDED IN THE CONSISTENT ORDERING:\n");
      order_by_beg1(&rh_headp);
      pr_hits(rh_headp);
     }
*/
   
    free_hits(oh_headp);
    free_hits(ch_headp);
    free_hits(rh_headp);
   }
  else
   {if (pstyle%2==0)
     {fprintf(outfp,"\nNO HITS.\n");
     }
   }
 } /* end-if(!errflag) */
/*                                                                            */
/******************************************************************************/

} /* end self() */
