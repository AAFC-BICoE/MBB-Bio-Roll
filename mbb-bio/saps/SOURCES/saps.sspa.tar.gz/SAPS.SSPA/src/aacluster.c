/* AACLUSTER.C;                                 Last update: March 19, 1997. */
/*   - a subroutine to identify specific amino acid clusters in protein      */
/*   sequences.                                                              */
/* Dependencies:   called by saps.c; calls mFct.c, tFct.c                    */
/* Bugs:                                                                     */

/*   Volker Brendel, Department of Mathematics, Stanford University,  */
/*   Stanford CA 94305; (415) 723-9256, volker@gnomic.stanford.edu    */

#include <stdio.h>
#include "def.h"
#define WNDLGTH1     30
#define WNDLGTH2     45
#define WNDLGTH3     60
extern int protein[PROTLGTH], occpos[PROTLGTH];
extern pstyle;
extern int af[23];
extern char sfname[81];
extern FILE *outfp;
extern char AAUC[25];
int pmask[4][23]= { {0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
		    {0,0,0,1,0,0,1,1,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0},
		    {0,0,0,0,0,0,0,0,0,0,0,1,0,0,1,0,0,0,0,0,0,0,0},
		    {0,0,0,1,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}
		  };

aacluster(numaa,aa)   /* ... finds significant clusters of certain amino */
		      /* acids ... */
int numaa, aa;
{
int i,j ,l;
int count;
int swp[PROTLGTH], lmax[PROTLGTH];
float prop= 0;
double t, tmax[PROTLGTH];
int min1, min2, min3;
int mFct();
double tFct();
int prti;
int prtpos[20], prtlgt[20];
double prttvl[20];
int swc= 0;
int prc= 0;
int totct= 0;
int last_letter, mpl, pst;

if (0<=aa && aa<=22)   /* - residue clusters */
  {prop= (float)af[aa]/(float)numaa;
   for(i=0;i<numaa;++i)
     {if (protein[i]==aa)
       {++totct;occpos[totct]=i;continue;}
     }
  }
if (50<=aa && aa<70)   /* - combined residue clusters */
  {for(i=0;i<23;++i)   if (pmask[aa-50][i])  prop+= (float)af[i];
   prop/= (float)numaa;
   for(i=0;i<numaa;++i)
     {if (pmask[aa-50][protein[i]])
       {++totct;occpos[totct]=i;continue;}
     }
  }
if (aa==70)   /* - multiplet clusters */
  {last_letter= protein[0]; mpl= 1; pst= 0;
   for (i=1;i<numaa;++i)
     {if (protein[i]==last_letter)   {++mpl; continue;}
      if (mpl>1)   occpos[++totct]= ++pst; 
      else ++pst;
      last_letter= protein[i];   mpl= 1;
     }
   if (mpl>1)   occpos[++totct]= ++pst;
   else ++pst;
   prop= (float)totct/(float)pst;
  }

min1 = mFct(7.0,WNDLGTH1,prop);
min2 = mFct(7.0,WNDLGTH2,prop);
min3 = mFct(7.0,WNDLGTH3,prop);

for( i=1; i<totct; ++i )
  {if( i+min1-1 <= totct )
     {if( occpos[i+min1-1] - occpos[i] + 1 <= WNDLGTH1 )
        {swp[swc] = i; ++swc; continue;}
     }
   else		continue;
   if( i+min2-1 <= totct )
     {if( occpos[i+min2-1] - occpos[i] + 1 <= WNDLGTH2 )
        {swp[swc] = i; ++swc; continue;}
     }
   else		continue;
   if( i+min3-1 <= totct )
     {if( occpos[i+min3-1] - occpos[i] + 1 <= WNDLGTH3 )
        {swp[swc] = i; ++swc;}
     }
  }

for( i=0; i<swc; ++i )
  {count=1; tmax[i]=0; lmax[i]=0;
   for( j=1; swp[i]+j <= totct; ++j )
     {++count;
      if( count < min1 )	continue;
      l = occpos[swp[i]+j] - occpos[swp[i]] + 1;
      t = tFct(count,l,prop);
      if( t > tmax[i] )   {tmax[i]=t; lmax[i]=l;}
      if( l > 75 )	break;
     }
  }

if( swc==1 )
  {prtpos[0] = occpos[swp[0]];
   prtlgt[0] = lmax[0]; prttvl[0] = tmax[0];
   prc = 1;
  }
if( swc>1 )
   {prti = 0;
    prc = 0;
    for( i=1; i<swc; ++i )
      {if( occpos[swp[i]] > occpos[swp[prti]] + lmax[prti] + 8)
   	 {prtpos[prc] = occpos[swp[prti]];
	  prtlgt[prc] = lmax[prti];
	  prttvl[prc] = tmax[prti];
   	  ++prc;
	  prti = i;
	 }
       else
         {if( occpos[swp[i]] + lmax[i] == 
	      occpos[swp[prti]] + lmax[prti] )
	    {if( tmax[i] > tmax[prti] )		prti = i;}
	  else
	    {count=0;
             for( j=swp[prti]; occpos[j]<=occpos[swp[i]]+lmax[i]-1; ++j)
	       {++count;
	        if( occpos[j] == occpos[totct] )	break;
	       }
	     l =  occpos[swp[i]] + lmax[i] - occpos[swp[prti]];
	     t =  tFct(count,l,prop);
	     if( tmax[i] > tmax[prti] )		prti = i;
	     if( t > tmax[prti] )  {lmax[prti] = l;  tmax[prti] = t;}
	    }
	  }
      }
    prtpos[prc] = occpos[swp[prti]];
    prtlgt[prc] = lmax[prti];
    prttvl[prc] = tmax[prti];
    ++prc;
   }

if (pstyle==1 && prc==0)   return;

if (pstyle%2==0)   fprintf(outfp,"\n");
fprintf(outfp,"\nClusters of ");
if (0<=aa && aa<=22)   fprintf(outfp,"%c",AAUC[aa]);
if (50<=aa && aa<70)
  {for(i=0;i<23;++i)   if (pmask[aa-50][i])   fprintf(outfp,"%c",AAUC[i]);}
if (aa==70)   fprintf(outfp,"multiplets");
fprintf(outfp," (cmin = %2d/%2d or %2d/%2d or %2d/%2d):",
	min1, WNDLGTH1, min2, WNDLGTH2, min3, WNDLGTH3);
for( j=0; j<prc; ++j )
     pr_aacluster(numaa,aa,j+1,prtpos[j],prtlgt[j],prttvl[j]);
if( prc==0 )  fprintf(outfp,"  none\n");

}



pr_aacluster(numaa,aa,num,wstart,wlgth,tval)
int numaa, aa, num, wstart, wlgth;
double tval;
{
int i, j, q;
int cnt= 0;
int cf[20];

for( i=0;i<=19;++i )   cf[i]= 0;


fprintf(outfp,"\n\n %1d) From %4d to %4d:   ", num, wstart+1, wstart+wlgth);

if (wlgth <= 55)
  {for( i=wstart; i < wstart+wlgth; ++i )
	fprintf(outfp,"%c", AAUC[protein[i]] );
  }
else	fprintf(outfp,"see sequence above" );

for( i=wstart;i < wstart+wlgth;++i )
  {if (0<=aa && aa<=22)   /* - residue clusters */
     if ( protein[i] == aa )  ++cnt;
   if (50<=aa && aa<70)   /* - combined residue clusters */
     if (pmask[aa-50][protein[i]])  ++cnt;
  }

q= (int)(4.*(float)wstart/(float)numaa)%4 +1;
fprintf(outfp,"\n    quartile: %1d;  size: %2d, count of ", q, wlgth);
if (0<=aa && aa<=22)   fprintf(outfp,"%c",AAUC[aa]);
if (50<=aa && aa<70)
  {for(i=0;i<23;++i)   if (pmask[aa-50][i])   fprintf(outfp,"%c",AAUC[i]);}
fprintf(outfp,": %3d;  t-value: %5.2f\n", cnt, tval );

if (pstyle%2==0)
  {q= 0;
   for( i=wstart; i < wstart+wlgth; ++i )
     for( j=0;j<20;++j )
        if ( AAUC[protein[i]] == AAUC[j] )   {++cf[j]; break;}
   for( i=0; i<=19; ++i )  
     {if ( 100.*(float)cf[i]/(float)wlgth >= 10.0 )
        {if (q==0)   fprintf(outfp,"  ");
	 if ((++q)%5==0)   fprintf(outfp,"\n  ");
         fprintf(outfp, "  %c: %2d (%4.1f%%);", AAUC[i], cf[i],
		100.*(float)cf[i]/(float)wlgth ); 
	}
     }
   if ( 100.*(float)(cf[0]+cf[4]+cf[9]+cf[13]+cf[17])/(float)wlgth >= 25.0 )
     {if (q%4==0)   {fprintf(outfp,"\n  "); ++q;}
      fprintf(outfp,"  LVIFM: %2d (%4.1f%%);", cf[0]+cf[4]+cf[9]+cf[13]+cf[17],
		100.*(float)(cf[0]+cf[4]+cf[9]+cf[13]+cf[17])/(float)wlgth );
     }
   if ( 100.*(float)(cf[3]+cf[7])/(float)wlgth >= 15.0 )
     {if (q%4==0)   fprintf(outfp,"\n  ");
      fprintf(outfp,"  ST: %2d (%4.1f%%);", cf[3]+cf[7],
		100.*(float)(cf[3]+cf[7])/(float)wlgth );
     }
  }

}
