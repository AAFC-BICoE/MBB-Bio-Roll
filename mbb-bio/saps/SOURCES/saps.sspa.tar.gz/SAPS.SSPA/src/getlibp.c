/* GETLIBP.C;                                 Last update: November 7, 1994. */
/*   - a subroutine to read a protein sequence in library file format.       */
/* Dependencies:   called by aaruns.c, mproc.c, pgrep.c, pmagic.c, pmotif.c, */
/*   propeat.c, prorep.c, prostat.c, pscore.c, psearch.c, pword.c, saps.c,   */
/*   zipscan.c                                                               */
/* Bugs:                                                                     */

/*   Volker Brendel, Department of Mathematics, Stanford University,  */
/*   Stanford CA 94305; (415) 723-9256, volker@gnomic.stanford.edu    */

#include <stdio.h>
#include "def.h"
extern FILE *outfp;
extern char sfname[81];
extern int pstyle;


getlibp(seq,fp,molwt)
int *seq; FILE *fp; float *molwt;
{
char buf[PROTLGTH];
int n= 0, j, l, nsflag= 0;
static float aamw[23] =
 { 113.16, 71.09, 57.05, 87.08, 99.14, 128.17, 129.12, 101.11,
   115.09, 113.16, 156.19, 97.12, 114.11, 147.18, 128.14, 163.18,
   137.14, 131.19, 103.15, 186.21, 114.60, 128.63, 119.40 };

for (j=0;j<81;++j)   sfname[j]= '\0';

fgets(buf,PROTLGTH,fp);
if (buf[0]=='>')
  {for (j=4,l=0; buf[j]!='\n' && buf[j]!=':'; ++j)
    {if (buf[j]!=' ')   {sfname[l++]= buf[j]; nsflag= 1;}
     else if (nsflag) break;
    }
  }

while (fgets(buf,PROTLGTH,fp) && buf[0]!='>')
  {l= strlen(buf);
   for (j=0;j<l;j++)
     {if ( buf[j]=='L' )  {seq[n++] =  0; *molwt+=  aamw[0]; continue;}
      if ( buf[j]=='A' )  {seq[n++] =  1; *molwt+=  aamw[1]; continue;}
      if ( buf[j]=='G' )  {seq[n++] =  2; *molwt+=  aamw[2]; continue;}
      if ( buf[j]=='S' )  {seq[n++] =  3; *molwt+=  aamw[3]; continue;}
      if ( buf[j]=='V' )  {seq[n++] =  4; *molwt+=  aamw[4]; continue;}
      if ( buf[j]=='K' )  {seq[n++] =  5; *molwt+=  aamw[5]; continue;}
      if ( buf[j]=='E' )  {seq[n++] =  6; *molwt+=  aamw[6]; continue;}
      if ( buf[j]=='T' )  {seq[n++] =  7; *molwt+=  aamw[7]; continue;}
      if ( buf[j]=='D' )  {seq[n++] =  8; *molwt+=  aamw[8]; continue;}
      if ( buf[j]=='I' )  {seq[n++] =  9; *molwt+=  aamw[9]; continue;}
      if ( buf[j]=='R' )  {seq[n++] = 10; *molwt+= aamw[10]; continue;}
      if ( buf[j]=='P' )  {seq[n++] = 11; *molwt+= aamw[11]; continue;}
      if ( buf[j]=='N' )  {seq[n++] = 12; *molwt+= aamw[12]; continue;}
      if ( buf[j]=='F' )  {seq[n++] = 13; *molwt+= aamw[13]; continue;}
      if ( buf[j]=='Q' )  {seq[n++] = 14; *molwt+= aamw[14]; continue;}
      if ( buf[j]=='Y' )  {seq[n++] = 15; *molwt+= aamw[15]; continue;}
      if ( buf[j]=='H' )  {seq[n++] = 16; *molwt+= aamw[16]; continue;}
      if ( buf[j]=='M' )  {seq[n++] = 17; *molwt+= aamw[17]; continue;}
      if ( buf[j]=='C' )  {seq[n++] = 18; *molwt+= aamw[18]; continue;}
      if ( buf[j]=='W' )  {seq[n++] = 19; *molwt+= aamw[19]; continue;}
      if ( buf[j]=='B' )  {seq[n++] = 20; *molwt+= aamw[20]; continue;}
      if ( buf[j]=='Z' )  {seq[n++] = 21; *molwt+= aamw[21]; continue;}
      if ( buf[j]=='X' )  {seq[n++] = 22; *molwt+= aamw[22]; continue;}
     }
  }

if (buf[0]=='>') fseek(fp,(long) -strlen(buf),1);

return (n);
}
