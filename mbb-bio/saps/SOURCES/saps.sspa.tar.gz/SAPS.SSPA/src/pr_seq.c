/* PR_SEQ.C;                                 Last update: November 29, 1995. */
/*   - a subroutine to print a sequence array.                               */
/* Dependencies:   called by codcmp.c prostat.c saps.c sspa.c                */
/* Bugs:                                                                     */

/*   Volker Brendel, Department of Mathematics, Stanford University,  */
/*   Stanford CA 94305; (415) 723-9256, volker@gnomic.stanford.edu    */

#include <stdio.h>
#include "def.h"


pr_seq(fp,seq,length,ABC,ftflag)   /* prints seq[] in ABC translation */
FILE *fp; int *seq, length, ftflag; char ABC[];
{
int i;

for (i=0;i<length;++i)
 {if (ftflag==1 && i%10==0)   fprintf(fp," ");
  if (ftflag==1 && i%60==0)   fprintf(fp,"\n  %8d  ",i+1);
  if (ftflag==2 && i%80==0)   fprintf(fp,"\n");
  fprintf(fp,"%c", ABC[seq[i]] );
 }
fprintf(fp,"\n");

} /* end pr_seq() */
