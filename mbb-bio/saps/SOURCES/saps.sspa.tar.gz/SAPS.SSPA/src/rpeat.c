/* RPEAT.C;                                     Last update: April 11, 1993. */
/*   - a subroutine to find internal repeats in protein sequences.           */
/* Dependencies:   called by saps.c and prorep.c; calls period.c.            */
/* Bugs:                                                                     */

/*   Volker Brendel & Illah Nourbakhsh, Department of Mathematics,           */
/*   Stanford University, Stanford CA 94305;                                 */
/*   (415) 723-9256, volker@gnomic.stanford.edu                              */

#include <stdio.h>
#include <string.h>
#include <math.h>
#include "def.h"
extern int protein[PROTLGTH];
extern FILE *outfp;

#define MAXSNODE 500	/* maximum number of sequences in one node */
#define AMBSEQMX  20

#define ERRORMSG1 "\nError in rpeat():\n\
 The %d-word/pattern at positions %d to %d is repeated more than %d times.\n\
Recompile with MAXSNODE > %d.\n"

#define ERRORMSG2 "\nError in rpeat():\n\
 remove_from_alignment()\
has been called with nodep for which nodep->index1=%3d\n\
is not found in the index1head list! This must be due to a programming error.\n"

#define ERRORMSG3 "\nError in rpeat():\n\
 index1print()\
did not find any index1=%3d supersets! This must be a programming error.\n"

#define ERRORMSG4 "\nError in rpeat():\n\
Reading parameters from the file 'rpeat.par' failed.\n\
rpeat.par should have the following format (default values shown):\n\n\
PRCENTMMIN 0.75\n\
MAXCSFREX 10\n\
BIGNODE 5\n\
TOOBIGTOPRINT 12\n\
CONSENSUS 60\n\
PFACTOR 10\n\
BFACTOR 1.5\n\
SLANTERROR 3\n\
ALIGNMAX 50\n\n"


int SQLGTH, CBSIZE, nocc_2[PROTLGTH], nextocc_cb[PROTLGTH];

int ignorelist[PROTLGTH];
int strcount;
int INDEX, MINPRD, MSGPRT, FirstPrint, FinalPrint;

int MAXCSFREX= 10, BIGNODE= 5, TOOBIGTOPRINT= 12, CONSENSUS= 60;
int PFACTOR= 10, SLANTERROR= 3, ALIGNMAX= 50;
float PRCENTMMIN= 0.75, BFACTOR= 1.5;

struct group {
	int crd[MAXSNODE][2];
	int nodesize;
	int noprtflag;
        int index1;
	int index2;
	struct group *nextgroup;
	struct group *leftwing;
	struct group *rightwing;
} *groupshead, *index1head, *index2head;

struct ogroup {
 	int beg;
	int end;
	int cslant;
	struct ogroup *next;
} *ogroupshead;

int TRL[26]; char SYMB[26];



rpeat(numaa,ABC,cbsze,mnprd,mpflag,rpflag) 
int numaa, ABC, cbsze, mnprd, mpflag, rpflag;
{
int i;

SQLGTH= numaa; CBSIZE= cbsze; MINPRD= mnprd; MSGPRT= mpflag;

strcount= INDEX= 0;
groupshead= index1head= index2head= NULL;
ogroupshead= NULL;

SYMB[25]= '_';
if (ABC==1)   /* amino acid alphabet */
  {strcpy(SYMB,"LAGSVKETDIRPNFQYHMCWBZX");
   for( i=0;i<26;++i)   TRL[i]= i;
  }

if (ABC==2)   /* 11-letter reduced alphabet */
  {strcpy(SYMB,"i+-sonaphmcx");
   TRL[0]= 0; TRL[1]= 3; TRL[2]= 3; TRL[3]= 4; TRL[4]= 0;
   TRL[5]= 1; TRL[6]= 2; TRL[7]= 4; TRL[8]= 2; TRL[9]= 0;
   TRL[10]= 1; TRL[11]= 7; TRL[12]= 5; TRL[13]= 0; TRL[14]= 5;
   TRL[15]= 6; TRL[16]= 8; TRL[17]= 9; TRL[18]= 10; TRL[19]= 6;
   TRL[20]= 11; TRL[21]= 11; TRL[22]= 11; TRL[25]= 25;
  }

if (ABC==3)   /* 8-letter chemical alphabet */
  {strcpy(SYMB,"ABHILMRSX");
   TRL[0]= 4; TRL[1]= 4; TRL[2]= 4; TRL[3]= 2; TRL[4]= 4;
   TRL[5]= 1; TRL[6]= 0; TRL[7]= 2; TRL[8]= 0; TRL[9]= 4;
   TRL[10]= 1; TRL[11]= 3; TRL[12]= 5; TRL[13]= 6; TRL[14]= 5;
   TRL[15]= 6; TRL[16]= 1; TRL[17]= 7; TRL[18]= 7; TRL[19]= 6;
   TRL[20]= 8; TRL[21]= 8; TRL[22]= 8; TRL[25]= 25;
  }

if (rpflag)   readpar();   /* - THEN READ PARAMETERS FROM FILE rpeat.par */

nextocc_2();   nexocc_cb(2,nocc_2);
 
for (i=0;i<SQLGTH-CBSIZE;++i)
 if (nextocc_cb[i] != 0 && ignorelist[i] == 0)   makenode(i);  

	if (MSGPRT) fprintf(outfp,"\n\n\nNOW ENTERING rmv_subsets.");  
if (groupshead != NULL)   rmv_subsets();
	if (MSGPRT) {fprintf(outfp,"\nAFTER rmv_subsets:\n\n"); print_amb();}
 
	if (MSGPRT) fprintf(outfp,"\n\n\nNOW ENTERING rmv_simplenodes.");  
if (groupshead != NULL)   rmv_simplenodes();
	if (MSGPRT) {fprintf(outfp,"\nAFTER rmv_simplenodes:\n\n"); print_amb();}
 
	if (MSGPRT) fprintf(outfp,"\n\n\nNOW ENTERING mesh_ovlsets.");
if (groupshead != NULL)   mesh_ovlsets();
	if (MSGPRT) {fprintf(outfp,"\nAFTER mesh_ovlsets:\n\n"); print_amb();}

	if (MSGPRT) fprintf(outfp,"\n\n\nNOW ENTERING clfy_nodes."); 
if (groupshead != NULL)   clfy_nodes(); 
	if (MSGPRT) {fprintf(outfp,"\nAFTER clfy_nodes:\n\n"); print_amb();}

	if (MSGPRT) fprintf(outfp,"\n\n\nNOW ENTERING det_str."); 
if (groupshead != NULL)   det_str(); 
	if (MSGPRT) {fprintf(outfp,"\nAFTER det_str:\n\n"); print_amb();}

	if (MSGPRT) fprintf(outfp,"\n\n\nNOW ENTERING cleanhrr."); 
if (groupshead != NULL)   cleanhrr();

	if (MSGPRT) fprintf(outfp,"\n\n\nNOW ENTERING aligngroups."); 
if (groupshead != NULL)   aligngroups();
	if (MSGPRT) {fprintf(outfp,"\nAFTER aligngroups:\n\n"); print_amb();} 

if (groupshead != NULL)   makedoublylinked();

	if (MSGPRT) fprintf(outfp,"\n\n\nNOW ENTERING unalignsubsets."); 
if (groupshead != NULL)   unalignsubsets(); 
	if (MSGPRT) {fprintf(outfp,"\nAFTER unalignsubsets:\n\n"); print_amb();}

	if (MSGPRT) fprintf(outfp,"\n\n\nNOW ENTERING remove_subsets."); 
if (groupshead != NULL)   remove_subsets(groupshead);

	if (MSGPRT) fprintf(outfp,"\n\n\nNOW ENTERING extendgroups.");
if (groupshead != NULL)   extendgroups();
	if (MSGPRT) {fprintf(outfp,"\nAFTER extendgroups:\n\n"); print_amb();}

	if (MSGPRT) fprintf(outfp,"\n\n\nNOW ENTERING lexterror.");
if (groupshead != NULL)   lexterror();
	if (MSGPRT) {fprintf(outfp,"\nAFTER lexterror:\n\n"); print_amb();}

	if (MSGPRT) fprintf(outfp,"\n\n\nNOW ENTERING cleanalignments(1).");
if (groupshead != NULL)   cleanalignments(1);
  if (MSGPRT) {fprintf(outfp,"\nAFTER cleanalignments(1):\n\n"); print_amb();}

	if (MSGPRT) fprintf(outfp,"\n\n\nNOW ENTERING cleanalignments(2).");
if (groupshead != NULL)   cleanalignments(2);
  if (MSGPRT) {fprintf(outfp,"\nAFTER cleanalignments(2):\n\n"); print_amb();}

	if (MSGPRT) fprintf(outfp,"\n\n\nNOW ENTERING olmesh.");
if (ogroupshead != NULL)   olmesh(); 

	if (MSGPRT) fprintf(outfp,"\n\n\nNOW ENTERING extendends.");
if (ogroupshead != NULL)   extendends();  

	if (MSGPRT) fprintf(outfp,"\n\n\nNOW ENTERING remove_subsets.");
if (index2head != NULL)   remove_subsets(index2head); 

	if (MSGPRT) fprintf(outfp,"\n\n\nNOW ENTERING order_by_place.");
if (groupshead != NULL)   order_by_place();

if (MSGPRT) fprintf(outfp,
	"\n\n\nNOW PRINTING THE FINAL OUTPUT AFTER REORDERING:\n\n"); 

FirstPrint= 1; FinalPrint= 1;
if (groupshead != NULL)   print_amb();
if (groupshead != NULL)   print_str();
if (ABC==1  &&  ogroupshead != NULL)   print_pdr();
if (groupshead != NULL)   print_hrr();

} /* end rpeat() */



/* nextocc_2 CREATES THE ARRAY nocc_2[]; nocc_2[i] IS THE FIRST INDEX nxt
   GREATER THAN i FOR WHICH protein[nxt]=protein[i] AND protein[nxt+1]=
   protein[i+1], OR 0 IF SUCH nxt DOES NOT EXIST. */
nextocc_2()
{
int i, nxt;

for (i=0;i<SQLGTH;i++) nocc_2[i]= 0;

for (i=0;i<SQLGTH-2;i++)
 {for (nxt=i+1; (TRL[protein[nxt]] != TRL[protein[i]] || TRL[protein[nxt+1]]
       != TRL[protein[i+1]]) && nxt < SQLGTH-1; ++nxt) {}
  if (nxt < SQLGTH-1)   nocc_2[i]= nxt;
 }

} /* end nextocc_2() */
 


int nextocc_t[PROTLGTH];

/* nextocc_cb CREATES THE ARRAY nocc_cb[]; nocc_cb[i] IS THE FIRST INDEX nxt
   GREATER THAN i FOR WHICH protein[nxt]=protein[i], protein[nxt+1]=
   protein[i+1], ..., protein[nxt+CBSIZE-1]= protein[i+CBSIZE+1], OR 0 IF
   SUCH nxt DOES NOT EXIST. */
nexocc_cb(csize,nextocc)
int csize, nextocc[];
{
int i, nxt, delta=0;

for (i=0;i<SQLGTH;i++)   nextocc_cb[i]=0;

if (csize*2 <= CBSIZE)   delta= csize;
else   delta= CBSIZE - csize;

for (i=0;i<SQLGTH-(delta+csize);i++)
 {for (nxt=nextocc[i];nxt != 0 && !isonpath(nextocc,i+delta,nxt+delta);
       nxt=nextocc[nxt]) {}
  nextocc_cb[i]= nxt;
 }

if (delta>0 && csize+delta < CBSIZE)
 {for (i=0;i<SQLGTH;i++)   nextocc_t[i]= nextocc_cb[i];
  nexocc_cb(csize+delta,nextocc_t);
 }

} /* end nexocc_cb() */



/* isonpath RETURNS 1 IF FOR THE GIVEN nextocc[] THE WORD AT i IS REPEATED
   AT j; ELSE RETURNS 0  */
isonpath(nextocc,i,j)
int nextocc[], i, j;
{

while (nextocc[i] != 0)
 {if (nextocc[i] == j)   return(1);
  if (nextocc[i] >  j)   return(0);
  i= nextocc[i];
 }
return(0);

} /* end isonpath() */



/* makenode PROCESSES THE SET OF CBSIZE REPEATS FIRST ENCOUNTERED AT POSITION
   i IN THE SEQUENCE. THE INITIAL STEP IS CONSTRUCTION OF A CHAIN OF FROM/TO
   COORDINATES OF THE REPEATS. SUCH A CHAIN WILL UNDERGO CHANGES IN TERMS OF
   EXTENSIONS TO THE RIGHT (WITH ERRORS) AND TO THE LEFT. SUBCHAINS WILL END
   UP AS EITHER TYPE 1 NODES (NONOVERLAPPING, MAXIMALLY EXTENDED REPEATS) OR
   AS TYPE 2 NODES (ANCESTORS OF TYPE 1 NODES) */
makenode(i)
int i;
{
int chain[MAXSNODE], chsize;

makechain(i,chain,&chsize);

if (chsize>1) chainanalysis(chain,chsize); 

} /* end makenode() */



/* makechain CREATES THE ARRAY chain[0]...chain[(*chsizep)-1] WHICH CONTAINS
   POSITIONS OF LIKE WORDS OF SIZE CBSIZE THAT DO NOT ALL EXTEND TO THE
   LEFT WITH THE SAME LETTER */
makechain(start,chain,chsizep)
int start, chain[], *chsizep;
{
int i, ibeg;
*chsizep= 0;

if (start==0)   ibeg= nextocc_cb[start];
else   ibeg= start;

for (i=nextocc_cb[ibeg];i>0;i=nextocc_cb[i])
 if (TRL[protein[i-1]]!=TRL[protein[ibeg-1]])    break;
if (i==0)   return;

if (start==0)   chain[(*chsizep)++]= 0;
for (i=ibeg;i>0;i=nextocc_cb[i])
 {chain[(*chsizep)++]= i;
  if (*chsizep > MAXSNODE)
   {fprintf(stderr,ERRORMSG1,CBSIZE,chain[0]+1,chain[0]+CBSIZE,MAXSNODE,
	    MAXSNODE); fflush(outfp); exit(-1);}
 }

} /* end makechain() */



/* chainanalysis() PROCESSES THE INPUT CHAIN AND (UNLESS DISCARDED) TRANSFORMS
   IT INTO A TYPE 1 NODE PLUS TYPE 2 NODES, INSERTED INTO THE LISTS HEADED By
   groupshead AND index2head, RESPECTIVELY */
chainanalysis(chain,chsize)
int chain[], chsize;
{
int i, j, fromto[MAXSNODE][2], index2;

for (i=0;i<MAXSNODE;i++) fromto[i][0]= fromto[i][1]= 0;
for (i=0;i<chsize;i++) {fromto[i][0]=chain[i]; fromto[i][1]=chain[i]+CBSIZE-1;}

if (MSGPRT)
 {fprintf(outfp,"\n");
  for (i=0;i<chsize;++i)
   {fprintf(outfp,"\nBEG  CHAINANALYSIS: Word #i=%3d at %5d to %5d  ",
	    i, fromto[i][0]+1, fromto[i][1]+1 );
    for (j=0;j<fromto[i][1]-fromto[i][0]+1;++j)
     fprintf(outfp,"%c", SYMB[TRL[protein[fromto[i][0]+j]]]);
   }
 }

rextnoerror(fromto,chsize);

if (MSGPRT)
 {fprintf(outfp,"\n");
  for (i=0;i<chsize;++i)
   {fprintf(outfp,"\nAFTER  REXTNOERROR: Word #i=%3d at %5d to %5d  ",
	    i, fromto[i][0]+1, fromto[i][1]+1 );
    for (j=0;j<fromto[i][1]-fromto[i][0]+1;++j)
     fprintf(outfp,"%c", SYMB[TRL[protein[fromto[i][0]+j]]]);
   }
 }

merge1shifts(fromto,&chsize);

if (MSGPRT)
 {fprintf(outfp,"\n");
  for (i=0;i<chsize;++i)
   {fprintf(outfp,"\nAFTER MERGE1SHIFTS: Word #i=%3d at %5d to %5d  ",
	    i, fromto[i][0]+1, fromto[i][1]+1 );
    for (j=0;j<fromto[i][1]-fromto[i][0]+1;++j)
     fprintf(outfp,"%c", SYMB[TRL[protein[fromto[i][0]+j]]]);
   }
 }

prcentmatch(fromto,&chsize);

if (chsize==1) return;	/* chsize==1 AT THIS POINT INDICATES THAT THE REPEAT
			   CHAIN IS A SINGLE REITERATION OF ONE LETTER */

if (MSGPRT)
 {fprintf(outfp,"\n");
  for (i=0;i<chsize;++i)
   {fprintf(outfp,"\nAFTER  PRCENTMATCH: Word #i=%3d at %5d to %5d  ",
	    i, fromto[i][0]+1, fromto[i][1]+1 );
    for (j=0;j<fromto[i][1]-fromto[i][0]+1;++j)
     fprintf(outfp,"%c", SYMB[TRL[protein[fromto[i][0]+j]]]);
   }
 }

index2= rexterror(fromto,&chsize);

if (MSGPRT)
 {fprintf(outfp,"\n");
  for (i=0;i<chsize;++i)
   {fprintf(outfp,"\nAFTER    REXTERROR: Word #i=%3d at %5d to %5d  ",
	    i, fromto[i][0]+1, fromto[i][1]+1 );
    for (j=0;j<fromto[i][1]-fromto[i][0]+1;++j)
     fprintf(outfp,"%c", SYMB[TRL[protein[fromto[i][0]+j]]]);
   }
 }

rextone(fromto,chsize);

if (MSGPRT)
 {fprintf(outfp,"\n");
  for (i=0;i<chsize;++i)
   {fprintf(outfp,"\nAFTER      REXTONE: Word #i=%3d at %5d to %5d  ",
	    i, fromto[i][0]+1, fromto[i][1]+1 );
    for (j=0;j<fromto[i][1]-fromto[i][0]+1;++j)
     fprintf(outfp,"%c", SYMB[TRL[protein[fromto[i][0]+j]]]);
   }
 }

lextnoerror(fromto,chsize);

if (MSGPRT)
 {fprintf(outfp,"\n");
  for (i=0;i<chsize;++i)
   {fprintf(outfp,"\nAFTER  LEXTNOERROR: Word #i=%3d at %5d to %5d  ",
	    i, fromto[i][0]+1, fromto[i][1]+1 );
    for (j=0;j<fromto[i][1]-fromto[i][0]+1;++j)
     fprintf(outfp,"%c", SYMB[TRL[protein[fromto[i][0]+j]]]);
   }
 }

make1node(fromto,chsize,index2);

} /* end chainanalysis() */



/* rextnoerror TAKES THE fromto[][] POSITIONS OF THE WORDS OF THE CURRENT
   CHAIN OF SIZE chsize AND REPLACES THE ENDPOINTS fromto[][1] BY THE
   POSITIONS TO WHICH ALL MEMBERS OF THE CHAIN RIGHTEXTEND MAXIMALLY WITH
   NO ERRORS */
rextnoerror(fromto,chsize)
int fromto[MAXSNODE][2], chsize;
{
int i;

while (fromto[chsize-1][1] < SQLGTH-1)
 {for (i=1;i<chsize;i++)
   if (TRL[protein[fromto[i][1]+1]] != TRL[protein[fromto[0][1]+1]])   break;
  if (i==chsize)   for (i=0;i<chsize;++i) ++fromto[i][1];
  else   return;
 }

} /* end rextnoerror() */



/* lextnoerror TAKES THE fromto[][] POSITIONS OF THE WORDS OF THE CURRENT
   CHAIN OF SIZE chsize AND REPLACES THE BEGINPOINTS fromto[][0] BY THE
   POSITIONS TO WHICH ALL MEMBERS OF THE CHAIN LEFTEXTEND MAXIMALLY WITH
   NO ERRORS; THE POSSIBILITY OF LEFTEXTENSION WAS INITIALLY TAKEN CARE OF
   BY makechain; HOWEVER, prcentmatch MAY HAVE SUBSEQUENTLY CREATED MATCHES
   THAT DO LEFTEXTEND */
lextnoerror(fromto,chsize)
int fromto[MAXSNODE][2], chsize;
{
int i;

while (fromto[0][0] > 0)
 {for (i=1;i<chsize;i++)
   if (TRL[protein[fromto[i][0]-1]] != TRL[protein[fromto[0][0]-1]])   break;
  if (i==chsize)   for (i=0;i<chsize;++i) --fromto[i][0];
  else   return;
 }

} /* end lextnoerror() */



/* merge1shifts REDUCES THE SIZE *chsizep OF THE CHAIN OF WORD MATCHES IT
   IS CALLED WITH BY MERGING ALL REPEATS THAT OVERLAP BY 1 LETTER; I.E.,
   A REPEAT AAAAAAA FOR A CORE BLOCK SIZE 4, INITALLY REPORTED AS AAAA
   OCCURRING AT POSITIONS i, i+1, i+2, AND i+3, WILL BE NOTED AS ONE ENTRY
   IN THE CHAIN FROM i TO i+7; NOTE THAT THIS MIGHT REDUCE *chsizep TO 1,
   FOR THE CASE OF A SINGLE RUN LONGER THAN CBSIZE OF ANY PARTICULAR LETTER;
   SUCH VESTIGIAL CHAINS (UNLESS AUGMENTED BY THE prcentmatch SEARCH) WILL
   NOT ENTER SUBSEQUENT CHAIN ANALYSIS */
merge1shifts(fromto,chsizep)
int fromto[MAXSNODE][2], *chsizep;
{
int i, j, ibase= 0, delta= 1;
int nfromto[MAXSNODE][2], newchsize= *chsizep;

for (i=0,j=0;i<(*chsizep);i++,j++)
 {nfromto[j][0]= fromto[i][0];   nfromto[j][1]= fromto[i][1];
  if (i>0)
   {if ( fromto[i][0] == fromto[ibase][0] + delta )
     {j--; newchsize-= 1; nfromto[j][1]= fromto[i][1];
      ignorelist[fromto[i][0]]= 1;
      ++delta;
     }
    else
     {ibase= i; delta= 1;}
   }
 }

*chsizep= newchsize;
for (i=0;i<newchsize;++i)
 {fromto[i][0]= nfromto[i][0]; fromto[i][1]= nfromto[i][1];}

} /* end merge1shifts() */



/* prcentmatch WILL ADD TO THE CHAIN ALL WORDS IN THE SEQUENCE THAT MATCH
   THE CHAIN PATTERN FOR AT LEAST 100*PRCENTMMIN % OF THE POSITIONS; HERE
   THE CHAIN PATTERN IS EITHER THE EXACT REPEAT COMPRISING THE CHAIN ENTRIES
   OR, IN THE CASE OF SEVERAL REITERATIONS OF A SINGLE LETTER, THE AVERAGE
   LENGTH OF THESE REITERATIONS */
prcentmatch(fromto,chsizep)
int fromto[MAXSNODE][2], *chsizep;
{
int i, minl, maxl, lgth, patpos, patlgth;
int gi, ai, ti;
int anum, afromto[MAXSNODE][2], tfromto[MAXSNODE][2];
 
minl= maxl= fromto[0][1]-fromto[0][0]+1; patpos= fromto[0][0];
for (i=1;i<(*chsizep);++i)
 {lgth= fromto[i][1]-fromto[i][0]+1;
  if (lgth<minl) minl= lgth;
  if (lgth>maxl) {maxl= lgth; patpos= fromto[i][0];}
 }
patlgth= (minl+maxl+1)/2;

if (patlgth<6) return;	/* CONDUCT SEARCH ONLY FOR PATTERNS OF LENGTHS
			   AT LEAST 6 */

anum= sforpat(afromto,fromto,*chsizep,patpos,patlgth);

if (anum>0)
 {ai= gi= ti= 0;
  while (ai < anum  &&  gi < *chsizep)
   {if (fromto[gi][0] < afromto[ai][0])
     {tfromto[ti][0]= fromto[gi][0];
      tfromto[ti++][1]= fromto[gi++][1];
      if (ti > MAXSNODE)
       {fprintf(stderr,ERRORMSG1,patlgth,patpos+1,patpos+patlgth,
		MAXSNODE, MAXSNODE); fflush(outfp); exit(-1);}
     }
    else
     {if ( (gi==0 || afromto[ai][0] > fromto[gi-1][1]) &&
	   afromto[ai][1] < fromto[gi][0] )
       {tfromto[ti][0]= afromto[ai][0];
        tfromto[ti++][1]= afromto[ai++][1];
        if (ti > MAXSNODE)
	 {fprintf(stderr,ERRORMSG1,patlgth,patpos+1,patpos+patlgth,
		  MAXSNODE, MAXSNODE); fflush(outfp); exit(-1);}
       }
      else   ai++;	/* ADD NEW ENTRIES ONLY IF THEY DO NOT OVERLAP
			   THE ORIGINAL CHAIN ENTRIES */
     }
   }

  if (ai == anum)
   {while (gi < *chsizep)
     {tfromto[ti][0]= fromto[gi][0];
      tfromto[ti++][1]= fromto[gi++][1];
      if (ti > MAXSNODE)
       {fprintf(stderr,ERRORMSG1,patlgth,patpos+1,patpos+patlgth,
		MAXSNODE, MAXSNODE); fflush(outfp); exit(-1);}
     }
   }
  else
   {while (ai < anum)
     {if (afromto[ai][0] > fromto[*chsizep-1][1])
       {tfromto[ti][0]= afromto[ai][0];
	tfromto[ti++][1]= afromto[ai++][1];
        if (ti > MAXSNODE)
         {fprintf(stderr,ERRORMSG1,patlgth,patpos+1,patpos+patlgth,
		  MAXSNODE, MAXSNODE); fflush(outfp); exit(-1);}
       }
      else   ai++;	/* ADD NEW ENTRIES ONLY IF THEY DO NOT OVERLAP
			   THE ORIGINAL CHAIN ENTRIES */
     }
   }

  for (i=0;i<ti;i++)
   {fromto[i][0]=tfromto[i][0]; fromto[i][1]=tfromto[i][1];}
  (*chsizep) = ti;
 }
   
} /* end prcentmatch() */




/* sforpat SEARCHES THROUGH ENTIRE SEQUENCE FOR >= 100*PRCENTMMIN % MATCHES TO
   THE GIVEN PATTERN, STORING THE COORDINATES OF THE MATCHES IN afromto[][];
   PATTERNS COINCIDING WITH THE ORIGINAL CHAIN ARE NOT CONSIDERED; sforpat
   RETURNS THE NUMBER OF THE ADDITIONAL MATCHES */
int sforpat(afromto,fromto,chsize,patpos,patlgth)
int afromto[MAXSNODE][2], fromto[MAXSNODE][2], chsize, patpos, patlgth;
{
int i= 0, gi= 0, count= 0;
float pidscore(), mscore;

for (i=0;i<=SQLGTH-patlgth;++i)
  {if (i > fromto[gi][0])   ++gi;
   if (i != fromto[gi][0])
    {if ((mscore=pidscore(i,patpos,patlgth)) >= PRCENTMMIN)
      {if (count > 0  &&  i < afromto[count-1][1])
	{if (mscore > pidscore(afromto[count-1][0],patpos,patlgth) + 0.001)
		--count;
         else   continue;
			/* OF OVERLAPPING NEW MATCHES, ONLY THE HIGHEST
			   SCORING ONE IS KEPT */
	}
       afromto[count][0]= i;   afromto[count][1]= i+patlgth-1;
       ++count;
       if (chsize+count > MAXSNODE)
        {fprintf(stderr,ERRORMSG1,patlgth,patpos+1,patpos+patlgth,MAXSNODE,
		 MAXSNODE); fflush(outfp); exit(-1);}
      }
    }
  }

return(count);
 
} /* end sforpat() */




/* pidscore RETURNS THE PERCENT IDENTITY BETWEEN TWO SEQUENCE SEGMENTS OF
   LENGTHS k STARTING AT a AND b; THE PERCENT IDENTITY IS SET TO 0.0 IF
   THE TWO SEGMENTS DIFFER IN EITHER END RESIDUE */
float pidscore(a,b,k)
int a, b, k;
{
int i;
float nmatch= 2.0;

if (TRL[protein[a]] != TRL[protein[b]] || 
    TRL[protein[a+k-1]] != TRL[protein[b+k-1]] )   return (0.0);

for (i=1;i<k-1;i++)   if (TRL[protein[a+i]] == TRL[protein[b+i]]) ++nmatch;

return(nmatch/(float)k);

} /* end pidscore() */



/* rexterror EXTENDS A MAXIMAL SUBSET OF THE CHAIN TO THE RIGHT WITH
   INSERTION/DELETION ERRORS OF SIZES 0, 1, OR 2 PRECEDING A MATCHING
   DIPEPTIDE. THE ORIGINAL CHAIN IS REDUCED RECURSIVELY, POSSIBLY UP TO
   CHAIN SIZE 2. IF THE RECURSION STEP RESULTS IN A REDUCED CHAIN SIZE,
   THEN THE ANCESTOR CHAIN IS SENT TO make2node FOR INSERTION IN THE NODE
   LIST. ALL SUCH ANCESTORS ARE INDEXED WITH THE SAME INTEGER index2. THE
   REDUCED CHAIN WILL BE PROCESSED FURTHER BY chainanalysis. */
rexterror(fromto,chsizep)
int fromto[MAXSNODE][2], *chsizep;
{
int i, ibeg= 0, j, jbeg= 0, gapsize, n, flag;
int dipcnt[23][23], consdipn, consdip[2];
int tfromto[MAXSNODE][2], nchsize= 2;
int index2=0;

if (*chsizep >= MAXCSFREX)   return(0);

while (nchsize > 1)
 {consdipn= 0;
  for (i=0;i<23;++i) for (j=0;j<23;++j)   dipcnt[i][j]= 0;

  for (gapsize=0;gapsize<3;++gapsize)
   {for (i=0;i<(*chsizep) && fromto[i][1]+gapsize+2 < SQLGTH;++i)
     {flag= 1;
      if (gapsize>0)
       {for (j=0;j<gapsize;++j)
	 if ( TRL[protein[fromto[i][1]+gapsize+1]] ==
 	       TRL[protein[fromto[i][1]+j+1]]   &&
	      TRL[protein[fromto[i][1]+gapsize+2]] ==
 	       TRL[protein[fromto[i][1]+j+2]]     )   {flag= 0; break;}
       }
      if (flag)  (n= ++dipcnt[TRL[protein[fromto[i][1]+gapsize+1]]]
		             [TRL[protein[fromto[i][1]+gapsize+2]]] );
		/* - COUNT EACH DIPEPTIDE AT MOST ONCE PER CHAIN MEMBER */
      if (n > consdipn)
       {consdipn= n;
	consdip[0]= TRL[protein[fromto[i][1]+gapsize+1]];
	consdip[1]= TRL[protein[fromto[i][1]+gapsize+2]];
       }
     }
   }

/* NOW CREATE A NEW CHAIN CONSISTING OF ALL OLD CHAIN MEMBERS THAT EXTEND
   WITH THE CONSENSUS DIPEPTIDE, ALLOWING FOR GAPS OF SIZES 0, 1, OR 2 */ 
  nchsize= 0;
  if (consdipn > 1)
   {for (i=0;i<(*chsizep);++i)
     {for (gapsize=0;gapsize<3;++gapsize)
       {if ( TRL[protein[fromto[i][1]+gapsize+1]] == consdip[0] && 
	     TRL[protein[fromto[i][1]+gapsize+2]] == consdip[1] )
	 {tfromto[nchsize][0]= fromto[i][0];
	  tfromto[nchsize][1]= fromto[i][1]+gapsize+2;
          ++nchsize;
	  break;
	 }
       }
     }

    while (nchsize==2 && tfromto[0][1] == tfromto[1][1] && ibeg*jbeg<=22*22) 
	/* - THE CASE OF TWO REPEATS OVERLAPPING BY LESS THAN THE MAXIMAL
	   GAP SIZE, 3, AT THIS POINT HAS LEAD TO THE RIGHTMOST ONE BEING
	   EXTENDED WITH GAP SIZE EQUAL TO SHIFT SIZE, THUS ENDING WITH
	   THE SAME NUCLEOTIDE -- A CASE THAT SHOULD NO LONGER BE PURSUED.
	   AN ATTEMPT IS MADE TO FIND ANOTHER EXTENSION:  */
     {flag= 0;
      for (i=ibeg;i<23 && !flag;++i) for (j=jbeg;j<23 && !flag;++j)
       {if (dipcnt[i][j]==2 && (i!=consdip[0] || j!=consdip[1]))
	 {consdip[0]= i; consdip[1]= j; flag= 1;}
       }
      if (j==23)   {ibeg= i;   if (i<23) jbeg= 0;   else jbeg= 23;}
      else   {ibeg= --i;   jbeg= j;}
      if (flag)
       {nchsize= 0;
	for (i=0;i<(*chsizep);++i)
	 {for (gapsize=0;gapsize<3;++gapsize)
	   {if ( TRL[protein[fromto[i][1]+gapsize+1]] == consdip[0] && 
	         TRL[protein[fromto[i][1]+gapsize+2]] == consdip[1] )
	     {tfromto[nchsize][0]= fromto[i][0];
	      tfromto[nchsize][1]= fromto[i][1]+gapsize+2;
              ++nchsize;
	      break;
	     }
           }
         }
       } /* end-of-if-flag */
     } /* end-of-while-nchsize... */

    if (nchsize==2 && tfromto[0][1] == tfromto[1][1])   nchsize= 0;

    if (nchsize > 1)
     {if (nchsize < *chsizep) 
       {if (index2 == 0)   index2= ++INDEX;
        make2node(fromto,*chsizep,index2);
       }
      for (i=0;i< *chsizep;++i)   fromto[i][0]= fromto[i][1]= 0;
      for (i=0;i<nchsize;++i)
       {fromto[i][0]= tfromto[i][0];   fromto[i][1]= tfromto[i][1];}
      *chsizep= nchsize;
     }

   } /* end-of-if-consdipn */
 } /* end-of-while-nchsize */

return(index2);

} /* end rexterror() */



/* rextone EXTENDS BY ONE RESIDUE TO THE RIGHT EACH CHAIN MEMBER FOR WHICH
   AT LEAST ONE OTHER CHAIN MEMBER CAN BE EXTENDED BY THE SAME RESIDUE; SUCH
   EXTENSION BY ONE WOULD NOT HAVE BEEN ACCOMPLISHED BY rexterror WHICH
   EXTENDS WITH DIMERS ONLY */
rextone(fromto,chsize)
int fromto[MAXSNODE][2], chsize;
{
int i, rcnt[23];

for (i=0;i<23;++i)   rcnt[i]= 0;

for (i=0;i<chsize;++i)
 if (fromto[i][1]+1 < SQLGTH)   ++rcnt[TRL[protein[fromto[i][1]+1]]];

for (i=0;i<chsize;++i)
 if (rcnt[TRL[protein[fromto[i][1]+1]]] > 1)   ++fromto[i][1];

} /* end rextone() */



/* newgnode ALLOCATES SPACE FOR A NEW GROUP NODE, RETURNING THE ADDRESS OF 
   THIS NEW NODE AFTER SETTING ALL VARIABLES TO NULL/ZERO */
struct group *newgnode()
{
struct group *gp;
int i;

gp = (struct group *) malloc(sizeof(struct group));

for (i=0;i<MAXSNODE;++i)
 {gp->crd[i][0]= 0; gp->crd[i][1]= 0;}
gp->nodesize = 0;
gp->noprtflag = 0;
gp->index1 = 0;
gp->index2 = 0;
gp->nextgroup = NULL;
gp->leftwing = NULL;
gp->rightwing = NULL;

return(gp);

} /* end newgnode() */



/* make1node MAKES A NODE CONTAINING fromto[][] AND chsize VALUES AND
   INSERTS THE NODE IN THE LIST POINTED TO BY groupshead */
make1node(fromto,chsize,index2)
int fromto[MAXSNODE][2], chsize, index2;
{
struct group *nodep, *newgnode();
int i, j;

nodep = newgnode();
nodep->nodesize = chsize;
nodep->index2 = index2;

for (i=0;i<chsize;++i)
 {nodep->crd[i][0] = fromto[i][0];   nodep->crd[i][1] = fromto[i][1];
  ignorelist[fromto[i][0]] = 1;
 }
 
if (MSGPRT)
 {fprintf(outfp,"\n");
  for (i=0;i<nodep->nodesize;++i)
   {fprintf(outfp,"\nINSERTING INTO GHL: Word #i=%3d at %5d to %5d  ",
	    i, nodep->crd[i][0]+1, nodep->crd[i][1]+1 );
    for (j=0;j<nodep->crd[i][1] - nodep->crd[i][0]+1;++j)
     fprintf(outfp,"%c", SYMB[TRL[protein[nodep->crd[i][0]+j]]]);
   }
 }

insert_by_pos(&groupshead,nodep);

} /* end make1node() */



/* make2node MAKES A NODE CONTAINING fromto[][] AND chsize VALUES AND
   INSERTS THE NODE IN THE LIST POINTED TO BY index2head */
make2node(fromto,chsize,index)
int fromto[MAXSNODE][2], chsize, index;
{
int i, j;
struct group *gp, *newgnode();

gp= newgnode();
gp->index2= index;
gp->nodesize= chsize;
 
if (MSGPRT) fprintf(outfp,"\n");

for (i=0;i<chsize;++i)
 {gp->crd[i][0]= fromto[i][0];   gp->crd[i][1]= fromto[i][1];

  if (MSGPRT)
   {fprintf(outfp,"\nMAKE2NODE (INDEX=%4d): Word #i=%3d at %5d to %5d  ",
	    index, i, fromto[i][0]+1, fromto[i][1]+1 );
    for (j=0;j<fromto[i][1]-fromto[i][0]+1;++j)
     fprintf(outfp,"%c", SYMB[TRL[protein[fromto[i][0]+j]]]);
   }
 } 

gp->nextgroup= NULL;

insert_by_ims(&index2head,gp);

} /* end make2node() */



/* insert_by_ims INSERTS THE NODE REPRESENTED BY nodep INTO THE LIST
   REPRESENTED BY rheadpp FIRST BY INCREADING index2 AND THEN SUCH THAT THE
   NODE WITH THE SMALLEST NUMBER OF ELEMENTS (CHAINSIZE) IS AT THE HEAD OF
   THE LIST, AND THE NODE WITH THE LARGEST NUMBER OF ELEMENTS IS AT THE TAIL
   OF THE LIST */
insert_by_ims(rheadpp,nodep)
struct group **rheadpp, *nodep;
{

if ( *rheadpp == NULL)   *rheadpp = nodep;
else
 {if ( (*rheadpp)->index2 < nodep->index2 )
   insert_by_ims(&((*rheadpp)->nextgroup),nodep);
  else
   {if ( (*rheadpp)->nodesize >= nodep->nodesize )
     insert_by_ims(&((*rheadpp)->nextgroup),nodep);
    else
     {nodep->nextgroup = *rheadpp;
      *rheadpp = nodep;
     }
   }
 }
} /* end insert_by_ims() */



/* insert_by_pos INSERTS THE NODE REPRESENTED BY nodep INTO THE LIST
   REPRESENTED BY rheadpp SUCH THAT THE NODE WITH THE SMALLEST FIRST
   COORDINATE IS AT THE HEAD OF THE LIST, AND THE NODE WITH THE LARGEST
   FIRST COORDINATE IS AT THE TAIL OF THE LIST */
insert_by_pos(rheadpp,nodep)
struct group **rheadpp, *nodep;
{

if ( *rheadpp == NULL)
 {nodep->nextgroup= NULL;
  *rheadpp = nodep;
 }
else
 {if ( (*rheadpp)->crd[0][0] < nodep->crd[0][0] )
   insert_by_pos(&((*rheadpp)->nextgroup),nodep);
  else
   {nodep->nextgroup = *rheadpp;
    *rheadpp = nodep;
   }
 }
} /* end insert_by_pos() */



/* rmv_subsets() WILL START AT THE HEAD OF GROUPSLIST AND REMOVE A NODE THAT
   IS A SUBSET OF THE PRECEDING NODE */
rmv_subsets()
{
struct group *nodep, *nextp;

nodep = groupshead;
while ( nodep != NULL  &&  nodep->nextgroup != NULL )
 {nextp = nodep->nextgroup;
  if ( removable(nodep,nextp) )   nodep->nextgroup = nextp->nextgroup;
  else   nodep = nodep->nextgroup;
 }

} /* end rmv_subsets() */



/* removable() RETURNS 1 IF nextp IS A SUBSET, LENGTH-WISE, OF nodep; ELSE
   RETURNS 0 */
removable(nodep,nextp)
struct group *nodep, *nextp;
{
int i, j= 0;

if (nodep->nodesize < nextp->nodesize)   return(0);
else
 {for(i=0;i<nextp->nodesize;++i)
   {for (;j<nodep->nodesize;++j)
     if (nextp->crd[i][0]>=nodep->crd[j][0] &&
	 nextp->crd[i][1]<=nodep->crd[j][1] )   break;
    if (j==nodep->nodesize) return(0);
   }

if (MSGPRT) {
for (i=0;i<nextp->nodesize;++i) fprintf(outfp,
	"\nREMOVED %d - %d", nextp->crd[i][0]+1, nextp->crd[i][1]+1);
for (i=0;i<nodep->nodesize;++i) fprintf(outfp,
	"\n   KEPT %d - %d", nodep->crd[i][0]+1, nodep->crd[i][1]+1);
fprintf(outfp,"\n");
}

  return(1);
 }

} /* end removable() */



/* rmv_simplenodes() WILL START AT THE HEAD OF GROUPSLIST AND REMOVE NODES THAT
   ARE SIMPLE IN COMPOSITION */
rmv_simplenodes()
{
struct group **ipp;
int i;

ipp= &groupshead;

while (*ipp != NULL)
 {if (simplenode(*ipp))
   {

if (MSGPRT) {
for (i=0;i<(*ipp)->nodesize;++i) fprintf(outfp,
	"\nREMOVED %d - %d", (*ipp)->crd[i][0]+1, (*ipp)->crd[i][1]+1);
fprintf(outfp,"\n");
}

    *ipp= (*ipp)->nextgroup;
   }
  else   ipp= &((*ipp)->nextgroup);
 }

} /* end rmv_simplenodes() */



/* simplenode() RETURNS 1 IF nodep IS A SIMPLE NODE; ELSE RETURNS 0. A NODE
   IS SAID TO BE SIMPLE IF ITS CONCATENATED SEQUENCE CONSISTS FOR AT LEAST
   100*PRCENTMMIN % OF A SINGLE RESIDUE */
simplenode(nodep)
struct group *nodep;
{
int i, l;
int act[23], max= 0, cnt= 0;

if (nodep->nodesize < 2) return(0);

for (l=0;l<23;++l) act[l]= 0;

for (i=0;i<nodep->nodesize;++i)
 {for (l=nodep->crd[i][0];l<=nodep->crd[i][1];++l)
   {if (++act[TRL[protein[l]]] > max)  max= act[TRL[protein[l]]];
    ++cnt;
   }
 }

/*
fprintf(outfp,"\nTESTING simplenode %d -- %d, size: %d\n",
	nodep->crd[0][0]+1, nodep->crd[0][1]+1, nodep->nodesize );
for (l=0;l<23;++l) fprintf(outfp,"%2d ", act[l]);
fprintf(outfp,"\nCOMPOSITION max=%d cnt=%d\n\n", max, cnt);
*/

if ((float)max/(float)cnt >= PRCENTMMIN)   return(1);
else   return(0);

} /* end simplenode() */



/* mesh_ovlsets() STARTS AT HEAD OF GROUPSLIST AND MERGES ALL NODES THAT ALIGN,
   OVERLAP, AND HAVE PRECISELY THE SAME NODESIZE */
mesh_ovlsets()
{
int i;
struct group *nodep= groupshead, **nextpp;
  
while (nodep != NULL)
 {for (nextpp = &(nodep->nextgroup);*nextpp != NULL;)
   {if (meshable(nodep,*nextpp))
     {

if (MSGPRT) {
for (i=0;i<(*nextpp)->nodesize;++i) fprintf(outfp,
	"\nMESHED %d - %d", (*nextpp)->crd[i][0]+1, (*nextpp)->crd[i][1]+1);
for (i=0;i<nodep->nodesize;++i) fprintf(outfp,
	"\n WITH  %d - %d", nodep->crd[i][0]+1, nodep->crd[i][1]+1);
for (i=0;i<nodep->nodesize;++i) fprintf(outfp,
	"\nTOGIVE %d - %d", nodep->crd[i][0]+1, (*nextpp)->crd[i][1]+1);
fprintf(outfp,"\n");
}

      for (i=0;i<nodep->nodesize;i++) nodep->crd[i][1] = (*nextpp)->crd[i][1];
      *nextpp = (*nextpp)->nextgroup;
     }
    else   nextpp = &((*nextpp)->nextgroup);
   }
  nodep = nodep->nextgroup;
 }
 
} /* end mesh_ovlsets() */



/* meshable() RETURNS 1 IF nextp IS A SUBSET OR OVERLAPPING EXTENSION OF
   nodep; ELSE RETURNS 0 */
meshable(nodep,nextp)
struct group *nodep, *nextp;
{
int i;

if (nodep->nodesize != nextp->nodesize)   return(0);

for (i=0;i<nodep->nodesize;++i)
 if (nodep->crd[i][1] < nextp->crd[i][0] ||
     nodep->crd[i][1] > nextp->crd[i][1] )   return(0);

return(1);

} /* end meshable() */



/* clfy_nodes() CLASSIFIES NODES AS OVERLAPPING NODES (ONODES) IF A
   SUFFICIENTLY LARGE FRACTION OF THE SLANT OFFSETS PRODUCE OVERLAPPING
   OF SUCCESSIVE NODE ENTRIES. IF MOST OF THE SLANT OFFSETS ARE THE SAME
   (CONSENSUS SLANT: cslant), THEN THE NODE REPRESENTS A PERIODIC REPEAT.
   ONODES ARE KEPT IN THE LIST HEADED BY ogroupshead, AND THEIR noprtflag
   IN THE groupshead LIST ENTRY IS SET TO >=1 */
clfy_nodes()
{
struct group *nodep= groupshead;

while (nodep != NULL)
 {if (nodep->nodesize > 2)   is_onode(nodep);
  nodep = nodep->nextgroup;
 }

} /* end clfy_nodes() */



/* is_onode() DETERMINES IF nodep REPRESENTS AN OVERLAPPING NODE, AND IF SO
   INSERTS IT APPROPRIATELY INTO THE ogroupshead HEADED LIST */
is_onode(nodep)
struct group *nodep;
{
struct ogroup *onodep, *newonode();
int i, cslant;	/* consensus slant */

cslant= det_cslant(nodep);

if (nodep->nodesize < BIGNODE)
 {if (0 < cslant  &&  cslant < CBSIZE)
   {nodep->noprtflag = 1;

if (MSGPRT) {
fprintf(outfp,"\nTYPE 1 NODE: size=%3d, cslant=%d, pflag=%d; at",
	nodep->nodesize, cslant, nodep->noprtflag );
for (i=0;i<nodep->nodesize;++i) fprintf(outfp,
	"\nTYPE 1   %4d - %4d", nodep->crd[i][0]+1, nodep->crd[i][1]+1);
fprintf(outfp,"\n");
}

    makeonodes(nodep,cslant);
   }
  else
   {if (muchoverlap(nodep))
     {nodep->noprtflag = 1;
      onodep = newonode();
      onodep->beg = nodep->crd[0][0];
      onodep->end = nodep->crd[nodep->nodesize -1][1];
      onodep->cslant = 0;

if (MSGPRT) {
fprintf(outfp,"\nTYPE 2 NODE: size=%3d, cslant=%d, pflag=%d; at",
	nodep->nodesize, cslant, nodep->noprtflag );
for (i=0;i<nodep->nodesize;++i) fprintf(outfp,
	"\nTYPE 2   %4d - %4d", nodep->crd[i][0]+1, nodep->crd[i][1]+1);
fprintf(outfp,"\n");
}

      insert_by_pos_csl(&ogroupshead,onodep);
     }

if (MSGPRT) {
fprintf(outfp,"\nTYPE 3 NODE: size=%3d, cslant=%d, pflag=%d; at",
	nodep->nodesize, cslant, nodep->noprtflag );
for (i=0;i<nodep->nodesize;++i) fprintf(outfp,
	"\nTYPE 3   %4d - %4d", nodep->crd[i][0]+1, nodep->crd[i][1]+1);
fprintf(outfp,"\n");
}

   }
 }
else
 {if (cslant == 0)
   {if (nodep->nodesize >= TOOBIGTOPRINT)   nodep->noprtflag = 3;

if (MSGPRT) {
fprintf(outfp,"\nTYPE 4 NODE: size=%3d, cslant=%d, pflag=%d; at",
	nodep->nodesize, cslant, nodep->noprtflag );
for (i=0;i<nodep->nodesize;++i) fprintf(outfp,
	"\nTYPE 4   %4d - %4d", nodep->crd[i][0]+1, nodep->crd[i][1]+1);
fprintf(outfp,"\n");
}
 }

  else
   {makeonodes(nodep,cslant);
    if (closelybunched(nodep,cslant))   nodep->noprtflag = 1;
    else if (nodep->nodesize >= TOOBIGTOPRINT)    nodep->noprtflag = 3;

if (MSGPRT) {
fprintf(outfp,"\nTYPE 5 NODE: size=%3d, cslant=%d, pflag=%d; at",
	nodep->nodesize, cslant, nodep->noprtflag );
for (i=0;i<nodep->nodesize;++i) fprintf(outfp,
	"\nTYPE 5   %4d - %4d", nodep->crd[i][0]+1, nodep->crd[i][1]+1);
fprintf(outfp,"\n");
}

   }
 }

} /* end is_onode() */



/* det_cslant() DETERMINES WHETHER THE NODE ENTRIES ARE OFFSET BY A CONSENSUS
   SLANT (DEFINED AS A SLANT VALUE ATTAINED BY AT LEAST CONSENSUS/100 % OF THE
   OFFSETS; IF SUCH A CONSENSUS SLANT EXISTS, ITS VALUE IS RETURNED; ELSE
   det_cslant RETURNS 0 */
det_cslant(nodep)
struct group *nodep;
{
int i, d, delta[PROTLGTH], cons_cnt= 0, cons_d= 0;

for (i=0;i<PROTLGTH;++i)   delta[i]= 0;

for (i=1;i<nodep->nodesize;++i)
 {d= nodep->crd[i][0] - nodep->crd[i-1][0];
  ++delta[d];
  if (delta[d] > cons_cnt) {cons_cnt= delta[d]; cons_d= d;}
 }
 
if ((float)cons_cnt/(float)(nodep->nodesize - 1) >= (float)CONSENSUS/100.0)
 return(cons_d);
else   return(0);

} /* end det_cslant() */



/* newonode() ALLOCATES SPACE FOR A NEW OVERLAPPING GROUP NODE, RETURNING THE
   ADDRESS OF THIS NEW NODE AFTER SETTING ALL VARIABLES TO NULL/ZERO */
struct ogroup *newonode()
{
struct ogroup *ogp;

ogp = (struct ogroup *) malloc(sizeof(struct ogroup));
ogp->beg = 0;
ogp->end = 0;
ogp->next = NULL;
ogp->cslant = 0;
return(ogp);

} /* end newonode() */



/* makeonodes() CREATES ONODES CORRESPONDING TO GROUPS OF OVERLAPPING REPEATS,
   WITH THE SPECIFICATION THAT GROUPS ARE SEPARATED IF THEY ARE MORE THAN
   PFACTOR * cslant POSITIONS APART */
makeonodes(nodep,cslant)
struct group *nodep;
int cslant;
{
struct ogroup *onodep, *newonode();
int i, lastbeg= 0;

if (cslant == 0)
 {onodep = newonode();
  onodep->beg = nodep->crd[0][0];
  onodep->end = nodep->crd[nodep->nodesize-1][1];
  onodep->cslant = 0;
  insert_by_pos_csl(&ogroupshead,onodep);                 
 }
else
 {for (i=1;i<nodep->nodesize;++i)
   {if ( nodep->crd[i][0] - nodep->crd[i-1][1]  >  PFACTOR * cslant )
     {onodep = newonode();
      onodep->beg = nodep->crd[lastbeg][0];
      onodep->end = nodep->crd[i-1][1];
      onodep->cslant = cslant;
      insert_by_pos_csl(&ogroupshead,onodep);
      lastbeg= i;
     }
   }
  onodep = newonode();
  onodep->beg = nodep->crd[lastbeg][0];
  onodep->end = nodep->crd[nodep->nodesize-1][1];
  onodep->cslant = cslant;
  insert_by_pos_csl(&ogroupshead,onodep);
 }

} /* end makeonodes() */
        


closelybunched(nodep,cslant)
struct group *nodep;
int cslant;
{
int span;

span = nodep->crd[nodep->nodesize - 1][1] - nodep->crd[0][0];
if (span > nodep->nodesize * cslant * BFACTOR)   return(0);
else   return(1);

} /* end closelybunched() */



/* muchoverlap DETERMINES THE FRACTION OF NODE ENTRIES THAT OVERLAP THE
   PRECEDING NODE ENTRY; IF >= 0.75, RETURNS 1; ELSE RETURNS 0 */
muchoverlap(nodep)
struct group *nodep;
{
int i, count= 0;

if (nodep->nodesize < 4) return(0);

for (i=1;i<nodep->nodesize;++i)
 if (nodep->crd[i][0] <= nodep->crd[i-1][1])   ++count;

if ( (float)count/(float)(nodep->nodesize - 1) >= 0.75 )   return(1);
else   return(0);

} /* end muchoverlap() */



/* insert_by_pos_csl INSERTS THE NODE REPRESENTED BY onodep INTO THE LIST
   REPRESENTED BY rheadpp SUCH THAT THE NODE WITH THE SMALLEST FIRST
   COORDINATE AND THE SMALLEST cslant IS AT THE HEAD OF THE LIST */
insert_by_pos_csl(rheadpp,onodep)
struct ogroup **rheadpp, *onodep;
{

if (0 < onodep->cslant  &&   onodep->cslant < MINPRD)   return;

if ( *rheadpp == NULL)   *rheadpp = onodep;
else
 {if ( (*rheadpp)->beg < onodep->beg  &&
       (*rheadpp)->cslant <= onodep->cslant )
   insert_by_pos_csl(&((*rheadpp)->next),onodep);
  else
   {onodep->next = *rheadpp;
    *rheadpp = onodep;
   }
 }

} /* end insert_by_pos_csl() */



/* det_str() DETERMINES NODES THAT ARE SIMPLE TANDEM REPEATS AND LABELS THEM
   BY SETTING THEIR noprtflag EQUAL TO 2 */
det_str()
{
struct group *gp= groupshead;
int i;

while (gp != NULL)
 {if ( gp->nodesize == 2  &&  gp->crd[1][0] <= gp->crd[0][1] )
   {if (gp->crd[1][0] - gp->crd[0][0] < MINPRD)   gp->noprtflag= 1;
    else   {gp->noprtflag= 2;   ++strcount;}

if (MSGPRT) {
for (i=0;i<gp->nodesize;++i)
 fprintf(outfp,"\nTANDEMR %4d - %4d; pflag=%1d",
	gp->crd[i][0]+1, gp->crd[i][1]+1, gp->noprtflag);
fprintf(outfp,"\n");
}

   }
  gp= gp->nextgroup;
 } /* end-of-while */

} /* end det_str() */



/* cleanhrr() MERGES HIGHLY REPETITIVE REGION NODES (NODES WITH noprtflag 3)
   THAT CORRESPOND TO OVERLAPPING MOTIFS */
cleanhrr()
{
struct group *nodep= groupshead, **ipp;
int i;

while (nodep != NULL)
 {if (nodep->noprtflag == 3)
   {ipp= &groupshead;
    while (*ipp != NULL)
     {if ((*ipp)->noprtflag == 3)
       {if (*ipp != nodep  &&  hrrsubset_of(*ipp,nodep))
         {
if (MSGPRT) {
fprintf(outfp,"\nIn cleanhrr:");
for (i=0;i<nodep->nodesize;++i)
 fprintf(outfp,"\n   KEPT %d - %d", nodep->crd[i][0]+1, nodep->crd[i][1]+1);
for (i=0;i<(*ipp)->nodesize;++i)
 fprintf(outfp,"\nREMOVED %d - %d", (*ipp)->crd[i][0]+1, (*ipp)->crd[i][1]+1);
}
          *ipp= (*ipp)->nextgroup;
         }
        else   ipp= &((*ipp)->nextgroup);
       }
      else   ipp= &((*ipp)->nextgroup);
     }
   }
  nodep= nodep->nextgroup;
 }

} /* end cleanhrr() */



hrrsubset_of(childp,parentp)
struct group *childp, *parentp;
{
int i, j= 0;

if (parentp->nodesize < childp->nodesize)   return(0);

for (i=0;i< parentp->nodesize;++i)
 if ((childp->crd[j][0] >= parentp->crd[i][0] &&
      childp->crd[j][0] <= parentp->crd[i][1]   )  ||
     (childp->crd[j][1] >= parentp->crd[i][0] &&
      childp->crd[j][1] <= parentp->crd[i][1]   )    )   ++j;

if (j < childp->nodesize)   return(0);
else	/* ALL childp ENTRIES START OR END WITHIN parentp ENTRIES; EXTEND
	   parentp AS APPROPRIATE AND MARK childp FOR ELIMINATION: */
 {j= 0;
  for (i=0;i< parentp->nodesize;++i)
   {if (childp->crd[j][0] >= parentp->crd[i][0]  &&
        childp->crd[j][0] <= parentp->crd[i][1]    )
     {if (childp->crd[j][1] > parentp->crd[i][1])
       parentp->crd[i][1] = childp->crd[j][1];
      ++j; continue;
     }
    if (childp->crd[j][1] >= parentp->crd[i][0]  &&
        childp->crd[j][1] <= parentp->crd[i][1]    )
     {if (childp->crd[j][0] < parentp->crd[i][1])
       parentp->crd[i][0] = childp->crd[j][0];
      ++j; continue;
     }
   }
  return(1);
 }

} /* end hrrsubset_of() */



/* aligngroups() USES THE groupshead LIST TO ALIGN AND MERGE GROUPS THAT,
   WITHIN SOME SLANTERROR ALIGN RELATIVE TO EACH OTHER SLANT-WISE. */
aligngroups()
{
int i, j;
struct group *gp= groupshead, *noprtp= NULL, *slistp= NULL, *tgp, *vgp, *hgp;
struct group **ipp, **ancestor_array[100], **ipp_a_array[100];
struct group **indexpp, **vindexpp;
int acount, ipp_acount;
int slants[MAXSNODE], offsets[MAXSNODE], sthaligned;

while (gp != NULL)
 {if (gp->noprtflag != 0)
   {tgp = gp->nextgroup;
    gp->nextgroup = noprtp;
    noprtp = gp;
    gp = tgp;
   }
  else
   {tgp= gp->nextgroup;
    insert_by_anc_msize(&slistp,gp);
    gp = tgp;
   }
 }

gp = slistp;
indexpp = &slistp;

while (gp != NULL)
 {sthaligned= 0;
  if (gp->index2 > 0)
   {acount= fill_ancestor_array(gp,ancestor_array);
    if (acount > 0)
     {vindexpp = ancestor_array[0];
      vgp = *vindexpp;
     }
    else   vgp= gp;
   }
  else
   {acount= 0; 
    vgp= gp;
   }
  slants[0]= vgp->nodesize-1;
  for (i=1;i<vgp->nodesize;++i)   slants[i] = vgp->crd[i][0] - vgp->crd[i-1][0];
	/* AT THIS POINT, slants[0] CONTAINS THE NUMBER OF SLANTS OF NODE vgp,
	   AND slants[1], slants[2], ..., CONTAIN THESES SLANTS */
  ipp = &(gp->nextgroup);
  while (*ipp != NULL)
   {if ((*ipp)->index2 > 0)
     ipp_acount= fill_ancestor_array(*ipp,ipp_a_array);
    else   ipp_acount= 0;
    if (slantmatch(slants,vgp,*ipp,offsets))
     {sthaligned= 1;
      mesh_groups(vgp,ipp,offsets);
      for (i=0;i<ipp_acount;++i)
       {if (slantmatch(slants,vgp,*ipp_a_array[i],offsets))
	 mesh_groups(vgp,ipp_a_array[i],offsets);
	if (ipp_acount > 2)
	 for (j=2;j<ipp_acount;++j) ipp_a_array[j-1] = ipp_a_array[j];
	--i; --ipp_acount;
       }
     }
    else ipp = &((*ipp)->nextgroup);    
   } /* end-of-while-(*ipp != NULL) */

   /* CALLING fill_ancestor_array AGAIN, SINCE INSERTING *ipp ANCESTORS INTO
      THE index1head LIST MIGHT HAVE CHANGED *vindexpp */
   acount= fill_ancestor_array(gp,ancestor_array);
   if (acount > 0)
    {vindexpp = ancestor_array[0];
     vgp = *vindexpp;
    }

  if (sthaligned == 1  &&  vgp != gp)
   {hgp = gp;
    if (slantmatch(slants,vgp,gp,offsets))
     {tgp = gp->nextgroup;
      mesh_groups(vgp,&gp,offsets);
      *vindexpp = vgp->nextgroup;
      vgp->nextgroup = tgp;
      *indexpp = vgp;
      gp = vgp;
     }
    acount= fill_ancestor_array(hgp,ancestor_array);
    for (i=0;i < acount;++i)
     {if (slantmatch(slants,vgp,*(ancestor_array[i]),offsets))
       mesh_groups(vgp,ancestor_array[i],offsets);
      if (acount > 2)
       for (j=2;j<acount;++j) ancestor_array[j-1] = ancestor_array[j];
      --i; --acount;
     }
   } /* end-of-if (sthaligned ... */
  if (gp->nextgroup == NULL)   break;
  indexpp= &(gp->nextgroup);
  gp= gp->nextgroup;
 } /* end-of-while-(gp != NULL) */

if (gp != NULL)
 {gp->nextgroup = noprtp;
  groupshead = slistp;
 }
else   groupshead = noprtp;

} /* end aligngroups () */



/* insert_by_anc_msize INSERTS THE NODE REPRESENTED BY nodep INTO THE LIST
   REPRESENTED BY rheadpp SUCH THAT THE NODE WITH THE LARGEST ANCESTOR IS AT
   AT THE HEAD OF THE LIST */
insert_by_anc_msize(rheadpp,nodep)
struct group **rheadpp, *nodep;
{
int msize;

msize = anc_msize(nodep);

if (*rheadpp == NULL)
 {*rheadpp = nodep;
  nodep->nextgroup = NULL;
 }
else
 {while ( (*rheadpp)->nextgroup != NULL  &&  anc_msize(*rheadpp) >= msize )
   rheadpp = &((*rheadpp)->nextgroup);
  if ((*rheadpp)->nextgroup == NULL)
   {if (anc_msize(*rheadpp) >= msize)
     {(*rheadpp)->nextgroup = nodep;
      nodep->nextgroup = NULL;
     }
    else
     {nodep->nextgroup = *rheadpp;
      *rheadpp = nodep;
     }
   }
  else
   {nodep->nextgroup = *rheadpp;
    *rheadpp = nodep;
   }
 }

} /* end insert_by_anc_msize()... */



/* anc_msize() RETURNS nodep->nodesize, OR, IF ANCESTORS EXIST, THE NODE SIZE
   OF THE LARGEST ANCESTOR (HAVING MOST ELEMENTS) OF nodep */
anc_msize(nodep)
struct group *nodep;
{
struct group **arraypp[100];
int acount;

if (nodep->index2 == 0)   return(nodep->nodesize);
acount= fill_ancestor_array(nodep,arraypp);
if (acount > 0)   return((*(arraypp[0]))->nodesize);
else   return(nodep->nodesize);

} /* end anc_msize... */



/* fill_ancestor_array() FILLS THE ARRAY OF POINTERS arraypp WITH POINTERS
   TO ANCESTORS OF nodep. THESE ANCESTORS ARE IDENTIFIED BY THE LABEL index2
   IN THE index2head HEADED LIST. ONLY TRULY DIFFERENT ANCESTORS ARE KEPT,
   AND IN arraypp THEY ARE LISTED BY INCREASING NODE SIZE. */
fill_ancestor_array(nodep,arraypp)
struct group *nodep, **arraypp[];
{
struct group **ipp;
int count= -1;

ipp= &index2head;
while (*ipp != NULL)
 {if ( (*ipp)->index2 == nodep->index2  &&  difference(*ipp,nodep) )
   {if (++count < 100)   arraypp[count]= ipp;
    else
     {fprintf(outfp,
	"\n\n RPEAT-WARNING: In fill_ancestor_array: count exceeds 100.\n\n");
      break;}
   }
  ipp= &((*ipp)->nextgroup);
 }

return(++count);
} /* end fill_ancestor_array() */



/* slantmatch() COMPARES THE SLANTS OF NODES gp AND ip AND RETURNS 1 IF AT
   LEAST mincount OF THESE SLANTS DIFFER BY LESS THAN SLANTERROR (AND
   CORRESPOND TO COORDINATES WITHIN ALIGNMAX DISTANCE); RETURNS 0 OTHERWISE */
slantmatch(slants,gp,ip,offsets)
int slants[MAXSNODE], offsets[MAXSNODE];
struct group *gp, *ip;
{
int i, ibeg, j, s, slt, count= 0, mincount= 1;
int ipslants[MAXSNODE];

if (gp->nodesize >= BIGNODE  ||  ip->nodesize >= BIGNODE)   mincount= 2;

ipslants[0]= ip->nodesize-1;
for (i=1;i<ip->nodesize;++i)   ipslants[i]= ip->crd[i][0] - ip->crd[i-1][0];

if (ip->nodesize > 2)
 {ibeg= 1;
  for (j=1;j<slants[0];++j)
   {for (i=ibeg;i<ip->nodesize;++i)
     {if ( abs(ipslants[i] - slants[j]) <= SLANTERROR  &&
	   abs(ip->crd[i-1][0] - gp->crd[j-1][0]) <= ALIGNMAX )
       {offsets[++count]= ip->crd[i-1][0] - gp->crd[j-1][0];
	break;
       }
     }
    if (i < ip->nodesize)   ibeg= i+1;
   }
 }
else	/* case: ip->nodesize == 2 */
 {for (s=1;s<=slants[0];++s)
   {for (j=1;j+s<=1+slants[0];++j)
     {for (i=0,slt=0;i<s;++i)   slt+= slants[j+i];
      if ( abs(ipslants[1] - slt) <= SLANTERROR  &&
	   abs(ip->crd[0][0] - gp->crd[j-1][0]) <= ALIGNMAX )
       {offsets[++count]= ip->crd[0][0] - gp->crd[j-1][0];
	break;
       }
     }
    if (j+s<=1+slants[0])   break;
   }
 }

offsets[0]= count;
if (count >= mincount)   return(1);
else   return(0);

} /* end slantmatch() */



/* mesh_groups TAKES THE NODES gp AND *ipp AND MESHES A SUBSET OF *ipp INTO gp,
   REMOVING *ipp FROM ITS LINKED LIST IN THE PROCESS */
mesh_groups(gp,ipp,offsets)
struct group *gp, **ipp;
int offsets[MAXSNODE];
{
int i, j, k= 0, oldi, flag= 1;
int count= 0, osvalue, osmatrix[MAXSNODE][2];
struct group *ip= *ipp, *wingp, *newgnode();

for (i=0;i<MAXSNODE;++i)   osmatrix[i][0]= osmatrix[i][1]= 0;

if (offsets[0] > 1)
 {for (i=1;i <= offsets[0];++i)
   {flag= 1;
    j= 0;
    while (flag  &&  j < k)
     {if (abs(offsets[i] - osmatrix[j][1]) <= SLANTERROR)
       {++osmatrix[j][0];
        if (osmatrix[j][0] > count)
	 {count= osmatrix[j][0];
          osvalue= osmatrix[j][1];
         }
        flag = 0;
       }
      j++;
     }
    if (flag)
     {osmatrix[k][0] = 1;
      osmatrix[k++][1] = offsets[i];
      if (osmatrix[j][0] > count)
       {count= osmatrix[j][0];
        osvalue= osmatrix[j][1];
       }
      }
   }
 }
else   osvalue= offsets[1];
	/* AT THIS POINT osvalue CONTAINS THE PREDOMINANT OFFSET (OCCURRING,
	   WITHIN SLANTERROR, IN count PAIRS OF ENTRIES FROM gp AND ip) */

if (abs(osvalue) <= ALIGNMAX)
 {*ipp = (*ipp)->nextgroup;	/* REMOVAL STEP */
  wingp= newgnode();
  wingp->nodesize = gp->nodesize; 
  k= 0;   i= 0;   flag= 1;
  for (j=0;j < gp->nodesize;++j,flag=1)
   {oldi= i;
    while (i < ip->nodesize  &&  flag)
     {if (abs((ip->crd[i][0] - gp->crd[j][0]) - osvalue) <= SLANTERROR)
       {flag= 0;
        wingp->crd[j][0] = ip->crd[i][0];
        wingp->crd[j][1] = ip->crd[i][1];
        ++k;
       }
      ++i;
     }
    if (flag) i= oldi;
   }
  wingp->index2 = ip->index2;
  if (k < ip->nodesize)
   {ip->index1 = ++INDEX;
    wingp->index1 = ip->index1;
    insert_by_pos(&index1head,ip);
   }
  insertwing(gp,wingp);
  return(1);
 }
else return(0);

} /* end mesh_groups() */



/* insertwing() goes to the trouble of figuring out whether the wingp 
   should be inserted left or right, then calls the appropriate function 
   until the insertion point is located, then inserting the wingp.  I 
   assume no strange overlapping core blocks from this point 
   forth--otherwise, I have a combinatorial explosion! */
insertwing(gp,wingp)
struct group *gp, *wingp;
{
int i;

for (i=0;i < wingp->nodesize;++i)   if (wingp->crd[i][1] != 0) break;
	/* i IS NOW THE FIRST INDEX FOR WHICH wingp->crd[i][1] != 0 */

if (wingp->crd[i][0] < gp->crd[i][0])
 recurwing(&(gp->leftwing),wingp,i,0);
else if (wingp->crd[i][0] >= gp->crd[i][0]) 
 recurwing(&(gp->rightwing),wingp,i,1); 

} /* end insertwing() */



/* recurwing() is an amazing routine.. it considers all non-overlapping cases, 
     recurring until it is capable of inserting wingp into indexp's horizontal
     graph space, whether it be to the right or the left!                     */
recurwing(indexpp,wingp,iwing,dir)
struct group **indexpp, *wingp;
int iwing, dir;
{

if (*indexpp == NULL)   *indexpp= wingp;
else
 {if (insq((*indexpp),wingp,iwing,dir) == 1)
   {if (dir == 0)   wingp->leftwing = *indexpp;
    else   wingp->rightwing = *indexpp;
    *indexpp = wingp;
   }
  else
   {if (dir == 0)   recurwing(&((*indexpp)->leftwing),wingp,iwing,dir);
    else   recurwing(&((*indexpp)->rightwing),wingp,iwing,dir);
   }
 }

} /* end recurwing() */



/* insq() returns 1 if wingp should be inserted immediately before
     (toward the center- depending upon direction) the next node, 
     represented by gp; returns 0 if wingp should be inserted 
     'later' ......this is, in reality, the comparison function!  */
insq(gp,wingp,iwing,dir)
struct group *gp, *wingp;
int iwing, dir;
{
int i, diffr;

if (gp->crd[iwing][1] == 0)
 {i= iwing;
  while ((gp->crd[i][1] == 0  ||  wingp->crd[i][1] == 0)  &&
         i < gp->nodesize)   ++i;
  if (i== gp->nodesize)   return(1);
  else
   {diffr = gp->crd[i][0] - wingp->crd[i][0];
    if (dir == 0) diffr *= -1;
    if (diffr > 0) return(1);
    else return(0);
   }
 }
else
 {diffr = gp->crd[iwing][0] - wingp->crd[iwing][0];
  if (dir == 0) diffr *= -1; /* this line distinguishes for left- and right- */
  if (diffr > 0) return(1);
  else return(0);
 }

} /* end insq() */



makedoublylinked()
{
struct group *nodep= groupshead, *lastp, *ip;

while (nodep != NULL)
 {ip= nodep->rightwing;
  lastp= nodep;
  while (ip != NULL)   {ip->leftwing = lastp; lastp = ip; ip = ip->rightwing;}
  ip= nodep->leftwing;
  lastp= nodep;
  while (ip != NULL)   {ip->rightwing = lastp; lastp = ip; ip = ip->leftwing;}
  nodep = nodep->nextgroup;
 }

} /* end makedoublylinked() */



/* unalignsubsets LOOKS FOR REDUNDANCY IN THE ALIGNMENTS. IT REMOVES REDUNDANT
   NODES AND PUTS THEM BACK IN THE groupshead LIST. */
unalignsubsets()
{
struct group *gp= groupshead;

while (gp != NULL)
 {if (gp->nextgroup != NULL)   unalignworks(gp);
  gp = gp->nextgroup;
 }

} /* end unalignsubsets() */



/* unalignworks CHECKS WHETHER nodep CONTAINS REDUNDANCIES IN ITS ALIGNMENT.
   IT REMOVES REDUNDANT NODES AND PUTS THEM BACK IN THE groupshead LIST. */
unalignworks(nodep)
struct group *nodep;
{
int i;
struct group *ip, *jp, *leftmost(), *nextp;

if (nodep->leftwing == NULL  &&  nodep->rightwing == NULL)   return;

ip= leftmost(nodep);

while (ip != NULL)
 {jp= leftmost(nodep);
  while (jp != NULL)
   {nextp= jp->rightwing;
    for (i=0;i< ip->nodesize;++i)
     {if (jp->crd[i][1] != 0)
       if (jp->crd[i][0] < ip->crd[i][0] || 
	   jp->crd[i][1] > ip->crd[i][1] )   break;
     }
    if (i == ip->nodesize  &&  jp != ip)
     {remove_from_alignment(jp); 
if (MSGPRT) {
 fprintf(outfp,"\nSOMETHING REMOVED FOR NODE AT %4d to %4d:",
		nodep->crd[0][0]+1, nodep->crd[0][1]+1 );
 for (i=0;i< ip->nodesize;++i)
  fprintf(outfp,"\ndiscarded %d-%d for %d-%d",
		jp->crd[i][0]+1, jp->crd[i][1]+1,
		ip->crd[i][0]+1, ip->crd[i][1]+1 );
 }/* end MSGPRT */
     }
    jp= nextp; 
   }
  ip= ip->rightwing;
 }

} /* end unalignworks() */



/* remove_from_alignment() REMOVES nodep FROM ITS ALIGNMENT, LOOKS UP THE
   REPRESENTATION OF nodep IN THE index1head HEADED LIST (IF ANY) AND MOVES IT
   FROM THAT LIST BACK TO THE groupshead HEADED LIST */
remove_from_alignment(nodep)
struct group *nodep;
{
struct group **ipp;

if (nodep->index1 > 0)
 {ipp= &index1head;
  while ((*ipp)->nextgroup != NULL  && 
         (*ipp)->index1 != nodep->index1)
   ipp= &((*ipp)->nextgroup);

  if ((*ipp)->index1 != nodep->index1)
   {fprintf(stderr,ERRORMSG2,nodep->index1); fflush(outfp); exit(-1);}

  if (nodep->leftwing != NULL)
   (nodep->leftwing)->rightwing = nodep->rightwing;
  if (nodep->rightwing != NULL)
   (nodep->rightwing)->leftwing = nodep->leftwing;

  nodep = *ipp;
  *ipp = nodep->nextgroup;
  nodep->leftwing = NULL;
  nodep->rightwing = NULL;
  nodep->nextgroup = NULL;
  nodep->noprtflag = 0;
  nodep->index1 = 0;
  insert_by_nodesize(nodep,&groupshead);
 }
else
 {if (nodep->leftwing != NULL)
   (nodep->leftwing)->rightwing = nodep->rightwing;
 if (nodep->rightwing != NULL)
  (nodep->rightwing)->leftwing = nodep->leftwing;
 }

} /* end remove_from_alignment() */



insert_by_nodesize(nodep,rheadpp)
struct group *nodep, **rheadpp;
{

if (*rheadpp == NULL)
 {*rheadpp= nodep;
  nodep->nextgroup = NULL;
 }
else
 {while ((*rheadpp)->nextgroup != NULL  && 
         (*rheadpp)->nodesize > nodep->nodesize)
   rheadpp= &((*rheadpp)->nextgroup);
  if ((*rheadpp)->nextgroup == NULL)
   {if ((*rheadpp)->nodesize > nodep->nodesize)
     {(*rheadpp)->nextgroup = nodep;
      nodep->nextgroup = NULL;
     }
    else
     {nodep->nextgroup = *rheadpp;
      *rheadpp = nodep;
     }
   }
  else
   {nodep->nextgroup = *rheadpp;
    *rheadpp = nodep;
   }
 }

} /* end insert_by_nodesize() */



/* extendgroups() LOOKS ON BOTH SIDES OF THE ALIGNMENT GROUPS FOR EXTENSIONS
   WITH MISMATCHES, EXTENSIONS WHICH MUST NECESSARILY BE SMALLER THAN THE
   COREBLOCK SIZE */
extendgroups()
{
struct group *nodep, *gp, *rightmost(), *leftmost();
int success= 1;

for (nodep= groupshead;nodep != NULL;nodep = nodep->nextgroup)
 {while (success)
   {gp = rightmost(nodep);
    success = rextend(gp);
   }
  success= 1;
  while (success)
   {gp = leftmost(nodep);
    success = lextend(gp);
   }
 }

} /* end extendgroups() */



/* rextend LOOKS 3 AND 4 MISMATCH ERRORS TO THE RIGHT OF THE RIGHT END OF gp,
   CHECKS FOR A PERFECT 2-MATCH BEYOND THAT POINT, AND RETURNS 1 IF SUCH
   OCCURS OR 0 OTHERWISE */
rextend(gp)
struct group *gp;
{
int delta, deltamin= 3, deltamax= 4;
int i, flag1= 1, flag2, flag3, a1, a2;
struct group *newgnode(), *tgp;

delta= deltamin;
while (flag1  &&  delta <= deltamax)
 {for (i=0,flag2=0,flag3=0;i<gp->nodesize;++i)
   {if (gp->crd[i][1] > 0)
     {if (gp->crd[i][1] + delta + 2 >= SQLGTH)   flag3= 1;
      if (flag2 == 0  &&  flag3 != 1)
       {flag2= 1;
        a1= TRL[protein[gp->crd[i][1] + delta + 1]];
        a2= TRL[protein[gp->crd[i][1] + delta + 2]];
       }
      else if (flag3 != 1)
       {if (TRL[protein[gp->crd[i][1]+delta+1]] != a1  || 
	    TRL[protein[gp->crd[i][1]+delta+2]] != a2)   flag3= 1;
       }
     }
   }
  if (flag3 == 0)   flag1= 0;
  else ++delta;
 }

if (flag1 == 0)
 {tgp = newgnode();
  gp->rightwing = tgp;
  tgp->nodesize = gp->nodesize;
  for (i=0;i<tgp->nodesize;i++)
   {if (gp->crd[i][1] > 0)
     {tgp->crd[i][0] = gp->crd[i][1] + delta + 1;
      tgp->crd[i][1] = tgp->crd[i][0] + 1;
     }
   }
  return(1);
 }
else return(0);

} /* end rextend() */



/* lextend LOOKS 3 AND 4 MISMATCH ERRORS TO THE LEFT OF THE LEFT END OF gp,
   CHECKS FOR A PERFECT 2-MATCH BEYOND THAT POINT, AND RETURNS 1 IF SUCH
   OCCURS OR 0 OTHERWISE */
lextend(gp)
struct group *gp;
{
int delta, deltamin= 3, deltamax= 4;
int i, flag1= 1, flag2, flag3, a1, a2;
struct group *newgnode(), *tgp;

delta= deltamin;
while (flag1  &&  delta <= deltamax)
 {for (i=0,flag2=0,flag3=0;i<gp->nodesize;++i)
   {if (gp->crd[i][1] > 0)
     {if (gp->crd[i][0] - delta - 2 < 0)   flag3= 1;
      if (flag2 == 0  &&  flag3 != 1)
       {flag2= 1;
        a1= TRL[protein[gp->crd[i][0] - delta - 2]];
        a2= TRL[protein[gp->crd[i][0] - delta - 1]];
       }
      else if (flag3 != 1)
       {if (TRL[protein[gp->crd[i][0]-delta-2]] != a1  || 
	    TRL[protein[gp->crd[i][0]-delta-1]] != a2)   flag3= 1;
       }
     }
   }
  if (flag3 == 0)   flag1= 0;
  else ++delta;
 }

if (flag1 == 0)
 {tgp = newgnode();
  gp->leftwing = tgp;
  tgp->nodesize = gp->nodesize;
  for (i=0;i<tgp->nodesize;i++)
   {if (gp->crd[i][1] > 0)
     {tgp->crd[i][0] = gp->crd[i][0] - delta - 2;
      tgp->crd[i][1] = tgp->crd[i][0] + 1;
     }
   }
  return(1);
 }
else return(0);

} /* end lextend() */



/* leftmost STARTS WITH SOME nodep POINTER AND GOES LEFT UNTIL IT FINDS THE
   LEFTMOST WING OF THAT NODE, THE ADDRESS OF WHICH IT RETURNS */
struct group *leftmost(nodep)
struct group *nodep;
{
struct group *ip= nodep;

while (ip->leftwing != NULL)   ip= ip->leftwing;
return(ip);

} /* end leftmost() */



/* rightmost STARTS WITH SOME nodep POINTER AND GOES RIGHT UNTIL IT FINDS THE
   RIGHTMOST WING OF THAT NODE, THE ADDRESS OF WHICH IT RETURNS */
struct group *rightmost(nodep)
struct group *nodep;
{
struct group *ip= nodep;

while (ip->rightwing != NULL)   ip= ip->rightwing;
return(ip);

} /* end rightmost() */



lexterror()
{
struct group *ip, *nodep, *tgp;
int sflag;

for (ip= groupshead;ip != NULL;ip= ip->nextgroup)
 {if (ip->noprtflag > 0)   continue;
  nodep= ip;
  while (nodep->leftwing != NULL)
   {tgp = nodep;
    nodep = nodep->leftwing;
    nodep->rightwing = tgp;
   }
  while (nodep != NULL)
   {sflag= 1;
    while (sflag)    sflag= lextwork(nodep);
    nodep = nodep->rightwing;
   }
 }

} /* end lexterror() */



/* lextwork() returns 1 if successful at extending at left 
	0,1,or 2 mismatches or deletion/insertions... */
lextwork(nodep)
struct group *nodep;
{
int i, j, gapsize, n, numseq= 0, sflag;
int dipcnt[23][23], consdipn= 0, consdip[2];

for (i=0;i<23;++i) for (j=0;j<23;++j)   dipcnt[i][j]= 0;

for (gapsize=0;gapsize<3;++gapsize)
 {for (i=0;i<nodep->nodesize;++i)
   {if (nodep->crd[i][1] > 0)
     {if (gapsize == 0)   ++numseq;
      if (nodep->crd[i][0] - gapsize - 2 >= 0)
       {n= ++(dipcnt[TRL[protein[nodep->crd[i][0]-gapsize-2]]]
			[TRL[protein[nodep->crd[i][0]-gapsize-1]]]);
        if (n > consdipn)
	 {consdipn= n;
	  consdip[0]= TRL[protein[nodep->crd[i][0]-gapsize-2]];
	  consdip[1]= TRL[protein[nodep->crd[i][0]-gapsize-1]];
	 }
       }
     }
   }
 }

if (consdipn >= numseq)
 {if (covers(nodep,consdip))
   {for (i=0;i<nodep->nodesize;++i)
     {if (nodep->crd[i][1] > 0)
       {gapsize= 0;
        sflag= 0;
        while (sflag == 0  &&  gapsize < 3)
	 {if (TRL[protein[nodep->crd[i][0]-gapsize-2]] == consdip[0]  &&
	      TRL[protein[nodep->crd[i][0]-gapsize-1]] == consdip[1] )
	   {sflag= 1;
	    nodep->crd[i][0] -= (gapsize + 2);
	   }
	  else   ++gapsize;
	 }
       }
     }
    furtherextension(nodep);
    return(1);
   }
  else   return(0);
 }
else   return(0);

} /* end lextwork() */



covers(nodep,consdip)
struct group *nodep;
int consdip[2];
{
int i, pos1= -1, pos2= -1, gapsize, sflag;

for (i=0;i<nodep->nodesize;++i)
 {if (nodep->crd[i][1] > 0)
   {gapsize= 0;
    sflag= 0;
    while (sflag == 0  &&  gapsize < 3)
     {if (nodep->crd[i][0]-gapsize-2 < 0)   return(0);
      if (TRL[protein[nodep->crd[i][0]-gapsize-2]] == consdip[0]  &&
          TRL[protein[nodep->crd[i][0]-gapsize-1]] == consdip[1] )   sflag= 1;
      else   ++gapsize;
     }
    if (gapsize == 3)   return(0);
    if (sflag == 1)
     {if (pos1 == -1)   pos1= nodep->crd[i][0]-gapsize-2;
      else if (pos2 == -1)   pos2= nodep->crd[i][0]-gapsize-2;
     }
   }
 }

if (pos1 == pos2)   return(0);
return(1);

} /* end covers() */



furtherextension(nodep)
struct group *nodep;
{
int sflag= 1, i, flag, delta= 0, alpha;

while (sflag)
 {flag= 0;
  ++delta;
  for (i=0;i<nodep->nodesize;++i)
   {if (nodep->crd[i][1] > 0)
     {if (nodep->crd[i][0] - delta < 0)   {sflag= 0; break;}
      if (sflag  &&  flag == 0)
       {alpha= TRL[protein[nodep->crd[i][0] - delta]];
        flag= 1;
       }
      else if (alpha != TRL[protein[nodep->crd[i][0] - delta]])   sflag= 0;
     }
   }
 }

if (--delta > 0)
 {for (i=0;i<nodep->nodesize;++i)
   if (nodep->crd[i][1] > 0)   nodep->crd[i][0]-= delta;
 }

} /* end furtherextension() */



/* cleanalignments MERGES OVERLAPPING NODES (IF CALLED WITH calln=1) AND
   ELIMINATES SUBSETS (IF CALLED WITH calln=2) IN EACH HORIZONTAL ALIGNMENT */
cleanalignments(calln)
int calln;
{
struct group *ip= groupshead, *nodep, *tgp;

while (ip != NULL)
 {nodep= ip;
  while (nodep->leftwing != NULL)
   {tgp = nodep;
    nodep = nodep->leftwing;
    nodep->rightwing = tgp;
   }
  while (nodep != NULL)
   {if (calln == 1)
     {if (cleanal1(nodep,nodep->rightwing,ip))   nodep = nodep->rightwing;}
    else
     {if (cleanal2(nodep,nodep->rightwing,ip))   nodep = nodep->rightwing;}
   }
  ip= ip->nextgroup;
 }

} /* end cleanalignments() */



/* cleanal1 MERGES nodep AND rwingp IF THEY OVERLAP, TAKING CARE THAT THE
   ELIMINATED NODE OF THE REDUNDANT PAIR IS NOT THE CENTRAL NODE cnodep THAT
   ANCHORS THE ALIGNMENT IN THE groupshead LIST */
cleanal1(nodep,rwingp,cnodep)
struct group *nodep, *rwingp, *cnodep;
{
int i;

if (rwingp == NULL)   return(1);

for (i=0;i<nodep->nodesize;++i)
 {if ((nodep->crd[i][1] == 0  &&  rwingp->crd[i][1] != 0)  ||
      (rwingp->crd[i][1] == 0  &&  nodep->crd[i][1] != 0) )   return(1);
 }

for (i=0;i<nodep->nodesize;++i)
 {if (nodep->crd[i][1] != 0)
   if (rwingp->crd[i][0] > nodep->crd[i][1])   return(1);
 }

/* AT THIS POINT IT IS ESTABLISHED THAT rwingp HAS THE SAME LINES OF SEQUENCE
   AS DOES nodep, AND FURTHERMORE NO BEGINPOINTS OF rwingp ARE BEYOND THE
   ENDPOINTS OF THE CORRESPONDING nodep ENTRIES; THUS, rwingp AND nodep
   SHOULD BE MERGED: */

for (i=0;i<nodep->nodesize;++i)
 {if (nodep->crd[i][1] != 0)
   {if (rwingp->crd[i][0] > nodep->crd[i][0])
     rwingp->crd[i][0] = nodep->crd[i][0];
    else   nodep->crd[i][0] = rwingp->crd[i][0];
    if (rwingp->crd[i][1] < nodep->crd[i][1])
     rwingp->crd[i][1] = nodep->crd[i][1];
    else   nodep->crd[i][1] = rwingp->crd[i][1];
   }
 }

if (rwingp != cnodep)
 {nodep->rightwing = rwingp->rightwing;
  if (nodep->rightwing != NULL)   (nodep->rightwing)->leftwing = nodep;
if (MSGPRT)
 {fprintf(outfp,"\ncleanal1A: Subset eliminated at node %d-%d\n",
	nodep->crd[0][0]+1, nodep->crd[0][1]+1);
  printit(nodep);
 }
  if (nodep->rightwing != NULL)   return(0);
  else   return(1);
 }
else
 {rwingp->leftwing = nodep->leftwing;
  if (rwingp->leftwing != NULL)
   (rwingp->leftwing)->rightwing = nodep->rightwing; 
if (MSGPRT)
 {fprintf(outfp,"\ncleanal1B: Subset eliminated at node %d-%d\n",
	nodep->crd[0][0]+1, nodep->crd[0][1]+1);
  printit(nodep);
 }
  return(1);
 }

} /* end cleanal1()  */



/* cleanal2 MERGES nodep AND rwingp IF nodep IS A SUBSET OF rwingp, TAKING
   CARE THAT THE ELIMINATED NODE OF THE REDUNDANT PAIR IS NOT THE CENTRAL NODE
   cnodep THAT ANCHORS THE ALIGNMENT IN THE groupshead LIST */
cleanal2(nodep,rwingp,cnodep)
struct group *nodep, *rwingp, *cnodep;
{
int i, naa= 0;

if (rwingp == NULL)   return(1);

for (i=0;i<nodep->nodesize;++i)
 if (nodep->crd[i][1] != 0  &&  rwingp->crd[i][1] != 0)   ++naa;
if (naa < 1)   return(1);

for (i=0;i<nodep->nodesize;++i)
 {if (nodep->crd[i][1] != 0  &&  rwingp->crd[i][1] != 0)
   if ((nodep->crd[i][0] != rwingp->crd[i][0]  &&
        nodep->crd[i][0] != rwingp->crd[i][0] - 1  &&
	nodep->crd[i][0] != rwingp->crd[i][0] - 2 ) || 
       nodep->crd[i][1] >  rwingp->crd[i][1]  ||
       rwingp->crd[i][1] > nodep->crd[i][1] + 2 )   return(1);
 }

for (i=0;i<nodep->nodesize;++i)
 {if (nodep->crd[i][1] == 0)
   {nodep->crd[i][0] = rwingp->crd[i][0];
    nodep->crd[i][1] = rwingp->crd[i][1];
    continue;
   }
  if (rwingp->crd[i][1] == 0)
   {rwingp->crd[i][0] = nodep->crd[i][0];
    rwingp->crd[i][1] = nodep->crd[i][1];
    continue;
   }
  rwingp->crd[i][0] = nodep->crd[i][0];
  if (nodep->crd[i][1] < rwingp->crd[i][1])
   nodep->crd[i][1] = rwingp->crd[i][1];
  else
   rwingp->crd[i][1] = nodep->crd[i][1];
 }

if (rwingp != cnodep)
 {nodep->rightwing = rwingp->rightwing;
  if (nodep->rightwing != NULL)   (nodep->rightwing)->leftwing = nodep;
if (MSGPRT)
 {fprintf(outfp,"\ncleanal2A: Subset eliminated at node %d-%d\n",
        nodep->crd[0][0]+1, nodep->crd[0][1]+1);
  printit(nodep);
 }
  if (nodep->rightwing != NULL)   return(0);
  else   return(1);
 }
else
 {rwingp->leftwing = nodep->leftwing;
  if (rwingp->leftwing != NULL)
   (rwingp->leftwing)->rightwing = nodep->rightwing; 
if (MSGPRT)
 {fprintf(outfp,"\ncleanal2B: Subset eliminated at node %d-%d\n",
        nodep->crd[0][0]+1, nodep->crd[0][1]+1);
  printit(nodep);
 }
  return(1);
 }

} /* end cleanal2() */



olmesh()
{
struct ogroup *nodep= ogroupshead, *ip, **ipp;

while (nodep != NULL)
 {ip= nodep->next;
  ipp= &(nodep->next);
  while (ip != NULL)
   {if (ip->beg <= nodep->end  &&  ip->cslant == nodep->cslant)
     {if (ip->end > nodep->end)   nodep->end = ip->end;
      *ipp= ip->next;
      ip= *ipp;
     }
    else
     {ip= ip->next;
      ipp= &(ip->next);
     }
   }
  nodep= nodep->next;
 }

} /* end olmesh() */



extendends()
{
struct ogroup *nodep= ogroupshead;

while (nodep != NULL)
 {nodep->beg -= (2*nodep->cslant);
  nodep->end += (2*nodep->cslant);
  if (nodep->cslant == 0)
   { nodep->beg -= 10; nodep->end += 10; }
  if (nodep->beg < 0)   nodep->beg = 0;
  if (nodep->end >= SQLGTH)   nodep->end = SQLGTH - 1;
  nodep = nodep->next;
 }

} /* end extendends() */



order_by_place()
{
struct group *gp= groupshead, *ip, *newrheadp= NULL;

while (gp != NULL)
 {ip= gp->nextgroup;
  gp->nextgroup = NULL;
  insert_by_place(gp, &(newrheadp));
  gp= ip;
 } 

groupshead= newrheadp;

} /* end order_by_place() */



insert_by_place(nodep,rheadpp)
struct group *nodep, **rheadpp;
{

if (*rheadpp == NULL)
 {*rheadpp= nodep;
  nodep->nextgroup= NULL;
 }
else
 {while ( (*rheadpp)->nextgroup != NULL  &&
          beginpoint(*rheadpp) < beginpoint(nodep) )
   rheadpp= &((*rheadpp)->nextgroup);
  if ((*rheadpp)->nextgroup == NULL)
   {if (beginpoint(*rheadpp) < beginpoint(nodep))
     {(*rheadpp)->nextgroup= nodep;
      nodep->nextgroup= NULL;
     }
    else
     {nodep->nextgroup= *rheadpp;
      *rheadpp= nodep;
     }
   }
  else
   {nodep->nextgroup= *rheadpp;
    *rheadpp= nodep;
   }
 }

} /* end insert_by_place */



int beginpoint(nodep)
struct group *nodep;
{
int i, leftmost;
struct group *ip;

leftmost= nodep->crd[0][0];
ip= nodep;

while (ip->leftwing != NULL)
 {ip= ip->leftwing;
  for (i=0;i<ip->nodesize;++i)
   {if (nodep->crd[i][1] != 0  &&  nodep->crd[i][0] < leftmost)
    leftmost= nodep->crd[i][0];
   }
 }

return(leftmost);

} /* end beginpoint() */



remove_subsets(rheadp)
struct group *rheadp;
{
struct group *nodep= rheadp, **ipp;
int i;

while (nodep != NULL)
 {ipp= &rheadp;
  while (*ipp != NULL)
   {if (*ipp != nodep  &&  subset_of(*ipp,nodep))
     {
if (MSGPRT) {
fprintf(outfp,"\nIn remove_subsets:");
for (i=0;i<nodep->nodesize;++i)
 fprintf(outfp,"\n   KEPT %d - %d", nodep->crd[i][0]+1, nodep->crd[i][1]+1);
for (i=0;i<(*ipp)->nodesize;++i)
 fprintf(outfp,"\nREMOVED %d - %d", (*ipp)->crd[i][0]+1, (*ipp)->crd[i][1]+1);
}
      *ipp= (*ipp)->nextgroup;
     }
    else   ipp= &((*ipp)->nextgroup);
   }
  nodep= nodep->nextgroup;
 }

} /* end remove_subsets() */



subset_of(childp,parentp)
struct group *childp, *parentp;
{
int i, j= 0;

if (parentp->nodesize < childp->nodesize)   return(0);

for (i=0;i< parentp->nodesize;++i)
 if (childp->crd[j][0] == parentp->crd[i][0]  &&
     childp->crd[j][1] == parentp->crd[i][1]    )   ++j;

if (j == childp->nodesize)   return(1);
else   return(0);

} /* end subset_of() */



/* print_amb() WILL PRINT EACH LINE OF MATCH ON THE SAME LINE OF OUTPUT, 
   HORIZONTALLY CUTTING ACROSS THE ALIGNED NODES */
print_amb()
{
struct group *gp= groupshead;

while (gp != NULL)
 {if (gp->noprtflag != 0)   {gp= gp->nextgroup; continue;}
  if (!FirstPrint)   fprintf(outfp,"______________________________\n");
  if (screenfit(gp))
   {printgroup(gp,0,(struct group *)NULL); fprintf(outfp,"\n");
    printseq(gp);}
  else  {screenspecial(gp); printseq(gp);}
  gp= gp->nextgroup;
 }

} /* end print_amb() */



/* screenfit() RETURNS 1 ONLY IF THERE ARE LESS THAN 5 NODES ALIGNED (80 
   CHARACTERS) IN THE nodep ALIGNMENT MATCH.  OTHERWISE, IT RETURNS ZERO */
screenfit(nodep)
struct group *nodep;
{
int i= 0;
struct group *gp;

while (nodep->leftwing != NULL)
 {gp = nodep;
  nodep = nodep->leftwing;
  nodep->rightwing = gp;
 }

while (nodep != NULL)
 {nodep = nodep->rightwing; ++i;}

if (i>4) return(0);   else return(1);

} /* end screenfit() */



/* printgroup() will feed node, matchnum by matchnum, to program that will
    print that one "line" out to the stdout....                          */
/* if brch is 1, then output is being split on two 'screens' therefore, 
   alignment distances for most right-hand end of first 'screen' are
   to be calculated using restp as the virtual next rightwing node. */
printgroup(nodep,brch,restp)
struct group *nodep, *restp;
int brch;
{
struct group *gp;
int i;

if (FirstPrint)
 {fprintf(outfp,"\nAligned matching blocks:\n\n");   FirstPrint= 0;}

while (nodep->leftwing != NULL)
 {gp = nodep;
  nodep = nodep->leftwing;
  nodep->rightwing = gp;
 }
if ( nodep->rightwing != NULL  ||  brch == -1 )
 {fprintf(outfp,"\n");
  for (i=0;i<nodep->nodesize;++i)   printline(nodep,i,brch,restp);
 }

} /* end printgroup() */



/* printline() prints one 'line' based on the matchnum (off of nodesize)
	that is being focused upon...starting from the left-most extension,
	all the way to the right most (just the numbers) */
printline(nodep,match,brch,restp)
struct group *nodep, *restp;
int match, brch;
{
int lastend;

if (nodep->crd[match][1] != 0)
 fprintf(outfp,"[%4d-%4d]",nodep->crd[match][0]+1,nodep->crd[match][1]+1 );
else   fprintf(outfp,"[         ]");

lastend= nodep->crd[match][1];
nodep= nodep->rightwing;

while (nodep != NULL)
 {if ( lastend != 0  &&  nodep->crd[match][1] != 0 )
   fprintf(outfp,"-(%4d)-",nodep->crd[match][0] - lastend -1 );
  else   fprintf(outfp,"--------");
  if (nodep->crd[match][1] != 0)
   fprintf(outfp,"[%4d-%4d]",nodep->crd[match][0]+1,nodep->crd[match][1]+1 );
  else   fprintf(outfp,"[         ]");
  lastend= nodep->crd[match][1];
  nodep= nodep->rightwing;
 }

if (brch == 1)
 {if ( lastend != 0  &&  restp->crd[match][1] != 0 )
   fprintf(outfp,"-(%4d)-",restp->crd[match][0] - lastend - 1);
  else   fprintf(outfp,"--------");
 } 

fprintf(outfp,"\n");

} /* end printline() */



/* printseq() will print out the actual sequences as we go, each core
	block at a time... the label for each block is the starting and
	ending points.  NOTE that printseq will not print matches of
	sequence length 2 or smaller. This is because they are not worth
	printing--they're just a straight match of 2 */
printseq(nodep)
struct group *nodep;
{
int i, j;

while (nodep->leftwing != NULL)   nodep= nodep->leftwing;

while (nodep != NULL)
 {i= 0;
  while (nodep->crd[i][1] == 0)   ++i;
  if (nodep->crd[i][1] - nodep->crd[i][0] > 2)
   {if (nodep->index1 == 0  ||  is_expandednode(nodep))
     {if (FinalPrint)   print_ambseq(nodep,0);
      else
       {while (i<nodep->nodesize)
 	 {if (nodep->crd[i][1] != 0)
	   {fprintf(outfp,"[%4d-%4d]   ",
			nodep->crd[i][0]+1,nodep->crd[i][1]+1 );
	    if (nodep->crd[i][1] - nodep->crd[i][0] < 60)
	     for (j=nodep->crd[i][0];j<=nodep->crd[i][1];++j) 
	       fprintf(outfp,"%c",SYMB[TRL[protein[j]]]);
	    else   fprintf(outfp,"see sequence above");
	    fprintf(outfp,"\n");
	   }
          ++i;
         }
        fprintf(outfp,"\n");
       }
     }
    if (nodep->index1 > 0)   index1print(nodep->index1);
    if (nodep->index2 > 0)   index2print(nodep);
   } /* end-of-if (nodep->crd... */
  nodep= nodep->rightwing;
 } /* end-of-while (nodep... */

} /* end printseq() */



print_ambseq(nodep,calln)
struct group *nodep;
int calln;
{
int i,j,k, pos, tlgth, mlgth, nseq= 0;
int ambseq[AMBSEQMX][60], ambsql[AMBSEQMX];
int cnt[26], maxcnt, scr, basescore= 0;
int maxshifti, maxshiftj, maxscore, indel, gapsz, delta;

for (i=0;i<nodep->nodesize;++i)
 {if (nodep->crd[i][1] != 0)
   {ambsql[i]= nodep->crd[i][1] - nodep->crd[i][0] + 1;
    if (ambsql[i] >= 60)
     {for (j=0;j<nodep->nodesize;++j)
       {if (nodep->crd[j][1] != 0)
         {fprintf(outfp,"[%4d-%4d]   ",nodep->crd[j][0]+1,nodep->crd[j][1]+1 );
          fprintf(outfp,"see sequence above\n");
         }
       } 
      fprintf(outfp,"\n");
      return;
     }
    for (j=0;j<ambsql[i];++j)   ambseq[i][j]= TRL[protein[nodep->crd[i][0]+j]];
    ++nseq;
   }
  else ambsql[i]= 0;
 }

tlgth= mlgth= 0;
for (i=0;i<nodep->nodesize;++i)
 {tlgth+= ambsql[i];
  if (ambsql[i] > mlgth)   mlgth= ambsql[i];
 }

for (j=0;j<mlgth;++j)
 {scr= 0;   for (i=0;i<26;++i) cnt[i]= 0;
  for (k=0;k<nodep->nodesize;++k)
   {if (ambsql[k]!=0 && j<ambsql[k])
     {if (++cnt[ambseq[k][j]] > scr)  scr= cnt[ambseq[k][j]];}
   }
  if (scr>1) basescore+= scr;
 }

if (basescore < tlgth)
 {while (1)
   {maxscore= 0; mlgth= 0; indel= -1;
    for (i=0;i<nodep->nodesize;++i) if (ambsql[i] > mlgth)   mlgth= ambsql[i];
    for (i=0;i<nodep->nodesize;++i) for(j=0;j<ambsql[i];++j)
     {if (ambsql[i] < mlgth)
       {scr= amb_iscore(ambseq,ambsql,nodep->nodesize,i,j,1);
        if (scr > maxscore)
         {maxscore= scr; maxshifti= i; maxshiftj= j; gapsz= 1; indel= 1;
	  delta= mlgth - ambsql[i] - 1;
	 }
       }
      if (nseq > 2  &&  ambsql[i] == mlgth)
       {scr= amb_dscore(ambseq,ambsql,nodep->nodesize,i,j,1);
        if (scr > maxscore)
         {maxscore= scr; maxshifti= i; maxshiftj= j; gapsz= 1; indel= 0;}
       }
      if (ambsql[i] < mlgth-1)
       {scr= amb_iscore(ambseq,ambsql,nodep->nodesize,i,j,2);
        if (scr > maxscore ||
	    (indel == 1 && scr == maxscore && mlgth - ambsql[i] - 2 < delta) )
         {maxscore= scr; maxshifti= i; maxshiftj= j; gapsz= 2; indel= 1;}
       }
      if (nseq > 2  &&  ambsql[i] == mlgth)
       {scr= amb_dscore(ambseq,ambsql,nodep->nodesize,i,j,2);
        if (scr > maxscore)
         {maxscore= scr; maxshifti= i; maxshiftj= j; gapsz= 2; indel= 0;}
       }
     }
    if (maxscore > basescore  ||  (indel == 0  &&
	 maxscore == basescore  &&  ambsql[maxshifti]+gapsz == mlgth) )
     {if (indel == 1)
       {for (i=ambsql[maxshifti]-1+gapsz;i>maxshiftj+gapsz-1;--i)
          ambseq[maxshifti][i]= ambseq[maxshifti][i-gapsz];
        for (j=0;j<gapsz;++j)   ambseq[maxshifti][maxshiftj+j]= 25;
        ambsql[maxshifti]+= gapsz;
       }
      else
       {for (i=0;i<nodep->nodesize;++i)
         {if (i != maxshifti && ambsql[i] != 0)
           {for (j=ambsql[i]-1+gapsz;j>maxshiftj+gapsz-1;--j)
              ambseq[i][j]= ambseq[i][j-gapsz];
            for (k=0;k<gapsz;++k)   ambseq[i][maxshiftj+k]= 25;
            ambsql[i]+= gapsz;
           }
         }
       }

      for (i=0;i<mlgth;++i)
       {for (j=0;j<26;++j) cnt[j]= 0;   maxcnt= 0;
        for (j=0;j<nodep->nodesize;++j)
	  if (ambsql[j]!=0 && i<ambsql[j])   {++cnt[ambseq[j][i]]; ++maxcnt;}
	if (cnt[25]==maxcnt)
	  {for (j=0;j<nodep->nodesize;++j)
	     {if (ambsql[j]!=0)
	       {for (pos=i;pos<ambsql[j]-1;++pos)
			ambseq[j][pos]= ambseq[j][pos+1];
		--ambsql[j];
	       }
	     }
	   maxscore-= maxcnt;
	  }
       }

      basescore= maxscore;
     }
    else break;
   }
 }
    
for (i=0;i<nodep->nodesize;++i)
 {if (nodep->crd[i][1] != 0)
   {for (j=1;j<=calln;++j)   fprintf(outfp," ");
    fprintf(outfp,"[%4d-%4d]   ",nodep->crd[i][0]+1,nodep->crd[i][1]+1 );
    for (j=0;j<ambsql[i];++j)  fprintf(outfp,"%c", SYMB[ambseq[i][j]] );
    fprintf(outfp,"\n");
   }
 }
fprintf(outfp,"\n");

} /* end print_ambseq() */



amb_iscore(seq,sql,npro,iseq,spos,gapsz)
int seq[AMBSEQMX][60], sql[AMBSEQMX], npro, iseq, spos, gapsz;
{
int i,j,k, mlgth= 0;
int nseq[AMBSEQMX][60], nsql[AMBSEQMX];
int cnt[26], scr= 0, tscore= 0;

for (i=0;i<npro;++i)
 {nsql[i]= sql[i];
  if (i != iseq)  for (j=0;j<nsql[i];++j)   nseq[i][j]= seq[i][j];
 }

for (i=0;i<spos;++i)   nseq[iseq][i]= seq[iseq][i];
for (j=0;j<gapsz;++j)   nseq[iseq][spos+j]= 25;
for (i=spos;i<sql[iseq];++i)   nseq[iseq][i+gapsz]= seq[iseq][i];
nsql[iseq]+= gapsz;

for (i=0;i<npro;++i)
  if (nsql[i] > mlgth)   mlgth= nsql[i];

for (j=0;j<mlgth;++j)
 {scr= 0;   for (i=0;i<26;++i) cnt[i]= 0;
  for (k=0;k<npro;++k)
   {if (j < nsql[k])
     {if (nseq[k][j]<25 && ++cnt[nseq[k][j]] > scr)  scr= cnt[nseq[k][j]];}
   }
  if (scr>1) tscore+= scr;
 }
 
return(tscore);

} /* end amb_iscore() */



amb_dscore(seq,sql,npro,iseq,spos,gapsz)
int seq[AMBSEQMX][60], sql[AMBSEQMX], npro, iseq, spos, gapsz;
{
int i,j,k, mlgth= 0;
int nseq[AMBSEQMX][60], nsql[AMBSEQMX];
int cnt[26], scr= 0, tscore= 0;

nsql[iseq]= sql[iseq];
for (j=0;j<nsql[iseq];++j) nseq[iseq][j]= seq[iseq][j];

for (k=0;k<npro;++k)
 {if (k != iseq)
   {if (sql[k] != 0)
     {if (sql[k] < spos)
       {for (i=0;i<sql[k];++i) nseq[k][i]= seq[k][i];
        nsql[k]= sql[k];
       }
      else
       {for (i=0;i<spos;++i) nseq[k][i]= seq[k][i];
        for (j=0;j<gapsz;++j) nseq[k][spos+j]= 25;
        for (i=spos;i<sql[k];++i) nseq[k][i+gapsz]= seq[k][i];
        nsql[k]= sql[k] + gapsz;
       }
     }
    else nsql[k]= 0;
   }
 }

for (i=0;i<npro;++i)
  if (nsql[i] > mlgth)   mlgth= nsql[i];

for (j=0;j<mlgth;++j)
 {scr= 0;   for (i=0;i<26;++i) cnt[i]= 0;
  for (k=0;k<npro;++k)
   {if (j < nsql[k])
     {if (nseq[k][j]<25 && ++cnt[nseq[k][j]] > scr)  scr= cnt[nseq[k][j]];}
   }
  if (scr>1) tscore+= scr;
 }
 
return(tscore);

} /* end amb_dscore() */



/* is_expandednode() RETURNS 1 FOR A GIVEN NODE WHICH HAS AN index1head LISTED
   SUPERSET ONLY IF IT CONTAINS SEQUENCE MATCHES THAT THE SUPERSET DOES NOT
   COVER */
is_expandednode(nodep)
struct group *nodep;
{
int i;
struct group *ip;

if (nodep->index1 == 0)   return(0);

ip= index1head;
while (ip->nextgroup != NULL  &&  ip->index1 != nodep->index1)
 ip= ip->nextgroup;
if (ip->index1 != nodep->index1)   return(1);

for (i=0;nodep->crd[i][1] == 0  &&  i < nodep->nodesize;++i)   {}
/* NOW i IS THE FIRST INDEX FOR WHICH nodep->crd[i][1] != 0 */

if (notfound(nodep,ip,i))   return(1);
else   return(0);

} /* end is_expandednode() */



/* notfound() RETURNS 1 IF THE i-TH ELEMENT OF node1 IS NOT A SUBSET OF ANY
   ELEMENT OF node2; ELSE RETURNS 0 */
notfound(node1,node2,i)
struct group *node1, *node2;
int i;
{
int j;

for (j=0;j < node2->nodesize;++j)
 if ( node1->crd[i][0] >= node2->crd[j][0]  && 
      node1->crd[i][1] <= node2->crd[j][1] )   break;

if (j == node2->nodesize)   return(1);
else   return(0);

} /* end notfound() */



index1print(index1)
int index1;
{
int i, j;
struct group *ip= index1head;

if (MSGPRT) fprintf(outfp,"Searching in index1 list for index1=%3d:\n",index1); 

while (ip->nextgroup != NULL  &&  ip->index1 != index1)   ip= ip->nextgroup;

if (ip->index1 == index1)
 {i= 0;
  fprintf(outfp,"matching also:\n");
  if (FinalPrint)   print_ambseq(ip,2);
  else
   {while (i<ip->nodesize)
     {fprintf(outfp,"  [%4d-%4d]   ",ip->crd[i][0]+1,ip->crd[i][1]+1 );
      if (ip->crd[i][1] - ip->crd[i][0] < 58)
       for (j=ip->crd[i][0];j<=ip->crd[i][1];++j) 
         fprintf(outfp,"%c",SYMB[TRL[protein[j]]]);
      else   fprintf(outfp,"  see sequence above");
      fprintf(outfp,"\n");
      ++i;
     }
    fprintf(outfp,"\n");
   }
 }
else fprintf(stderr,ERRORMSG3,index1);
 
} /* end index1print() */



index2print(nodep)
struct group *nodep;
{
int i, j, index2= nodep->index2;
struct group *ip= index2head;
int nss= 0;

if (MSGPRT) fprintf(outfp,"Searching in index2 list for index2=%3d:\n",index2); 

while (ip != NULL)
 {if (ip->index2 == index2  &&  difference(ip,nodep))
   {++nss;   i= 0;
    if (nss < 2)   fprintf(outfp,"with superset:\n");
    else   fprintf(outfp,"and:\n");
    if (FinalPrint)   print_ambseq(ip,2);
    else
     {while (i<ip->nodesize)
       {fprintf(outfp,"  [%4d-%4d]   ", ip->crd[i][0]+1, ip->crd[i][1]+1);
        if (ip->crd[i][1] - ip->crd[i][0] < 58)
         for (j=ip->crd[i][0];j<=ip->crd[i][1];++j) 
           fprintf(outfp,"%c",SYMB[TRL[protein[j]]]);
        else   fprintf(outfp,"  see sequence above");
        fprintf(outfp,"\n");
        ++i;
       }
      fprintf(outfp,"\n");
     }
   }
  ip= ip->nextgroup;
 }

if (MSGPRT) 
 fprintf(outfp,"End of index2 search-and-print for index2=%3d\n",index2);

} /* end index2print() */



/* difference() RETURNS 1 IF node1 IS OF LARGER SIZE THAN node2, OR IF node1
   COVERS A REGION THAT node2 DOES NOT COVER; ELSE RETURNS 0 */
difference(node1,node2)
struct group *node1, *node2;
{
int i;
struct group *olgrunp;

if (node2->index1 > 0)
 {olgrunp= index1head;
  while (olgrunp->nextgroup != NULL  &&  olgrunp->index1 != node2->index1)
   olgrunp= olgrunp->nextgroup;
  if (olgrunp->index1 == node2->index1)   node2= olgrunp;
 }

if (node1->nodesize > node2->nodesize)   return(1);

for (i=0;i < node1->nodesize;++i)
 if (notfound(node1,node2,i))   break;

if (i == node1->nodesize)   return(0);
else   return(1);

} /* end difference() */



/* screenspecial() prints alignments for 1st 4 nodes then, on a new line, 
   the rest (hopefully less than 5 nodes also!!      */
screenspecial(nodep)
struct group *nodep;
{
struct group *ip, *restptr;
int i;

while (nodep->leftwing != NULL)
 {ip= nodep;
  nodep= nodep->leftwing;
  nodep->rightwing= ip;
 }

ip= nodep;
for (i=0;i<3  &&  ip->rightwing != NULL;++i)   ip= ip->rightwing;

restptr= ip->rightwing;
ip->rightwing= NULL;

if (restptr != NULL)   restptr->leftwing= NULL;
else   printgroup(nodep,-1,(struct group *)NULL);
if (restptr != NULL)   printgroup(nodep,1,restptr);
if (restptr != NULL)   {fprintf(outfp,"\n"); screenspecial(restptr);}
fprintf(outfp,"\n");

ip->rightwing= restptr;
if (restptr != NULL) restptr->leftwing= ip;
 
} /* end screenspecial() */



/* print_str() PRINTS ALL SIMPLE TANDEM REPEAT NODES IN SIMPLE TANDEM 
   REPEAT FORMAT. */
print_str()
{
struct group *ip= groupshead;

if (strcount >= 1)
 {fprintf(outfp,"\n______________________________\n");
  fprintf(outfp,"Simple tandem repeat");
  if (strcount > 1)   fprintf(outfp,"s: \n\n");
  else   fprintf(outfp,": \n\n");
 }

while (ip != NULL)
 {if (ip->noprtflag == 2)   print_strseq(ip);
  ip= ip->nextgroup;
 }

} /* end print_str() */



print_strseq(nodep)
struct group *nodep;
{
int i, ibeg, iend, j, pos1, pos2, indel;
int nchar, rlgth, strseq[PROTLGTH], nstrseq[PROTLGTH], cnt[26];
int scr, delta, basescore= 0, maxscore= 0, maxshift= 0, gapsz;
int maxri, maxrj, jump, jmin= 0;
 
nchar= nodep->crd[1][1] - nodep->crd[0][0] + 1;
rlgth= nodep->crd[1][0] - nodep->crd[0][0];

for (i=nodep->crd[0][0],j=0;i<=nodep->crd[1][1];++i,++j)
 strseq[j]= TRL[protein[i]];

for (i=0;i<rlgth;++i)
 {scr= 0;
  for (j=0;j<26;++j)   cnt[j]= 0;
  for (j=0;i+j < nchar;j+= rlgth)
    if (++cnt[strseq[i+j]] > scr)   scr= cnt[strseq[i+j]];
  if (scr>1) basescore+= scr;   
 }

if (basescore < nchar)
 {while (1)
   {maxscore= 0; indel= -1;
    for(j=0;j < nchar;j+= rlgth) for (i=0;i<rlgth && j+i<nchar;++i)
     {if (j+i < nchar-1)
       {scr= str_iscore(strseq,nchar,rlgth,i,j,1);
        if (scr > maxscore) {maxscore= scr; maxshift= i+j; gapsz= 1; indel= 1;}
        scr= str_iscore(strseq,nchar,rlgth,i,j,2);
        if (scr > maxscore) {maxscore= scr; maxshift= i+j; gapsz= 2; indel= 1;}
       }
      scr= str_dscore(strseq,nchar,rlgth,i,j,jmin,1);
      if (scr > maxscore)
       {maxscore= scr; maxri= i; maxrj= j; gapsz= 1; indel= 0;}
     }
    if (maxscore > basescore)
     {if (indel == 1)
       {for (i=nchar-1+gapsz;i>maxshift+gapsz-1;--i) strseq[i]= strseq[i-gapsz];
        for (j=0;j<gapsz;++j)   strseq[maxshift+j]= 25;
        nchar+= gapsz;
        basescore= maxscore;
       }
      else 
       {delta= jump= 0;
	for (j=0;j< nchar;j+= rlgth)
	 {if (j==maxrj) iend= rlgth+1;  else iend= rlgth;
          if (j > maxrj) jump= gapsz;
          for (i=0;i<iend;++i)
	   {if (i<maxri)
	     {nstrseq[j+i+delta+jump]= strseq[j+i+jump]; continue;}
	    if (i==maxri)
	     {if (j>=jmin && j < maxrj) {nstrseq[j+i+jump+delta]= 25; ++delta;}
	      nstrseq[j+i+jump+delta]= strseq[j+i+jump];
	      continue;
	     }
	    if (i>maxri)  nstrseq[j+i+jump+delta]= strseq[j+i+jump];
	   }
         }
	nchar= nchar+delta; rlgth+= gapsz;
	for (j=0;j< nchar;++j)  strseq[j]= nstrseq[j];
        basescore= maxscore; jmin= maxrj+1;
       }
     }
    else break;
   }
 }

while (1)
 {maxscore= 0;
  for (j=0;j < nchar;j+= rlgth) for (i=0;i<rlgth && j+i<nchar;++i)
   {if (strseq[j+i] == 25)
     {scr= str_cscore(strseq,nchar,rlgth,i,j); 
      if (scr>maxscore)   {maxscore= scr; maxri= i; maxrj= j;}
     }
   }
  if (maxscore > basescore)
   {for (i=0;i<rlgth && maxrj+i < nchar;++i)
     {if (i >= maxri && i < rlgth-1) strseq[maxrj+i]= strseq[maxrj+i+1];
      if (i==rlgth-1) strseq[maxrj+i]= 25;
     }
    basescore= maxscore;
   }
  else break;
 }

str_cdisp(strseq,&nchar,&rlgth);

iend= rlgth;
j= 0;
for (i=0;i<iend;++i)   if (strseq[i]==25) ++j;
pos1= nodep->crd[0][0]+1; pos2= pos1+rlgth-1-j;
fprintf(outfp,"[%4d-%4d]    ", pos1, pos2);
if (rlgth<60) for (i=0;i<iend;++i)   fprintf(outfp,"%c",SYMB[strseq[i]]);
else   fprintf(outfp,"see sequence above");
fprintf(outfp,"\n");

while (iend+rlgth < nchar)
 {ibeg= iend;   iend+= rlgth;
  j= 0;
  for (i=ibeg;i<iend;++i)   if (strseq[i]==25) ++j;
  pos1= pos2+1; pos2= pos1+rlgth-1-j;
  fprintf(outfp,"[%4d-%4d]    ", pos1, pos2);
  if (rlgth<60) for (i=ibeg;i<iend;++i)   fprintf(outfp,"%c",SYMB[strseq[i]]);
  else   fprintf(outfp,"see sequence above");
  fprintf(outfp,"\n");
 }

ibeg= iend;   iend= nchar;
if (ibeg < iend)
 {j= 0;
  for (i=ibeg;i<iend;++i)   if (strseq[i]==25) ++j;
  pos1= pos2+1; pos2= pos1+iend-ibeg-1-j;
  fprintf(outfp,"[%4d-%4d]    ",pos1, pos2 );
  if (rlgth<60) for (i=ibeg;i<iend;++i)   fprintf(outfp,"%c",SYMB[strseq[i]]);
  else   fprintf(outfp,"see sequence above");
 }
fprintf(outfp,"\n\n");

} /* end print_strseq() */



str_iscore(seq,sql,rlgth,ri,rj,gapsz)
int *seq, sql, rlgth, ri, rj, gapsz;
{
int i,j, nseq[PROTLGTH], shift;
int cnt[26], scr= 0, tscore= 0;

shift= ri + rj;

if (shift > 0)
 {for (i=0;i<shift;++i) nseq[i]= seq[i];
  for (j=0;j<gapsz;++j) nseq[shift+j]= 25;
  for (i=shift;i<sql;++i) nseq[i+gapsz]= seq[i];
 }
else
 return(0);

for (i=0;i<rlgth;++i)
 {scr= 0;
  for (j=0;j<26;++j)   cnt[j]= 0;
  for (j=0;i+j < sql+gapsz;j+= rlgth)
    if (nseq[i+j]<25 && ++cnt[nseq[i+j]] > scr)   scr= cnt[nseq[i+j]];
  if (scr>1) tscore+= scr;   
 }
 
return(tscore);

} /* end str_iscore() */




str_dscore(seq,sql,rlgth,ri,rj,jmin,gapsz)
int *seq, sql, rlgth, ri, rj, jmin, gapsz;
{
int i,j, nseq[PROTLGTH];
int delta= 0, jump= 0, iend;
int cnt[26], scr= 0, tscore= 0;

for (j=0;j< sql;j+= rlgth)
 {if (j==rj) iend= rlgth+1;  else iend= rlgth;
  if (j > rj) jump= gapsz;
  for (i=0;i<iend;++i)
   {if (i<ri) 
     {nseq[j+i+delta+jump]= seq[j+i+jump]; continue;}
    if (i==ri)
     {if (j>=jmin && j < rj)
       {nseq[j+i+jump+delta]= 25; ++delta;}
      nseq[j+i+jump+delta]= seq[j+i+jump];
      continue;}
    if (i>ri)  nseq[j+i+jump+delta]= seq[j+i+jump];
   }
  }
sql= sql+delta-1; rlgth+= gapsz;

for (i=0;i<rlgth;++i)
 {scr= 0;
  for (j=0;j<26;++j)   cnt[j]= 0;
  for (j=0;i+j < sql;j+= rlgth)
    if (nseq[i+j]<25 && ++cnt[nseq[i+j]] > scr)   scr= cnt[nseq[i+j]];
  if (scr>1) tscore+= scr;   
 }
 
return(tscore);

} /* end str_dscore() */



str_cscore(seq,sql,rlgth,ri,rj)
int *seq, sql, rlgth, ri, rj;
{
int i,j, nseq[PROTLGTH];
int cnt[26], scr= 0, tscore= 0;

for (j=0;j < sql;j+= rlgth)
 {for (i=0;i<rlgth && j+i < sql;++i)
   {if (j != rj) nseq[j+i]= seq[j+i];
    else
     {if (i < ri) nseq[j+i]= seq[j+i];
      else
       {if (i < rlgth-1) nseq[j+i]= seq[j+i+1];
	if (i==rlgth-1 || i+j == sql-1) nseq[j+i]= 25;
       }
     }
   }
 }

for (i=0;i<rlgth;++i)
 {scr= 0;
  for (j=0;j<26;++j)   cnt[j]= 0;
  for (j=0;i+j < sql;j+= rlgth)
    if (nseq[i+j]<25 && ++cnt[nseq[i+j]] > scr)   scr= cnt[nseq[i+j]];
  if (scr>1) tscore+= scr;   
 }
 
return(tscore);

} /* end str_cscore() */



str_cdisp(seq,nchar,rlgth)
int *seq, *nchar, *rlgth;
{
int i,j,k,l,pos;
int fflag, nswu= 0, mini= *rlgth, maxi= 0, delta= 0;
int nrep, strseq[10][10], tstrseq[10][10], mstrseq[10][10], slgth;
int cnt[26], scr, basescore, tscore= 0, maxscore;

for (j=0;j< *nchar;j+= *rlgth)
 {fflag= 1;
  for (i=0;i< *rlgth;++i) if (seq[j+i]==25)
     {if (fflag)   {++nswu; fflag= 0;}
      if (i < mini)   mini= i;
      if (i > maxi)   maxi= i;
     }
 }
nrep= j/ *rlgth;

if (nrep > 10  ||  nswu < nrep)   return;
slgth= maxi-mini+1;
if (slgth > 10)   return;

for (j=0;j< *nchar;j+= *rlgth)
 for (i=0;i<slgth;++i)
  {if (j+mini+i >= *nchar) strseq[j/ *rlgth][i]= 25;
   else   strseq[j/ *rlgth][i]= seq[j+mini+i];
  }

for (i=0;i<slgth;++i) 
 {scr= 0;
  for (j=0;j<26;++j)   cnt[j]= 0;
  for (j=0;j< nrep;++j)
    if (strseq[j][i]<25 && ++cnt[strseq[j][i]] > scr)   scr= cnt[strseq[j][i]];
  if (scr>1) tscore+= scr;
 }
basescore= tscore;

while (1)
 {maxscore= 0;
  for (j=0;j< nrep;++j)
   {for (pos=0;pos<26;++pos)   cnt[pos]= 0;
    for (pos=0;pos<slgth;++pos)   ++cnt[strseq[j][pos]];
    if (cnt[25]==0)   continue;
    for (i=0;i<slgth;++i)
     {for (k=0;k< nrep;++k)
       {if (k != j)
         {for (l=0;l<slgth;++l) tstrseq[k][l]= strseq[k][l];}
        else
         {pos= 0;
          for (l=0;l<i;++l)
	   {while (pos<slgth && strseq[k][pos]==25) ++pos;
  	    if (pos<slgth) tstrseq[k][l]= strseq[k][pos];
  	    else tstrseq[k][l]= 25;
  	    ++pos;
  	   } 
  	  tstrseq[k][i]= 25;
          for (l=i+1;l<slgth;++l)
  	   {while (pos<slgth && strseq[k][pos]==25) ++pos;
  	    if (pos<slgth) tstrseq[k][l]= strseq[k][pos];
  	    else tstrseq[k][l]= 25;
  	    ++pos;
  	   } 
         }
       }
      tscore= 0;
      for (pos=0;pos<slgth;++pos) 
       {scr= 0;
        for (k=0;k<26;++k)   cnt[k]= 0;
        for (k=0;k< nrep;++k)
          if (++cnt[tstrseq[k][pos]] > scr)   scr= cnt[tstrseq[k][pos]];
        if (scr>1) tscore+= scr;
       }
      if (tscore > maxscore)
       {maxscore= tscore;
        for (pos=0;pos<slgth;++pos) for (k=0;k< nrep;++k)
          mstrseq[k][pos]= tstrseq[k][pos];
       }
     }
   }
  if (maxscore > basescore)
   {for (i=0;i<slgth;++i)
     {for (k=0;k<26;++k)   cnt[k]= 0;
      for (k=0;k< nrep;++k) ++cnt[mstrseq[k][i]];
      if (cnt[25]==nrep)
       {for (pos=i;pos<slgth-1;++pos)
	  for (k=0;k<nrep;++k)   mstrseq[k][pos]= mstrseq[k][pos+1];
        --slgth;   maxscore-= nrep;   ++delta;
       }
     }
    for (i=0;i<slgth;++i) for (k=0;k< nrep;++k)
      strseq[k][i]= mstrseq[k][i];
    basescore= maxscore;
   }
  else   break;
 } /* end of while(1) */
 
pos= 0;
for (j=0;j<nrep;++j)
 {for (i=0;i<mini;++i)   seq[pos++]= seq[j* (*rlgth) +i];
  for (i=0;i<slgth;++i)   seq[pos++]= strseq[j][i];
  for (i=maxi+1;i< *rlgth  &&  j* (*rlgth) +i < *nchar;++i)
    seq[pos++]= seq[j* (*rlgth) +i];
 }
*rlgth-= delta;
*nchar-= delta*nrep;

} /* end str_cdisp() */



print_pdr()
{
struct ogroup *ip= ogroupshead;
int PMIN, PMAX;

fprintf(outfp,"\nPeriodic repeats:\n\n");
while (ip != NULL)
 {if (ip->cslant > 0)   {PMIN= PMAX= ip->cslant;}
  else   {PMIN= 1; PMAX= 10;}
  period(SQLGTH,3,PMIN,PMAX,ip->beg,ip->end,3);
  ip= ip->next;
 }

} /* print_pdr() */



print_hrr()
{
struct group *gp= groupshead;
int fflag= 1;

while (gp != NULL)
 {if (gp->noprtflag == 3)
   {if (fflag)   {fprintf(outfp,"\nHighly repetitive regions:\n\n"); fflag= 0;}
    fprintf(outfp,"From %4d to %4d ",
	    gp->crd[0][0]+1, gp->crd[gp->nodesize -1][1] +1); 
    print_hrr_motif(gp);
   }
  gp= gp->nextgroup;
 }

} /* end print_hrr() */



print_hrr_motif(nodep)
struct group *nodep;
{
int i, j, cflag= 1, n;
int rcnt[23], consrcnt, consr[40];

for (i=0;cflag == 1;++i)
 {cflag= consrcnt= 0;   for (j=0;j<23;++j)   rcnt[j]= 0;
  for (j=0;j<nodep->nodesize;++j)
   {if (nodep->crd[j][0]+i <= nodep->crd[j][1])
     {cflag= 1;
      n= ++rcnt[TRL[protein[nodep->crd[j][0]+i]]];
      if (n > consrcnt)
       {consrcnt= n;
        if (i<40)   consr[i]= TRL[protein[nodep->crd[j][0]+i]];
       }
     }
   }
 }

if (--i < 40)
 {fprintf(outfp,"with major motif ");
  for (j=0;j<i;++j)   fprintf(outfp,"%c",SYMB[TRL[consr[j]]]);
 }
fprintf(outfp,".\n");

} /* end print_hrr_motif() */



readpar()
{
FILE *parfp;
char varname[32];

if ( (parfp = fopen("rpeat.par","r")) == NULL )
 {fprintf(stderr,"File rpeat.par cannot be opened.\n");
  perror("rpeat.par");   fprintf(stderr,ERRORMSG4);   exit(-1);
 }
fprintf(outfp,"\nParameters set as follows:");
fscanf(parfp,"%s %f",varname,&PRCENTMMIN);
 if (strcmp(varname,"PRCENTMMIN"))
  fprintf(outfp,"\nRPEAT-WARNING: Set PRCENTMMIN!");
 fprintf(outfp,"\n  %s %4.2f",varname,PRCENTMMIN);
fscanf(parfp,"%s %d",varname,&MAXCSFREX);
 if (strcmp(varname,"MAXCSFREX"))
  fprintf(outfp,"\nRPEAT-WARNING: Set MAXCSFREX!");
 fprintf(outfp,"\n  %s %d",varname,MAXCSFREX);
fscanf(parfp,"%s %d",varname,&BIGNODE);
 if (strcmp(varname,"BIGNODE"))
  fprintf(outfp,"\nRPEAT-WARNING: Set BIGNODE!");
 fprintf(outfp,"\n  %s %d",varname,BIGNODE);
fscanf(parfp,"%s %d",varname,&TOOBIGTOPRINT);
 if (strcmp(varname,"TOOBIGTOPRINT"))
  fprintf(outfp,"\nRPEAT-WARNING: Set TOOBIGTOPRINT!");
 fprintf(outfp,"\n  %s %d",varname,TOOBIGTOPRINT);
fscanf(parfp,"%s %d",varname,&CONSENSUS);
 if (strcmp(varname,"CONSENSUS"))
  fprintf(outfp,"\nRPEAT-WARNING: Set CONSENSUS!");
 fprintf(outfp,"\n  %s %d",varname,CONSENSUS);
fscanf(parfp,"%s %d",varname,&PFACTOR);
 if (strcmp(varname,"PFACTOR"))
  fprintf(outfp,"\nRPEAT-WARNING: Set PFACTOR!");
 fprintf(outfp,"\n  %s %d",varname,PFACTOR);
fscanf(parfp,"%s %f",varname,&BFACTOR);
 if (strcmp(varname,"BFACTOR"))
  fprintf(outfp,"\nRPEAT-WARNING: Set BFACTOR!");
 fprintf(outfp,"\n  %s %3.1f",varname,BFACTOR);
fscanf(parfp,"%s %d",varname,&SLANTERROR);
 if (strcmp(varname,"SLANTERROR"))
  fprintf(outfp,"\nRPEAT-WARNING: Set SLANTERROR!");
 fprintf(outfp,"\n  %s %d",varname,SLANTERROR);
fscanf(parfp,"%s %d",varname,&ALIGNMAX);
 if (strcmp(varname,"ALIGNMAX"))
  fprintf(outfp,"\nRPEAT-WARNING: Set ALIGNMAX!");
 fprintf(outfp,"\n  %s %d",varname,ALIGNMAX);
fprintf(outfp,"\n\n");

} /* end readpar() */



/* ******* DEBUGGING TOOLS ******* */
printme(rheadp)
struct group *rheadp;
{
struct group *gp= rheadp;
int i, j= 1;

while (gp != NULL)
 {fprintf(outfp,"\nnode %d: size=%d  index1=%d  index2=%d",
	j++, gp->nodesize, gp->index1, gp->index2 );
  for (i=0;i<gp->nodesize;++i)
   {fprintf(outfp,"\ni=%2d: %d -- %d", i, gp->crd[i][0]+1, gp->crd[i][1]+1);
    fflush(outfp);
   }
  gp= gp->nextgroup;
 }

} /* end printme() */



printit(nodep)
struct group *nodep;
{
struct group *gp;
int i, j= 1;

gp = nodep;

while (gp != NULL)
 {fprintf(outfp,"\nnode %d: size=%d  index1=%d  index2=%d",
	j++, gp->nodesize, gp->index1, gp->index2 );
  for (i=0;i<gp->nodesize;++i)
   {fprintf(outfp,"\ni=%2d: %d -- %d", i, gp->crd[i][0]+1, gp->crd[i][1]+1);
    fflush(outfp);
   }
  gp= gp->rightwing;
 }

} /* end printit() */
