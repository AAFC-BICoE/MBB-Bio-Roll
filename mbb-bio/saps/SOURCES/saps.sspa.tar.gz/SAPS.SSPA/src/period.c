/* PERIOD.C;                                     Last update: April 11, 1996 */
/*   - a subroutine to find periodic repeats in protein sequences.           */
/* Dependencies:   called by saps.c and prorep.c.                            */
/* Bugs:                                                                     */

/*   Volker Brendel & Illah Nourbakhsh, Department of Mathematics,           */
/*   Stanford University, Stanford CA 94305;                                 */
/*   (415) 723-9256, volker@gnomic.stanford.edu                              */

#include <stdio.h>
#include <math.h>

#include <stdio.h>
#include <math.h>
#include "def.h"
extern FILE *outfp;
extern protein[PROTLGTH];
extern int pf[9];
extern char AAUC[25], CHPN[25], HPIC[25];
#define NOCHECKFLAG

struct peod {
	int per;
	int pos;
	int cores;
	int copyn;
	int nerr[150];
	int cflag;
	char star;
	char pstr[151];
	struct peod *next;
} *pheadp;

int per_printed;


period(numaa,calln,PMIN,PMAX,BEGIN,END,CMIN)
int numaa, calln;
int PMIN, PMAX, BEGIN, END, CMIN;
{
int i,j,k,l,m,kmax;
int iadj;
static int CSTAR;
struct peod *nodep;
float f, x, p, per_pfct(), per_rtbis();
int r;
int cores, copyn, numerr[150];
int bflag, cflag;
int NLET;
char ABC[25], SYMB[20];
int cf[20];
char pstring[151];
int ndots;
int ai, aia, aib;
int mtchcnt, errcnt, itoprt, bmtchcnt, netoprt;

if (PMAX>150)
  {fprintf(stderr,"\nPMAX (set to %d) must not exceed 150!\n", PMAX);
   return;
  }

if (calln==1 || calln==3)   aia= aib= 0;
if (calln==2)   {aia=1; aib= 2;}

for (ai=aia;ai<=aib;++ai)
  {if (ai==0)   /* amino acid alphabet */
     {strcpy(ABC,AAUC);
      NLET=20;
      for (i=0;i<NLET;++i)   SYMB[i]= ABC[i];
      f= 0.05;
      for (r=1;r<PMAX;++r)
	{i= 1;
	 while ( per_pfct((float)i,r,f)<0 )   ++i;
	 x= per_rtbis(per_pfct,0.001,(float)i,.000001,r,f);
	 p= (1.0-f*x)/ ( (r+1-r*x)*(1.0-f)*pow((double)x,(double)(numaa+1)) );
	 p= 1.0-p;
	 if (p<.01)   break;
	}
      CSTAR= r+1;
      if (calln==1)
	{fprintf(outfp,"\nA. AMINO ACID ALPHABET (core: %2d; !-core:%2d)\n",
		CMIN, CSTAR );
	 fprintf(outfp,"\nLocation\tPeriod\tElement\t\tCopies\tCore\tErrors\n");
	}
      if (calln==3)
	{fprintf(outfp,"Periodic elements (period range %3d to %3d)",PMIN,PMAX);
	 fprintf(outfp," in segment [%d,%d]:", BEGIN+1, END+1 );
	 fprintf(outfp,"\nLocation\tPeriod\tElement\t\tCopies\tCore\tErrors\n");
	}
     }
   if (ai==1)   /* +-0 charge alphabet */
     {strcpy(ABC,CHPN);
      NLET=3;
      SYMB[0]= '+'; SYMB[1]= '-'; SYMB[2]= '0';
      f= (float)pf[2]/(2*numaa);
      if (f == 0.0)   return;
      for (r=1;r<PMAX;++r)
	{i= 1;
	 while ( per_pfct((float)i,r,f)<0 )   ++i;
	 x= per_rtbis(per_pfct,0.001,(float)i,.000001,r,f);
	 p= (1.0-f*x)/ ( (r+1-r*x)*(1.0-f)*pow((double)x,(double)(numaa+1)) );
	 p= 1.0-p;
	 if (p<.01)   break;
	}
      CSTAR= r+1;
      fprintf(outfp,
	"B. CHARGE ALPHABET ({+= KR; -= ED; 0}; core: %2d; !-core:%2d)\n",
	CMIN, CSTAR );
     }
   if (ai==2)   /* *i0 hydrophobicity alphabet */
     {strcpy(ABC,HPIC);
      NLET= 3;
      SYMB[0]= '*'; SYMB[1]= 'h'; SYMB[2]= '0';
      f= (float)(pf[2]+pf[5])/(2*numaa);
      if (f == 0.0)   return;
      ++CMIN;
      for (r=1;r<PMAX;++r)
	{i= 1;
	 while ( per_pfct((float)i,r,f)<0 )   ++i;
	 x= per_rtbis(per_pfct,0.001,(float)i,.000001,r,f);
	 p= (1.0-f*x)/ ( (r+1-r*x)*(1.0-f)*pow((double)x,(double)(numaa+1)) );
	 p= 1.0-p;
	 if (p<.01)   break;
	}
      CSTAR= r+1;
      fprintf(outfp,"   and HYDROPHOBICITY ALPHABET ({*= KRED; i= LVIF; 0};");
      fprintf(outfp," core: %2d; !-core:%2d)\n", CMIN, CSTAR );
      fprintf(outfp,"\nLocation\tPeriod\tElement\t\tCopies\tCore\tErrors\n");
     }

   if (ai==aia)   {pheadp= NULL; per_printed= 0;}

   for( i=BEGIN;i<=END+1-CMIN;++i )   /* loop over all sites */
     {if (ABC[protein[i]]=='0')   continue;
      for( j=PMIN;j<=PMAX;++j )   /* loop over all periods */
        {cores= 1; copyn= 1; bflag= 0; numerr[0]= 0;
         for( k=i+j;k<=END;k+=j )
           {if (ABC[protein[k]]!=ABC[protein[i]])
              {if (cores<CMIN || bflag)   break;
               ++numerr[0];
               bflag= 1;
              }
            else
   	   {if (numerr[0]==0)   ++cores;
               ++copyn;
               bflag= 0;
              }
           }
         if (cores<CMIN)   continue;   /* continue with next j (period) */
         if (ABC[protein[k-j]]!=ABC[protein[i]])   --numerr[0];
   
         bflag= 0; iadj= i;
         for( k=i-j;k>=BEGIN;k-=j )   /* extending with errors to the left */
           {if (ABC[protein[k]]!=ABC[protein[i]])
              {if (bflag)   break;
               ++numerr[0];
               bflag= 1;
              }
            else
   	   {if (k==i-j)   break;   /* this pattern has already been processed */
   	    ++copyn;
   	    iadj= k;
               bflag= 0;
              }
           }
         if (k==i-j && k>=BEGIN)   continue;
				   /* continue with next j (period) */
         if (ABC[protein[k+j]]!=ABC[protein[i]])   --numerr[0];
   
         if ( copyn-cores < 2*numerr[0])
	  {bmtchcnt= 0;
	   for (k=iadj;k<iadj+(copyn+numerr[0])*j;k+= j)
	    {mtchcnt= errcnt= 0;
	     for (l=k;l<iadj+(copyn+numerr[0])*j;l+= j)
	      {if (ABC[protein[l]]==ABC[protein[i]]) ++mtchcnt;
	       else ++errcnt;
	       if (mtchcnt-cores >= 2*errcnt && mtchcnt > bmtchcnt) 
		{itoprt= k; bmtchcnt= mtchcnt; netoprt= errcnt;}
	      }
	    }
	   if (bmtchcnt>0)
	    {iadj= itoprt; copyn= bmtchcnt; numerr[0]= netoprt;}
	  }
	    /* require at least 2 additional matches for each error */

         if (PMAX<10) kmax= 10;   else kmax= PMAX;
         for (k=0;k<kmax;++k)   pstring[k]= ' '; pstring[kmax]= '\0';
         cflag= 0; ndots= 0;
         pstring[0]= ABC[protein[i]];
         for (k=1;k<j;++k)
           {for (m=0;m<NLET;++m)   cf[m]= 0;
            for (l=0;l<copyn+numerr[0];++l)
              {for (m=0;m<NLET;++m)
                 if ( iadj+l*j+k < numaa &&
   		   ABC[protein[iadj+l*j+k]]==SYMB[m])   {++cf[m]; break;}
              }
            for (m=0;m<NLET;++m)
              {if ( (float)cf[m]/(float)(copyn+numerr[0])>.65 )
                 {pstring[k]= SYMB[m];
		  numerr[k]= copyn+numerr[0] - cf[m];
                  if ( (float)cf[m]/(float)(copyn+numerr[0])<1.0 )   cflag= 1;
                  break;
                 }
              }
            if (m==NLET)   {pstring[k]='.'; ++ndots;}
           }
   
         if ( j>10 && (float)ndots/(float)j > .50)   continue;
	    /* ignore periodic patterns of period > 10 if they contain less
   	       than 50% consensus positions */
   
         nodep= (struct peod *) malloc(sizeof(struct peod));
         nodep->per= j;
         nodep->pos= iadj+1;
         nodep->cores= cores;
         nodep->copyn= copyn;
         for( m=0;m<j;++m )   nodep->nerr[m]= numerr[m];
         nodep->cflag= cflag;
         if (cores>=CSTAR)   nodep->star= '!';
         else   nodep->star= ' ';
         strcpy(nodep->pstr,pstring);
         nodep->next = NULL;
         per_ins_node(&pheadp,nodep);    /* recursive insertion procedure */
        } /* end-of-for-j */
     } /* end-of-for-i */
  } /* end-of-for-ai */

per_pr_nodes(pheadp,PMAX);
if (!per_printed)
  fprintf(outfp,"There are no periodicities of the prescribed length.\n");
fprintf(outfp,"\n");

}



per_ins_node(pheadpp,nodep)
struct peod **pheadpp;
struct peod *nodep;
{

if (*pheadpp == NULL)
  {*pheadpp = nodep;

#ifdef CHECKFLAG
fprintf(outfp,
"\nTOP OF LIST: p. %2d/ %s at %4d-%4d; %2d copies (%2d core; %2d errors) %c",
nodep->per, nodep->pstr, nodep->pos,
nodep->pos + (nodep->copyn +nodep->nerr[0]) * nodep->per -1,
nodep->copyn, nodep->cores, nodep->nerr[0], nodep->star );
#endif

  }
else
  {switch (per_comp_nodes(*pheadpp,nodep))   {
	case 0:

#ifdef CHECKFLAG
fprintf(outfp,
"\nINSERT: p. %2d/ %s at %4d-%4d; %2d copies (%2d core; %2d errors) %c",
nodep->per, nodep->pstr, nodep->pos,
nodep->pos + (nodep->copyn +nodep->nerr[0]) * nodep->per -1,
nodep->copyn, nodep->cores, nodep->nerr[0], nodep->star );
fprintf(outfp,
"\n   BEFORE  p. %2d/ %s at %4d-%4d; %2d copies (%2d core; %2d errors) %c",
(*pheadpp)->per, (*pheadpp)->pstr, (*pheadpp)->pos,
(*pheadpp)->pos + ((*pheadpp)->copyn +(*pheadpp)->nerr[0]) * (*pheadpp)->per -1,
(*pheadpp)->copyn, (*pheadpp)->cores, (*pheadpp)->nerr[0], (*pheadpp)->star );
#endif

		per_ins_nh(pheadpp,nodep);   /* insert nodep before *pheadpp */
		break;
	case 1:
		per_ins_node(&((*pheadpp)->next),nodep);
		break;
	case 2:

#ifdef CHECKFLAG
fprintf(outfp,
"\nREPLACE: p. %2d/ %s at %d-%4d; %2d copies (%2d core; %2d errors) %c",
(*pheadpp)->per, (*pheadpp)->pstr, (*pheadpp)->pos,
(*pheadpp)->pos + ((*pheadpp)->copyn +(*pheadpp)->nerr[0]) * (*pheadpp)->per -1, 
(*pheadpp)->copyn, (*pheadpp)->cores, (*pheadpp)->nerr[0], (*pheadpp)->star );
fprintf(outfp,
"\n      BY p. %2d/ %s at %d -%4d; %2d copies (%2d core; %2d errors) %c",
nodep->per, nodep->pstr, nodep->pos, 
nodep->pos + (nodep->copyn +nodep->nerr[0]) * nodep->per -1, 
nodep->copyn, nodep->cores, nodep->nerr[0], nodep->star );
#endif

		*pheadpp = (*pheadpp)->next;   /* delete *pheadpp; continue */
		per_ins_node(&(*pheadpp),nodep);
		break;
	default:

#ifdef CHECKFLAG
fprintf(outfp,
"\nIGNORE: p. %2d/ %s at %4d-%4d; %2d copies (%2d core; %2d errors) %c",
nodep->per, nodep->pstr, nodep->pos,
nodep->pos + (nodep->copyn +nodep->nerr[0]) * nodep->per -1,
nodep->copyn, nodep->cores, nodep->nerr[0], nodep->star );
fprintf(outfp,
"\n   FOR  p. %2d/ %s at %4d-%4d; %2d copies (%2d core; %2d errors) %c",
(*pheadpp)->per, (*pheadpp)->pstr, (*pheadpp)->pos,
(*pheadpp)->pos + ((*pheadpp)->copyn +(*pheadpp)->nerr[0]) * (*pheadpp)->per -1,
(*pheadpp)->copyn, (*pheadpp)->cores, (*pheadpp)->nerr[0], (*pheadpp)->star );
#endif

		break;   /* ignore nodep altogether */
	}
  }

}



per_ins_nh(pheadpp,nodep)   /* inserts nodep node before *pheadpp node */
struct peod **pheadpp;
struct peod *nodep;
{

struct peod *temptr;
temptr = *pheadpp;
*pheadpp = nodep;
nodep->next = temptr;

}



int per_comp_nodes(pheadptr,nodep)
struct peod *pheadptr;
struct peod *nodep;
/* - comparison function; returns 0 if nodep is to be inserted immediately
   in front of headnode; returns 1 if comparison is to continue; returns 2
   if nodep should replace pheadptr, and returns 3 if nodep should be ignored */
{
int n_end, h_end;

n_end= nodep->pos + (nodep->copyn +nodep->nerr[0]) * nodep->per -1;
h_end= pheadptr->pos + (pheadptr->copyn + pheadptr->nerr[0]) * pheadptr->per -1;

if ( nodep->pos < pheadptr->pos - 2*nodep->per )
  {return(0);
  }
/* ... nodep occurs substantially upstream of pheadptr; insert! */

if ( n_end > h_end + 2*nodep->per )
  {if (nodep->pos < pheadptr->pos)   return(0);
   else   return(1);
  }
/* ... nodep extends well beyond pheadptr; insert or continue with next
   pheadptr! */

/* nodep and pheadptr represent overlapping periods: */
if (nodep->per > pheadptr->per)
  {if ( nodep->pstr[0]==pheadptr->pstr[0] || nodep->pstr[0]=='*' 
	|| nodep->per%pheadptr->per==0 )   return(3);
      /* ... ignore nodep */
   else 
     {if (nodep->pos < pheadptr->pos)   return(0);
      else   return(1);
     }
  }
if (nodep->per==pheadptr->per)
  {if (nodep->cores > pheadptr->cores && nodep->pstr[0]!='*' )   return(2);
      /* ... replace pheadptr by nodep */
   else   return(3);
      /* ... ignore nodep */
  }
else
  {if ( (nodep->pstr[0]==pheadptr->pstr[0] || pheadptr->pstr[0]=='*'
	|| pheadptr->per%nodep->per==0) &&
	pheadptr->pos >= nodep->pos - 2*pheadptr->per &&
	h_end <= n_end + 2*pheadptr->per   )   return(2);
      /* ... replace pheadptr by nodep */
   else 
     {if (nodep->pos < pheadptr->pos)   return(0);
      else   return(1);
     }
  }

}



per_pr_nodes(nodep,PMAX)   /* prints all nodes in order */
struct peod *nodep;
int PMAX;
{
int i;

while (nodep != NULL)
  {if (PMAX<=10)
     {fprintf(outfp,"%4d-%4d\t%2d\t%s\t%2d\t", nodep->pos,
	nodep->pos + (nodep->copyn +nodep->nerr[0]) * nodep->per -1,
	nodep->per, nodep->pstr, nodep->copyn );
      if (!nodep->cflag)
	fprintf(outfp, "%2d %c\t%2d\n",
		nodep->cores, nodep->star, nodep->nerr[0] );
      else
	{fprintf(outfp, "%2d %c\t/", nodep->cores, nodep->star );
	 for( i=0;i<nodep->per;++i )
	   {if (nodep->pstr[i]!='.')   fprintf(outfp,"%d/", nodep->nerr[i] ); 
	    else   fprintf(outfp,"./");
	   }
	 fprintf(outfp,"\n");
	}
     }
   else
     {if (nodep->per<=10)
	{nodep->pstr[10]= '\0';
	 fprintf(outfp, "\nperiod %2d element %s at %4d-%4d; %2d copies ",
		nodep->per, nodep->pstr, nodep->pos,
		nodep->pos + (nodep->copyn +nodep->nerr[0]) * nodep->per -1,
		nodep->copyn );
	 if (!nodep->cflag)
	 fprintf(outfp, "(errors: %2d; core: %2d)  %c%c",
		nodep->nerr[0], nodep->cores, nodep->star, nodep->star );
	 else
	   {fprintf(outfp, "(core: %2d)  %c%c",
		nodep->cores, nodep->star, nodep->star );
	    fprintf(outfp,"\n  (consensus; # of errors in each position: /");
	    for( i=0;i<nodep->per;++i )
	      {if (nodep->pstr[i]!='.')   fprintf(outfp,"%d/", nodep->nerr[i] ); 
	       else   fprintf(outfp,"./");
	      }
	    fprintf(outfp," )");
	   }
	}
      else
        {fprintf(outfp, "\nperiod %3d element at %4d-%4d; %2d copies ",
		nodep->per, nodep->pos,
		nodep->pos + (nodep->copyn +nodep->nerr[0]) * nodep->per -1,
		nodep->copyn );
         if (!nodep->cflag)
	   fprintf(outfp, "(errors: %2d; core: %2d)  %c%c",
		nodep->nerr[0], nodep->cores, nodep->star, nodep->star );
	 else
	   fprintf(outfp, "(core: %2d)  %c%c",
		nodep->cores, nodep->star, nodep->star );
	 for (i=0;i<nodep->per;++i)
	   {if (i%30==0)   fprintf(outfp,"\n");
	    if (i%10==0)   fprintf(outfp," ");
	    fprintf(outfp,"%c", nodep->pstr[i] );
	   }
	 if (nodep->cflag)
	   {fprintf(outfp,"\n consensus; # of errors in each position:");
	    for (i=0;i<nodep->per;++i)
	      {if (i%30==0)   fprintf(outfp,"\n");
	       if (i%10==0)   fprintf(outfp," ");
	       if (nodep->pstr[i]!='.')   fprintf(outfp,"%d/", nodep->nerr[i] ); 
	       else   fprintf(outfp,"./");
	      }
           }
        }
     }
   per_printed= 1;
   nodep= nodep->next;
  }
fprintf(outfp,"\n");

}



float per_pfct(x,r,f)
float x, f;
int r;
{
int i;
float y= 0.;
double F= (double)f, X= (double)x;
 
for (i=0;i<r;++i)   y+= pow(F,(double)i)*pow(X,(double)i);
y*= (1.-F)*x;
y-= 1.0;
 
return(y);
}



float per_rtbis(func,x1,x2,xacc,r,F)
float (*func)(),x1,x2,xacc,F;
int r;
{
int j;
float dx,f,fmid,xmid,rtb;
void per_nr_error();
int JMAX= 40;

f=(*func)(x1,r,F);
fmid=(*func)(x2,r,F);
if (f*fmid >= 0.0)
  per_nr_error("Root must be bracketed for bisection in RTBIS");
rtb = f < 0.0 ? (dx=x2-x1,x1) : (dx=x1-x2,x2);
for (j=1;j<=JMAX;j++) {
    fmid=(*func)(xmid=rtb+(dx *= 0.5),r,F);
    if (fmid <= 0.0) rtb=xmid;
    if (fabs(dx) < xacc || fmid ==0.0) return rtb;
   }
per_nr_error("Too many bisections in RTBIS");

}



void per_nr_error(error_text)
char error_text[];
{

fprintf(stderr,"Numerical Recipes run-time error...\n");
fprintf(stderr,"period.c:  %s\n",error_text);
fprintf(stderr,"...now exiting to system...\n");
exit(1);

}
