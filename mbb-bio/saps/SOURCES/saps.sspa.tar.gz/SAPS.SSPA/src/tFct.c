/* tFct.C;                                   Last update: February 17, 1993. */
/*   - a function returning the t-value corresponding to c successes         */
/*   (occurring with probability p) in a window of length l.                 */
/* Dependencies:   called by aacluster.c, chcluster.c                        */
/* Bugs:                                                                     */

/*   Volker Brendel, Department of Mathematics, Stanford University,  */
/*   Stanford CA 94305; (415) 723-9256, volker@gnomic.stanford.edu    */

#include <math.h>

double tFct(c,l,p)
int c, l;
float p;
{
double t;
double C, L, P;

	C = (double) c;
	L = (double) l;
	P = (double) p;

	if( P == 0. || P == 1. )  t=0.;
	else
	t = (C - L*P) / sqrt(L*P*(1.-P));

return (t);

}
