#define HEADER "\n\
 SAPS (Statistical Analysis of Protein Sequences) evaluates by  statistical\n\
 criteria a wide variety of protein sequence properties. A full description\n\
 of the methods is given in the paper referred to below. The output is  or-\n\
 ganized  in the following sections: file name, sequence printout, composi-\n\
 tional analysis, charge distributional  analysis  (charge  clusters;  high\n\
 scoring  (un)charged  segments; charge runs and patterns), distribution of\n\
 other amino acid types (high scoring hydrophobic  and  transmembrane  seg-\n\
 ments; cysteine spacings), repetitive structures (in the amino acid alpha-\n\
 bet and in a 11-letter reduced alphabet),  multiplets  (counts,  spacings,\n\
 and  clusters  in  the  amino  acid  and  charge  alphabets),  periodicity\n\
 analysis, spacing analysis. Each section is annotated below under its sec-\n\
 tion title.\n\
      The SAPS program was developed in the group of Prof. Samuel Karlin at\n\
 Stanford  University.  Correspondence relating to SAPS should be addressed\n\
 to either Volker Brendel or Samuel Karlin at the Department  of  Mathemat-\n\
 ics,  Stanford  University,  Stanford  CA 94305, U.S.A.; phone: (415) 723-\n\
 2209; fax: (415) 725-2040; email: volker@gnomic.stanford.edu. Users of the\n\
 program  should  cite  the  following  reference: Brendel, V., Bucher, P.,\n\
 Nourbakhsh, I., Blaisdell, B.E., Karlin, S. (1992) Methods and  algorithms\n\
 for statistical analysis of protein sequences.  Proc. Natl. Acad. Sci. USA\n\
 89: 2002-2006.\n\n"

#define COMP_DOC "\n\
 The composition of the input sequence is evaluated relative to the residue\n\
 usage  quantile  table  specified with the `-s species' flag. Low usage in\n\
 the 1%% quantile is indicated by the label -- (e.g., Y--  means  that  the\n\
 input  sequence uses tyrosine as little as the 1%% least tyrosine contain-\n\
 ing proteins in the reference set); low usage in the 5%% quantile is indi-\n\
 cated  by  the  label  `-'  (e.g., L-); high usage above the 95%% quantile\n\
 point is indicated by the label `+' (e.g., A+); and high usage  above  the\n\
 99%%  quantile  point  is indicated by the label `++' (e.g., LIVFM++). The\n\
 usage is evaluated for all 20 amino acids, positive (KR) and negative (ED)\n\
 charge,  total  charge  (KRED),  net  charge  (KR-ED),  major hydrophobics\n\
 (LVIFM), and the groupings ST, AGP (encoded by CCN, GCN, and GGN  codons),\n\
 and FIKMNY (encoded by AAN, AUN, UAN, and UUN codons).\n\n"

#define CHDA_DOC "\n\
 The distribution of charges in the protein sequence is evaluated in  terms\n\
 of  clusters, high scoring segments, and runs and periodic patterns. Clus-\n\
 ters indicate regions of typically 30 to 60 residues  exhibiting  a  rela-\n\
 tively  high charge concentration. For high scoring charge segments, posi-\n\
 tive scores are assigned to charge residues of the  appropriate  type  and\n\
 negative  scores  to all other residues. A significant cumulative positive\n\
 score again indicates a region of high charge concentration.  The  cluster\n\
 method  and  the  scoring method will generally pick out the same segments\n\
 (with the scoring method  often  delimiting  the  segment  to  a  narrower\n\
 range),  conferring  robustness  to  the  results.  Short segments of high\n\
 charge concentration are displayed as runs (with  errors).  Periodic  pat-\n\
 terns  focus  on  those  with charges every second or third position, with\n\
 possible relevance to amphipathic  secondary  structures;  other  periodic\n\
 patterns  are displayed in the general periodicity analysis section of the\n\
 output.\n\n"

#define CLUS_DOC "\n\
 Positive, negative, and mixed charge clusters are distinguished.  In  each\n\
 case, cmin indicates the minimum number of charges required for a signifi-\n\
 cant charge cluster corresponding to the given window size; e.g.,  cmin  =\n\
 9/30 or 12/45 or 15/60 means that significance requires at least 9 charges\n\
 in a segment of 30 (or fewer) residues, or 12  charges  in  a  segment  of\n\
 length  45,  or 15 charges in a segment of length 60. In the case of posi-\n\
 tive and negative charge clusters, these counts refer to net charge, i.e.,\n\
 charges  of  the  opposite  sign  within the window are counted as -1. The\n\
 sizes of the clusters are optimized for display to indicate the segment of\n\
 highest  charge  concentration,  but  a  minimum  size  of  20 residues is\n\
 required.  A mixed charge cluster that begins and ends within 15  residues\n\
 of the endpoints of a pure charge cluster is not displayed (since its sig-\n\
 nificance rests mostly on the charged residues  comprising  the  displayed\n\
 pure charge cluster), unless the -v (verbose output) flag is set, in which\n\
 case both the pure and the mixed charge  cluster  are  displayed.  On  the\n\
 other  hand,  pure charge clusters that are embedded in mixed charge clus-\n\
 ters are displayed separately (indicated by a * preceding  the  specifica-\n\
 tion of location).\n\
      For each cluster are given its location in the sequence  (From,  to),\n\
 the  quartile  of  the  location  (1st,  2nd,  3rd,  or 4th quarter of the\n\
 sequence), length, count, and t-value (standard deviations above the mean;\n\
 to  accommodate  the  multiple  tests  performed, the t-value significance\n\
 threshold is set to 4.0 for sequences up  to  750  residues,  to  4.5  for\n\
 sequences  of  length 750-1500 residues, and to 5.0 for longer sequences);\n\
 also indicated are residues comprising at least 10%% of the cluster.\n\n"

#define HSSG_DOC "\n\
 For each scoring scheme (scores assigned to residues as  displayed),  SAPS\n\
 displays  segments of the sequence with aggregate score exceeding the par-\n\
 ticular threshold values M_0.01 (1%% significance level, segments  labeled\n\
 with  **),  M_0.05 (5%% significance level, segments labeled *), or other-\n\
 wise as indicated. A minimal segment length is set as shown.  The expected\n\
 score/letter should be sufficiently large negative, and the average infor-\n\
 mation per letter should be sufficiently large positive in order  for  the\n\
 scoring statistics to apply properly (the program prints out when the con-\n\
 ditions are not met and skips evaluations).\n\n"

#define RUPA_DOC "\n\
 The table below shows the charge runs and patterns searched for (*  stands\n\
 for  +  or  -)  and  the required minimum number of matches to the pattern\n\
 allowing for at most 0 (lmin0), 1 (lmin1),  or  2  (lmin2)  mismatches  or\n\
 insertions/deletions (1%% significance level). Occurrences are arranged in\n\
 the order in which they appear in the sequence. For each  run  or  pattern\n\
 are  displayed  its  length  (number  of matches) and a triplet giving the\n\
 number of mismatches, insertions and deletions. 0-runs are further charac-\n\
 terized  by  their  composition (residues comprising more than 10%% of the\n\
 run).\n\
      Run count statistics are compiled for runs of lengths at least 2/3 of\n\
 the minimal significant length (lmin0); given are the number and locations\n\
 of such runs.\n\n"

#define IONP_DOC "\n\
\n"
 
#define DAAT_DOC "\n\
 Routinely, SAPS indicates high scoring hydrophobic and transmembrane  seg-\n\
 ments.  The display is as desribed above for high scoring charge segments.\n\
 The scores for the hydrophobic segments correspond to a  digitized  hydro-\n\
 pathy  scale.   The transmembrane scores were derived from target frequen-\n\
 cies in putative transmembrane proteins (see the paper referred to  above;\n\
 note, however, that the scores used in the program have been rederived and\n\
 differ from the ones given in the paper). With the -a command  line  flag,\n\
 the  user  can invoke a similar analysis for other residue types.  In view\n\
 of the special role of cysteines for protein structure,  the  spacings  of\n\
 the  cysteine residues in the sequence are displayed separately, with par-\n\
 ticular emphasis on close pairs of cysteines and  distances  between  such\n\
 pairs.\n\n"

#define REPE_DOC "\n\
 Repeats are indicated for two alphabets: the 20-letter amino  acid  alpha-\n\
 bet,  and  a  reduced  11-letter  alphabet in which the major hydrophobics\n\
 LVIF, the charged residues KR and ED, the small residues AG, the  hydroxyl\n\
 group  residues  ST,  the amid group residues NQ, and the aromatics YW are\n\
 treated as combined letters.  For each alphabet, three classes of  repeats\n\
 are  distinguished: separated repeats, simple tandem repeats, and periodic\n\
 repeats. The separated  repeats  are  largely  non-overlapping.  They  are\n\
 displayed  in  groups  of  matching  blocks  (exceeding a given core block\n\
 length of contiguous  exact  matches)  and  intervening  spacer  distances\n\
 (which  may  be  negative,  signifying  a partial overlap). The core block\n\
 length in case of the amino acid alphabet is set to 4 for sequences up  to\n\
 500  residues,  to 5 for sequences between 500 and 2000 residues, and to 6\n\
 for longer sequences (same values increased by 4 for  the  reduced  alpha-\n\
 bet).   Simple  tandem  repeats  are  displayed  in  similar  layout,  but\n\
 separately. Sequence segments that are highly repetitive  with  relatively\n\
 short repeats are displayed as periodic repeats.\n\n"

#define MULT_DOC "\n\
 Multiplets refer to homooligopeptides of any length (e.g., A2, Q7,  etc.);\n\
 altplets  refer  to  reiterations  of  two  different  residues (e.g., RG,\n\
 EAEAEA, etc.). The  multiplet  composition  of  the  protein  sequence  is\n\
 evaluated  for  both the amino acid and the charge alphabet. (High) Aggre-\n\
 gate altplet counts are evalued only for the charge alphabet.  The  multi-\n\
 plet  sequence  is  displayed  whenever  the  total multiplet count of the\n\
 sequence falls outside the expected range (i.e., beyond 3 standard  devia-\n\
 tions of the mean). Printed are also the histogram of the spacings between\n\
 consecutive multiplets (differences between starting positions) as well as\n\
 clusters  of multiplets (multiplet clusters are determined in the same way\n\
 as charge clusters are determined; the  binomial  test  is  applied  to  a\n\
 compressed sequence over the alphabet {M,S}, where M signifies a multiplet\n\
 and S signifies a singlet; i.e., the amino acid sequence AADFFFGHRRT... is\n\
 translated  as MSMSSMS..., and the binomial cluster test is applied to the\n\
 latter sequence). Multiplets and altplets of specific residue content that\n\
 individually show an unusually high count are indicated, and the positions\n\
 of all multiplets exceeding a minimum length of 5 residues are shown.\n\n"

#define PERD_DOC "\n\
 The program identifies periodic elements of periods between 1 and  10  for\n\
 the amino acid alphabet, for the charge alphabet, and for a hydrophobicity\n\
 alphabet. Each periodic element consists of an error-free core pattern (of\n\
 length  at least 4 for the amino acid alphabet, 5 for the charge alphabet,\n\
 and 6 for the hydrophobicity alphabet)  which  is  extended  allowing  for\n\
 errors.   The  numbers  of  errors are given for each position in the con-\n\
 sensus of a periodic pattern involving more than one letter. The displayed\n\
 periodic patterns would generally not be statistically significant but are\n\
 listed for the sake of a general interactive appraisal  of  the  sequence.\n\
 Periodicities  of  exceptionally  high copy number are indicated with a !-\n\
 mark.\n\n"

#define SPAC_DOC "\n\
 The spacings between consecutive residues of the same type (all  20  amino\n\
 acids,  +  and - charge, and combined charge *) are evaluated for signifi-\n\
 cantly large or small maximal and minimal spacings. The output is  ordered\n\
 by  the beginning point of the significant spacing. Entries are identified\n\
 by the residue type, spacing (number of amino acids between the identified\n\
 positions),  rank  of  the  displayed  spacing  (e.g.,  50 alanines in the\n\
 sequence induce 51 spacings, ranked by decreasing length from  1  to  51),\n\
 and  p-value  (probability  of exceeding the displayed spacing). A maximal\n\
 spacing with p-value 0.01 or less is  considered  significantly  large;  a\n\
 maximal  spacing  with  p-value 0.99 or larger is considered significantly\n\
 small. Similarly, a minimal spacing with p-value 0.99 or  larger  is  con-\n\
 sidered  significantly  small,  and a minimal spacing with p-value 0.01 or\n\
 less is considered significantly large (excluding doublets). If the  first\n\
 maximal  spacing  (rank  1)  of a residue is significantly large or small,\n\
 then also the second maximal spacing (rank 2) is evaluated. Large  maximal\n\
 and small minimal spacings indicate clustering effects, whereas small max-\n\
 imal and large minimal spacings indicate excessive evenness in the distri-\n\
 bution of the residues.\n\n"
