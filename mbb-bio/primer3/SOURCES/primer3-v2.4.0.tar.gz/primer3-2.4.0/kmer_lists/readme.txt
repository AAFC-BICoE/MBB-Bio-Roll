Currently, directory kmer_lists contains TEST files (because of the size of
list files).

To download kmer-lists or to make ones, please visit
http://primer3.ut.ee/lists.htm or homepage of "FastGT package version
4.0" at http://bioinfo.ut.ee/?page_id=167&lang=en

By default Primer3 uses kmer-lists with k-mer size 11 and size 16. File name
format should be for human homo_sapiens_11.list and homo_sapiens_16.list
(species_name_wordlenght.list)