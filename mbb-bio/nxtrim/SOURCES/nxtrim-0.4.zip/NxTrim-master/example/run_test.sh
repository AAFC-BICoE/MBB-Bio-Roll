./nxtrim -1 example/ENA_R1.fastq.gz -2 example/ENA_R2.fastq.gz --out example/ENA
./nxtrim -1 example/example11_R1.fastq.gz -2 example/example11_R2.fastq.gz --out example/example11
./nxtrim -1 example/EXTERNAL_R1.fastq.gz -2 example/EXTERNAL_R2.fastq.gz --out example/EXTERNAL
./nxtrim -1 example/FailPF_R1.fastq.gz -2 example/FailPF_R2.fastq.gz --out example/FailPF
./nxtrim -1 example/MP_R1.fastq.gz -2 example/MP_R2.fastq.gz --out example/MP
./nxtrim -1 example/PE_R1.fastq.gz -2 example/PE_R2.fastq.gz --out example/PE
./nxtrim -1 example/sample_R1.fastq.gz -2 example/sample_R2.fastq.gz --out example/sample
./nxtrim -1 example/UNKNOWN_R1.fastq.gz -2 example/UNKNOWN_R2.fastq.gz --out example/UNKNOWN
