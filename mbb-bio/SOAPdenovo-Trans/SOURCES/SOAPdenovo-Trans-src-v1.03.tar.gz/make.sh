cd SOAPdenovo-Trans/
make
make 127mer=1
