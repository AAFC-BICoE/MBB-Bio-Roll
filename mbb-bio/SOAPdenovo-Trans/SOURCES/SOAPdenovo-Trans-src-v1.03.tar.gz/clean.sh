cd SOAPdenovo-Trans
make clean
make clean 127mer=1

