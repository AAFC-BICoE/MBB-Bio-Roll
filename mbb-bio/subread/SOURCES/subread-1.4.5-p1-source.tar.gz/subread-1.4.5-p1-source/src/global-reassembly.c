/***************************************************************

   The Subread and Rsubread software packages are free
   software packages:
 
   you can redistribute it and/or modify it under the terms
   of the GNU General Public License as published by the 
   Free Software Foundation, either version 3 of the License,
   or (at your option) any later version.

   Subread is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty
   of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
   
   See the GNU General Public License for more details.

   Authors: Drs Yang Liao and Wei Shi

  ***************************************************************/
 


#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include <unistd.h>
#include <ctype.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>


#ifndef MAKE_STANDALONE
  #include <R.h>
#endif

#include <zlib.h>
#include <math.h>
#include <pthread.h>
#include <getopt.h>
#include "subread.h"
#include "sambam-file.h"
#include "gene-algorithms.h"
#include "input-files.h"
#include "long-hashtable.h"
#include "HelperFunctions.h"


static struct option GRA_long_options[] =
{
	{"in", required_argument, 0, 'i'},
	{"BAMinput", no_argument, 0, 'b'},
	{"out", required_argument, 0, 'o'},
	{"threads", required_argument, 0, 'T'},
	{0, 0, 0, 0}
};

#define GRA_FRAG_USED_BEFORE 1
#define GRA_FRAG_USED_NOW 2

typedef struct{

	short length_1;
	short replicate_count_1;
	short sequencing_quality_1;

	short length_2;
	short replicate_count_2;
	short sequencing_quality_2;

	unsigned int flags;

	unsigned long long list_file_pos;
	unsigned long long replicate_representitive_1;
	unsigned long long replicate_representitive_2;

} GRA_frag_properties_t;



typedef struct {
	char input_file_name [300];
	char output_file_name [300];
	int is_BAM_input;
	int total_threads;
	int shortest_read_allowed;
	int subread_extract_step;
	int read_trim_base_quality;
	int min_overlap_votes;

	// ====== Global Runtime ======
	int no_more_assembly;
	unsigned long long all_fragments;
	double start_time;
	int fd_fragproperties;
	FILE * fp_fragproperties;
	FILE * fp_fraglist;
	GRA_frag_properties_t * frag_properties_array;
	lnhash_t assembling_index;

	// ====== Global System ======
	char tmp_file_prefix[300];
	unsigned int random_seeds[8];
	pid_t system_pid;

	// ====== Current Contig ======
	GRA_frag_properties_t * start_fragment_props;
	unsigned long long current_frag_no;
	int current_frag_reversed_to_start;

} GRA_global_context_t;

void GRA_print_usage()
{
	SUBREADputs("\nUsage:");
	SUBREADputs("\n  ./globalReassembly -i input.{SAM|BAM} -o output.txt {--BAMinput} \n");
}

int GRA_check_config (GRA_global_context_t * global_context)
{
	if(global_context -> input_file_name[0]==0 || global_context -> output_file_name[0]==0)
	{
		SUBREADputs("ERROR: You have to specify the input file and the output file.");
		return 1;
	}

	SUBREADputs("");
	SUBREADputs("");
	SUBREADputs(" ============== Global Reassembly of Reads ==============");
	SUBREADputs("");
	SUBREADprintf("\n\tInput file\t:\t%s\n", global_context -> input_file_name);
	SUBREADprintf("\tOutput file\t:\t%s\n", global_context -> output_file_name);
	if(global_context -> is_BAM_input)
		SUBREADputs("\tFile Format\t:\tBAM");
	else
		SUBREADputs("\tFile Format\t:\tSAM");

	SUBREADputs("");

	return 0;
}


void GRA_init_context(GRA_global_context_t * global_context)
{
	FILE * system_random_fp; 
	memset(global_context, 0 , sizeof(GRA_global_context_t));

	global_context -> system_pid = getpid();
	system_random_fp = fopen("/dev/urandom","rb");
	assert(system_random_fp);
	fread(global_context -> random_seeds, 8 * sizeof(int), 1, system_random_fp);
	fclose(system_random_fp);
	sprintf(global_context -> tmp_file_prefix, "GRAtmp-%u-%d", global_context -> random_seeds[0], global_context -> system_pid);

	global_context -> shortest_read_allowed = 60; 
	global_context -> total_threads = 1;
	global_context -> read_trim_base_quality = 20 + 33; 
	global_context -> subread_extract_step = 7;
	global_context -> min_overlap_votes = 5;
	global_context -> start_time = miltime();
}

int GRA_trim_reads(GRA_global_context_t * global_context)
{
	int line_buff_len = MAX_READ_LENGTH * 2 + MAX_READ_NAME_LEN + MAX_CHROMOSOME_NAME_LEN * 3 + 500; 
	char tmp_fname[300],
		* line_buff = malloc(line_buff_len),
		* in_sequence = malloc(MAX_READ_LENGTH),
		* in_quality_string = malloc(MAX_READ_LENGTH),
		* in_readname = malloc(MAX_READ_NAME_LEN);
	FILE * fp_fraglist, * fp_fragproperties;

	sprintf(tmp_fname, "%s.fragproperties", global_context -> tmp_file_prefix);
	fp_fragproperties = fopen(tmp_fname,"wb");

	sprintf(tmp_fname, "%s.fraglist", global_context -> tmp_file_prefix);
	fp_fraglist = fopen(tmp_fname,"wb");

	if(!(fp_fragproperties && fp_fraglist)){
		SUBREADprintf("Unable to create temporary files in the currect directory!\n");
		return 1;
	}

	SamBam_FILE * reader = SamBam_fopen(global_context -> input_file_name,
		global_context->is_BAM_input?SAMBAM_FILE_BAM:SAMBAM_FILE_SAM);

	if(!reader)
	{
		SUBREADprintf("Unable to open input file '%s' as a %s file!\n", 
			global_context -> input_file_name,
			global_context->is_BAM_input?"BAM":"SAM"
			);
		return 1;
	}

	unsigned long long short_frag_number = 0;
	unsigned long long frag_number = 0;
	unsigned long readname_hash = 0;
	GRA_frag_properties_t frag_props;
	while(1)
	{
		char * readret = SamBam_fgets(reader, line_buff, line_buff_len, 1); 
		char in_cigar[100];
		int  in_flags = 0, in_mapq = 0, in_isrepeated = 0, in_rl = 0;
		unsigned int in_pos=0, in_tlen=0;
		char in_chro[MAX_CHROMOSOME_NAME_LEN];
		if(!readret) break;
		if(line_buff[0]=='@') continue;

		
		parse_SAM_line(line_buff, in_readname, &in_flags, in_chro, &in_pos, in_cigar, &in_mapq, &in_tlen, in_sequence , in_quality_string, &in_rl, &in_isrepeated);

		if(in_flags & SAM_FLAG_SECOND_READ_IN_PAIR)
			assert(readname_hash == fc_chro_hash(in_readname));
		else{
			unsigned long new_readname_hash = fc_chro_hash(in_readname); 
			readname_hash = new_readname_hash;
		}


		int xk1,best_qual_window_value = 0, current_qual_sum = 0;
		short best_qual_window_to_head = -1;

		// xk1 is the last base being added into the window.
		for(xk1 = 0 ; xk1 < in_rl; xk1++)
		{
			current_qual_sum += in_quality_string[xk1];
			if(xk1>=10)
			{
				if(current_qual_sum > best_qual_window_value)
				{
					best_qual_window_value = current_qual_sum;
					best_qual_window_to_head = xk1 - 10;
				}
				current_qual_sum -= in_quality_string[xk1 - 10];
			}
		}

		char * new_read_start = in_sequence;
		char * new_qual_start = in_quality_string;
		for(xk1 = best_qual_window_to_head; xk1>=0; xk1--)
		{
			if(in_quality_string[xk1] < global_context -> read_trim_base_quality)
			{
				new_read_start = in_sequence + xk1;
				new_qual_start = in_quality_string + xk1;
				break;
			}
		}

		for(xk1 = best_qual_window_to_head; xk1< in_rl; xk1++)
		{
			if(in_quality_string[xk1] < global_context -> read_trim_base_quality)
			{
				in_sequence[xk1]=0;
				in_quality_string[xk1]=0;
				break;
			}
		}


		int new_rl = strlen(new_read_start);
		short min_quality_value = 9999;
		for(xk1 = 0; xk1<new_rl; xk1++)
		{
			min_quality_value = min(min_quality_value, new_qual_start[xk1]);
		}
		
		unsigned long long pos_fraglist = ftello(fp_fraglist);

		if(in_flags & SAM_FLAG_SECOND_READ_IN_PAIR)
		{
			frag_props . sequencing_quality_2 = min_quality_value;
			frag_props . length_2 = new_rl;
			frag_props . replicate_count_2 = 0;
			frag_props . flags = 0;
			fwrite(&frag_props, sizeof(frag_props), 1, fp_fragproperties);
			if(frag_props . length_1 < global_context -> shortest_read_allowed || frag_props . length_2 < global_context -> shortest_read_allowed)short_frag_number++;

			memset(&frag_props, 0, sizeof(frag_props));
		}
		else
		{
			frag_props . sequencing_quality_1 = min_quality_value;
			frag_props . length_1 = new_rl;
			frag_props . replicate_count_1 = 0;
			frag_props . list_file_pos = pos_fraglist;
		}

		if(in_flags & SAM_FLAG_REVERSE_STRAND_MATCHED)
		{
			reverse_read(new_read_start, new_rl, GENE_SPACE_BASE); 
			reverse_quality(new_qual_start, new_rl);
		}

		// the frag list is simply the concatination if SEQ_1, QUAL_1, SEQ_2, QUAL_2, ... 
		fwrite(new_read_start, new_rl, 1, fp_fraglist);
		fputc('|', fp_fraglist);
		fwrite(new_qual_start, new_rl, 1, fp_fraglist);
		fputc('|', fp_fraglist);
		
		if(in_flags & SAM_FLAG_SECOND_READ_IN_PAIR) 
			frag_number ++;
	}
	global_context -> all_fragments = frag_number;

	SUBREADprintf("Finished read trimming. %llu fragments were processed; %llu fragments were too short.\n\n", 
		global_context -> all_fragments, short_frag_number);

	fclose(fp_fraglist);
	fclose(fp_fragproperties);

	free(in_readname);
	free(in_sequence);
	free(in_quality_string);
	free(line_buff);

	assert(!(frag_props . length_1 || frag_props . length_2));

	return 0;
}

unsigned long long get_frag_number_part(unsigned long long q)
{
	return q >> 16;
}


void get_frag_property(GRA_global_context_t* global_context, unsigned long long frag_no, GRA_frag_properties_t * prop )
{
	unsigned long long cpos = ftello(global_context -> fp_fragproperties);
	unsigned long long fpos = frag_no * sizeof(GRA_frag_properties_t);

	fseeko(global_context -> fp_fragproperties, fpos, SEEK_SET);
	fread(prop, sizeof(GRA_frag_properties_t), 1, global_context -> fp_fragproperties);
	fseeko(global_context -> fp_fragproperties, cpos, SEEK_SET);
}

void get_frag_sequence(GRA_global_context_t* global_context, GRA_frag_properties_t * prop, int is_read2, char * seq_buffer)
{
	unsigned long long fpos = prop -> list_file_pos;
	if(is_read2) fpos += prop -> length_1 *2 + 2;
	int seq_len = is_read2 ? prop -> length_2:prop -> length_1;
	unsigned long long cpos = ftello(global_context -> fp_fraglist);

	//SUBREADprintf("FPOS=%llu, CPOS=%llu\n", fpos, cpos);
	fseeko(global_context -> fp_fraglist , fpos, SEEK_SET);
	fread(seq_buffer, seq_len,1 , global_context -> fp_fraglist);
	seq_buffer[seq_len]=0;
	fseeko(global_context -> fp_fraglist , cpos, SEEK_SET);

	assert(!strchr(seq_buffer,'|'));

	//if(is_read2)SUBREADprintf("QFSR=%s\n", seq_buffer);
	//else SUBREADprintf("QFSA=%s\n", seq_buffer);
}

int search_replicate_representitive(GRA_global_context_t* global_context, lnhash_vote_record_t * vote_rec, unsigned long long frag_number, GRA_frag_properties_t * query_prop, int query_is_read2, unsigned long long * representitiva_id)
{
	if(get_frag_number_part(vote_rec -> head_position) == frag_number) return 0;

	int rlen = query_is_read2?query_prop -> length_2:query_prop -> length_1;
	int mapp_target = (vote_rec -> head_position & 0x3fff);
	int target_is_read2 = (vote_rec -> head_position & 0x8000)?1:0;
	if(mapp_target<1300 && vote_rec -> coverage_start < global_context -> subread_extract_step && vote_rec -> coverage_end > rlen - global_context -> subread_extract_step - 1 && (vote_rec -> coverage_end - 15 - vote_rec -> coverage_start) / global_context -> subread_extract_step + 1 == vote_rec -> num_votes)
	{
		GRA_frag_properties_t frag_prop;
		get_frag_property(global_context, get_frag_number_part(vote_rec -> head_position), &frag_prop);
		int target_rlen = target_is_read2?frag_prop.length_2:frag_prop.length_1;

		if(target_rlen >= rlen + mapp_target &&  vote_rec -> coverage_end - vote_rec -> coverage_start + mapp_target <= target_rlen)
		{
			char read_seq_query[MAX_READ_LENGTH], read_seq_target[MAX_READ_LENGTH];
			int target_is_reversed = (vote_rec -> head_position & 0x4000)?1:0, xk1, mm=0;

			get_frag_sequence(global_context, &frag_prop, target_is_read2, read_seq_target);
			get_frag_sequence(global_context, query_prop, query_is_read2 , read_seq_query );

			if(target_is_reversed) reverse_read(read_seq_target , target_rlen, GENE_SPACE_BASE);

			for(xk1=0; read_seq_query[xk1]; xk1++)
				mm+= (read_seq_target[xk1 + mapp_target] == 'N' || read_seq_target[xk1 + mapp_target] != read_seq_query[xk1]);

			if(!mm)
			{
				(*representitiva_id) = get_frag_number_part(vote_rec -> head_position);
				if(rlen == target_rlen)
					return (*representitiva_id) < frag_number;
				return 1;
			}
		}
	}
	return 0;
}

int GRA_build_read_index(GRA_global_context_t* global_context)
{
	unsigned long long report_step = max(1, global_context -> all_fragments/20);
	FILE * fp_fragproperties, * fp_fraglist;
	GRA_frag_properties_t frag_prop;

	lnhash_create(&global_context -> assembling_index, 666661);

	char tmp_fname[300],
		* in_sequence_1 = malloc(MAX_READ_LENGTH),
		* in_quality_string_1 = malloc(MAX_READ_LENGTH),
		* in_sequence_2 = malloc(MAX_READ_LENGTH),
		* in_quality_string_2 = malloc(MAX_READ_LENGTH);


	lnhash_t first_index;
	lnhash_create(&first_index, 666661);

	sprintf(tmp_fname, "%s.fragproperties", global_context -> tmp_file_prefix);
	fp_fragproperties = fopen(tmp_fname,"rb");
	global_context -> fp_fragproperties = fp_fragproperties;

	sprintf(tmp_fname, "%s.fraglist", global_context -> tmp_file_prefix);
	fp_fraglist = fopen(tmp_fname,"rb");
	global_context -> fp_fraglist = fp_fraglist;

	unsigned long long frag_number = 0;

	while(1)
	{
		int nrecord = fread(&frag_prop, sizeof(frag_prop), 1, fp_fragproperties);
		if(nrecord<1) break;
		if(frag_prop.length_1 >= global_context -> shortest_read_allowed && frag_prop.length_2 >= global_context -> shortest_read_allowed)
		{

			fseeko(fp_fraglist, frag_prop.list_file_pos, SEEK_SET);
			fread(in_sequence_1, frag_prop.length_1 , 1, fp_fraglist);
			fgetc(fp_fraglist);
			fread(in_quality_string_1, frag_prop.length_1 , 1, fp_fraglist);
			fgetc(fp_fraglist);
			fread(in_sequence_2, frag_prop.length_2 , 1, fp_fraglist);
			fgetc(fp_fraglist);
			fread(in_quality_string_2, frag_prop.length_2 , 1, fp_fraglist);
			fgetc(fp_fraglist);

			int is_reversed, is_second_read, xxi, current_len;
			char * current_seq;
			for(xxi = 0; xxi<4; xxi++)
			{
				is_second_read = xxi/2;
				is_reversed = xxi%2;

				current_seq = is_second_read?in_sequence_2:in_sequence_1;
				current_len = is_second_read?frag_prop.length_2:frag_prop.length_1;
				unsigned long long read_pos_code = (frag_number<<16) | (is_second_read << 15) | (is_reversed << 14) ;
				int extract_cursor;
				unsigned long long current_repeated = is_second_read?frag_prop.replicate_representitive_2:frag_prop.replicate_representitive_1;

				if(!current_repeated)
				{
					for(extract_cursor=0; extract_cursor< current_len-15; extract_cursor += global_context -> subread_extract_step)
					{

						char * subread_txt = current_seq + extract_cursor;
						unsigned int subread_int = genekey2int(subread_txt, GENE_SPACE_BASE); 

						lnhash_insert(&global_context -> assembling_index, subread_int, read_pos_code | extract_cursor);
					}			
				}

				if(0==xxi)
					reverse_read(in_sequence_1, frag_prop.length_1, GENE_SPACE_BASE);
				if(2==xxi)
					reverse_read(in_sequence_2, frag_prop.length_2, GENE_SPACE_BASE);
			}

		}

		if(frag_number % report_step == 0)
			SUBREADprintf("  Building reassembly index, %.1f%% finished in %.1f minutes.\n", frag_number*100./global_context -> all_fragments, (miltime() - global_context -> start_time)/60);

		frag_number++;
	}

	fclose(fp_fragproperties);
	free(in_sequence_1);
	free(in_sequence_2);
	free(in_quality_string_1);
	free(in_quality_string_2);


	lnhash_resort(&global_context -> assembling_index);

	return 0;
}

int GRA_mark_read_duplicate(GRA_global_context_t* global_context)
{
	unsigned long long report_step = max(1, global_context -> all_fragments/20);
	FILE * fp_fragproperties, * fp_fraglist;
	GRA_frag_properties_t frag_prop;
	char tmp_fname[300],
		* in_sequence_1 = malloc(MAX_READ_LENGTH),
		* in_quality_string_1 = malloc(MAX_READ_LENGTH),
		* in_sequence_2 = malloc(MAX_READ_LENGTH),
		* in_quality_string_2 = malloc(MAX_READ_LENGTH);


	lnhash_t first_index;
	lnhash_create(&first_index, 666661);

	sprintf(tmp_fname, "%s.fragproperties", global_context -> tmp_file_prefix);
	fp_fragproperties = fopen(tmp_fname,"rb");
	global_context -> fp_fragproperties = fp_fragproperties;

	sprintf(tmp_fname, "%s.fraglist", global_context -> tmp_file_prefix);
	fp_fraglist = fopen(tmp_fname,"r+");
	global_context -> fp_fraglist = fp_fraglist;

	unsigned long long frag_number = 0;

	while(1)
	{
		int nrecord = fread(&frag_prop, sizeof(frag_prop), 1, fp_fragproperties);
		if(nrecord<1) break;

		if(frag_prop.length_1 >= global_context -> shortest_read_allowed && frag_prop.length_2 >= global_context -> shortest_read_allowed)
		{

			fseeko(fp_fraglist, frag_prop.list_file_pos, SEEK_SET);
			fread(in_sequence_1, frag_prop.length_1 , 1, fp_fraglist);
			fgetc(fp_fraglist);
			fread(in_quality_string_1, frag_prop.length_1 , 1, fp_fraglist);
			fgetc(fp_fraglist);
			fread(in_sequence_2, frag_prop.length_2 , 1, fp_fraglist);
			fgetc(fp_fraglist);
			fread(in_quality_string_2, frag_prop.length_2 , 1, fp_fraglist);
			fgetc(fp_fraglist);

			int is_reversed, is_second_read, xxi, current_len;
			char * current_seq;
			for(xxi = 0; xxi<4; xxi++)
			{
				is_second_read = xxi/2;
				is_reversed = xxi%2;

				current_seq = is_second_read?in_sequence_2:in_sequence_1;
				current_len = is_second_read?frag_prop.length_2:frag_prop.length_1;
				unsigned long long read_pos_code = (frag_number<<16) | (is_second_read << 15) | (is_reversed << 14) ;
				int extract_cursor;

				for(extract_cursor=0; extract_cursor< current_len-15; extract_cursor += global_context -> subread_extract_step)
				{
					char * subread_txt = current_seq + extract_cursor;
					unsigned int subread_int = genekey2int(subread_txt, GENE_SPACE_BASE); 

					lnhash_insert(&first_index, subread_int, read_pos_code | extract_cursor);
				}

				if(0==xxi)
					reverse_read(in_sequence_1, frag_prop.length_1, GENE_SPACE_BASE);
				if(2==xxi)
					reverse_read(in_sequence_2, frag_prop.length_2, GENE_SPACE_BASE);
			}
		}
		if(frag_number % report_step == 0)
			SUBREADprintf("  Building first index, %.1f%% finished in %.1f minutes.\n", frag_number*100./global_context -> all_fragments, (miltime() - global_context -> start_time)/60);
		frag_number ++;

	}

	SUBREADprintf("\nThe index has been built.\n\n");

	fseeko(fp_fraglist,0, SEEK_SET);
	fseeko(fp_fragproperties,0, SEEK_SET);
	frag_number = 0;

	lnhash_resort(&first_index);

	lnhash_vote_t * votes = malloc(sizeof(lnhash_vote_t));


	while(1)
	{
		unsigned long long fprop_cpos = ftello(fp_fragproperties);
		int nrecord = fread(&frag_prop, sizeof(frag_prop), 1, fp_fragproperties);
		if(nrecord<1) break;

		if(frag_prop.length_1 >= global_context -> shortest_read_allowed && frag_prop.length_2 >= global_context -> shortest_read_allowed)
		{
			fseeko(fp_fraglist, frag_prop.list_file_pos, SEEK_SET);
			fread(in_sequence_1, frag_prop.length_1 , 1, fp_fraglist);
			fgetc(fp_fraglist);
			fread(in_quality_string_1, frag_prop.length_1 , 1, fp_fraglist);
			fgetc(fp_fraglist);
			fread(in_sequence_2, frag_prop.length_2 , 1, fp_fraglist);
			fgetc(fp_fraglist);
			fread(in_quality_string_2, frag_prop.length_2 , 1, fp_fraglist);
			fgetc(fp_fraglist);

			int is_second_read, xxi, current_len;
			char * current_seq;
			for(xxi = 0; xxi<2; xxi++)
			{
				lnhash_init_votes(votes);
				is_second_read = xxi;

				current_seq = is_second_read?in_sequence_2:in_sequence_1;
				current_len = is_second_read?frag_prop.length_2:frag_prop.length_1;
				int extract_cursor;

				for(extract_cursor=0; extract_cursor< current_len-15; extract_cursor ++)
				{
					char * subread_txt = current_seq + extract_cursor;
					unsigned int subread_int = genekey2int(subread_txt, GENE_SPACE_BASE); 

					lnhash_query(&first_index, votes, subread_int, extract_cursor);
				}

				int vote_X, vote_Y;

				for(vote_Y=0; vote_Y<LNHASH_VOTE_ARRAY_HEIGHT; vote_Y++)
					for(vote_X=0; vote_X<votes -> vote_record_items[vote_Y]; vote_X++)
					{
						unsigned long long representitiva_id = 0;
						lnhash_vote_record_t * vote_1_rec = &(votes -> vote_records[vote_Y][vote_X]);
						int is_rep_found = search_replicate_representitive(global_context, vote_1_rec, frag_number, &frag_prop , is_second_read , &representitiva_id);
						if(is_rep_found)
						{
							if(is_second_read) 	frag_prop.replicate_representitive_2 = representitiva_id + 1;
							else			frag_prop.replicate_representitive_1 = representitiva_id + 1;
						}
					}
		
			}
		}

		//if(frag_prop.replicate_representitive_2||frag_prop.replicate_representitive_1)
		//	SUBREADprintf("REP=%llu  ,  %llu\n", frag_prop.replicate_representitive_1, frag_prop.replicate_representitive_2);

		fseeko(fp_fragproperties, fprop_cpos, SEEK_SET);
		fwrite(&frag_prop, sizeof(frag_prop), 1, fp_fragproperties);
		fseeko(fp_fragproperties, fprop_cpos+sizeof(frag_prop), SEEK_SET);

		if(frag_number % report_step == 0)
		{
			SUBREADprintf("  Searching for replicates, %.1f%% finished in %.1f minutes.\n", frag_number*100./global_context -> all_fragments, (miltime() - global_context -> start_time)/60);
		}
		frag_number ++;
	}
	free(votes);

	SUBREADputs("\nReplicates are marked.\n");

	fclose(fp_fraglist);
	fclose(fp_fragproperties);
	free(in_sequence_1);
	free(in_sequence_2);
	free(in_quality_string_1);
	free(in_quality_string_2);

	lnhash_destroy(&first_index);


	return 0;

} 

#define GRA_write_current_assembly nobody 

int nobody(GRA_global_context_t* global_context){return 0;}



typedef struct
{
	unsigned long long frag_number;

	int map_1_pos;
	int map_2_pos;

	int read_1_reversed_map;
	int read_2_reversed_map;

	int read_1_votes;
	int read_2_votes;

	int read_1_coverage_start;
	int read_1_coverage_end;

	int read_2_coverage_start;
	int read_2_coverage_end;
} GRA_votes_pairs;

int GRA_reassemble_reads_LR(GRA_global_context_t* global_context, int to_right)
{
	char * seq_buf_1 = malloc(MAX_READ_LENGTH);
	char * seq_buf_2 = malloc(MAX_READ_LENGTH);
	char * target_seq_buf = malloc(MAX_READ_LENGTH);
	lnhash_vote_t * votes1 = malloc(sizeof(lnhash_vote_t));
	lnhash_vote_t * votes2 = malloc(sizeof(lnhash_vote_t));
	GRA_votes_pairs * examine_vote_pairs = malloc(sizeof(GRA_votes_pairs) * LNHASH_VOTE_ARRAY_WIDTH * LNHASH_VOTE_ARRAY_HEIGHT);
	
	while(1)
	{
		GRA_frag_properties_t * current_prop = global_context -> frag_properties_array + global_context -> current_frag_no;

		int examine_vote_pair_count = 0;
		int is_second_read, xxi, current_len;
		for(xxi = 0; xxi<2; xxi++)
		{
			is_second_read = xxi;
			char * seq_buf = is_second_read?seq_buf_2:seq_buf_1;
			lnhash_vote_t * votes = is_second_read?votes2:votes1;
			lnhash_init_votes(votes);

			get_frag_sequence(global_context, current_prop, is_second_read, seq_buf);

			current_len = is_second_read?current_prop -> length_2:current_prop -> length_1;
			int extract_cursor;

			for(extract_cursor=0; extract_cursor< current_len-15; extract_cursor ++)
			{
				char * subread_txt = seq_buf + extract_cursor;
				unsigned int subread_int = genekey2int(subread_txt, GENE_SPACE_BASE); 

				lnhash_query(&global_context -> assembling_index, votes, subread_int, extract_cursor);
			}
		}


		// examine v1 and v2.
		//
		memset(examine_vote_pairs, 0, sizeof(GRA_votes_pairs) * LNHASH_VOTE_ARRAY_WIDTH * LNHASH_VOTE_ARRAY_HEIGHT);

		int vote_X, vote_Y, test_pair;
		for(is_second_read = 0; is_second_read<2; is_second_read++)
		{
			lnhash_vote_t * votes = is_second_read?votes2:votes1;
			for(vote_Y = 0; vote_Y < LNHASH_VOTE_ARRAY_HEIGHT ; vote_Y++) 
				for(vote_X = 0; vote_X < votes->vote_record_items[vote_Y] ; vote_X++) 
				{
					lnhash_vote_record_t * voterec = &(votes -> vote_records[vote_Y][vote_X]);
					unsigned long long next_frag_no = get_frag_number_part(voterec -> head_position);
					int map_to_pos = voterec -> head_position & 0x3fff;
					if(map_to_pos >= 0x2000) map_to_pos = map_to_pos - 0x4000;
					int map_to_reversed = (voterec -> head_position & 0x4000)?1:0;
					int map_to_read2 = (voterec -> head_position & 0x8000)?1:0;
					int is_found = 0;

					//SUBREADprintf("VV[%llu]: next_frag_no=%llu; V=%d; is_second_read=%d; targ_second=%d; targ_rev=%d\n", global_context -> current_frag_no, next_frag_no , voterec -> num_votes , is_second_read , map_to_read2, map_to_reversed);

					//if((map_to_reversed ^ map_to_read2) != is_second_read)continue;
					if(global_context -> current_frag_no == next_frag_no)continue;

					for(test_pair =0; test_pair < examine_vote_pair_count; test_pair++)
					{
						if(examine_vote_pairs [test_pair].frag_number == next_frag_no && 
							examine_vote_pairs [test_pair].read_1_reversed_map != map_to_reversed)
						{
							examine_vote_pairs[test_pair].map_2_pos = map_to_pos;
							examine_vote_pairs[test_pair].read_2_votes = voterec -> num_votes;
							examine_vote_pairs[test_pair].read_2_reversed_map = map_to_reversed;
							examine_vote_pairs[test_pair].read_2_coverage_start = voterec -> coverage_start;
							examine_vote_pairs[test_pair].read_2_coverage_end = voterec -> coverage_end;
							is_found = 1;
						}
					}
					if((!is_found) && !is_second_read)
					{
						examine_vote_pairs[examine_vote_pair_count].map_1_pos = map_to_pos;
						examine_vote_pairs[examine_vote_pair_count].read_1_votes = voterec -> num_votes;
						examine_vote_pairs[examine_vote_pair_count].read_1_reversed_map = map_to_reversed;
						examine_vote_pairs[examine_vote_pair_count].frag_number = next_frag_no;
						examine_vote_pairs[examine_vote_pair_count].read_1_coverage_start = voterec -> coverage_start;
						examine_vote_pairs[examine_vote_pair_count].read_1_coverage_end = voterec -> coverage_end;
						examine_vote_pair_count++;
					}
				}
		}

		SUBREADprintf("HITs=%d\n", examine_vote_pair_count);
		int max_votes = 0;
		int next_current_frag_reversed_to_start=0;
		unsigned long long next_current_frag_no=0;

		for(test_pair =0; test_pair < examine_vote_pair_count; test_pair++)
		{
			// read 1 is mapped to the reversed strand -> read 1 mapped to target read 2

			GRA_votes_pairs * tpair = &(examine_vote_pairs[test_pair]);
			if(tpair -> read_1_votes<global_context -> min_overlap_votes || tpair -> read_2_votes<global_context -> min_overlap_votes) continue;

			int is_current_read2_extension = (global_context -> current_frag_reversed_to_start ^ to_right);
			int is_target_read2_used = is_current_read2_extension?(!tpair -> read_2_reversed_map):(tpair -> read_1_reversed_map);

			if(!is_current_read2_extension && tpair->map_1_pos <= 0) continue;

			int current_read_coverage_start = is_current_read2_extension?tpair -> read_2_coverage_start:tpair -> read_1_coverage_start;
			int current_read_coverage_end = is_current_read2_extension?tpair -> read_2_coverage_end:tpair -> read_1_coverage_end;

			int is_current_read_fully_covered = 0;
			if(is_current_read2_extension)
				is_current_read_fully_covered = current_read_coverage_end >= current_prop -> length_1 - 1 - global_context -> subread_extract_step;
			else
				is_current_read_fully_covered = current_read_coverage_start < global_context -> subread_extract_step;

			if(!is_current_read_fully_covered) continue;

			GRA_frag_properties_t * target_prop = global_context -> frag_properties_array + tpair -> frag_number;
			int target_rlen = (is_target_read2_used) ? target_prop -> length_2:target_prop -> length_1;

			if(is_current_read2_extension && target_rlen - tpair->map_2_pos - target_prop -> length_2 <= 0) continue;
			if((target_prop -> flags & GRA_FRAG_USED_NOW) || (target_prop -> flags & GRA_FRAG_USED_BEFORE) )continue;

			int is_target_read_fully_covered = 0, xk1, mm=0, target_votes=0;
			if(is_current_read2_extension)
			{
				if( tpair->read_2_votes <  global_context -> min_overlap_votes + 2) continue;

				SUBREADprintf("IS_R2_EXT, Target2_used = %d, Read2_Map_Rev = %d\n", is_target_read2_used , tpair -> read_2_reversed_map);

				int min_overlap_start_on_current = max(0, -tpair->map_2_pos);
				is_target_read_fully_covered = current_read_coverage_start < min_overlap_start_on_current + global_context -> subread_extract_step;
				if(!is_target_read_fully_covered) continue;
				get_frag_sequence(global_context , target_prop , is_target_read2_used , target_seq_buf);
				if(tpair -> read_2_reversed_map) reverse_read(target_seq_buf, target_rlen , GENE_SPACE_BASE);

				for(xk1 = min_overlap_start_on_current; xk1 < current_prop -> length_2; xk1++)
					mm += (*(seq_buf_2 + min_overlap_start_on_current + xk1) != *(target_seq_buf  + xk1+ max(0,tpair->map_2_pos)));
				target_votes = tpair -> read_2_votes;

				SUBREADprintf(" === %s {2} V=%d, MM=%d === M2POS=%d    MOSNC=%d     RLEN=%d     TLEN=%d    FRAG=%llu\n", to_right?">>>":"<<<", tpair -> read_2_votes, mm , tpair->map_2_pos, min_overlap_start_on_current, current_prop -> length_2, target_rlen,  tpair -> frag_number);
				SUBREADprintf("Q=%s\n",seq_buf_2 + 0*min_overlap_start_on_current);
				SUBREADprintf("T=%s\n",target_seq_buf + 0*max(0,tpair->map_2_pos));

				SUBREADputs("");
			}
			else
			{
				if( tpair->read_1_votes <  global_context -> min_overlap_votes + 2) continue;

				int max_overlap_end_on_current = min( target_prop -> length_1 , target_rlen - tpair->map_1_pos );
				is_target_read_fully_covered = current_read_coverage_end > max_overlap_end_on_current - global_context -> subread_extract_step;
				if(!is_target_read_fully_covered) continue;
				get_frag_sequence(global_context , target_prop , is_target_read2_used , target_seq_buf);
				if(tpair -> read_1_reversed_map) reverse_read(target_seq_buf, target_rlen , GENE_SPACE_BASE);

				for(xk1 = 0; xk1 < max_overlap_end_on_current; xk1++)
					mm += (*(seq_buf_1 + xk1) != *(target_seq_buf  + xk1 + tpair->map_1_pos));
				target_votes = tpair -> read_1_votes;

				SUBREADprintf(" === %s {1} V=%d, MM=%d === TARG_REV=%d \n", to_right?">>>":"<<<", tpair -> read_1_votes, mm, tpair -> read_1_reversed_map);
				SUBREADprintf("Q=%s\n",seq_buf_1);
				SUBREADprintf("T=%s\n",target_seq_buf + tpair->map_1_pos);
				SUBREADputs("");

			}
			if( max_votes < target_votes &&!mm)
			{
				max_votes = target_votes;
				next_current_frag_no = tpair -> frag_number;
				next_current_frag_reversed_to_start = global_context -> current_frag_reversed_to_start ^ (is_current_read2_extension?tpair -> read_2_reversed_map:tpair -> read_1_reversed_map); 
			}

		}

		if(max_votes<3)break;

		global_context -> current_frag_no = next_current_frag_no;
		global_context -> current_frag_reversed_to_start = next_current_frag_reversed_to_start;

		SUBREADprintf("  === %s === REV=%d    FRAG=%llu === \n", to_right?">>>":"<<<" , global_context -> current_frag_reversed_to_start ,  global_context -> current_frag_no );

		GRA_frag_properties_t * target_prop = global_context -> frag_properties_array + global_context -> current_frag_no;
		target_prop -> flags |= GRA_FRAG_USED_NOW; 
	}
	free(seq_buf_1);
	free(seq_buf_2);
	free(target_seq_buf);
	free(votes2);
	free(votes1);
	return 0;
}

int GRA_reassemble_reads(GRA_global_context_t* global_context)
{
	global_context -> current_frag_reversed_to_start = 0;
	global_context -> current_frag_no = global_context -> start_fragment_props - global_context -> frag_properties_array;
	int ret =  GRA_reassemble_reads_LR(global_context,0);

	global_context -> current_frag_reversed_to_start = 0;
	global_context -> current_frag_no = global_context -> start_fragment_props - global_context -> frag_properties_array;
	return ret || GRA_reassemble_reads_LR(global_context,1);
}

void GRA_destroy_context(GRA_global_context_t* global_context)
{
	lnhash_destroy(&global_context -> assembling_index);
	close(global_context -> fd_fragproperties);
	SUBREADprintf("\nRead assembly finished in %.1f minutes.\n\n", (miltime() - global_context -> start_time)/60);
}


int GRA_memory_map(GRA_global_context_t* global_context)
{
	char tmp_fname[300];

	sprintf(tmp_fname, "%s.fragproperties", global_context -> tmp_file_prefix);
	global_context -> fd_fragproperties = open(tmp_fname,O_RDWR);

	global_context -> frag_properties_array = mmap64(NULL, global_context -> all_fragments * sizeof(GRA_frag_properties_t),
		PROT_WRITE|PROT_READ,  MAP_PRIVATE, global_context -> fd_fragproperties, 0);

	assert(global_context -> frag_properties_array);

	SUBREADputs("\nThe property file is mapped to memory.\n");

	return 0;
}


int GRA_find_start_read(GRA_global_context_t* global_context)
{
	unsigned long long frag_number, best_number = 0;
	int max_length = 0;
	GRA_frag_properties_t * best_frag = NULL; 

	for(frag_number = 0; frag_number < global_context -> all_fragments ; frag_number++)
	{
		GRA_frag_properties_t * frag_prop = global_context -> frag_properties_array + frag_number;
		if(frag_prop->flags & GRA_FRAG_USED_BEFORE) continue;
		if(frag_prop->length_1 + frag_prop->length_2 > max_length && (frag_prop -> replicate_representitive_1 ==0 || frag_prop -> replicate_representitive_2 == 0))
		{
			max_length = frag_prop->length_1 + frag_prop->length_2;
			best_number = frag_number;
			best_frag = frag_prop;
		}
	}

	if(max_length > 0)
	{
		global_context -> start_fragment_props = best_frag;
		best_frag -> flags |= GRA_FRAG_USED_BEFORE;
		//SUBREADprintf("Contig seed = %llu; len=%d + %d\n", best_number, best_frag->length_1, best_frag->length_2);
	}
	else	global_context -> no_more_assembly = 1;

	return 0;
}

int main(int argc, char ** argv)
{

	int c;
	int option_index = 0;
	GRA_global_context_t * global_context = malloc(sizeof(GRA_global_context_t));

	GRA_init_context(global_context);
	optind=0;
	opterr=1;
	optopt=63;

	while ((c = getopt_long (argc, argv, "i:o:b", GRA_long_options, &option_index)) != -1)
		switch(c)
		{
			case 'i':
				strcpy(global_context -> input_file_name, optarg);
			break;

			case 'b':
				global_context -> is_BAM_input = 1;
			break;

			case 'o':
				strcpy(global_context -> output_file_name, optarg);
			break;

			case 'T':
				global_context -> total_threads = atoi(optarg);
			break;

			default:
				GRA_print_usage();
				return -1;
		}
	

	int ret = 0;

	ret = ret || GRA_check_config(global_context);
	ret = ret || GRA_trim_reads(global_context);
	ret = ret || GRA_mark_read_duplicate(global_context);
	ret = ret || GRA_build_read_index(global_context);
	ret = ret || GRA_memory_map(global_context);

	while(1){
		ret = ret || GRA_find_start_read(global_context);
		if(global_context -> no_more_assembly)
			break;

		ret = ret || GRA_reassemble_reads(global_context);
		ret = ret || GRA_write_current_assembly(global_context);
		SUBREADputs("====================================================");
		SUBREADputs("====================================================");
		SUBREADputs("====================================================");
	}

	GRA_destroy_context(global_context);
	free(global_context);

	return ret;

}
