#!/bin/bash
#
#PBS -l walltime=120:00:00
#PBS -l nodes=1:ppn=8
#PBS -o loo.out
#PBS -e loo.err
#PBS -j oe
#PBS -W umask=022
#PBS -r n
mpirun -np 8 ../pb_mpi -f -d convo9849.ali -cat -gtr -dgam 4 -dc catgtrconvo

