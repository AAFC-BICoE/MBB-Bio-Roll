# pysam versioning information

__version__ = "0.8.4pre"

__samtools_version__ = "1.2"

__htslib_version__ = "1.2.1"
