echo FILE M1044 > times.dat 
time beastII -overwrite  testHKY1044.xml >> times.dat 2>&1
echo FILE M1366 >> times.dat 
time beastII -overwrite  testHKY1366.xml >> times.dat 2>&1
echo FILE M1510 >> times.dat 
time beastII -overwrite  testHKY1510.xml >> times.dat 2>&1
echo FILE M1748 >> times.dat 
time beastII -overwrite  testHKY1748.xml >> times.dat 2>&1
echo FILE M1749 >> times.dat 
time beastII -overwrite  testHKY1749.xml >> times.dat 2>&1
echo FILE M1809 >> times.dat 
time beastII -overwrite  testHKY1809.xml >> times.dat 2>&1
echo FILE M336 >> times.dat 
time beastII -overwrite  testHKY336.xml >> times.dat 2>&1
echo FILE M3475 >> times.dat 
time beastII -overwrite  testHKY3475.xml >> times.dat 2>&1
echo FILE M501 >> times.dat 
time beastII -overwrite  testHKY501.xml >> times.dat 2>&1
echo FILE M520 >> times.dat 
time beastII -overwrite  testHKY520.xml >> times.dat 2>&1
echo FILE M755 >> times.dat 
time beastII -overwrite  testHKY755.xml >> times.dat 2>&1
echo FILE M767 >> times.dat 
time beastII -overwrite  testHKY767.xml >> times.dat 2>&1
