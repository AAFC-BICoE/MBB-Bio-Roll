/*
 * Classify.h
 *
 *  Created on: May 19, 2010
 *      Author: mscott
 */

#ifndef CLASSIFY_H_
#define CLASSIFY_H_

#define TOP_INTRA_AT 0
#define BEST_INTER_AT 1
#define OTHER_INTER_AT 2
#define SAVE_TYPE_COUNT 3

#endif /* CLASSIFY_H_ */
