/*
 * LinkParser.cpp
 *
 *  Created on: Apr 28, 2010
 *      Author: mscott
 */

#include "LinkParser.h"
#include <math.h>
#include <cstdlib>
#include <iostream>


LinkParser::LinkParser() {
}

LinkParser::~LinkParser() {
	// TODO Auto-generated destructor stub
}
