#!/usr/bin/perl -w

$sum = 0;
while(<>) {
       $sum += $_;
}

print "$sum\n";
