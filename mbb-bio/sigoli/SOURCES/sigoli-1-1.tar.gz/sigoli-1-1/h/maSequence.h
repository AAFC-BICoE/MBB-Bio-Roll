#ifndef __maSequence_h__
#define __maSequence_h__

#include <string.h>

#include "amwObject.h"
#include "amwList.h"

#include "maSubSequence.h"
#include "maGroup.h"
#include "maOligoSource.h"

#include "liSequenceBuffer.h"

class maSubSequence;
class amwBinTree;
class maGroup;

class maSequence : public maOligoSource
{
public:
	maSequence( char* sFileName, char* sFilePath, maGroup* pFromGroup = NULL );
	~maSequence();

	maSubSequence*	GetFirstSubSequence( int iSubSequenceSize );
	maSubSequence*	GetNextSubSequence();
	maSubSequence*	GetSubSequence( int iSubSequenceIndex, int iSubSequenceSize );
	char*						GetSequenceString();
	maGroup*				GetGroup();

	int							Show();

	int							AddAmbiguousSubSequence( maSubSequence* pWithSubsequence );

	maSubSequence*	GetFirstAmbiguousSubSequence();
	maSubSequence*	GetNextAmbiguousSubSequence();

	int AddString( char*	sWithString );
	int SetString( char*	sWithString );

	int							SetValid();
	int							SetInvalid();
	int							IsValid();
private:
	char NucleotideToCode( char cNucleotideSymbol );

	static const int	I_max_sequences;
	static const int	I_max_sequence_size;

	static char	S_sequence_read_buffer[];

//	specific to maSequence
	int		i_valid;

	char*	s_sequence;
	int		i_sequence_size;
	int		i_sub_sequence_size;
	int		i_crt_sub_sequence;
	maGroup*		p_group;
	amwList*		p_ambiguous_list;

};

#endif

/*

Signature Oligo
Copyright (C) 2000-2008 Manuel Zahariev
mz@alumni.sfu.ca

This file is part of SigOli.

SigOli is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/
