#ifndef __maOligoSource_h__
#define __maOligoSource_h__

#include <string.h>

#include "amwBinTree.h"

class maOligoSource : public amwObject
{
public:
	maOligoSource();
	~maOligoSource();
	
//	get / set the name of the oligo source object
	char*						GetName();
	int							SetName( char* sWithName );

	char*						GetFileName();
	int							SetFileName( char* sWithName );

//	get / set the oligo tree associated with the oligo source object
	amwBinTree*			GetOligoTree();
	int							SetOligoTree( amwBinTree* pWithTree );

private:
//	name of the oligo source
	char	s_name[ 256 ];
	char	s_file_name[ 256 ];

//	oligo tree associated with the oligo source
	amwBinTree*	p_oligo_tree;
};

#endif

/*

Signature Oligo
Copyright (C) 2000-2008 Manuel Zahariev
mz@alumni.sfu.ca

This file is part of SigOli.

SigOli is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/
