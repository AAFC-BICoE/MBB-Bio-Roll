#ifndef __maApplication_h__
#define __maApplication_h__

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include <sys/types.h>
#include <sys/stat.h>

//	this may be different from win32 to unix (linux)
extern "C"{
#include <dirent.h>
}

#include "amwConsoleApplication.h"
#include "maOligoSource.h"
#include "maSequence.h"
#include "maSubSequence.h"
#include "maGroup.h"
#include "amwBinTree.h"
#include "maOligo.h"

class maApplication : public amwConsoleApplication
{
public:
	maApplication( int iArgc, char* asArgv[], FILE* pOutput, FILE* pError );
	~maApplication();

	virtual int Run();

protected:
	typedef enum
	{
		I_operation_no_operation = 0,

		I_operation_print_oligo_strings = 1001,
		I_operation_print_oligo_positions,
		I_operation_print_oligo_ranges,
		I_operation_print_ambiguous_subsequences,

	} TypeOligoOperation;

	TypeOligoOperation i_operation;

	amwBinTree*	p_oligo_candidates;
	int					i_oligo_size;


	int					i_sequences;
	int					i_groups;

	int					i_sources;

//	1 if oligos with ambiguous nucleotides are considered or not
	int					i_ambiguous;

//	1 if the difference sought between oligos and any other subsequence must be bigger than 1
	int					i_diff;

//	0 if an oligo range is represented by just the center of the range
//	1 if an oligo range is represented multiple sites distributed in the range
	int					i_crowded;

	char*				s_sequence_directory;

//	for a range, find multiple sites, based on the diagram:
//	[*<---i_first_site_gap-->*<--i_inter_site_gap-->* ... *<--i_inter_site_gap-->*<---i_first_site_gap-->*]
	int					i_first_site_gap;
	int					i_inter_site_gap;

	int					i_max_unambiguous_count;

	int					i_stop_on_file_error;
	int					i_file_error_encountered;
private:
	int	BuildSubSequenceTree( char* sSequenceDirectory );
	int	BuildOligoTrees();

	int	PrintOligoPositions();
	int	PrintOligoStrings();
	int	PrintOligoRanges();
	int	PrintAmbiguousSubSequences();
	
//	the macro __OLIGO_MAX_SEQUENCES__ must be defined through a preprocessor
//	directive

	maSequence*			a_sequences[ __MA_OLIGO_MAX_SEQUENCES__ ];
	maGroup*				a_groups[ __MA_OLIGO_MAX_SEQUENCES__ ];

	maOligoSource*	a_sources[ __MA_OLIGO_MAX_SEQUENCES__ ];

};

#endif

/*

Signature Oligo
Copyright (C) 2000-2008 Manuel Zahariev
mz@alumni.sfu.ca

This file is part of SigOli.

SigOli is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/
