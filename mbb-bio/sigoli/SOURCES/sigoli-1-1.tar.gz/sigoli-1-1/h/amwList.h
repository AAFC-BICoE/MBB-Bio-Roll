#ifndef __amwList_h__
#define __amwList_h__

#include "amwObject.h"

class amwList : public amwObject
{
//	implementation of a double-linked list
	public:
		amwList();
		~amwList();

		int Append( amwObject* pWithObject );
		int Insert( amwObject* pWithObject );

		amwObject* Get();

//	remove the current element from the list; remember: this will not delete the object
//	that's why it is returned, as a reminder
		amwObject* Remove();

		amwObject* GetFirst();
		amwObject* GetLast();
		
		amwObject* GetNext();
		amwObject* GetPrev();

		int	IsEmpty();
		int	IsFirst();
		int	IsLast();

		int Reverse();
//	show all elements from the list first-to-last
		int Show();

//	destructively link to another list: add another list to the end of this list
//	note: the other list is destroyed in the process (!!), but not its elements
		int Link( amwList* pToList );

		int Empty();
	private:
		struct amwListElement
		{
//	an element of a double linked list
			amwObject*	p_object;
			amwListElement*	p_next;
			amwListElement*	p_prev;
		};

		amwListElement*	p_crt;
		amwListElement*	p_first;
		amwListElement*	p_last;
};

#endif

/*

Signature Oligo
Copyright (C) 2000-2008 Manuel Zahariev
mz@alumni.sfu.ca

This file is part of SigOli.

SigOli is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/
