#ifndef __maGroup_h__
#define __maGroup_h__

#include <sys/types.h>
#include <sys/stat.h>

//	this may be different from win32 to unix (linux)
extern "C"{
#include <dirent.h>
}

#include "amwObject.h"
#include "amwBinTree.h"
#include "maOligoSource.h"
#include "maSequence.h"

class maSequence;

class maGroup : public maOligoSource
{
public:
	maGroup( char* sFileName, char* sFilePath );
	~maGroup();

//	common with maSequence
/*
	char*				GetName();
	amwBinTree*	GetOligoTree();
	int					SetOligoTree( amwBinTree* pWithTree );
*/

//	specific to maGroup
	maSequence*	GetFirstSequence();
	maSequence*	GetNextSequence();
	int					GetCount();

private:
//	common with maSequence
/*
	char*				s_group_name;
	amwBinTree*	p_oligo_tree;
*/

//	specific to maGroup
	int					i_sequence_count;
	int					i_crt_sequence;
	maSequence*	a_sequences[ __MA_OLIGO_MAX_SEQUENCES__ ];
};

#endif

/*

Signature Oligo
Copyright (C) 2000-2008 Manuel Zahariev
mz@alumni.sfu.ca

This file is part of SigOli.

SigOli is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/
