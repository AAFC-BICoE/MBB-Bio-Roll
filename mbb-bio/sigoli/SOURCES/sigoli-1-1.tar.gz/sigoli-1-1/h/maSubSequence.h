#ifndef __maSubSequence_h__
#define __maSubSequence_h__

#include <string.h>

#include "amwElement.h"
#include "maSequence.h"
#include "maGroup.h"

class maSequence;
class maGroup;

class maSubSequence : public amwElement
{
public:
	maSubSequence( char* sString, maSequence* pSequence, int iIndex, int iLength );
	~maSubSequence();

//	build from another subsequence
	maSubSequence( maSubSequence& rFromSubSequence );

	virtual int operator<= ( amwElement& rOtherElement );
	virtual int operator== ( amwElement& rOtherElement );

	int operator<= ( maSubSequence& rOtherElement );
	int operator== ( maSubSequence& rOtherElement );

	virtual int	Mark( amwElement& rWithElement );

	int	Mark( maSubSequence& rWithSubSequence );

	virtual int	Show();

//	get methods
	char*				GetString();
	int					GetLength();
	maSequence*	GetOriginatorSequence();
	maGroup*		GetOriginatorGroup();
	int					GetSequenceIndex();
	int					GetGroupSequenceCount();

//	returns 0 if the subsequence uses only ACGT, 1 otherwise
	int					IsAmbiguous();

//	returns 0 if the subsequence has been disambiguated from another
//	subsequence
	int					IsDisambiguated();

//	returns the first subsequence with 1 difference
	maSubSequence*	GetFirstSmallDiff();
	maSubSequence*	GetNextSmallDiff();

//	sequentially return subsequences with only unambiguous nucleotides
//	that match the originator sequence
	maSubSequence*	GetFirstUnambiguous();
	maSubSequence*	GetNextUnambiguous();

	int							GetUnambiguousCount();
protected:
	char NucleotideConvert( char sNucleotideSymbol );
	char CodeToNucleotide( char cNucleotideCode );

//	index into the sequence that indicates the beginning of the subsequence
	int							i_sequence_index;

private:
//	pointer to the beginning of the string representing the subsequence
	char*						s_sub_sequence_string;

//	pointer to the sequence originating the subsequence
	maSequence*			p_originator_sequence;
//	pointer to the group originating the subsequence
	maGroup*				p_originator_group;

//	sequence count for the originator count -- counts how many sequences
//	the current subsequence belongs to in the current group
//	if the number equals the number of sequences in the group -- this is a
//	group oligo
	int							i_originator_group_sequence_count;

//	length of the subsequence
	int							i_length;

//	number of occurences of the subsequence in the data set
	int							i_occurences;

//	pointer the current subsequence with "small difference" from the current subsequence
//	a "small difference" represents one nucleotide being different from the originator
//	subsequence
	maSubSequence*	p_crt_diff;
//	index in the subsequence of the nucleotide that is different
	int							i_crt_diff_index;

//	pointer to the current unambiguous subsequence derived from the current subsequence
	maSubSequence*	p_crt_unambiguous;

//	number of unabiguous subsequences that can be derived from the current subsequence
	int							i_unambiguous_count;

//	indicates whether the current subsequence is obtained from the disambiguation of a
//	subsequence
	int							i_disambiguated;

	static const char A_nucleo_loop[16][16];
};

#endif

/*

Signature Oligo
Copyright (C) 2000-2008 Manuel Zahariev
mz@alumni.sfu.ca

This file is part of SigOli.

SigOli is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/
