#define __maApplication_cpp__

#include "maApplication.h"

maApplication :: maApplication( int iArgc, char* asArgv[], FILE* pOutput, FILE* pError ) :
	amwConsoleApplication( iArgc, asArgv, pOutput, pError ),
	i_sources( 0 ),
	i_groups( 0 ),
	i_sequences( 0 ),
	p_oligo_candidates( NULL )
{
}

maApplication :: ~maApplication()
{
	if( p_oligo_candidates )
		delete p_oligo_candidates;
}

int maApplication :: Run()
{

	if( i_operation == I_operation_no_operation )
	{
			PrintLn( "Signature Oligo ver. 1.1." );
			PrintLn( "--------------------------------------------------" );
			PrintLn( "usage: sigoli.exe [command-line-options]" );
			PrintLn( "command-line-options: [option-name=option-value]*" );
			PrintLn( " -operation=(operation-name); supported operations:" );
			PrintLn( "    strings   -- writes to the output all oligo strings from all sequences and all groups" );
			PrintLn( "    positions -- generates an input file for Array Designer (tab-separated list of oligo sites)" );
			PrintLn( "    ranges    -- writes a list of all ranges of oligos from each sequence and each group" );
			PrintLn( "    ambig     -- writes a list of all ambiguous subsequences that have been discarded because of more ambiguities than max-unambiguous-count" );
			PrintLn( " -sequence-directory=(relative-directory-name); the location of the directory name where the sequences and directories to be analysed are located" );
			PrintLn( " -oligo-size=(oligo-size); will set the size of oligos to be discovered; default=16" );
			PrintLn( " -ambiguous=(yes/no); (obsolete) if yes, ambiguous subsequences may be considered oligos" );
			PrintLn( " -diff=(yes/no); indicates whether small differences (1 nucleotide) are considered" );
			PrintLn( " -crowded=(yes/no); indicates whether for the ranges and positions operations, an oligo range is populated with intermediary sites" );
			PrintLn( " -stop-on-error=(yes/no); indicates whether the system will stop when encountering an invalid sequence file; default=no" );
			PrintLn( " -first-site-gap=(gap-size); for a crowded display, indicates the size of the gap between the border of the range and the first interior site" );
			PrintLn( " -inter-site-gap=(gap-size); for a crowded display, indicates the size of the gap between sites inside an oligo range" );
			PrintLn( " -max-unambiguous-count=(count); indicates the maximum number of unambiguous sequences that will be considered in a disambiguation " );
			PrintLn( "--------------------------------------------------" );
			PrintLn( "example:" );
			PrintLn( "sigoli -operation=positions -oligo-size=20 -sequence-directory=s -ambiguous=yes -diff=no -crowded=yes -first-site-gap=12 -inter-site-gap=5 -max-unambiguous-count=1000" );
			PrintLn( "--------------------------------------------------" );
			PrintLn( "SigOli is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License" );
			PrintLn( "--------------------------------------------------" );
			PrintLn( "author: Manuel Zahariev, mz@alumni.sfu.ca" );
			PrintLn( "--------------------------------------------------" );
			PrintLn( "This product contains software developed by the University of California and its contributors." );
			PrintLn( "--------------------------------------------------" );
			PrintLn( "This product contains output from GNU Bison, used in accordance with the license conditions specified in \"Conditions for using Bison\"." );

			return 0;
	}


	BuildSubSequenceTree( s_sequence_directory );
	BuildOligoTrees();


	switch( i_operation )
	{
		case I_operation_print_oligo_positions:
			PrintOligoPositions();
			return 1;

		case I_operation_print_oligo_strings:
			PrintOligoStrings();
			return 1;

		case I_operation_print_oligo_ranges:
			PrintOligoRanges();
			return 1;

		case I_operation_print_ambiguous_subsequences:
			PrintAmbiguousSubSequences();
			return 1;

		default:
			PrintLn( "Signature Oligo ver. 1.1." );
			PrintLn( "--------------------------------------------------" );
			PrintLn( "usage: sigoli.exe [command-line-options]" );
			PrintLn( "command-line-options: [option-name=option-value]*" );
			PrintLn( " -operation=(operation-name); supported operations:" );
			PrintLn( "    strings   -- writes to the output all oligo strings from all sequences and all groups" );
			PrintLn( "    positions -- generates an input file for Array Designer (tab-separated list of oligo sites)" );
			PrintLn( "    ranges    -- writes a list of all ranges of oligos from each sequence and each group" );
			PrintLn( "    ambig     -- writes a list of all ambiguous subsequences that have been discarded because of more ambiguities than max-unambiguous-count" );
			PrintLn( " -sequence-directory=(relative-directory-name); the location of the directory name where the sequences and directories to be analysed are located" );
			PrintLn( " -oligo-size=(oligo-size); will set the size of oligos to be discovered; default=16" );
			PrintLn( " -ambiguous=(yes/no); (obsolete) if yes, ambiguous subsequences may be considered oligos" );
			PrintLn( " -diff=(yes/no); indicates whether small differences (1 nucleotide) are considered" );
			PrintLn( " -crowded=(yes/no); indicates whether for the ranges and positions operations, an oligo range is populated with intermediary sites" );
			PrintLn( " -stop-on-error=(yes/no); indicates whether the system will stop when encountering an invalid sequence file; default=no" );
			PrintLn( " -first-site-gap=(gap-size); for a crowded display, indicates the size of the gap between the border of the range and the first interior site" );
			PrintLn( " -inter-site-gap=(gap-size); for a crowded display, indicates the size of the gap between sites inside an oligo range" );
			PrintLn( " -max-unambiguous-count=(count); indicates the maximum number of unambiguous sequences that will be considered in a disambiguation " );
			PrintLn( "--------------------------------------------------" );
			PrintLn( "example:" );
			PrintLn( "sigoli -operation=positions -oligo-size=20 -sequence-directory=s -ambiguous=yes -diff=no -crowded=yes -first-site-gap=12 -inter-site-gap=5 -max-unambiguous-count=1000" );
			PrintLn( "--------------------------------------------------" );
			PrintLn( "SigOli is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License" );
			PrintLn( "--------------------------------------------------" );
			PrintLn( "author: Manuel Zahariev, mz@alumni.sfu.ca" );
			PrintLn( "--------------------------------------------------" );
			PrintLn( "This product contains software developed by the University of California and its contributors." );
			PrintLn( "--------------------------------------------------" );
			PrintLn( "This product contains output from GNU Bison, used in accordance with the license conditions specified in \"Conditions for using Bison\"." );

			return 0;
	}
}

int maApplication :: BuildSubSequenceTree( char* sSequenceDirectory )
{
	int							i = 0;

	DIR*						d = NULL;
	struct dirent*	e = NULL;

	maSequence*			seq = NULL;
	maSubSequence*	ss = NULL;

	char						fn[ 256 ];

	struct stat			sb;

	int	ic = 0;
	int	icu = 0;
	int	iu = 0;
	maSubSequence*	ssu = NULL;

	d = opendir( sSequenceDirectory );
	if( !d )
		Error( 10001, "error: cannot open directory", sSequenceDirectory );

	while( 1 )
	{
		e = readdir( d );

		if( !e ) break;

		if( strcmp( e->d_name, "." ) == 0 )
//	ignore the current directory
			continue;

		if( strcmp( e->d_name, ".." ) == 0 )
//	ignore the parent directory
			continue;

		sprintf( fn, "%s/%s", sSequenceDirectory, e->d_name );

		if( stat( fn, &sb ) == -1 )
			Error( 10003, "cannot obtain status information", fn );

		if( sb.st_mode & S_IFDIR )
		{
//	will get here if the current directory entry is a directory
//	directories are interpreted as groups			
			a_groups[ i_groups ] = new maGroup( e->d_name, sSequenceDirectory );
			a_sources[ i_sources ] = a_groups[ i_groups ];

			i_groups++;
			i_sources++;

			continue;
		}

//	will get here if the current directory entry is a regular file
//	regular files are interpreted as sequences
		a_sequences[ i_sequences ] = new maSequence( e->d_name, fn, NULL );
		a_sources[ i_sources ] = a_sequences[ i_sequences ];

		if( !a_sequences[ i_sequences ]->IsValid())
		{
			Print( "** warning: invalid sequence file: " );
			PrintLn( e->d_name );

			i_file_error_encountered++;

			continue;
		}

		i_sequences++;
		i_sources++;
	}

	closedir( d );

	if( i_stop_on_file_error && i_file_error_encountered )
		Error( 10002, "cannot process input files", "file errors encountered" );

//	count the ambiguities for the current operations
//	this is dead code (calculated + never used)
//	print the number of ambiguities after the loop for debugging
	for( i = 0 ; i < i_sequences ; i++ )
		for( ss = a_sequences[ i ]->GetFirstSubSequence( i_oligo_size ) ; ss ; ss = a_sequences[ i ]->GetNextSubSequence())
		{
			ic++;

			iu = ss->GetUnambiguousCount();
			icu += iu;
		};

//	add to the oligo candidates all the subsequences of all sequences of all groups
	for( i = 0 ; i < i_groups ; i++ )
		for( seq = 	a_groups[ i ]->GetFirstSequence() ; seq ; seq = a_groups[ i ]->GetNextSequence())
			for( ss = seq->GetFirstSubSequence( i_oligo_size ) ; ss ; ss = seq->GetNextSubSequence())
				if( ss->IsAmbiguous())
//	consider a i_max_unambiguous_count == 0 as a hint not to use a maximum disambiguation count
					if( !i_max_unambiguous_count || ( ss->GetUnambiguousCount() < i_max_unambiguous_count ))
						for( ssu = ss->GetFirstUnambiguous() ; ssu ; ssu = ss->GetNextUnambiguous())
							if( !p_oligo_candidates )
								p_oligo_candidates = new amwBinTree( *ssu );
							else
								p_oligo_candidates->InsertOrMark( *ssu );
					else
						seq->AddAmbiguousSubSequence( ss );
				else
					if( !p_oligo_candidates )
						p_oligo_candidates = new amwBinTree( *ss );
					else
						p_oligo_candidates = p_oligo_candidates->InsertOrMark( *ss );

//	add to the oligo candidates all the subsequences of all sequences without a group
	for( i = 0 ; i < i_sequences ; i++ )
		for( ss = a_sequences[ i ]->GetFirstSubSequence( i_oligo_size ) ; ss ; ss = a_sequences[ i ]->GetNextSubSequence())
			if( ss->IsAmbiguous())
//	consider a i_max_unambiguous_count == 0 as a hint not to use a maximum disambiguation count
				if( !i_max_unambiguous_count || ( ss->GetUnambiguousCount() < i_max_unambiguous_count ))
					for( ssu = ss->GetFirstUnambiguous() ; ssu ; ssu = ss->GetNextUnambiguous())
						if( !p_oligo_candidates )
							p_oligo_candidates = new amwBinTree( *ssu );
						else
							p_oligo_candidates->InsertOrMark( *ssu );
				else
					a_sequences[ i ]->AddAmbiguousSubSequence( ss );
			else
				if( !p_oligo_candidates )
					p_oligo_candidates = new amwBinTree( *ss );
				else
					p_oligo_candidates = p_oligo_candidates->InsertOrMark( *ss );

	return 1;
}

int maApplication :: BuildOligoTrees()
{
	amwBinTree*			pcrttree = NULL;
	amwBinTree*			poligotree = NULL;
	maSequence*			pseq = NULL;
	maGroup*				pgr = NULL;

	maSubSequence*	psd = NULL;
	maSubSequence*	pcrtss = NULL;
	maSubSequence*	pfound = NULL;

	int							ismalldifffound = 0;

	for( pcrttree = p_oligo_candidates->Iterate( NULL ) ; pcrttree ; pcrttree = p_oligo_candidates->Iterate( pcrttree ))
	{
		pcrtss = &( maSubSequence& )( pcrttree->GetTopElement());

		pseq = pcrtss->GetOriginatorSequence();
		pgr = pcrtss->GetOriginatorGroup();

		if( pcrtss->IsDisambiguated())
//	do not consider subsequences that have been disambiguated -- cannot be oligos
			continue;

		if( !pseq && !pgr )
//	the current subsequence has no originator group and no originator sequence => is not an oligo
			continue;

	if( pgr && ( pcrtss->GetGroupSequenceCount() != pgr->GetCount()))
//	the current subsequence could be a group oligo, but it doesn't occur in all the
//	sequences in the group
		continue;

//		if( !i_ambiguous && pcrtss->IsAmbiguous())
//	(obsolete) do not consider oligos that have ambiguous nucleotides
//			continue;

		if( i_diff )
		{
//	compare all subsequences with a difference of 1 from the oligo
//	by trying to find them in the oligo candidates tree
			ismalldifffound = 0;

			for( psd = pcrtss->GetFirstSmallDiff() ; psd ; psd = pcrtss->GetNextSmallDiff())
			{
				pfound = ( maSubSequence* )( p_oligo_candidates->Find( *psd ));

				if( pfound && !( *pcrtss == *pfound ))
				{
					ismalldifffound = 1;
					break;
				}
			}

			if( psd )
				delete psd;

			psd = NULL;

			if( ismalldifffound )
//	if a subsequence with a small difference from the oligo has been found, ignore the oligo
				continue;
		}

//	here determine if we're dealing with an originator sequence or group
		if( !pgr )
		{
//	will get here if the oligo source for the current subsequence is a sequence
			if( !pseq->GetOligoTree())
				pseq->SetOligoTree( new amwBinTree(*( new maOligo( *pcrtss ))));
			else
				pseq->SetOligoTree( pseq->GetOligoTree()->Insert(*( new maOligo( *pcrtss ))));

			continue;
		}

//	will get here if the oligo source for the current subsequence is a group
		if( !pgr->GetOligoTree())
			pgr->SetOligoTree( new amwBinTree(*( new maOligo( *pcrtss ))));
		else
			pgr->SetOligoTree( pgr->GetOligoTree()->Insert(*( new maOligo( *pcrtss ))));
	}

	return 1;
}

int maApplication :: PrintOligoPositions()
{
	int							i = 0;
	int							j = 0;
	int							k = 0;

	amwBinTree* pcrttree = NULL;
	amwBinTree* poligotree = NULL;

	maOligo*	psubseq = NULL;
	maSequence*	pseq = NULL;

	char*	ssubseqstring = NULL;
	int	ilen = 0;
	int iindex = 0;
	int ioldindex = 0;

	int ilow = 0;
	int ihigh = 0;

	int idelta = 0;
	int ilambda = 0;
	int ipsi = 0;
	
	char	sdisplay[ 1024 ];

	Print( "Filename\tAccession\tSites" );

	for( i = 0 ; i < i_sources ; i++ )
	{
		Print( "\n" );
		Print( s_sequence_directory );
		Print( "/" );
		Print( a_sources[ i ]->GetFileName());
		Print( "\t" );

		Print( a_sources[ i ]->GetName());

		poligotree = a_sources[ i ]->GetOligoTree();

		if( !poligotree ) continue;

		ioldindex = -1;
		ilow = -1;
		ihigh = -1;

		do
		{
			pcrttree = poligotree->Iterate( pcrttree );
			if( !pcrttree )	break;

			psubseq = &(( maOligo& )( pcrttree->GetTopElement()));

			ssubseqstring = psubseq->GetString();
			iindex = psubseq->GetSequenceIndex();
			ilen = psubseq->GetLength();

			if( ioldindex + 1 < iindex )
			{
//	a disruption happened here
//	consider that the right end of the range is the last nucleotide (the end)
//	of the rightmost oligonucleotide in the range (definition 1)
				ihigh = ioldindex;

				if(( ilow <= ihigh ) && ihigh != -1 )
				{
//	a true distruption, rather than a low border condition
					if( ilow == -1 ) ilow = 0;

//	i_oligo_size comes from definition 1
//	+ 2 comes from turning C arrays [0..n-1] into arrays [1..n]
					if( i_crowded )
					{
						ilow += 1;
						ihigh += i_oligo_size + 1;

						idelta = ihigh - ilow - 2 * i_first_site_gap;

						if( idelta > 0 )
						{
							ilambda = idelta / 2 / i_inter_site_gap;
							ipsi = idelta - 2 * ilambda * i_inter_site_gap;
							ilambda -= ipsi ? 0 : 1;

							for( j = 0 ; j <= ilambda ; j++ )
							{
								sprintf( sdisplay, "\t%d", ilow + i_first_site_gap + j * i_inter_site_gap );
								Print( sdisplay );
							}

							if( !ipsi || ( ipsi > i_inter_site_gap ))
							{
								sprintf( sdisplay, "\t%d", ( int )( ilow + ihigh )/2 );
								Print( sdisplay );
							}

							for( j = ilambda ; j >= 0 ; j-- )
							{
								sprintf( sdisplay, "\t%d", ihigh - i_first_site_gap - j * i_inter_site_gap );
								Print( sdisplay );
							}
						}
						else
						{
							sprintf( sdisplay, "\t%d", ( int )( ilow + ihigh ) / 2 );
							Print( sdisplay );
						}
					}
					else
					{
						sprintf( sdisplay, "\t%d", ( int )( ilow + ihigh + i_oligo_size + 2 ) / 2 );
						Print( sdisplay );
					}
				}

				ilow = iindex;
			}

			ioldindex = iindex;
			
		}while( pcrttree );

		ihigh = ioldindex;

		if( ilow != ihigh )
		{
			if( ilow == -1 ) ilow = 0;

			sprintf( sdisplay, "\t%d", ( int )( ilow + ihigh + i_oligo_size ) / 2 );
			Print( sdisplay );
		}
	}

	PrintLn( "" );
	return 0;
}

int	maApplication :: PrintOligoStrings()
{
	int							i = 0;

	amwBinTree* pcrttree = NULL;
	amwBinTree* poligotree = NULL;

	maOligo*	psubseq = NULL;
	maSequence*	pseq = NULL;

	char*	ssubseqstring = NULL;
	int	ilen = 0;
	int iindex = 0;
	int ioldindex = 0;

	int ilow = 0;
	int ihigh = 0;

	char	sdisplay[ 1024 ];

	for( i = 0 ; i < i_sources ; i++ )
	{
		PrintLn( "------------------------" );
		PrintLn( a_sources[ i ]->GetName());
		PrintLn( "------------------------" );

		poligotree = a_sources[ i ]->GetOligoTree();

		if( !poligotree ) continue;

		do
		{
			pcrttree = poligotree->Iterate( pcrttree );
			if( !pcrttree )	break;

			psubseq = &(( maOligo& )( pcrttree->GetTopElement()));

			ssubseqstring = psubseq->GetString();
			iindex = psubseq->GetSequenceIndex();
			ilen = psubseq->GetLength();

//	iindex + 1 comes from turning C arrays [0..n-1] into arrays [1..n]
			psubseq->Show();

		}while( pcrttree );
	}

	return 0;
}

int maApplication :: PrintOligoRanges()
{
	int							i = 0;
	int							j = 0;
	int							k = 0;
	
	amwBinTree* pcrttree = NULL;
	amwBinTree* poligotree = NULL;

	maOligo*	psubseq = NULL;
	maSequence*	pseq = NULL;

	char*	ssubseqstring = NULL;
	int	ilen = 0;
	int iindex = 0;
	int ioldindex = 0;

	int ilow = 0;
	int ihigh = 0;

	int idelta = 0;
	int ilambda = 0;
	int ipsi = 0;
	
	char	sdisplay[ 1024 ];

	for( i = 0 ; i < i_sources ; i++ )
	{
		PrintLn( "------------------------" );
		PrintLn( a_sources[ i ]->GetName());
		PrintLn( "------------------------" );

		poligotree = a_sources[ i ]->GetOligoTree();

		if( !poligotree ) continue;

		ioldindex = -1;

		ilow = -1;
		ihigh = -1;

		do
		{
			pcrttree = poligotree->Iterate( pcrttree );
			if( !pcrttree )	break;

			psubseq = &(( maOligo& )( pcrttree->GetTopElement()));

			ssubseqstring = psubseq->GetString();
			iindex = psubseq->GetSequenceIndex();
			ilen = psubseq->GetLength();

			if( ioldindex + 1 < iindex )
			{
//	a disruption happened here
				ihigh = ioldindex;

				if(( ilow <= ihigh ) && ihigh != -1 )
				{
//	a true distruption, rather than a low border condition
					if( ilow == -1 ) ilow = 0;

//	i_oligo_size comes from definition 1
//	"+ 1" and "+ 2" come from turning C arrays [0..n-1] into arrays [1..n]
					sprintf( sdisplay, "[%4d - %4d] : %4d", ilow + 1, ihigh + i_oligo_size + 1, ( int )( ilow + ihigh + i_oligo_size + 2 ) / 2 );
					Print( sdisplay );

					if( i_crowded )
					{
						ilow += 1;
						ihigh += i_oligo_size + 1;

						idelta = ihigh - ilow - 2 * i_first_site_gap;

						if( idelta > 0 )
						{
							ilambda = idelta / 2 / i_inter_site_gap;
							ipsi = idelta - 2 * ilambda * i_inter_site_gap;
							ilambda -= ipsi ? 0 : 1;

							Print( "  { " );

							for( j = 0 ; j <= ilambda ; j++ )
							{
								sprintf( sdisplay, "< %d ", ilow + i_first_site_gap + j * i_inter_site_gap );
								Print( sdisplay );
							}

							if( !ipsi || ( ipsi > i_inter_site_gap ))
							{
								sprintf( sdisplay, "< %d >", ( int )( ilow + ihigh )/2 );
								Print( sdisplay );
							}

							for( j = ilambda ; j >= 0 ; j-- )
							{
								sprintf( sdisplay, " %d >", ihigh - i_first_site_gap - j * i_inter_site_gap );
								Print( sdisplay );
							}

							Print( " }" );
						}
					}

					PrintLn( "" );

				}

				ilow = iindex;
			}

			ioldindex = iindex;

		}while( pcrttree );

		ihigh = ioldindex;

		if( ilow != ihigh )
		{
			if( ilow == -1 ) ilow = 0;

//	i_oligo_size comes from definition 1
//	"+ 1" and "+ 2" come from turning C arrays [0..n-1] into arrays [1..n]
			sprintf( sdisplay, "[%4d - %4d] : %4d", ilow + 1, ihigh + i_oligo_size + 1, ( int )( ilow + ihigh + i_oligo_size + 1 ) / 2 );
			PrintLn( sdisplay );
		}
	}

	return 0;
}

int maApplication :: PrintAmbiguousSubSequences()
{
	int i = 0;
	maSubSequence*	pss = NULL;
	maSequence*			pseq = NULL;

	for( i = 0 ; i < i_sequences ; i++ )
	{
//	print all ambiguous subsequences from the current sequence

		PrintLn( "------------------------" );
		PrintLn( a_sequences[ i ]->GetName());
		PrintLn( "------------------------" );

		for
			(
				pss = a_sequences[ i ]->GetFirstAmbiguousSubSequence() ;
				pss ;
				pss = a_sequences[ i ]->GetNextAmbiguousSubSequence()
			)
			pss->Show();
	}

	for( i = 0 ; i < i_groups ; i++ )
		for( pseq = 	a_groups[ i ]->GetFirstSequence() ; pseq ; pseq = a_groups[ i ]->GetNextSequence())
		{
//	print all ambiguous subsequences from the current sequence

			PrintLn( "------------------------" );
			PrintLn( pseq->GetName());
			PrintLn( "------------------------" );

			for
				(
					pss = pseq->GetFirstAmbiguousSubSequence() ;
					pss ;
					pss = pseq->GetNextAmbiguousSubSequence()
				)
				pss->Show();
		}


	return 0;
}

/*

Signature Oligo
Copyright (C) 2000-2008 Manuel Zahariev
mz@alumni.sfu.ca

This file is part of SigOli.

SigOli is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/
