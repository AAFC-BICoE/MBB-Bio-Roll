#define __maCmdLineApplication_cpp__

#include "maCmdLineApplication.h"

maCmdLineApplication :: maCmdLineApplication( int iArgc, char* asArgv[] ) :
	maApplication( iArgc, asArgv, stdout, stdout )
{
	int	i = 0;

	i_sequences = 0;
	i_oligo_size = 16;
	i_operation = I_operation_no_operation;
	s_sequence_directory = NULL;
	i_ambiguous = 0;
	i_diff = 0;
	i_crowded = 0;
	i_first_site_gap = 0;
	i_inter_site_gap = 0;
	i_max_unambiguous_count = 0;
	i_stop_on_file_error = 0;

	i_file_error_encountered = 0;
	
	for( i = 1 ; i < iArgc ; i++ )
	{
		if( strncmp( asArgv[ i ], "-operation=", strlen( "-operation=" )) == 0 )
		{
//	the operation is determined here
			if( strcmp( asArgv[ i ] + 11, "strings" ) == 0 )
				i_operation = I_operation_print_oligo_strings;

			else if( strcmp( asArgv[ i ] + 11, "ranges" ) == 0 )
				i_operation = I_operation_print_oligo_ranges;

			else if( strcmp( asArgv[ i ] + 11, "positions" ) == 0 )
				i_operation = I_operation_print_oligo_positions;

			else if( strcmp( asArgv[ i ] + 11, "ambig" ) == 0 )
				i_operation = I_operation_print_ambiguous_subsequences;
			else
				i_operation = I_operation_no_operation;

			continue;
		}

		if( strncmp( asArgv[ i ], "-oligo-size=", strlen( "-oligo-size=" )) == 0 )
		{
//	the size of the oligo is determined here
			i_oligo_size = atoi( asArgv[ i ] + 12 );
			continue;
		}

		if( strncmp( asArgv[ i ], "-sequence-directory=", strlen( "-sequence-directory=" )) == 0 )
		{
//	the sequence directory
			s_sequence_directory = new char[ strlen( asArgv[ i ] ) - 20 + 1 ];
			strcpy( s_sequence_directory, asArgv[ i ] + 20 );

			continue;
		}

		if( strncmp( asArgv[ i ], "-ambiguous=", strlen( "-ambiguous=" )) == 0 )
		{
//	whether ambiguous subsequences may be considered oligos
			i_ambiguous = ( strlen( asArgv[ i ] ) > 11 ) && ( asArgv[ i ][ 11 ] == 'y' ) || ( asArgv[ i ][ 11 ] == 'Y' );

			continue;
		}

		if( strncmp( asArgv[ i ], "-diff=", strlen( "-diff=" )) == 0 )
		{
//	whether small differences are considered
			i_diff = ( strlen( asArgv[ i ] ) > 6 ) && (( asArgv[ i ][ 6 ] == 'y' ) || ( asArgv[ i ][ 6 ] == 'Y' ));

			continue;
		}

		if( strncmp( asArgv[ i ], "-crowded=", strlen( "-crowded=" )) == 0 )
		{
//	whether the display is crowded
			i_crowded = ( strlen( asArgv[ i ] ) > 9 ) && (( asArgv[ i ][ 9 ] == 'y' ) || ( asArgv[ i ][ 9 ] == 'Y' ));

			continue;
		}

		if( strncmp( asArgv[ i ], "-first-site-gap=", strlen( "-first-site-gap=" )) == 0 )
		{
//	size of the first gap in displaying an oligo range
			i_first_site_gap = atoi( asArgv[ i ] + 16 );

			continue;
		}
					
		if( strncmp( asArgv[ i ], "-inter-site-gap=", strlen( "-inter-site-gap=" )) == 0 )
		{
//	inter-gap size in displaying an oligo range
			i_inter_site_gap = atoi( asArgv[ i ] + 16 );

			continue;
		}

		if( strncmp( asArgv[ i ], "-max-unambiguous-count=", strlen( "-max-unambiguous-count=" )) == 0 )
		{
//	maximum number of unambiguous subsequences in the disambiguation of a polymorphic subsequence
			i_max_unambiguous_count = atoi( asArgv[ i ] + 23 );

			continue;
		}

		if( strncmp( asArgv[ i ], "-stop-on-error=", strlen( "-stop-on-error=" )) == 0 )
		{
//	whether the system will stop when encountering an error
			i_stop_on_file_error =
				( strlen( asArgv[ i ] ) > strlen( "-stop-on-error=" ))
				&& (( asArgv[ i ][ strlen( "-stop-on-error=" )] == 'y' )
						|| ( asArgv[ i ][ strlen( "-stop-on-error=" )] == 'Y' ));

			continue;
		}

	}
}

maCmdLineApplication :: ~maCmdLineApplication()
{
}

int maCmdLineApplication :: PrintLn( char* sString )
{
	Print( sString );
	Print( "\n" );

	return 1;
}

/*

Signature Oligo
Copyright (C) 2000-2008 Manuel Zahariev
mz@alumni.sfu.ca

This file is part of SigOli.

SigOli is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/
