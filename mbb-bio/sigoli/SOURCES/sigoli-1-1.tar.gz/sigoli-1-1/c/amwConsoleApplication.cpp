#define __amwConsoleApplication_cpp__

#include "stdlib.h"

#include "amwConsoleApplication.h"

amwConsoleApplication :: amwConsoleApplication( int iArgc, char* asArgv[], FILE* pOutput, FILE* pError ) :
	i_argc( iArgc ),
	as_argv( asArgv ),
	f_output( pOutput ),
	f_error( pError )
{
}

amwConsoleApplication :: ~amwConsoleApplication()
{
}


int amwConsoleApplication :: Print( char* sString )
{
	if( f_output )
		fprintf( f_output, "%s", sString );

	return 1;
}

int amwConsoleApplication :: PrintLn( char* sString )
{
	Print( sString );

	if( f_output )
		fprintf( f_output, "\n" );

	return 1;
}

int amwConsoleApplication :: Error( int iErrorCode, char* sCaption, char* sMessage )
{
	if( f_error )
		fprintf( f_error, "\n**error: %d\n%s: %s\n", iErrorCode, sCaption, sMessage );

	exit( 0 );

	return 1;
}

/*

Signature Oligo
Copyright (C) 2000-2008 Manuel Zahariev
mz@alumni.sfu.ca

This file is part of SigOli.

SigOli is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/
