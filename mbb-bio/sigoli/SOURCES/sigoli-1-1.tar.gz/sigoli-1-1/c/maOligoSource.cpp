#define __maOligoSource_cpp__

#include "maOligoSource.h"

maOligoSource :: maOligoSource() :
	p_oligo_tree( NULL )
{
	strcpy( s_name, "" );
	strcpy( s_file_name, "" );
}

maOligoSource :: ~maOligoSource()
{
//	if( s_name )
//	the oligo source had a name, delete it
//		delete [] s_name;

//	if( s_file_name )
//	the oligo source had a name, delete it
//		delete [] s_file_name;

	if( p_oligo_tree )
//	the oligo source had an oligo tree; delete it
		delete p_oligo_tree;
}

char* maOligoSource :: GetName()
{
	return s_name;
}

char* maOligoSource :: GetFileName()
{
	return s_file_name;
}

amwBinTree* maOligoSource :: GetOligoTree()
{
	return p_oligo_tree;
}

int maOligoSource :: SetOligoTree( amwBinTree* pWithTree )
{
	p_oligo_tree = pWithTree;
	return 1;
}

int maOligoSource :: SetName( char* sWithName )
{
//	if( s_name )
//	the oligo source already had a name; rename it
//		delete [] s_name;

//	s_name = new char[ strlen( sWithName ) + 1 ];

	strcpy( s_name, sWithName );

	return 1;
}

int maOligoSource :: SetFileName( char* sWithName )
{
//	if( s_file_name )
//	the oligo source already had a file name; rename it
//		delete [] s_name;

//	s_file_name = new char[ strlen( sWithName ) + 1 ];

	strcpy( s_file_name, sWithName );

	return 1;
}

/*

Signature Oligo
Copyright (C) 2000-2008 Manuel Zahariev
mz@alumni.sfu.ca

This file is part of SigOli.

SigOli is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/
