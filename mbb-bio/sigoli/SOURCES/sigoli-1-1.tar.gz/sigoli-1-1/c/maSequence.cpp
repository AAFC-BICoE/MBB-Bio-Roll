#define __maSequence_cpp__

#include "maSequence.h"

extern "C"{
extern int maSequenceparse();
extern FILE*	maSequencein;
extern FILE*	maSequenceout;
}

const int	maSequence :: I_max_sequences = __MA_OLIGO_MAX_SEQUENCES__;
const int	maSequence :: I_max_sequence_size = 3000;

char maSequence :: S_sequence_read_buffer[ __MA_OLIGO_MAX_SEQUENCES__ ];

maSequence :: maSequence( char* sFileName, char* sFilePath, maGroup* pFromGroup ) :
//	s_sequence_name( NULL ),
	s_sequence( NULL ),
	i_sequence_size( 0 ),
	i_sub_sequence_size( 0 ),
	i_crt_sub_sequence( 0 ),
//	p_oligo_tree( NULL ),
	p_group( pFromGroup ),

	p_ambiguous_list( NULL ),

	i_valid( 0 )
{
	FILE*	fs = NULL;
	char	sbuffer[ I_max_sequence_size ];
	int		i = 0;

	p_ambiguous_list = new amwList;

//	s_sequence = new char [ I_max_sequence_size + 1 ];
//	s_sequence[ 0 ] = 0;

	fs = fopen( sFilePath, "rt" );
	if( !fs )
		Error( 10001, "open file", sFileName );
	fclose( fs );

	SetFileName( sFileName );
	SetName( sFileName );

	maSequencein = fopen( sFilePath, "rt" );

	if( !maSequencein )
		Error( 10012, "open file", sFilePath );

	maSequenceout = stdout;

	liSequenceSetSequence( this );
	maSequenceparse();
	liSequenceSetSequence( NULL );

	fclose( maSequencein );

	s_sequence = new char[ i_sequence_size + 1 ];
	strncpy( s_sequence, S_sequence_read_buffer, i_sequence_size );
	s_sequence[ i_sequence_size ] = 0;

//	printf( "%s\n", GetName());

/*
	while( fscanf( fs, "%s\n", sbuffer ) != EOF )
	{
		if( sbuffer[ 0 ] == '>' )
		{
//	here if the name will be read from a name line in a file in the fasta format
			SetName( sbuffer + 1 );
			continue;
		}

		strcat( s_sequence, sbuffer );
	}

	i_sequence_size = strlen( s_sequence );

	for( i = 0 ; i < i_sequence_size ; i++ )
		s_sequence[ i ] = NucleotideToCode( s_sequence[ i ]);

//	i_sequence_size = fread( s_sequence, 1, I_max_sequence_size, fs );
//	s_sequence[ i_sequence_size ] = 0;

	fclose( fs );
*/
}

maSequence :: ~maSequence()
{
	maSubSequence*	ps = NULL;

//	remove (& delete) all elements from the list of ambiguous elements
	while( !p_ambiguous_list->IsEmpty())
	{
		p_ambiguous_list->GetFirst();
		ps = ( maSubSequence* )( p_ambiguous_list->Remove());
		delete ps;
	}

//	delete the list of ambiguous elements
	delete p_ambiguous_list;

	delete [] s_sequence;
//	delete [] s_sequence_name;
}

maSubSequence* maSequence :: GetFirstSubSequence( int iSubSequenceSize )
{
	i_sub_sequence_size = iSubSequenceSize;
	i_crt_sub_sequence = 0;

	if( i_sub_sequence_size > i_sequence_size )
		return NULL;

	return new maSubSequence( s_sequence, this, i_crt_sub_sequence, i_sub_sequence_size );
}

maSubSequence* maSequence :: GetNextSubSequence()
{
	if( ++i_crt_sub_sequence > i_sequence_size - i_sub_sequence_size )
		return NULL;

	return new maSubSequence( s_sequence + i_crt_sub_sequence, this, i_crt_sub_sequence, i_sub_sequence_size );
}

maSubSequence* maSequence :: GetSubSequence( int iSubSequenceIndex, int iSubSequenceSize )
{
	if( iSubSequenceIndex > i_sequence_size - i_sub_sequence_size )
		return NULL;

	return new maSubSequence( s_sequence + iSubSequenceIndex, this, iSubSequenceIndex, iSubSequenceSize );
}

char*	maSequence :: GetSequenceString()
{
	return s_sequence;
}

maGroup* maSequence :: GetGroup()
{
	return p_group;
}

char maSequence :: NucleotideToCode( char cNucleotideSymbol )
{
	switch( cNucleotideSymbol )
	{
//	A A Adenine
		case 'A':
		case 'a':
			return 1;

//	C C Cytosine 
		case 'C':
		case 'c':
			return 2;

//	G G Guanine 
		case 'G':
		case 'g':
			return 4;

//	T T Thymine 
		case 'T':
		case 't':
			return 8;

//	R A or G puRine 
		case 'R':
		case 'r':
			return 5;

//	Y C or T pYrimidine 
		case 'Y':
		case 'y':
			return 10;

//	W A or T Weak hydrogen bonding 
		case 'W':
		case 'w':
			return 9;

//	S G or C Strong hydrogen bonding 
		case 'S':
		case 's':
			return 6;

//	M A or C aMino group at common position 
		case 'M':
		case 'm':
			return 3;

//	K G or T Keto group at common position 
		case 'K':
		case 'k':
			return 12;

//	H A, C or T not G 
		case 'H':
		case 'h':
			return 11;

//	B G, C or T not A 
		case 'B':
		case 'b':
			return 14;

//	V G, A, C not T 
		case 'V':
		case 'v':
			return 7;

//	D G, A or T not C 
		case 'D':
		case 'd':
			return 13;

//	N G, A, C or T aNy
		case 'N':
		case 'n':
			return 15;
	}

	Error( 10002, "maSequence :: NucleotideToCode", "cannot find nucleotide code" );

	return cNucleotideSymbol;
}

int maSequence :: Show()
{
	char	sdisplay[ 256 ];
	int		i = 0;

	for( i = 0 ; i < i_sequence_size ; i++ )
	{
		sprintf( sdisplay, "%X", *( s_sequence + i ));
		Print( sdisplay );
	}

	PrintLn( "" );

	return i_sequence_size;
}

int maSequence :: AddAmbiguousSubSequence( maSubSequence* pWithSubsequence )
{
	return p_ambiguous_list->Append( pWithSubsequence );
}

maSubSequence* maSequence :: GetFirstAmbiguousSubSequence()
{
	return ( maSubSequence* )( p_ambiguous_list->GetFirst());
}

maSubSequence* maSequence :: GetNextAmbiguousSubSequence()
{
	return ( maSubSequence* )( p_ambiguous_list->GetNext());
}

int maSequence :: AddString( char*	sWithString )
{
	int	i = 0;
	int ilen = strlen( sWithString );

	for( i = 0 ; i < ilen ; i++ )
		sWithString[ i ] = NucleotideToCode( sWithString[ i ]);

//	memcpy( s_sequence + i_sequence_size, sWithString, ilen + 1 );
	memcpy( S_sequence_read_buffer + i_sequence_size, sWithString, ilen + 1 );
	i_sequence_size += ilen;

	return 1;
}

int maSequence :: SetString( char*	sWithString )
{
	int	i = 0;
	int ilen = strlen( sWithString );

	for( i = 0 ; i < ilen ; i++ )
		sWithString[ i ] = NucleotideToCode( sWithString[ i ]);

//	strcpy( s_sequence, sWithString );
	strcpy( S_sequence_read_buffer, sWithString );
	i_sequence_size = ilen;

	return 1;
}

int maSequence :: SetValid()
{
	i_valid = 1;
	return 0;
}

int maSequence :: SetInvalid()
{
	i_valid = 0;
	return 0;
}

int maSequence :: IsValid()
{
	return i_valid;
}

/*

Signature Oligo
Copyright (C) 2000-2008 Manuel Zahariev
mz@alumni.sfu.ca

This file is part of SigOli.

SigOli is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/
