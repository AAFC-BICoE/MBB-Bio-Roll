#define __amwList_cpp__

#include "amwList.h"

amwList :: amwList() :
	p_crt( NULL ),
	p_first( NULL ),
	p_last( NULL )
{
}

amwList :: ~amwList()
{
}

int amwList :: Append( amwObject* pWithObject )
{
	struct amwListElement* pel = new struct amwListElement;

	pel->p_object = pWithObject;
	pel->p_prev = p_last;
	pel->p_next = NULL;

	if( p_last )
		p_last->p_next = pel;
	else
	{
//	when appending the first element to a list, make it the current element
		p_first = pel;
		p_crt = pel;
	}

	p_last = pel;

	return 1;
}

int amwList :: Insert( amwObject* pWithObject )
{
	if( !p_first )
//	here if inserting into an empty list; same as Append
		return Append( pWithObject );

	if( !p_crt )
//	if there is no current element, treat this as an error
		return Error( 10001, "amwList::Error", "*** err-10001: null current element in a list" );

	struct amwListElement* pel = new struct amwListElement;

	pel->p_object = pWithObject;
	pel->p_prev = p_crt->p_prev;
	pel->p_next = p_crt;

	if( p_crt->p_prev )
		p_crt->p_prev->p_next = pel;
	else
//	when inserting before the first element into a list, make the new element
//	the first element in the list
		p_first = pel;

	p_crt->p_prev = pel;

	return 1;
}

amwObject* amwList :: Get()
{
	return p_crt->p_object;
}

amwObject* amwList :: Remove()
{
	amwObject*			poc = NULL;
	amwListElement*	plec = NULL;
	
	if( IsEmpty())
//	cannot remove from an empty list
		return NULL;

	if( !p_crt )
//	if there is no current element, treat this as an error
		Error( 10002, "amwList::Error", "*** err-10002: null current element in a list" );

	poc = p_crt->p_object;

	if( p_first == p_last )
	{
//	when removing the only element from a list
		delete p_crt;

		p_first = NULL;
		p_last = NULL;
		p_crt = NULL;

		return poc;
	}

	if( IsLast())
	{
//	when removing the last element of a list; the current element becomes the previous element
		p_last = p_last->p_prev;
		p_last->p_next = NULL;

		delete p_crt;
		p_crt = p_last;

		return poc;
	}

	if( IsFirst())
//	when removing the first element from a list, make the first element the next element
		p_first = p_first->p_next;
	else
//	when removing an element other than the first element, change the "next" of the "prev" element
		p_crt->p_prev->p_next = p_crt->p_next;

//	change the "prev" of the "next" element
	p_crt->p_next->p_prev = p_crt->p_prev;

	plec = p_crt->p_next;
	delete p_crt;

	p_crt = plec;

	return poc;
}

amwObject* amwList :: GetFirst()
{
	if( IsEmpty())
		return NULL;

	p_crt = p_first;
	return p_crt->p_object;
}

amwObject* amwList :: GetLast()
{
	if( IsEmpty())
		return NULL;

	p_crt = p_last;
	return p_crt->p_object;
}

amwObject* amwList :: GetNext()
{
	if( IsEmpty() || IsLast())
		return NULL;

	p_crt = p_crt->p_next;
	return p_crt->p_object;
}

amwObject* amwList :: GetPrev()
{
	if( IsEmpty() || IsFirst())
		return NULL;

	p_crt = p_crt->p_prev;
	return p_crt->p_object;
}

int	amwList :: IsEmpty()
{
	return ( p_first == NULL );
}

int	amwList :: IsFirst()
{
	return !IsEmpty() && ( p_crt == p_first );
}

int	amwList :: IsLast()
{
	return !IsEmpty() && ( p_crt == p_last );
}

int amwList :: Reverse()
{
	amwListElement* ptmp = NULL;
	amwListElement*	pcrt = p_crt;

	if( IsEmpty())
//	when reversing an empty list
		return 0;

	if( p_first == p_last )
//	when reversing a list with just 1 element
		return 1;
	
	GetFirst();
	do
	{
		ptmp = p_crt->p_next;
		p_crt->p_next = p_crt->p_prev;
		p_crt->p_prev = ptmp;

		p_crt = ptmp;
	} while( ptmp );

	p_crt = pcrt;

	ptmp = p_first;
	p_first = p_last;
	p_last = ptmp;

	return 2;
}

//	show all elements from the list first-to-last
int amwList :: Show()
{
	if( IsEmpty())
		return 0;
	
	GetFirst();

	while( 1 )
	{
//		Get()->Show();
		PrintLn( "" );

		if( IsLast())
			return 1;

		GetNext();
	}
}

int amwList :: Link( amwList* pToList )
{
	if( pToList->IsEmpty())
	{
//	link a list to an empty list
		delete pToList;
		return 0;
	}

	if( IsEmpty())
//	link an empty list to a non-empty list
		p_first = pToList->p_first;
	else
//	link a non-empty list to a non-empty list
		p_last->p_next = pToList->p_first;

	pToList->p_first->p_prev = p_last;

	p_last  = pToList->p_last;
	p_crt   = p_first;

	delete pToList;

	return 0;
}

int amwList :: Empty()
{
	if( IsEmpty())
		return 0;

	GetFirst();

	do{
		Remove();
	}while( GetNext());

	if( !IsEmpty())
		Remove();

	return 1;
}

/*

Signature Oligo
Copyright (C) 2000-2008 Manuel Zahariev
mz@alumni.sfu.ca

This file is part of SigOli.

SigOli is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/
