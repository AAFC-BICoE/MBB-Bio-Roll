#define __maGroup_cpp__

#include "maGroup.h"

maGroup :: maGroup( char* sFileName, char* sFilePath ) :
//	s_group_name( NULL ),
	i_crt_sequence( 0 ),
	i_sequence_count( 0 )
//	p_oligo_tree( NULL )
{
	DIR*						d = NULL;
	struct dirent*	e = NULL;

	maSubSequence*	ss = NULL;

	char						dn[ 256 ];
	char						fn[ 256 ];
	char						sn[ 256 ];

	int							i = 0;
/*
	s_group_name = new char[ strlen( sFileName ) + 1 ];
	strcpy( s_group_name, sFileName );
*/

	SetName( sFileName );
	SetFileName( sFileName );

//	open the directory of the group
	sprintf( dn, "%s/%s", sFilePath, GetName());

	d = opendir( dn );
	if( !d )
		Error( 10001, "error: cannot open directory", dn );

//	for each file in the directory
	for( i_sequence_count = 0 ; i_sequence_count < __MA_OLIGO_MAX_SEQUENCES__ ; )
	{
		e = readdir( d );

		if( !e ) break;

		if( strcmp( e->d_name, "." ) == 0 ) continue;
		if( strcmp( e->d_name, ".." ) == 0 ) continue;

		sprintf( fn, "%s/%s", dn, e->d_name );

//	create a sequence from the file
		a_sequences[ i_sequence_count ] = new maSequence( e->d_name, fn, this );

		i_sequence_count++;
	}

	if( i_sequence_count )
	{
//	borrow the name from the first sequence in the group
		sprintf( dn, "%s/%s", GetName(), a_sequences[ 0 ]->GetFileName());

		SetName( a_sequences[ 0 ]->GetName());
		SetFileName( dn );
	}

	closedir( d );
}

maGroup :: ~maGroup()
{
//	delete [] s_group_name;
}

maSequence* maGroup :: GetFirstSequence()
{
	i_crt_sequence = 0;
	
	return GetNextSequence();
}

maSequence* maGroup :: GetNextSequence()
{
	if( i_crt_sequence >= i_sequence_count )
		return NULL;

	return a_sequences[ i_crt_sequence++ ];
}

int maGroup :: GetCount()
{
	return i_sequence_count;
}

/*

Signature Oligo
Copyright (C) 2000-2008 Manuel Zahariev
mz@alumni.sfu.ca

This file is part of SigOli.

SigOli is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/
