#define __amwObject_cpp__

#include "amwObject.h"

amwApplication*	amwObject :: p_printer = NULL;
amwApplication*	amwObject :: p_error_display = NULL;

int amwObject :: Print( char* sString )
{
	if( p_printer )
		return p_printer->Print( sString );

	return 0;
}

int amwObject :: PrintLn( char* sString )
{
	if( p_printer )
		return p_printer->PrintLn( sString );

	return 0;
}

int amwObject :: Error( int iErrorCode, char* sCaption, char* sMessage )
{
	if( p_error_display )
		return p_error_display->Error( iErrorCode, sCaption, sMessage );

	return 0;
}


/*

Signature Oligo
Copyright (C) 2000-2008 Manuel Zahariev
mz@alumni.sfu.ca

This file is part of SigOli.

SigOli is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/
