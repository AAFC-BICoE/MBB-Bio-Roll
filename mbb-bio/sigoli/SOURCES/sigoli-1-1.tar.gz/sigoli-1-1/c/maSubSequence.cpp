#define __maSubSequence_cpp__

#include "maSubSequence.h"

const char maSubSequence :: A_nucleo_loop[ 16 ][ 16 ] =
{
//	0000 == 0
	{	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1 },

//	0001 == 1
	{	1,	1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1 },

//	0010 == 2
	{	2,	-1,	2,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1 },

//	0011 == 3
	{	1,	2,	2,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1 },

//	0100 == 4
	{	4,	-1,	-1,	-1,	4,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1 },

//	0101 == 5
	{	1,	4,	-1,	-1,	1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1 },

//	0110 == 6
	{	2,	-1,	4,	-1,	2,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1 },

//	0111 == 7
	{	1,	2,	4,	-1,	1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	-1 },

//	1000 == 8
	{	8,	-1,	-1,	-1,	-1,	-1,	-1,	-1,	8,	-1,	-1,	-1,	-1,	-1,	-1,	-1 },

//	1001 == 9
	{	1,	8,	-1,	-1,	-1,	-1,	-1,	-1,	1,	-1,	-1,	-1,	-1,	-1,	-1,	-1 },

//	1010 == 10
	{	2,	-1,	8,	-1,	-1,	-1,	-1,	-1,	2,	-1,	-1,	-1,	-1,	-1,	-1,	-1 },

//	1011 == 11
	{	1,	2,	8,	-1,	-1,	-1,	-1,	-1,	1,	-1,	-1,	-1,	-1,	-1,	-1,	-1 },

//	1100 == 12
	{	4,	-1,	-1,	-1,	8,	-1,	-1,	-1,	4,	-1,	-1,	-1,	-1,	-1,	-1,	-1 },

//	1101 == 13
	{	1,	4,	-1,	-1,	8,	-1,	-1,	-1,	1,	-1,	-1,	-1,	-1,	-1,	-1,	-1 },

//	1110 == 14
	{	2,	-1,	4,	-1,	8,	-1,	-1,	-1,	2,	-1,	-1,	-1,	-1,	-1,	-1,	-1 },

//	1111 == 15
	{	1,	2,	4,	-1,	8,	-1,	-1,	-1,	1,	-1,	-1,	-1,	-1,	-1,	-1,	-1 }
};

maSubSequence :: maSubSequence( char* sString, maSequence* pSequence, int iIndex, int iLength ) :
	s_sub_sequence_string( sString ),
	p_originator_sequence( pSequence ),
	p_originator_group( pSequence->GetGroup()),
	i_originator_group_sequence_count( 1 ),
	i_sequence_index( iIndex ),
	i_length( iLength ),
	i_crt_diff_index( 0 ),
	p_crt_diff( NULL ),
	p_crt_unambiguous( NULL ),
	i_disambiguated( 0 )
{
}

maSubSequence :: ~maSubSequence()
{
	delete s_sub_sequence_string;
}

maSubSequence :: maSubSequence( maSubSequence& rFromSubSequence ):
	p_originator_sequence( rFromSubSequence.p_originator_sequence ),

	p_originator_group( rFromSubSequence.p_originator_group ),
	i_originator_group_sequence_count( rFromSubSequence.i_originator_group_sequence_count ),
	i_sequence_index( rFromSubSequence.i_sequence_index ),
	i_length( rFromSubSequence.i_length ),

	i_crt_diff_index( 0 ),
	p_crt_diff( NULL ),
	p_crt_unambiguous( NULL ),
	i_disambiguated( 0 )
{
	s_sub_sequence_string = new char[ i_length ];
	memcpy( s_sub_sequence_string, rFromSubSequence.s_sub_sequence_string, i_length );
}

int maSubSequence :: operator== ( maSubSequence& rOtherElement )
{
	int	icounter = 0;

	char	ca = 0;
	char	cb = 0;

	if( i_length != rOtherElement.i_length )
		return 0;

	for( icounter = 0 ; icounter < i_length ; icounter++ )
	{
		ca = *( s_sub_sequence_string + icounter );
		cb = *( rOtherElement.s_sub_sequence_string + icounter );

		if( ca & cb )
			continue;

		return 0;
	}

	return 1;
}

int maSubSequence :: operator<= ( maSubSequence& rOtherElement )
{
	int	icounter = 0;

	char	ca = 0;
	char	cb = 0;

	int la = i_length;
	int	lb = rOtherElement.i_length;
	int	ll = 0;

	ll = ( la <= lb ) ? la : lb;

	for( icounter = 0 ; icounter < ll ; icounter++ )
	{
		ca = *( s_sub_sequence_string + icounter );
		cb = *( rOtherElement.s_sub_sequence_string + icounter );

		if( ca < cb )
			return 1;

		if( ca > cb )
			return 0;
	}

	if( la > ll )
		return 0;

	return 1;
}

int maSubSequence :: operator== ( amwElement& pOtherElement )
{
	return operator==(( maSubSequence& ) pOtherElement );
}

int maSubSequence :: operator<= ( amwElement& pOtherElement )
{
	return operator<=(( maSubSequence& ) pOtherElement );
}

int maSubSequence :: Mark( amwElement& rWithElement )
{
	return Mark(( maSubSequence& ) rWithElement );
}

int maSubSequence :: Mark( maSubSequence& rWithSubSequence )
{
	i_occurences++;

//	if the subsequence occured in the same sequence, ignore it
//	--this relies on the sequential addition of [subsequences from] sequences--
	if( rWithSubSequence.p_originator_sequence == p_originator_sequence )
		return 0;

//	if the subsequence occured in the same group, increase the number of hits in the group
	if( p_originator_group && ( rWithSubSequence.p_originator_sequence->GetGroup() == p_originator_group ))
	{
		i_originator_group_sequence_count++;
		return 0;
	}

//	everything else fails
	p_originator_group = NULL;
	p_originator_sequence = NULL;

	return 1;
}

int	maSubSequence :: Show()
{
	char	sdisplay[ 256 ];
	int		i = 0;

	if( !p_originator_sequence )
		return 0;

	for( i = 0 ; i < i_length ; i++ )
	{
		sprintf( sdisplay, "%c", CodeToNucleotide( *( s_sub_sequence_string + i )));

		Print( sdisplay );
	}

	PrintLn( "" );

	return i_length;
}

char maSubSequence :: NucleotideConvert( char cNucleotideSymbol )
{
	switch( cNucleotideSymbol )
	{
//	A A Adenine
		case 'A':
		case 'a':
			return 1;

//	C C Cytosine 
		case 'C':
		case 'c':
			return 2;

//	G G Guanine 
		case 'G':
		case 'g':
			return 4;

//	T T Thymine 
		case 'T':
		case 't':
			return 8;

//	R A or G puRine 
		case 'R':
		case 'r':
			return 5;

//	Y C or T pYrimidine 
		case 'Y':
		case 'y':
			return 10;

//	W A or T Weak hydrogen bonding 
		case 'W':
		case 'w':
			return 9;

//	S G or C Strong hydrogen bonding 
		case 'S':
		case 's':
			return 6;

//	M A or C aMino group at common position 
		case 'M':
		case 'm':
			return 3;

//	K G or T Keto group at common position 
		case 'K':
		case 'k':
			return 12;

//	H A, C or T not G 
		case 'H':
		case 'h':
			return 11;

//	B G, C or T not A 
		case 'B':
		case 'b':
			return 14;

//	V G, A, C not T 
		case 'V':
		case 'v':
			return 7;

//	D G, A or T not C 
		case 'D':
		case 'd':
			return 13;

//	N G, A, C or T aNy
		case 'N':
		case 'n':
			return 15;
	}

	Error( 10002, "maSubSequence :: NucleotideConvert", "cannot find nucleotide code" );

	return cNucleotideSymbol;
}

char maSubSequence :: CodeToNucleotide( char cNucleotideCode )
{
	switch( cNucleotideCode )
	{
		case 1:
//	A A Adenine
			return 'A';

		case 2:
//	C C Cytosine 
			return 'C';

		case 3:
//	M A or C aMino group at common position 
			return 'M';

		case 4:
//	G G Guanine 
			return 'G';

		case 5:
//	R A or G puRine 
			return 'R';

		case 6:
//	S G or C Strong hydrogen bonding 
			return 'S';

		case 7:
//	V G, A, C not T 
			return 'V';

		case 8:
//	T T Thymine 
			return 'T';

		case 9:
//	W A or T Weak hydrogen bonding 
			return 'W';

		case 10:
//	Y C or T pYrimidine 
			return 'Y';

		case 11:
//	H A, C or T not G 
			return 'H';

		case 12:
//	K G or T Keto group at common position 
			return 'K';

		case 13:
//	D G, A or T not C 
			return 'D';

		case 14:
//	B G, C or T not A 
			return 'B';

		case 15:
//	N G, A, C or T aNy
			return 'N';
	}
}


//	get methods
char* maSubSequence :: GetString()
{
	return s_sub_sequence_string;
}

int maSubSequence :: GetLength()
{
	return i_length;
}

maSequence* maSubSequence :: GetOriginatorSequence()
{
	return p_originator_sequence;
}

int maSubSequence :: GetSequenceIndex()
{
	return i_sequence_index;
}

int maSubSequence :: IsAmbiguous()
{
	int i = 0;

	for( i = 0 ; i < i_length ; i++ )
		if(
				(	s_sub_sequence_string[ i ] != 1 ) &&
				(	s_sub_sequence_string[ i ] != 2 ) &&
				(	s_sub_sequence_string[ i ] != 4 ) &&
				(	s_sub_sequence_string[ i ] != 8 )
			)
			return 1;

	return 0;
}

int maSubSequence :: IsDisambiguated()
{
	return i_disambiguated;
}

maSubSequence* maSubSequence :: GetFirstSmallDiff()
{
	p_crt_diff = new maSubSequence( *this );
	i_crt_diff_index = 0;

	p_crt_diff->s_sub_sequence_string[ i_crt_diff_index ] = 1;

	return p_crt_diff;
}

maSubSequence* maSubSequence :: GetNextSmallDiff()
{
	int i = 0;

	p_crt_diff->s_sub_sequence_string[ i_crt_diff_index ] <<= 1;

	if( p_crt_diff->s_sub_sequence_string[ i_crt_diff_index ] == s_sub_sequence_string[ i_crt_diff_index ])
//	will get here if the next subsequence with a small difference is the current subsequence
		return GetNextSmallDiff();

	if( p_crt_diff->s_sub_sequence_string[ i_crt_diff_index ] > 8 )
	{
		p_crt_diff->s_sub_sequence_string[ i_crt_diff_index ] = s_sub_sequence_string[ i_crt_diff_index ];

		if( i_crt_diff_index + 1 >= i_length )
//	will get here if there are no more subsequences with small differences
			return NULL;

		p_crt_diff->s_sub_sequence_string[ ++i_crt_diff_index ] = 1;

		if( p_crt_diff->s_sub_sequence_string[ i_crt_diff_index ] == s_sub_sequence_string[ i_crt_diff_index ])
//	will get here if the next subsequence with a small difference is the current subsequence
			return GetNextSmallDiff();
	}

	return p_crt_diff;
}

int maSubSequence :: GetGroupSequenceCount()
{
	return i_originator_group_sequence_count;
}

maGroup* maSubSequence :: GetOriginatorGroup()
{
	return p_originator_group;
}

maSubSequence* maSubSequence :: GetFirstUnambiguous()
{
	int	i = 0;

	i_unambiguous_count = GetUnambiguousCount();

	if( i_unambiguous_count <= 1 )
//	here if there are no unambiguous elements in the subsequence
		return NULL;

	p_crt_unambiguous = new maSubSequence( *this );
	p_crt_unambiguous->i_disambiguated = 1;

	for( i = 0 ; i < i_length ; i++ )
		p_crt_unambiguous->s_sub_sequence_string[ i ] = A_nucleo_loop[ s_sub_sequence_string[ i ]][ 0 ];

	return p_crt_unambiguous;
}

maSubSequence* maSubSequence :: GetNextUnambiguous()
{
	int		i = 0;

	char	ccrt = 0;
	char	cnext = 0;
	char	cfirst = 0;
	char	cbase = 0;
	
	if( !p_crt_unambiguous )
//	here it must be an error: not called after GetFirst
		return NULL;

//	if( ++i_crt_unambiguous_index > i_unambiguous_count )
//	here if the last unambiguous subsequence has already been
//	returned
//		return NULL;

	p_crt_unambiguous = new maSubSequence( *p_crt_unambiguous );
	p_crt_unambiguous->i_disambiguated = 1;

	for( i = 0 ; i < i_length ; i++ )
	{
		ccrt   = p_crt_unambiguous->s_sub_sequence_string[ i ];
		cbase  = s_sub_sequence_string[ i ];

		cfirst = A_nucleo_loop[ cbase ][ 0 ];
		cnext  = A_nucleo_loop[ cbase ][ ccrt ];

		if( cnext == ccrt )
//	will get here if the current nucleotide is unambiguous; go to the next
			continue;

		p_crt_unambiguous->s_sub_sequence_string[ i ] = cnext;

		if( cnext != cfirst )
//	will get here if the current nucleotide is ambiguous, has been changed and there is no "carry"
			return p_crt_unambiguous;

//	will get here if the current nucleotide is ambiguous, has been changed and there is "carry"
	}

//	will get here if all unambiguous subsequences have been exhausted
//	normally, the unambiguous count should have taken care of that -- that's why an error
//	should be generated
	delete p_crt_unambiguous;
//	Error( 10003, "maSubSequence :: GetNextUnambiguous", "no more unambiguous" );

	return NULL;
}

int maSubSequence :: GetUnambiguousCount()
{
	int		i = 0;
	char	s[ 16 ];
	int		iamb = 0;
	char	c = 0;

	i_unambiguous_count = 1;

	for( i = 0 ; i < i_length ; i++ )
	{
		c = s_sub_sequence_string[ i ];

		iamb =
			( c & 1 ) +
			(( c & 2 ) >> 1 ) +
			(( c & 4 ) >> 2 ) +
			(( c & 8 ) >> 3 );

		i_unambiguous_count *= iamb;
	}

	return i_unambiguous_count;
}

/*

Signature Oligo
Copyright (C) 2000-2008 Manuel Zahariev
mz@alumni.sfu.ca

This file is part of SigOli.

SigOli is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/
