#define __amwBinTree_cpp__

#include "amwBinTree.h"

amwBinTree :: amwBinTree( amwElement& rElement ) :
	p_left( NULL ),
	p_right( NULL ),
	p_up( NULL ),
	r_element( rElement ),
	i_score( 0 ),
	i_height( 1 )
{
}

amwBinTree :: amwBinTree( amwBinTree* pLeft, amwBinTree* pRight, amwElement& rElement ) :
	p_left( pLeft ),
	p_right( pRight ),
	r_element( rElement )
{
	int ihl = pLeft ? pLeft->i_height : 0;
	int ihr = pRight ? pRight->i_height : 0;

	i_height = ( ihl < ihr ) ? ihr : ihl;
	i_score = ihl - ihr;

	if( p_left ) p_left->p_up = this;
	if( p_right ) p_right->p_up = this;
}

amwBinTree :: ~amwBinTree()
{
	if( p_left ) delete p_left;
	if( p_right ) delete p_right;

	delete &r_element;
}

amwElement*	amwBinTree :: Find( amwElement& rElement )
{
	if( rElement == r_element )
		return &r_element;

	if( rElement <= r_element )
		if( p_left )
			return p_left->Find( rElement );
		else
			return NULL;

	if( p_right )
		return p_right->Find( rElement );

	return NULL;
}

amwBinTree* amwBinTree :: Insert( amwElement& rElement )
{
	if( rElement == r_element )
//	the element to be inserted is the current element
		return this;

	if( rElement <= r_element )
//	insert the element in the left subtree
		if( p_left )
			p_left = p_left->Insert( rElement );
		else
//	there's no left subtree -- create one
		{
			p_left = new amwBinTree( rElement );
			p_left->p_up = this;
		}
	else
//	insert the element in the right subtree
		if( p_right )
			p_right = p_right->Insert( rElement );
		else
//	there's no right subtree -- create one
		{
			p_right = new amwBinTree( rElement );
			p_right->p_up = this;
		}

	i_height = ((( p_left ? p_left->i_height : 0 ) >= ( p_right ? p_right->i_height : 0 )) ? ( p_left ? p_left->i_height : 0 ) : ( p_right ? p_right->i_height : 0 )) + 1;
	i_score = ( p_right ? p_right->i_height : 0 ) - ( p_left ? p_left->i_height : 0 );

	return Rebalance();
}

amwBinTree* amwBinTree :: Remove( amwElement& rElement )
{
//	not implemented yet
	return 0;
}

amwBinTree* amwBinTree :: InsertOrMark( amwElement& rElement )
{
	if( rElement == r_element )
	{
//	the element to be inserted is the current element
		Mark( rElement );

		return this;
	}

	if( rElement <= r_element )
//	insert the element in the left subtree
		if( p_left )
			p_left = p_left->InsertOrMark( rElement );
		else
//	will get here if there's no left subtree
//	in this case InsertOrMark is the same as Insert --> do Insert
			Insert( rElement );
	else
		if( p_right )
//	insert or mark the element in the right subtree
			p_right = p_right->InsertOrMark( rElement );
		else
//	will get here if there's no right subtree
//	in this case InsertOrMark is the same as Insert --> do Insert
			Insert( rElement );

	i_height = ((( p_left ? p_left->i_height : 0 ) >= ( p_right ? p_right->i_height : 0 )) ? ( p_left ? p_left->i_height : 0 ) : ( p_right ? p_right->i_height : 0 )) + 1;
	i_score = ( p_right ? p_right->i_height : 0 ) - ( p_left ? p_left->i_height : 0 );

	return Rebalance();
}

int amwBinTree :: Mark( amwElement& rElement )
{
	return r_element.Mark( rElement );
}

int amwBinTree :: Show()
{
	char	sdisplay[ 256 ];

	if( p_left ) p_left->Show();

	r_element.Show();

	if( p_right ) p_right->Show();

	return 1;
}

amwBinTree* amwBinTree :: Iterate( amwBinTree* pFromTree )
{
	amwBinTree*	pu = NULL;
	amwBinTree*	pr = NULL;

	if( !pFromTree )
//	start from the first element
		if( p_left )
			return p_left->Iterate( NULL );
		else
//	if you cannot go left, you're there
			return this;

	if( pFromTree->p_right )
//	if you can go rigth, do it:
//	same as finding the first element in the right tree
		return pFromTree->p_right->Iterate( NULL );

//	try to go higher returning on right branches
	pr = pFromTree;
	pu = pFromTree->p_up;

	while( pu )
	{
		if( pu->p_left == pr )
			return pu;

		pr = pu;
		pu = pu->p_up;
	}

	return NULL;
}

amwElement&	amwBinTree :: GetTopElement()
{
	return r_element;
}

amwBinTree* amwBinTree :: RebalanceRightA()
{
	amwBinTree*	pa = this;
	amwBinTree*	pb = p_right;

	amwBinTree*	palpha = p_left;
	amwBinTree*	pbeta  = p_right->p_left;
	amwBinTree*	pgamma = p_right->p_right;

//	rearrange nodes
	pa->p_left  = palpha;
	pa->p_right = pbeta;

	pb->p_left  = pa;
	pb->p_right = pgamma;

//	fix up links
	if( palpha ) palpha->p_up = pa;
	if( pbeta  )  pbeta->p_up = pa;
  if( pgamma ) pgamma->p_up = pb;		//	the "if" is redundant

	pb->p_up = pa->p_up;
	pa->p_up = pb;

//	recalculate heights
	pa->i_height = ( palpha ? palpha->i_height : 0 ) + 1;
	pa->i_score  = 0;

	pb->i_height = pgamma->i_height + 1;
	pb->i_score  = 0;

	return pb;
}

amwBinTree* amwBinTree :: RebalanceRightB()
{
	amwBinTree*	pa = this;
	amwBinTree*	pb = p_right;
	amwBinTree* pc = p_right->p_left;

//	rearrange nodes
	pb->p_right = NULL;
	pb->p_left  = NULL;

	pa->p_right = NULL;
	pa->p_left  = NULL;

	pc->p_right = pb;
	pc->p_left  = pa;

//	fix up links
	pc->p_up = pa->p_up;
	pa->p_up = pc;
	pb->p_up = pc;

//	recalculate heights
	pc->i_height = 2;
	pc->i_score  = 0;

	pb->i_height = 1;
	pb->i_score  = 0;

	pa->i_height = 1;
	pa->i_score  = 0;

	return pc;
}

amwBinTree* amwBinTree :: RebalanceRightC()
{
	amwBinTree*	pa = this;
	amwBinTree*	pb = p_right;
	amwBinTree*	pc = p_right->p_left;

	amwBinTree*	palpha = p_left;
	amwBinTree*	pbeta  = pc->p_left;
	amwBinTree*	pgamma = pc->p_right;
	amwBinTree*	pdelta = pb->p_right;
	
//	rearrange nodes
	pa->p_left  = palpha;
	pa->p_right = pbeta;

	pb->p_left  = pgamma;
	pb->p_right = pdelta;

	pc->p_left  = pa;
	pc->p_right = pb;

//	fix up links
	if( palpha ) palpha->p_up = pa;		//	the "if" is redundant
	if( pbeta  )  pbeta->p_up = pa;
	if( pgamma ) pgamma->p_up = pb;		//	the "if" is redundant
	if( palpha ) pdelta->p_up = pb;		//	the "if" is redundant

	pc->p_up = pa->p_up;
	pa->p_up = pc;
	pb->p_up = pc;

//	recalculate heights
	pa->i_height = palpha->i_height + 1;
	pa->i_score  = -1;

	pb->i_height = pdelta->i_height + 1;
	pb->i_score  = 0;

	pc->i_height = palpha->i_height + 2;
	pc->i_score  = 0;

	return pc;
}

amwBinTree* amwBinTree :: RebalanceRightD()
{
	amwBinTree*	pa = this;
	amwBinTree*	pb = p_right;
	amwBinTree*	pc = p_right->p_left;

	amwBinTree*	palpha = p_left;
	amwBinTree*	pbeta  = pc->p_left;
	amwBinTree*	pgamma = pc->p_right;
	amwBinTree*	pdelta = pb->p_right;

//	rearrange nodes
	pa->p_left  = palpha;
	pa->p_right = pbeta;

	pb->p_left  = pgamma;
	pb->p_right = pdelta;

	pc->p_left  = pa;
	pc->p_right = pb;

//	fix up links
	if( palpha ) palpha->p_up = pa;		//	the "if" is redundant
	if( pbeta  )  pbeta->p_up = pa;		//	the "if" is redundant
	if( pgamma ) pgamma->p_up = pb;
	if( palpha ) pdelta->p_up = pb;		//	the "if" is redundant

	pc->p_up = pa->p_up;
	pa->p_up = pc;
	pb->p_up = pc;

//	recalculate heights
	pa->i_height = palpha->i_height + 1;
	pa->i_score  = 0;

	pb->i_height = pdelta->i_height + 1;
	pb->i_score  = 1;

	pc->i_height = palpha->i_height + 2;
	pc->i_score  = 0;

	return pc;
}

//	mirror ReBalanceRightX

amwBinTree* amwBinTree :: RebalanceLeftA()
{
	amwBinTree*	pa = this;
	amwBinTree*	pb = p_left;

	amwBinTree*	palpha = p_right;
	amwBinTree*	pbeta  = p_left->p_right;
	amwBinTree*	pgamma = p_left->p_left;

//	rearrange nodes
	pa->p_right = palpha;
	pa->p_left  = pbeta;

	pb->p_right = pa;
	pb->p_left  = pgamma;

//	fix up links
	if( palpha ) palpha->p_up = pa;
	if( pbeta  )  pbeta->p_up = pa;
  if( pgamma ) pgamma->p_up = pb;		//	the "if" is redundant

	pb->p_up = pa->p_up;
	pa->p_up = pb;

//	recalculate heights
	pa->i_height = ( palpha ? palpha->i_height : 0 ) + 1;
	pa->i_score  = 0;

	pb->i_height = pgamma->i_height + 1;
	pb->i_score  = 0;

	return pb;
}

amwBinTree* amwBinTree :: RebalanceLeftB()
{
	amwBinTree*	pa = this;
	amwBinTree*	pb = p_left;
	amwBinTree* pc = p_left->p_right;

//	rearrange nodes
	pb->p_left  = NULL;
	pb->p_right = NULL;

	pa->p_left  = NULL;
	pa->p_right = NULL;

	pc->p_left  = pb;
	pc->p_right = pa;

//	fix up links
	pc->p_up = pa->p_up;
	pa->p_up = pc;
	pb->p_up = pc;

//	recalculate heights
	pc->i_height = 2;
	pc->i_score  = 0;

	pb->i_height = 1;
	pb->i_score  = 0;

	pa->i_height = 1;
	pa->i_score  = 0;

	return pc;
}

amwBinTree* amwBinTree :: RebalanceLeftC()
{
	amwBinTree*	pa = this;
	amwBinTree*	pb = p_left;
	amwBinTree*	pc = p_left->p_right;

	amwBinTree*	palpha = p_right;
	amwBinTree*	pbeta  = pc->p_right;
	amwBinTree*	pgamma = pc->p_left;
	amwBinTree*	pdelta = pb->p_left;
	
//	rearrange nodes
	pa->p_right = palpha;
	pa->p_left  = pbeta;

	pb->p_right = pgamma;
	pb->p_left  = pdelta;

	pc->p_right = pa;
	pc->p_left  = pb;

//	fix up links
	if( palpha ) palpha->p_up = pa;		//	the "if" is redundant
	if( pbeta  )  pbeta->p_up = pa;
	if( pgamma ) pgamma->p_up = pb;		//	the "if" is redundant
	if( palpha ) pdelta->p_up = pb;		//	the "if" is redundant

	pc->p_up = pa->p_up;
	pa->p_up = pc;
	pb->p_up = pc;

//	recalculate heights
	pa->i_height = palpha->i_height + 1;
	pa->i_score  = 1;

	pb->i_height = pdelta->i_height + 1;
	pb->i_score  = 0;

	pc->i_height = palpha->i_height + 2;
	pc->i_score  = 0;

	return pc;
}

amwBinTree* amwBinTree :: RebalanceLeftD()
{
	amwBinTree*	pa = this;
	amwBinTree*	pb = p_left;
	amwBinTree*	pc = p_left->p_right;

	amwBinTree*	palpha = p_right;
	amwBinTree*	pbeta  = pc->p_right;
	amwBinTree*	pgamma = pc->p_left;
	amwBinTree*	pdelta = pb->p_left;

//	rearrange nodes
	pa->p_right = palpha;
	pa->p_left  = pbeta;

	pb->p_right = pgamma;
	pb->p_left  = pdelta;

	pc->p_right = pa;
	pc->p_left  = pb;

//	fix up links
	if( palpha ) palpha->p_up = pa;		//	the "if" is redundant
	if( pbeta  )  pbeta->p_up = pa;		//	the "if" is redundant
	if( pgamma ) pgamma->p_up = pb;
	if( palpha ) pdelta->p_up = pb;		//	the "if" is redundant

	pc->p_up = pa->p_up;
	pa->p_up = pc;
	pb->p_up = pc;

//	recalculate heights
	pa->i_height = palpha->i_height + 1;
	pa->i_score  = 0;

	pb->i_height = pdelta->i_height + 1;
	pb->i_score  = -1;

	pc->i_height = palpha->i_height + 2;
	pc->i_score  = 0;

	return pc;
}

amwBinTree* amwBinTree :: Rebalance()
{
	if( i_score == 2 )
	{
//	rebalance tree
		if( p_right->i_score == 1 )
			return RebalanceRightA();

		if(( p_right->i_score == -1 ) && ( p_right->p_left->i_score == 0 ))
			return RebalanceRightB();

		if(( p_right->i_score == -1 ) && ( p_right->p_left->i_score == 1 ))
			return RebalanceRightC();

		if(( p_right->i_score == -1 ) && ( p_right->p_left->i_score == -1 ))
			return RebalanceRightD();

		Error( 10004, "Rebalance R", "Unknown case" );
		return NULL;
	}

	if( i_score == -2 )
	{
//	rebalance tree
		if( p_left->i_score == -1 )
			return RebalanceLeftA();

		if(( p_left->i_score == 1 ) && ( p_left->p_right->i_score == 0 ))
			return RebalanceLeftB();

		if(( p_left->i_score == 1 ) && ( p_left->p_right->i_score == -1 ))
			return RebalanceLeftC();

		if(( p_left->i_score == 1 ) && ( p_left->p_right->i_score == 1 ))
			return RebalanceLeftD();

		Error( 10005, "Rebalance L", "Unknown case" );
		return NULL;
	}

//	will get here if no rebalancing needs to be done
	return this;
}

/*

Signature Oligo
Copyright (C) 2000-2008 Manuel Zahariev
mz@alumni.sfu.ca

This file is part of SigOli.

SigOli is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/
