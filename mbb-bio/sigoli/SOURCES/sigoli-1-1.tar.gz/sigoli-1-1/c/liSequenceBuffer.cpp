#define __liSequenceBuffer_cpp__

#include "maSequence.h"

#include "liSequenceBuffer.h"

static maSequence*	p_sequence = NULL;

int liSequenceSetSequence( maSequence* pWithSequence )
{
	p_sequence = pWithSequence;

	return 0;
}

int liSequenceSetName( char* sWithName )
{
	if( !p_sequence )
		return 0;

	return p_sequence->SetName( sWithName );
}

int liSequenceAddString( char* sWithString )
{
	if( !p_sequence )
		return 0;

	return p_sequence->AddString( sWithString );
}

int liSequenceSetString( char* sWithString )
{
	if( !p_sequence )
		return 0;

	return p_sequence->SetString( sWithString );
}

int liSequenceSetValid()
{
	if( !p_sequence )
		return 0;

	return p_sequence->SetValid();
}

int liSequenceSetInvalid()
{
	if( !p_sequence )
		return 0;

	return p_sequence->SetInvalid();
}

int liSequenceError( char* sWithErrorMessage )
{
//	for debug purposes only
//	printf( "%s: %s\n", p_sequence->GetFileName(), "sequence file corrupt" );

	return 0;
}

/*

Signature Oligo
Copyright (C) 2000-2008 Manuel Zahariev
mz@alumni.sfu.ca

This file is part of SigOli.

SigOli is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/
