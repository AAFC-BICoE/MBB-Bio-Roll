#ifndef XZ_CONFIG_H
#define XZ_CONFIG_H

typedef unsigned long mlong;
const char XZ_VERSION[]="4.2.1";
//4.2.1 default turn on subtraction
//4.2,  compatible for GCC 4.3
//4.1,  fix bug for large K (K>15)

#endif

