int  DoQuit (void);
void GetTimeSeed (void);
int	 InitializeMrBayes (void);
int  ReinitializeMrBayes (void);
void SetCode (int part);
