int      DoPlot (void);
int      DoPlotParm (char *parmName, char *tkn);
