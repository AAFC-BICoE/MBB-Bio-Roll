char version[]="$Id: mb.c,v 1.3 2011/07/07 Exp $";
const char* const svnRevisionMbC="$Rev: 417 $";   /* Revision keyword which is expended/updated by svn on each commit/update*/
