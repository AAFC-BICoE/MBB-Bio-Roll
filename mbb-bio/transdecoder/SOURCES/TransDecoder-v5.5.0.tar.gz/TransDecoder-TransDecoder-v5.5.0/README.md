# TransDecoder

Visit the project [wiki](https://github.com/TransDecoder/TransDecoder/wiki) for all TransDecoder documentation.


