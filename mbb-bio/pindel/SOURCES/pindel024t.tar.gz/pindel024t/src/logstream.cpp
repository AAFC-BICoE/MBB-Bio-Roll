#include "logstream.h"

std::ostream* logStream;
