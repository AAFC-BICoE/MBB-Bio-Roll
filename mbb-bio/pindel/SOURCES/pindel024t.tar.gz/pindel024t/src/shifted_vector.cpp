#include "shifted_vector.h"

#include <iostream>
#include <vector>
#include <stdlib.h>



