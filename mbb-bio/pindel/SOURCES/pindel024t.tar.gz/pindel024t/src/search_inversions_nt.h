#ifndef SEARCH_INVERSIONS_NT_H
#define	SEARCH_INVERSIONS_NT_H

int searchInversionsNT(ControlState& currentState, unsigned NumBoxes, const SearchWindow& currentWindow);
#endif /* SEARCH_INVERSIONS_NT_H */
