#ifndef SEARCH_INDELS_H
#define	SEARCH_INDELS_H

int searchIndels(ControlState& currentState, unsigned NumBoxes, const SearchWindow& currentWindow);
#endif /* SEARCH_INDELS_H */
