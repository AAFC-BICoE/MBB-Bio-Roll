#ifndef SEARCH_TANDEM_DUPLICATIONS_H
#define	SEARCH_TANDEM_DUPLICATIONS_H

int searchTandemDuplications(ControlState& currentState, unsigned NumBoxes, const SearchWindow& currentWindow);
#endif /* SEARCH_TANDEM_DUPLICATIONS_H */
