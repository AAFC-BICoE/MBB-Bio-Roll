#ifndef LOGSTREAM_H
#define LOGSTREAM_H

#include <iostream>

extern std::ostream* logStream;

#endif
