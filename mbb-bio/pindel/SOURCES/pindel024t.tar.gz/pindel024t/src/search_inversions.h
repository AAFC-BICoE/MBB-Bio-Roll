#ifndef SEARCH_INVERSIONS_H
#define	SEARCH_INVERSIONS_H

int searchInversions(ControlState& currentState, unsigned NumBoxes, const SearchWindow& currentWindow);
#endif /* SEARCH_INVERSIONS_H */
