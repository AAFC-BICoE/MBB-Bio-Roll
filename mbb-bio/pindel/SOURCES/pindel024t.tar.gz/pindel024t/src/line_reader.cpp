
#include "line_reader.h"


LineReader::LineReader()
{
}


LineReader::~LineReader()
{
}