#ifndef SEARCH_TANDEM_DUPLICATIONS_NT_H
#define	SEARCH_TANDEM_DUPLICATIONS_NT_H

int searchTandemDuplicationsNT(ControlState& currentState, unsigned NumBoxes, const SearchWindow& currentWindow);
#endif /* SEARCH_TANDEM_DUPLICATIONS_NT_H */
