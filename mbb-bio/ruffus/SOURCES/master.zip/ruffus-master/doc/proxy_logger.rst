.. include:: global.inc
#####################
ruffus.proxy_logger
#####################

.. _proxy-logger:

.. automodule:: ruffus.proxy_logger
      :undoc-members:
      

===========================
Proxies for a log:
===========================

.. autofunction:: make_shared_logger_and_proxy

===========================
Create a logging object
===========================


.. autofunction:: setup_std_shared_logger

