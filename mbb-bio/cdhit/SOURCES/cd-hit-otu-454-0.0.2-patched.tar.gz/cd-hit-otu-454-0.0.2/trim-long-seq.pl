#!/usr/bin/perl

use Getopt::Std;

getopts("i:o:p:",\%opts);
die usage() unless ($opts{i} and $opts{o} and $opts{p});

my $fasta      = $opts{i};
my $output     = $opts{o};
my $cutoff     = $opts{p};

my $des = "";
my $len1;
my $seq = "";
my $cutoff_len;

open(TMP, $fasta) || die "can not open $fasta\n";
open(OUT, ">$output") || die "can not write to $output\n";
while($ll=<TMP>){
  if ($ll =~ /^>/){
    if ($seq) {
      $len1 = length($seq);
      if ($cutoff < 1 ) {$cutoff_len = int($len1 * $cutoff); }
      else              {$cutoff_len = $cutoff; }
      if ($len1 > $cutoff_len) { $seq = substr($seq,0,$cutoff_len); }
      print OUT $des,$seq,"\n";
    }
    $des = $ll;
    $seq = "";
  }
  else {
    $ll =~ s/\s//g;
    $seq = $seq . $ll;
  } 
}
    if ($seq) {
      $len1 = length($seq);
      if ($cutoff < 1 ) {$cutoff_len = int($len1 * $cutoff); }
      else              {$cutoff_len = $cutoff; }
      if ($len1 > $cutoff_len) { $seq = substr($seq,0,$cutoff_len); }
      print OUT $des,$seq,"\n";
    }

close(TMP);
close(OUT);


sub usage {
<<EOD

Usage $0 -i fasta-file-of-raw-reads -o output -p cutoff

        lenght-cutoff-lower-fraction default 0.8

This script trims tails of sequences
       if cutoff is a integer number (like 200), the program will trim sequences to this length
       if cutoff is a fraction (like 0.8), the program will keep fraction of this reads

EOD
}
######### END usage
