#!/usr/bin/perl

my $total_score = 0;
my $total_base = 0;
my $n = 0;
my $total_worst = 0;

my $worst;
my $readin = 0;
while($ll=<>){
  if ($ll =~ /^>/){
    if ($readin) {
      $total_worst += $worst;
    }
    $n++;
    $worst = 99999999;
  }
  else {
    chop ($ll);
    $readin=1;
    my @lls = split(/\s+/,$ll);
    foreach $i (@lls) {
      $total_score += $i;
      $total_base ++;
      $worst = $i if ($i < $worst);
    }
  }
}
    if ($readin) {
      $total_worst += $worst;
    }

my $ave = $total_score / $total_base;
my $e = 1 / (10 ** ($ave/10));

my $avew = $total_worst / $n;
my $ew = 1 / (10 ** ($avew/10));

print <<EOD;
total seq: $n
total score: $total_score
total base: $total_base
average: $ave
error: $e


total worst: $total_worst
average worst: $avew
error worst: $ew
EOD


