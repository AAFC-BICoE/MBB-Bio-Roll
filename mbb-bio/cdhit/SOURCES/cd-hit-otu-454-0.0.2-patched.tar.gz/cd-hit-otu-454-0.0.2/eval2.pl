#!/usr/bin/perl

my $ref = shift; #fasta of reference 
my $raw = shift; #raw reads
my $otu = shift; #otu
my $dup = shift;

my $script_name = $0;
my $script_dir = $0;
   $script_dir =~ s/[^\/]+$//;
   chop($script_dir);
   $script_dir = "./" unless ($script_dir);

my $cmd;

#recruit
my $z = "$raw.eval";
my $t1 = "$z-ref-vs-raw";
#$cmd = `$script_dir/cd-hit/cd-hit-est-2d -i $ref -i2 $raw -o $t1 -c 0.97 -n 10 -p 1 -d 0 -g 1 -G 0 -aS 0.8 -b 5 -s2 0.8 > $t1.log`;
$cmd = `$script_dir/cd-hit/cd-hit-est-2d -i $ref -i2 $raw -o $t1 -c 0.97 -n 10 -p 1 -d 0 -g 1 -G 0 -aS 0.8 -b 5 -s2 0.8 > $t1.log`;
my $ref_seq_no = `grep -c "^>" $ref`;            $ref_seq_no =~ s/\D//g;
my $seq_in_clstr = `grep -cv "^>" $t1.clstr`;    $seq_in_clstr =~ s/\D//g;
my $raw_in_clstr = $seq_in_clstr - $ref_seq_no;
my $cutoff = int($raw_in_clstr * 0.0001 + 0.5);
   $cutoff++;
$cmd = `$script_dir/clstr_select_rep.pl size $cutoff 99999999 < $t1.clstr > $t1-ref.ids`;
$cmd = `$script_dir/fetch_fasta_by_ids.pl $t1-ref.ids $ref > $t1-ref.fa`;
$cmd = `$script_dir/cd-hit/cd-hit-est-2d -i $otu -i2 $t1-ref.fa -o $z-calc-vs-ref -c 0.97 -n 10 -p 1 -d 0 -g 1 -G 0 -b 5 -s2 0.1 -A 150 > $z-calc-vs-ref.log`;
if (-s "$z-calc-vs-ref") {
  $cmd = `$script_dir/cd-hit/cd-hit-est -i $z-calc-vs-ref -o $z-calc-vs-ref-2 -c 0.97 -n 10 -p 1 -d 0 -g 1 -G 0 -aS 0.8 -b 5 > $z-calc-vs-ref-2.log`;
  $cmd = `cat $z-calc-vs-ref-2.clstr >> $z-calc-vs-ref.clstr`;
}

my %ref_ids = ();
open(TMP, $ref) || die;
while($ll=<TMP>){
  if ($ll =~ /^>/){
    $gi = substr($ll,1);
    chop($gi);
    $gi =~ s/\s.+$//;
    $ref_ids{$gi}=1;
  }
}
close(TMP);

my $no_ref=0;
my $no_data=0;
my $clstr_good = 0;
my $clstr_noise = 0;
my $clstr_missed = 0;
my @noise_ids = ();
my @missed_ids = ();
my $rep_id;

#open(TMP, "$t2-OTU.all.clstr") || die;
open(TMP, "$z-calc-vs-ref.clstr") || die;
while($ll=<TMP>){
  if ($ll =~ /^>/) {
    if ($no_ref or $no_data) {
      if (($no_ref>0) and ($no_data>0)) {$clstr_good++;}
      elsif ($no_ref>0) {$clstr_missed++;push(@missed_ids,$rep_id);}
      else              {$clstr_noise++; push(@noise_ids, $rep_id);}
    }
    $no_ref=0;
    $no_data=0;
    $rep_id="";
  }
  else {
    chop($ll);
    if ($ll =~ /(\d+)(aa|nt), >(.+)\.\.\./) {
      my $gi = $3;
      if ($ref_ids{$gi}) {$no_ref++;}
      else {$no_data++}
      if ($ll =~ /\*$/) {$rep_id=$gi;}
    }
  }
}
    if ($no_ref or $no_data) {
      if (($no_ref>0) and ($no_data>0)) {$clstr_good++;}
      elsif ($no_ref>0) {$clstr_missed++;push(@missed_ids,$rep_id);}
      else              {$clstr_noise++; push(@noise_ids, $rep_id);}
    }

close(TMP);

my $ref_otu = $clstr_good + $clstr_missed;
my $data_otu = $clstr_good + $clstr_noise;
my $sensitivity = int($clstr_good / $ref_otu*100)/100;
my $specificity = int($clstr_good / $data_otu*100)/100;

print "ref-otu\tpred-otu\tgood\tmissed\tnoise\tsensitivity\tspecificity\n";
print "$ref_otu\t$data_otu\t$clstr_good\t$clstr_missed\t$clstr_noise\t$sensitivity\t$specificity\n";

if (@noise_ids) {
  open(OUT, ">$z-noise.ids") || die;
  foreach $i (@noise_ids) {print OUT "$i\n";}
  close(OUT);
  $cmd = `$script_dir/fetch_fasta_by_ids.pl $z-noise.ids $otu > $z-noise.fa`;
  $cmd = `formatdb -i $dup -p F`;
  $cmd = `blastall -p blastn -b 250 -v 250 -d $dup -i $z-noise.fa -o $z-noise-bl-dup`;
  $cmd = `formatdb -i $ref -p F`;
  $cmd = `blastall -p blastn -b 250 -v 250 -d $ref -i $z-noise.fa -o $z-noise-bl-ref`;
  print "check noise reads at $z-noise-bl-dup & $z-noise-bl-ref\n";
}


