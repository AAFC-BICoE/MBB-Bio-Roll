module load compilers/gcc/4.4.2 mpi/openmpi/1.4.3_gcc
