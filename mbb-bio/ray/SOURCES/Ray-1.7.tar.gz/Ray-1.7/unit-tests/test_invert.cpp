#include <unit-tests/unitTest.h>
#include <core/common_functions.h>
#include <stdint.h>
#include <iostream>
using namespace std;

/** invertEdges was removed */
int main(){
	return 0;
}
