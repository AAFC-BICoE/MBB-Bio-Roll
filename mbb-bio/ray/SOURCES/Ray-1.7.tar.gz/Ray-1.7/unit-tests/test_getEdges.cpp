#include <unitTest.h>
#include <Kmer.h>
#include <common_functions.h>
#include <assert.h>
#include <string>
#include <iostream>
using namespace std;

int main(int argc,char**argv){

	return 0;
}
