g++ test_peakFinder.cpp ../code/pairs/LibraryPeakFinder.cpp -I ../code/ -o peaks

