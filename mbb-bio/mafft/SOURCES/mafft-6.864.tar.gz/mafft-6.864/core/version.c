#include "mltaln.h"

main()
{
	fprintf( stdout, VERSION"\n" );
}
