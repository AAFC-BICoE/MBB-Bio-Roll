#!/bin/bash

$TRINITY_HOME/Analysis/FL_reconstruction_analysis/FL_trans_analysis_pipeline.pl $*
