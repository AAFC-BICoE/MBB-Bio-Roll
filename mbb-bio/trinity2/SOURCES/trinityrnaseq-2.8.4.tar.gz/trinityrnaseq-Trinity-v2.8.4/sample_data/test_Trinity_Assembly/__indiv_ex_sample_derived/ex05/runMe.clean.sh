#!/bin/sh
../../../../Trinity.pl --seqType fq --left clean.left.fq --right clean.right.fq --seqType fq --JM 1G --bfly_opts "-V 15 --stderr "
