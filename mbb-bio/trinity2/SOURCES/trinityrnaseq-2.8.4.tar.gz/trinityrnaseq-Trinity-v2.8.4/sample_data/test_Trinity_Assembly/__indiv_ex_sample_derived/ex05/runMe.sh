#!/bin/sh
../../../../Trinity.pl --seqType fq --left ex5.reads.left.fq --right ex5.reads.right.fq --seqType fq --JM 1G --bfly_opts "-V 15 --stderr"
