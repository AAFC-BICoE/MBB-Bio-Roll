trinityrnaseq
=============

[![Build Status](https://travis-ci.org/trinityrnaseq/trinityrnaseq.svg?branch=master)](https://travis-ci.org/trinityrnaseq/trinityrnaseq)
[![install with bioconda](https://img.shields.io/badge/install%20with-bioconda-brightgreen.svg?style=flat-square)](https://bioconda.github.io/recipes/trinity/README.html)

Trinity RNA-Seq de novo transcriptome assembly see the main webpage [http://trinityrnaseq.github.io](http://trinityrnaseq.github.io)
