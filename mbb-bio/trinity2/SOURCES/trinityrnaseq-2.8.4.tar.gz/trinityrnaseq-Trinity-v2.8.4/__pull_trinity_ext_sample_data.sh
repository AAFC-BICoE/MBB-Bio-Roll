#!/bin/bash

set -ve

git submodule init trinity_ext_sample_data

git submodule update trinity_ext_sample_data
