
public class PathOverlap {

	int match_score;
	int match_length;
	
	public PathOverlap(int score, int length) {
		this.match_score = score;
		this.match_length = length;
	}
	
}
