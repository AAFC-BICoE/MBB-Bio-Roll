## documentation stub (to be completed very soon!)

trinityrnaseq/Analysis/DifferentialExpression/TissueEnrichment/DE_results_to_pairwise_summary.pl transcripts.TMM.fpkm.avg_reps.matrix . > DE.pairwise_summary

trinityrnaseq/Analysis/DifferentialExpression/TissueEnrichment/pairwise_DE_summary_to_DE_classification.pl DE.pairwise_summary
