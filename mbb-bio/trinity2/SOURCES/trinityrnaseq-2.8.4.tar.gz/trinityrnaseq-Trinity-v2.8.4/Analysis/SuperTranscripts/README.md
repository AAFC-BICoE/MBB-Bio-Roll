SuperTranscript developments here are based on work published by Davidson et al:

SuperTranscripts: a data driven reference for analysis and visualisation of transcriptomes
Genome Biology2017

https://genomebiology.biomedcentral.com/articles/10.1186/s13059-017-1284-1

