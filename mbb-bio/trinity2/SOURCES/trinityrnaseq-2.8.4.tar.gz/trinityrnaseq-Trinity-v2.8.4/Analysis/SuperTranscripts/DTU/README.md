Exploring Differential Transcript Usage (DTU) in the context of SuperTranscripts
