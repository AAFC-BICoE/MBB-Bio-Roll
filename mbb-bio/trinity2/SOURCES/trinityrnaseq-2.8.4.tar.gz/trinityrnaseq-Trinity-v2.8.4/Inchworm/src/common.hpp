#ifndef __COMMON__
#define __COMMON__

extern unsigned int DEBUG_LEVEL;

#endif

