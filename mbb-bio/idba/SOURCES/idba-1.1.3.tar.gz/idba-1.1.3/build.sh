aclocal
autoconf
automake --add-missing
./configure
make clean 
make -j
