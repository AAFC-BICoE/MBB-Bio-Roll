
/*
class doublestream {

	public:
	doublestream(const char* name)	{
		os = new ofstream(name);
	}

	~doublestream()	{
		delete os;
		os = 0;
	}

	void flush()	{
		os->flush();
	}

	void close()	{
		os->close();
	}
	
	template<class T> doublestream& operator<<(const T& t)	{
		(*os) << t;
		cout << t;
		return *this;
	}

	private:
	ofstream* os;

};
*/
