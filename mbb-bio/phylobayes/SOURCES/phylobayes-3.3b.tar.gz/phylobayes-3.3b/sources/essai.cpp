#include "iostream"
#include "cstdlib"

using namespace std;

/*
class init	{

	public:

	init()	{
		cerr << '\n';
		cerr << "before main\n";
	}

};

static init i;
*/

int main()	{
	cerr << "hello\n";
}

