
int IsInt(string s);
int IsFloat(string s);

int Int(string s);
double Double(string s);

int EmptyLine(string s);
int IsDigit(char c);
string StringReplace(char c, string by, string s);
string Filter(string input, char c);

